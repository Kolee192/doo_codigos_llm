import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Entry {
    private String title;
    private String username;
    private String password;
    private String url;
    private String notes;
    private Group group;

    public Entry(String title, String username, String password, String repeatPassword, String url, String notes, Group group) {
        if (group == null) {
            throw new IllegalStateException("An entry must belong to a group to be created (REQ-11).");
        }
        validatePasswords(password, repeatPassword);
        this.title = title != null ? title : "";
        this.username = username != null ? username : "";
        this.password = password != null ? password : "";
        this.url = url != null ? url : "";
        this.notes = notes != null ? notes : "";
        this.group = group;
        group.addEntry(this);
    }

    protected void validatePasswords(String password, String repeatPassword) {
        if (password != null && !password.isEmpty()) {
            if (repeatPassword == null || repeatPassword.isEmpty()) {
                throw new IllegalArgumentException("When the password field is completed the repeat password field must be completed (REQ-12).");
            }
            if (!password.equals(repeatPassword)) {
                throw new IllegalArgumentException("Password field and repeat password field must be identical (REQ-13).");
            }
        }
    }

    public void setPassword(String password, String repeatPassword) {
        if (repeatPassword == null || !repeatPassword.equals(password)) {
            throw new IllegalArgumentException("When the password field is changed the repeat password field must be changed and be identical with password field (REQ-15).");
        }
        this.password = password;
    }

    public String extractAutoTypeSequence() {
        if (notes == null || notes.isEmpty()) {
            return null;
        }

        Pattern pattern = Pattern.compile("(?m)^Auto-Type:(.*)$");
        Matcher matcher = pattern.matcher(notes);
        if (matcher.find()) {
            String fullLine = matcher.group(0).trim();
            if (fullLine.length() > 59) {
                throw new IllegalArgumentException("Sequence's length must not be more than a line (59 characters) (REQ-20).");
            }
            return fullLine;
        }
        return null;
    }

    public boolean matchesWord(String word) {
        if (word == null || word.isEmpty()) {
            return false;
        }
        String lower = word.toLowerCase();
        return (title != null && title.toLowerCase().contains(lower))
                || (username != null && username.toLowerCase().contains(lower))
                || (password != null && password.toLowerCase().contains(lower))
                || (url != null && url.toLowerCase().contains(lower))
                || (notes != null && notes.toLowerCase().contains(lower));
    }

    public Entry copy(Group targetGroup) {
        return new Entry(this.title + " (Copy)", this.username, this.password, this.password, this.url, this.notes, targetGroup);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    @Override
    public String toString() {
        return "Entry{" +
                "title='" + title + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", url='" + url + '\'' +
                ", notes='" + notes + '\'' +
                '}';
    }
}
