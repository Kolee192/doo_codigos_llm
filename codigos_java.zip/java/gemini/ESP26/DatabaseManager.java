import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class DatabaseManager {
    private final Map<String, Database> databaseRegistry;

    public DatabaseManager() {
        this.databaseRegistry = new HashMap<>();
    }

    public Database registerDatabase(Database db) {
        if (db == null) {
            throw new IllegalArgumentException("Database cannot be null.");
        }
        databaseRegistry.put(db.getFileName(), db);
        return db;
    }

    public Database getDatabase(String fileName) {
        return databaseRegistry.get(fileName);
    }

    public boolean hasDatabase(String fileName) {
        return databaseRegistry.containsKey(fileName);
    }

    public int getDatabaseCount() {
        return databaseRegistry.size();
    }

    public Map<String, Database> getDatabases() {
        return Collections.unmodifiableMap(databaseRegistry);
    }
}
