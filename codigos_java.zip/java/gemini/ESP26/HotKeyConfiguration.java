public final class HotKeyConfiguration {
    public static final String GLOBAL_HOT_KEY = "Ctrl+Alt+A";

    private HotKeyConfiguration() {
    }

    public static String getGlobalHotKey() {
        return GLOBAL_HOT_KEY;
    }

    public static void setGlobalHotKey(String newHotKey) {
        throw new UnsupportedOperationException("Global hot key cannot be changed (REQ-31).");
    }
}
