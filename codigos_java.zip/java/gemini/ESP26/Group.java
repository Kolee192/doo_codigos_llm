import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Group {
    private String name;
    private final Group parent;
    private final List<Group> subgroups;
    private final List<Entry> entries;

    public Group(String name, Group parent) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("A name is required in order for the new group/subgroup to be created (REQ-7).");
        }
        this.name = name.trim();
        this.parent = parent;
        this.subgroups = new ArrayList<>();
        this.entries = new ArrayList<>();
        if (parent != null) {
            parent.subgroups.add(this);
        }
    }

    public static Group createRootGroup(String name) {
        return new Group(name, null);
    }

    public Group createSubgroup(String name) {
        return new Group(name, this);
    }

    public void rename(String newName) {
        if (newName == null || newName.trim().isEmpty()) {
            throw new IllegalArgumentException("A name is required in order for the group/subgroup to be renamed (REQ-9).");
        }
        this.name = newName.trim();
    }

    public void addEntry(Entry entry) {
        if (entry != null && !entries.contains(entry)) {
            entries.add(entry);
        }
    }

    public boolean removeEntry(Entry entry) {
        return entries.remove(entry);
    }

    public List<Entry> findInGroup(String word) {
        if (word == null || word.trim().isEmpty()) {
            throw new IllegalArgumentException("In order to find something in a group a word must be placed in the find field (REQ-10).");
        }
        List<Entry> results = new ArrayList<>();
        for (Entry entry : entries) {
            if (entry.matchesWord(word)) {
                results.add(entry);
            }
        }
        for (Group sub : subgroups) {
            results.addAll(sub.findInGroup(word));
        }
        return results;
    }

    public List<Entry> getAllEntriesRecursive() {
        List<Entry> all = new ArrayList<>(entries);
        for (Group sub : subgroups) {
            all.addAll(sub.getAllEntriesRecursive());
        }
        return all;
    }

    public String getName() {
        return name;
    }

    public Group getParent() {
        return parent;
    }

    public List<Group> getSubgroups() {
        return Collections.unmodifiableList(subgroups);
    }

    public List<Entry> getEntries() {
        return Collections.unmodifiableList(entries);
    }
}
