import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class DatabaseFileFormat {
    public static final int SIGNATURE_1 = 0x9AA2D903;
    public static final int SIGNATURE_2 = 0xB54BFB65;

    public static byte[] serializeLayout(String dbName, int groupCount, int entryCount) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (DataOutputStream dos = new DataOutputStream(baos)) {
            dos.writeInt(SIGNATURE_1);
            dos.writeInt(SIGNATURE_2);
            dos.writeUTF(dbName);
            dos.writeInt(groupCount);
            dos.writeInt(entryCount);
        } catch (IOException e) {
            throw new RuntimeException("Error writing low-level data layout", e);
        }
        return baos.toByteArray();
    }
}
