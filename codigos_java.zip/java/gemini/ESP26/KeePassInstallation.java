public class KeePassInstallation {
    private boolean downloaded;
    private boolean installed;

    public KeePassInstallation() {
        this.downloaded = false;
        this.installed = false;
    }

    public void download() {
        this.downloaded = true;
    }

    public void install() {
        if (!downloaded) {
            throw new IllegalStateException("KeePass must be downloaded before it can be installed (REQ-1).");
        }
        this.installed = true;
    }

    public boolean isInstalled() {
        return installed;
    }

    public void downloadLanguageTranslation(String language, boolean hasInternetConnection, boolean hasBrowser) {
        if (!hasInternetConnection || !hasBrowser) {
            throw new IllegalStateException("An internet connection and a browser are required in order to download new language translations (REQ-18).");
        }
        if (!installed) {
            throw new IllegalStateException("KeePass must be installed before downloading translations (REQ-1).");
        }
    }
}
