import java.util.ArrayList;
import java.util.List;

public class Database {
    private final String fileName;
    private final DatabaseKey key;
    private boolean unlocked;
    private final Group rootGroup;
    private Group selectedGroup;
    private Entry selectedEntry;

    public Database(String fileName, DatabaseKey key) {
        if (fileName == null || !fileName.toLowerCase().endsWith(".kdb")) {
            throw new IllegalArgumentException("Folder/file selected must be of type the database can read and that is \"name\".kdb (REQ-3).");
        }
        if (key == null) {
            throw new IllegalArgumentException("Database key configuration is required.");
        }
        this.fileName = fileName;
        this.key = key;
        this.unlocked = false;
        String rootName = fileName.replace(".kdb", "");
        this.rootGroup = Group.createRootGroup(rootName);
        this.selectedGroup = this.rootGroup;
        this.selectedEntry = null;
    }

    public boolean open(String masterPassword, byte[] keyFile) {
        if (key.validate(masterPassword, keyFile)) {
            this.unlocked = true;
            return true;
        }
        this.unlocked = false;
        return false;
    }

    public void lock() {
        this.unlocked = false;
        this.selectedEntry = null;
    }

    public boolean isUnlocked() {
        return unlocked;
    }

    private void checkUnlocked() {
        if (!unlocked) {
            throw new IllegalStateException("Database is locked. Correct credentials must be entered to open (REQ-24, REQ-25, REQ-26, REQ-27, REQ-28).");
        }
    }

    public Group createSubgroupUnderSelected(String name) {
        checkUnlocked();
        if (selectedGroup == null) {
            throw new IllegalStateException("A subgroup cannot be created when no group is selected (REQ-8).");
        }
        return selectedGroup.createSubgroup(name);
    }

    public void renameSelectedGroup(String newName) {
        checkUnlocked();
        if (selectedGroup == null) {
            throw new IllegalStateException("No group selected to rename.");
        }
        selectedGroup.rename(newName);
    }

    public void selectGroup(Group group) {
        checkUnlocked();
        this.selectedGroup = group;
    }

    public Group getSelectedGroup() {
        return selectedGroup;
    }

    public void selectEntry(Entry entry) {
        checkUnlocked();
        this.selectedEntry = entry;
    }

    public Entry getSelectedEntry() {
        return selectedEntry;
    }

    public Entry viewSelectedEntry() {
        checkUnlocked();
        if (selectedEntry == null) {
            throw new IllegalStateException("An entry must be selected to be viewed or modified (REQ-14).");
        }
        return selectedEntry;
    }

    public void modifySelectedEntry(String newTitle, String newUsername, String newUrl, String newNotes) {
        checkUnlocked();
        if (selectedEntry == null) {
            throw new IllegalStateException("An entry must be selected to be viewed or modified (REQ-14).");
        }
        selectedEntry.setTitle(newTitle);
        selectedEntry.setUsername(newUsername);
        selectedEntry.setUrl(newUrl);
        selectedEntry.setNotes(newNotes);
    }

    public void modifySelectedEntryPassword(String newPassword, String repeatPassword) {
        checkUnlocked();
        if (selectedEntry == null) {
            throw new IllegalStateException("An entry must be selected to be viewed or modified (REQ-14).");
        }
        selectedEntry.setPassword(newPassword, repeatPassword);
    }

    public Entry duplicateSelectedEntry() {
        checkUnlocked();
        if (selectedEntry == null) {
            throw new IllegalStateException("An entry must be selected before it is duplicated (REQ-16).");
        }
        return selectedEntry.copy(selectedEntry.getGroup());
    }

    public void deleteSelectedEntry() {
        checkUnlocked();
        if (selectedEntry == null) {
            throw new IllegalStateException("An entry must be selected to be deleted (REQ-17).");
        }
        selectedEntry.getGroup().removeEntry(selectedEntry);
        selectedEntry = null;
    }

    public List<Entry> printEntries() {
        checkUnlocked();
        List<Entry> all = rootGroup.getAllEntriesRecursive();
        if (all.isEmpty()) {
            throw new IllegalStateException("There must be entries in the database in order for them to be printed (REQ-5).");
        }
        return all;
    }

    public List<Entry> find(String word) {
        checkUnlocked();
        if (word == null || word.trim().isEmpty()) {
            throw new IllegalArgumentException("In order to find something in a group a word must be placed in the find field (REQ-10).");
        }
        return rootGroup.findInGroup(word);
    }

    public String getFileName() {
        return fileName;
    }

    public Group getRootGroup() {
        return rootGroup;
    }
}
