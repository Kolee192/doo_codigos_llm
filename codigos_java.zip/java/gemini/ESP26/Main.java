import java.nio.charset.StandardCharsets;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // REQ-1 & REQ-18: Installation and Translation Download
        KeePassInstallation app = new KeePassInstallation();
        app.download();
        app.install();
        app.downloadLanguageTranslation("German", true, true);

        // REQ-2: Master Password with no length limits (> 100 characters sentence)
        String sentencePassword = "This is a very long master password sentence designed to exceed one hundred characters easily without any truncation whatsoever!";
        byte[] keyFileData = "SecretKeyFileBytes".getBytes(StandardCharsets.UTF_8);

        // REQ-3: File selected must end with .kdb
        String validDbFile = "personal.kdb";
        DatabaseKey compositeKey = DatabaseKey.ofComposite(sentencePassword, keyFileData);
        Database db1 = new Database(validDbFile, compositeKey);

        // REQ-4: Databases must have different names or else replace previous one
        DatabaseManager manager = new DatabaseManager();
        manager.registerDatabase(db1);
        Database db1Replacement = new Database("personal.kdb", compositeKey);
        manager.registerDatabase(db1Replacement);

        // REQ-24, REQ-25, REQ-26, REQ-27, REQ-28: Unlock requirements
        db1Replacement.open(sentencePassword, keyFileData);

        // REQ-7, REQ-8, REQ-9: Group and Subgroup operations
        Group generalGroup = db1Replacement.createSubgroupUnderSelected("General");
        generalGroup.rename("General Accounts");
        db1Replacement.selectGroup(generalGroup);

        // REQ-11, REQ-12, REQ-13, REQ-15: Entry password completion & matching
        Entry entry1 = new Entry("Email", "user_abc", "pass123", "pass123", "https://mail.com", "Auto-Type:{USERNAME}{TAB}{PASSWORD}{ENTER}", generalGroup);
        Entry entry2 = new Entry("Bank", "user_xyz", "my_abc_secret", "my_abc_secret", "https://bank.com", "Auto-Type:{USERNAME}{TAB}{PASSWORD}{ENTER}\nAuto-Type:{PASSWORD}", generalGroup);

        // REQ-19, REQ-20, REQ-21: Auto-Type formatting and prefix
        String autoType1 = entry1.extractAutoTypeSequence();
        String autoType2 = entry2.extractAutoTypeSequence();

        // REQ-5: Printing entries
        List<Entry> printed = db1Replacement.printEntries();

        // REQ-6 & REQ-10: Finding related data (word 'abc' matches username in entry1 and password in entry2)
        List<Entry> findResults = db1Replacement.find("abc");

        // REQ-14: Viewing & modifying selected entry
        db1Replacement.selectEntry(entry1);
        Entry viewed = db1Replacement.viewSelectedEntry();
        db1Replacement.modifySelectedEntry("Email Primary", "user_abc_updated", "https://mail.com", viewed.getNotes());
        db1Replacement.modifySelectedEntryPassword("newPass123", "newPass123");

        // REQ-16: Duplicating selected entry
        Entry duplicate = db1Replacement.duplicateSelectedEntry();

        // REQ-17: Deleting selected entry
        db1Replacement.selectEntry(duplicate);
        db1Replacement.deleteSelectedEntry();

        // REQ-22 & REQ-23: Command-line path handling and quotes for spaces
        String quotedPath = CommandLineParser.formatPath("C:\\My Documents\\db.kdb");
        String parsedPath = CommandLineParser.parseSingleDatabasePath("\"C:\\My Documents\\db.kdb\" --config=none");

        // REQ-29 & REQ-30: File format layout
        byte[] rawLayout = DatabaseFileFormat.serializeLayout("personal.kdb", 2, 2);

        // REQ-31: Global hot key cannot be changed
        String hotKey = HotKeyConfiguration.getGlobalHotKey();

        // REQ-32 & REQ-33: TAN Entry constraints and single-use expiration
        TanEntry tan = new TanEntry("TAN #1", "BankingTAN", "987654", "987654", "https://bank.com", "", generalGroup);
        String usedTan = tan.useTan();
        boolean isExpired = tan.isExpired();

        System.out.println("KeePass Demo Completed Successfully.");
        System.out.println("Global Hot Key: " + hotKey);
        System.out.println("Found entries matching 'abc': " + findResults.size());
        System.out.println("AutoType for entry2 (only first used): " + autoType2);
        System.out.println("TAN used and expired: " + isExpired + " (Code: " + usedTan + ")");
        System.out.println("Parsed path: " + parsedPath + " (Quoted: " + quotedPath + ")");
        System.out.println("Raw layout bytes: " + rawLayout.length);
    }
}
