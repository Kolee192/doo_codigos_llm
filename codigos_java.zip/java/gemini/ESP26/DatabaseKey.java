import java.util.Arrays;
import java.util.Objects;

public class DatabaseKey {
    private final String masterPassword;
    private final byte[] keyFileData;
    private final boolean requiresPassword;
    private final boolean requiresKeyFile;

    public DatabaseKey(String masterPassword, byte[] keyFileData) {
        this.requiresPassword = masterPassword != null && !masterPassword.isEmpty();
        this.requiresKeyFile = keyFileData != null && keyFileData.length > 0;

        if (!requiresPassword && !requiresKeyFile) {
            throw new IllegalArgumentException("Database key must have at least a password or key file.");
        }

        this.masterPassword = masterPassword;
        this.keyFileData = keyFileData != null ? Arrays.copyOf(keyFileData, keyFileData.length) : null;
    }

    public static DatabaseKey ofPassword(String masterPassword) {
        return new DatabaseKey(masterPassword, null);
    }

    public static DatabaseKey ofKeyFile(byte[] keyFileData) {
        return new DatabaseKey(null, keyFileData);
    }

    public static DatabaseKey ofComposite(String masterPassword, byte[] keyFileData) {
        return new DatabaseKey(masterPassword, keyFileData);
    }

    public boolean validate(String attemptPassword, byte[] attemptKeyFile) {
        if (requiresPassword && requiresKeyFile) {
            if (attemptPassword == null || attemptKeyFile == null) {
                return false;
            }
            return Objects.equals(this.masterPassword, attemptPassword)
                    && Arrays.equals(this.keyFileData, attemptKeyFile);
        } else if (requiresPassword) {
            if (attemptPassword == null) {
                return false;
            }
            return Objects.equals(this.masterPassword, attemptPassword);
        } else {
            if (attemptKeyFile == null) {
                return false;
            }
            return Arrays.equals(this.keyFileData, attemptKeyFile);
        }
    }

    public boolean isComposite() {
        return requiresPassword && requiresKeyFile;
    }

    public boolean requiresPassword() {
        return requiresPassword;
    }

    public boolean requiresKeyFile() {
        return requiresKeyFile;
    }
}
