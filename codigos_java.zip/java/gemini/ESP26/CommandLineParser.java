import java.util.ArrayList;
import java.util.List;

public class CommandLineParser {

    public static String parseSingleDatabasePath(String commandLineArgs) {
        if (commandLineArgs == null || commandLineArgs.trim().isEmpty()) {
            throw new IllegalArgumentException("No database file specified in command line options.");
        }

        List<String> tokens = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < commandLineArgs.length(); i++) {
            char c = commandLineArgs.charAt(i);
            if (c == '\"') {
                inQuotes = !inQuotes;
            } else if (Character.isWhitespace(c) && !inQuotes) {
                if (current.length() > 0) {
                    tokens.add(current.toString());
                    current.setLength(0);
                }
            } else {
                current.append(c);
            }
        }
        if (current.length() > 0) {
            tokens.add(current.toString());
        }

        List<String> kdbPaths = new ArrayList<>();
        for (String token : tokens) {
            if (token.endsWith(".kdb")) {
                kdbPaths.add(token);
            }
        }

        if (kdbPaths.size() > 1) {
            throw new IllegalArgumentException("Only one database file is allowed in command line options (REQ-22).");
        }
        if (kdbPaths.isEmpty()) {
            throw new IllegalArgumentException("Folder/file selected must be of type .kdb (REQ-3).");
        }

        return kdbPaths.get(0);
    }

    public static String formatPath(String path) {
        if (path == null) {
            return null;
        }
        if (path.contains(" ") && (!path.startsWith("\"") || !path.endsWith("\""))) {
            return "\"" + path + "\"";
        }
        return path;
    }
}
