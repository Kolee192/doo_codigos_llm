public class TanEntry extends Entry {
    private boolean expired;

    public TanEntry(String title, String username, String tanCode, String repeatTanCode, String url, String notes, Group group) {
        super(title, username, tanCode, repeatTanCode, url, notes, group);
        this.expired = false;
    }

    @Override
    public void setTitle(String title) {
        throw new UnsupportedOperationException("Title, username or URL cannot be changed in a TAN entry (REQ-32).");
    }

    @Override
    public void setUsername(String username) {
        throw new UnsupportedOperationException("Title, username or URL cannot be changed in a TAN entry (REQ-32).");
    }

    @Override
    public void setUrl(String url) {
        throw new UnsupportedOperationException("Title, username or URL cannot be changed in a TAN entry (REQ-32).");
    }

    public String useTan() {
        if (expired) {
            throw new IllegalStateException("When a TAN is used, it expires automatically and can never be used again (REQ-33).");
        }
        expired = true;
        return getPassword();
    }

    public boolean isExpired() {
        return expired;
    }

    @Override
    public String toString() {
        return "TanEntry{" +
                "title='" + getTitle() + '\'' +
                ", username='" + getUsername() + '\'' +
                ", expired=" + expired +
                '}';
    }
}
