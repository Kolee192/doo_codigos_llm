public class OriginInfo {
    private String placeOfPublication;
    private String publisher;
    private String edition;
    private String dateIssued;

    public OriginInfo(String placeOfPublication, String publisher, String edition, String dateIssued) {
        this.placeOfPublication = placeOfPublication;
        this.publisher = publisher;
        this.edition = edition;
        this.dateIssued = dateIssued;
    }

    public String getPlaceOfPublication() {
        return placeOfPublication;
    }

    public void setPlaceOfPublication(String placeOfPublication) {
        this.placeOfPublication = placeOfPublication;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public String getDateIssued() {
        return dateIssued;
    }

    public void setDateIssued(String dateIssued) {
        this.dateIssued = dateIssued;
    }

    @Override
    public String toString() {
        return "Published: " + publisher + " (" + placeOfPublication + "), Edition: " + edition + ", Date: " + dateIssued;
    }
}
