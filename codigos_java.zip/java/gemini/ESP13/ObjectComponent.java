import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ObjectComponent {
    private final String id;
    private int order;
    private final Map<String, String> titles = new HashMap<>(); // type -> title (e.g. "primary", "alternative")
    private String date;
    private final List<String> languages = new ArrayList<>();
    private final List<NameAssociation> names = new ArrayList<>();
    private final List<SubjectHeading> subjects = new ArrayList<>();
    private OriginInfo originInfo;
    private final Map<String, String> notes = new HashMap<>(); // facet name -> note
    private GeoCoordinates geoCoordinates;
    private RightsMetadata componentRights; // optional override of object rights
    private final List<ExternalDescription> externalDescriptions = new ArrayList<>();
    private final List<ContentFile> files = new ArrayList<>();
    private final List<ObjectComponent> childComponents = new ArrayList<>();
    private final List<ObjectComponent> linkedComponents = new ArrayList<>();
    private final List<DamsEvent> lifecycleEvents = new ArrayList<>();

    public ObjectComponent(String id, int order, String primaryTitle) {
        this.id = id;
        this.order = order;
        this.titles.put("primary", primaryTitle);
    }

    public String getId() {
        return id;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public String getPrimaryTitle() {
        return titles.getOrDefault("primary", titles.values().stream().findFirst().orElse("Untitled Component"));
    }

    public Map<String, String> getTitles() {
        return titles;
    }

    public void setTitle(String form, String title) {
        titles.put(form, title);
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<String> getLanguages() {
        return languages;
    }

    public void addLanguage(String language) {
        if (!languages.contains(language)) {
            languages.add(language);
        }
    }

    public List<NameAssociation> getNames() {
        return names;
    }

    public void addName(NameAssociation name) {
        this.names.add(name);
    }

    public List<SubjectHeading> getSubjects() {
        return subjects;
    }

    public void addSubject(SubjectHeading subject) {
        this.subjects.add(subject);
    }

    public OriginInfo getOriginInfo() {
        return originInfo;
    }

    public void setOriginInfo(OriginInfo originInfo) {
        this.originInfo = originInfo;
    }

    public Map<String, String> getNotes() {
        return notes;
    }

    public void putNote(String facet, String content) {
        notes.put(facet, content);
    }

    public GeoCoordinates getGeoCoordinates() {
        return geoCoordinates;
    }

    public void setGeoCoordinates(GeoCoordinates geoCoordinates) {
        this.geoCoordinates = geoCoordinates;
    }

    public RightsMetadata getComponentRights() {
        return componentRights;
    }

    public void setComponentRights(RightsMetadata componentRights) {
        this.componentRights = componentRights;
    }

    public List<ExternalDescription> getExternalDescriptions() {
        return externalDescriptions;
    }

    public void addExternalDescription(ExternalDescription description) {
        this.externalDescriptions.add(description);
    }

    public List<ContentFile> getFiles() {
        return files;
    }

    public void addFile(ContentFile file) {
        this.files.add(file);
    }

    public List<ObjectComponent> getChildComponents() {
        return childComponents;
    }

    public void addChildComponent(ObjectComponent child) {
        this.childComponents.add(child);
        this.childComponents.sort((a, b) -> Integer.compare(a.getOrder(), b.getOrder()));
    }

    public List<ObjectComponent> getLinkedComponents() {
        return linkedComponents;
    }

    public void linkComponent(ObjectComponent other) {
        if (!linkedComponents.contains(other)) {
            linkedComponents.add(other);
        }
    }

    public List<DamsEvent> getLifecycleEvents() {
        return lifecycleEvents;
    }

    public void recordEvent(DamsEvent event) {
        this.lifecycleEvents.add(event);
    }

    @Override
    public String toString() {
        return "Component #" + order + " [" + id + "]: " + getPrimaryTitle();
    }
}
