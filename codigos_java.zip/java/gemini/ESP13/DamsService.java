import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class DamsService implements Repository.RepositoryChangeListener {
    private final Map<String, Repository> repositories = new HashMap<>();
    private final Map<String, DigitalCollection> collections = new HashMap<>();
    private final Map<String, DigitalObject> objects = new HashMap<>();
    private final Map<String, ContentFile> files = new HashMap<>();
    private final List<DamsEvent> allScheduledEvents = new ArrayList<>();
    private int eventCounter = 1;

    public DamsService() {}

    // Repository operations
    public void registerRepository(Repository repo) {
        repositories.put(repo.getId(), repo);
        repo.addListener(this);
    }

    public Optional<Repository> getRepository(String id) {
        return Optional.ofNullable(repositories.get(id));
    }

    public List<Repository> getAllRepositories() {
        return new ArrayList<>(repositories.values());
    }

    @Override
    public void onRepositoryUpdated(Repository repo) {
        recordEvent("REPOSITORY_UPDATED", "system", "Propagated update for repository " + repo.getId(), repo.getId());
    }

    // Access control check
    public boolean checkCuratorialAccess(User user, String repositoryId) {
        return user.canCurateUnit(repositoryId);
    }

    // Collections
    public void addCollection(DigitalCollection collection, User user) {
        if (!user.canCurateUnit(collection.getRepositoryId())) {
            throw new SecurityException("User " + user.getName() + " lacks curatorial access to repository " + collection.getRepositoryId());
        }
        collections.put(collection.getId(), collection);
        recordEvent("COLLECTION_CREATED", user.getId(), "Collection created: " + collection.getPrimaryTitle(), collection.getId());
    }

    public Optional<DigitalCollection> getCollection(String id) {
        return Optional.ofNullable(collections.get(id));
    }

    public List<DigitalCollection> getCollectionsByRepository(String repoId) {
        return collections.values().stream()
                .filter(c -> c.getRepositoryId().equals(repoId))
                .collect(Collectors.toList());
    }

    public List<DigitalCollection> getFormalCollections() {
        return collections.values().stream()
                .filter(DigitalCollection::isFormalCollection)
                .collect(Collectors.toList());
    }

    public List<DigitalCollection> getAllCollections() {
        return new ArrayList<>(collections.values());
    }

    // Digital Objects
    public void addObject(DigitalObject obj, User user) {
        if (!user.canCurateUnit(obj.getRepositoryId())) {
            throw new SecurityException("User " + user.getName() + " lacks curatorial access to repository " + obj.getRepositoryId());
        }
        objects.put(obj.getId(), obj);
        for (ContentFile cf : obj.getAllFiles()) {
            files.put(cf.getId(), cf);
        }
        recordEvent("OBJECT_CREATED", user.getId(), "Object created: " + obj.getPrimaryTitle(), obj.getId());
    }

    public Optional<DigitalObject> getObject(String id) {
        return Optional.ofNullable(objects.get(id));
    }

    public List<DigitalObject> getObjectsByRepository(String repoId) {
        return objects.values().stream()
                .filter(o -> o.getRepositoryId().equals(repoId))
                .collect(Collectors.toList());
    }

    public List<DigitalObject> getObjectsByCollection(String collectionId) {
        return objects.values().stream()
                .filter(o -> o.getCollectionIds().contains(collectionId))
                .collect(Collectors.toList());
    }

    public List<DigitalObject> getAllObjects() {
        return new ArrayList<>(objects.values());
    }

    // Files
    public void registerFile(ContentFile file) {
        files.put(file.getId(), file);
    }

    public Optional<ContentFile> getFile(String id) {
        return Optional.ofNullable(files.get(id));
    }

    public List<ContentFile> getFilesForRepository(String repoId) {
        List<ContentFile> result = new ArrayList<>();
        for (DigitalObject obj : getObjectsByRepository(repoId)) {
            result.addAll(obj.getAllFiles());
        }
        return result;
    }

    public List<ContentFile> getCompromisedFiles() {
        return files.values().stream()
                .filter(ContentFile::isIntegrityQuestioned)
                .collect(Collectors.toList());
    }

    // Searches
    public List<DigitalCollection> searchCollectionsByTitle(String query) {
        String q = query.toLowerCase();
        return collections.values().stream()
                .filter(c -> c.getTitles().values().stream().anyMatch(t -> t.toLowerCase().contains(q)))
                .collect(Collectors.toList());
    }

    public List<DigitalObject> searchObjectsByTitle(String query, Collection<String> scopeCollectionIds) {
        String q = query.toLowerCase();
        return objects.values().stream()
                .filter(o -> scopeCollectionIds == null || scopeCollectionIds.isEmpty() ||
                        o.getCollectionIds().stream().anyMatch(scopeCollectionIds::contains))
                .filter(o -> o.getTitles().values().stream().anyMatch(t -> t.toLowerCase().contains(q)))
                .collect(Collectors.toList());
    }

    public List<DigitalObject> searchObjectsByLanguage(String language, Collection<String> scopeCollectionIds) {
        String lang = language.toLowerCase();
        return objects.values().stream()
                .filter(o -> scopeCollectionIds == null || scopeCollectionIds.isEmpty() ||
                        o.getCollectionIds().stream().anyMatch(scopeCollectionIds::contains))
                .filter(o -> o.getLanguages().stream().anyMatch(l -> l.equalsIgnoreCase(lang)))
                .collect(Collectors.toList());
    }

    public List<DigitalObject> searchObjectsByNameAndRole(String nameQuery, String role) {
        String nq = nameQuery.toLowerCase();
        return objects.values().stream()
                .filter(o -> o.getNames().stream().anyMatch(na ->
                        na.getName().toLowerCase().contains(nq) &&
                                (role == null || na.getRole().equalsIgnoreCase(role))))
                .collect(Collectors.toList());
    }

    public List<DigitalObject> searchObjectsBySubject(String subjectQuery, SubjectHeading.SubjectType type) {
        String sq = subjectQuery.toLowerCase();
        return objects.values().stream()
                .filter(o -> o.getSubjects().stream().anyMatch(sh ->
                        sh.getHeading().toLowerCase().contains(sq) &&
                                (type == null || sh.getType() == type)))
                .collect(Collectors.toList());
    }

    // Rights checks
    public List<DigitalObject> getObjectsUnderCopyright() {
        return objects.values().stream()
                .filter(o -> o.getRightsMetadata().getCopyrightStatus() != null &&
                        o.getRightsMetadata().getCopyrightStatus().isUnderCopyright())
                .collect(Collectors.toList());
    }

    // Events
    public DamsEvent recordEvent(String eventType, String agentId, String outcome, String targetId) {
        String eventId = "EVT-" + (eventCounter++);
        DamsEvent evt = new DamsEvent(eventId, eventType, LocalDateTime.now(), agentId, outcome, targetId);
        allScheduledEvents.add(evt);

        // route event to appropriate object/collection/file
        if (collections.containsKey(targetId)) {
            collections.get(targetId).recordEvent(evt);
        } else if (objects.containsKey(targetId)) {
            objects.get(targetId).recordEvent(evt);
        } else if (files.containsKey(targetId)) {
            files.get(targetId).recordEvent(evt);
        }
        return evt;
    }

    public List<DamsEvent> getAllRecordedEvents() {
        return Collections.unmodifiableList(allScheduledEvents);
    }
}
