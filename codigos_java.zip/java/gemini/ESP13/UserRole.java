public enum UserRole {
    USER,
    REPOSITORY_STAFF,
    REPOSITORY_MANAGER,
    DAMS_MANAGER
}
