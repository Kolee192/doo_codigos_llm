public class ExternalDescription {
    private final String title;
    private final String url;
    private final String description;

    public ExternalDescription(String title, String url, String description) {
        this.title = title;
        this.url = url;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return title + " <" + url + ">: " + description;
    }
}
