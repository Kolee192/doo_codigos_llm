import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Starting DAMS Demo ===");

        DamsService dams = new DamsService();

        // 1. Setup Library Units / Repositories
        Repository specialCollections = new Repository(
                "repo-spec-coll",
                "Special Collections & Archives",
                "spec-coll@library.example.edu",
                "+1-555-0199",
                "100 Library Mall, Floor 4"
        );
        dams.registerRepository(specialCollections);

        Repository musicLibrary = new Repository(
                "repo-music",
                "Music & Sound Archives",
                "music-archive@library.example.edu",
                "+1-555-0188",
                "Music Hall, Room 210"
        );
        dams.registerRepository(musicLibrary);

        // 2. Users with role-based curatorial access
        User damsAdmin = new User("usr-admin", "Diana Admin", UserRole.DAMS_MANAGER, null);
        User specManager = new User("usr-spec-mgr", "Sam Curator", UserRole.REPOSITORY_MANAGER, "repo-spec-coll");
        User musicStaff = new User("usr-music-staff", "Miles Davis Fan", UserRole.REPOSITORY_STAFF, "repo-music");
        User publicUser = new User("usr-public", "Jane Public", UserRole.USER, null);

        System.out.println("Checking curator permissions:");
        System.out.println(" - DAMS Manager can curate spec-coll? " + damsAdmin.canCurateUnit("repo-spec-coll"));
        System.out.println(" - Spec Manager can curate spec-coll? " + specManager.canCurateUnit("repo-spec-coll"));
        System.out.println(" - Spec Manager can curate music? " + specManager.canCurateUnit("repo-music"));

        // 3. Create Collections (Composed, with Provenance, metadata, related collections)
        DigitalCollection earlyManuscripts = new DigitalCollection(
                "col-001",
                "repo-spec-coll",
                "Early Medieval Manuscripts",
                true,
                DigitalCollection.CompositionType.SHARED_PROVENANCE,
                "Gift of Lord Pemberton, 1923"
        );
        earlyManuscripts.setInclusiveDates("1100 - 1350");
        earlyManuscripts.setBulkDates("1200 - 1280");
        earlyManuscripts.addLanguage("Latin");
        earlyManuscripts.addLanguage("Old French");
        earlyManuscripts.addName(new NameAssociation("Pemberton Estate", "source"));
        earlyManuscripts.addSubject(new SubjectHeading("Illuminated manuscripts", SubjectHeading.SubjectType.TOPIC));
        earlyManuscripts.addExternalDescription(new ExternalDescription("Finding Aid", "http://archives.org/pemberton", "Full EAD finding aid"));
        earlyManuscripts.setGeoCoordinates(new GeoCoordinates(51.5074, -0.1278));

        DigitalCollection charterCollection = new DigitalCollection(
                "col-002",
                "repo-spec-coll",
                "Medieval Charters and Deeds",
                true,
                DigitalCollection.CompositionType.ASSEMBLED,
                "Assembled from various institutional acquisitions"
        );
        earlyManuscripts.addRelatedCollection(charterCollection.getId());
        charterCollection.addRelatedCollection(earlyManuscripts.getId());

        dams.addCollection(earlyManuscripts, specManager);
        dams.addCollection(charterCollection, specManager);

        // 4. Create Digital Object with Components, Content Files, Rights, GeoContext, Notes
        DigitalObject codex = new DigitalObject("obj-codex-1", "repo-spec-coll", "Codex Aureus Pemberton");
        codex.addCollectionId(earlyManuscripts.getId());
        codex.setTitle("alternative", "The Golden Book of Pemberton");
        codex.setDate("ca. 1220");
        codex.addLanguage("Latin");
        codex.addName(new NameAssociation("Monastery of St. Peter", "creator"));
        codex.addName(new NameAssociation("Brother Thomas", "illustrator"));
        codex.addSubject(new SubjectHeading("Gospel Books", SubjectHeading.SubjectType.GENRE_FORM));
        codex.setOriginInfo(new OriginInfo("Canterbury", "Scriptorium of St. Peter", "1st Edition", "1220"));
        codex.putNote("Scope & Content", "Parchment codex with 120 folios, including 14 full-page miniatures.");
        codex.putNote("Condition Governing Access", "Open access for digital surrogate; physical original restricted.");
        codex.setGeoCoordinates(new GeoCoordinates(51.2798, 1.0789));

        // Rights Metadata
        CopyrightStatus crStatus = new CopyrightStatus(false, "Public Domain", LocalDate.of(1300, 1, 1), "UK Copyright Act Section 12");
        RightsMetadata rights = new RightsMetadata(crStatus, "CC0 1.0 Universal", "Unrestricted research and commercial use");
        rights.addStatute(new StatuteInfo("Public Domain Mark", "Worldwide", null));
        rights.addPolicyRestriction(new PolicyRestriction("High-res Download Policy", "High resolution downloads permitted with credit", null));
        rights.addUsageRule(new RightsUsageRule("Display", RightsUsageRule.RuleType.PERMITTED, LocalDate.of(2000, 1, 1), null));
        rights.addUsageRule(new RightsUsageRule("Download", RightsUsageRule.RuleType.PERMITTED, LocalDate.of(2000, 1, 1), null));
        codex.setRightsMetadata(rights);

        // Components & Content Files (Structure & File technical metadata)
        ObjectComponent fol1r = new ObjectComponent("comp-01", 1, "Folio 1 recto (Incipit)");
        fol1r.setDate("ca. 1220");
        fol1r.addLanguage("Latin");
        fol1r.addName(new NameAssociation("Brother Thomas", "illustrator"));

        ContentFile fileMasterTiff = new ContentFile(
                "fil-001",
                "fol1r_master.tif",
                154857600L, // ~147 MB
                LocalDateTime.now().minusDays(10),
                "TIFF",
                "6.0",
                "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                "SHA-256",
                true
        );
        fileMasterTiff.setSourceCaptureInfo("Phase One IQ4 150MP", "Capture One CH 14.2");

        ContentFile fileAccessJpg = new ContentFile(
                "fil-002",
                "fol1r_access.jpg",
                3145728L, // ~3 MB
                LocalDateTime.now().minusDays(10),
                "JPEG",
                "1.02",
                "cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce",
                "SHA-256",
                false
        );

        fol1r.addFile(fileMasterTiff);
        fol1r.addFile(fileAccessJpg);
        codex.addComponent(fol1r);

        ObjectComponent fol1v = new ObjectComponent("comp-02", 2, "Folio 1 verso (Blank)");
        fol1r.linkComponent(fol1v);
        codex.addComponent(fol1v);

        dams.addObject(codex, specManager);

        // 5. Update Repository info in one place and verify event propagation
        System.out.println("\nUpdating Special Collections Repository details...");
        specialCollections.updateInfo("Special Collections & University Archives", "archives@library.example.edu", "+1-555-9999", "100 Library Mall, 5th Floor");

        // 6. User browsing and limiting searches
        System.out.println("\nBrowse collections belonging to 'repo-spec-coll':");
        for (DigitalCollection col : dams.getCollectionsByRepository("repo-spec-coll")) {
            System.out.println(" - " + col.getPrimaryTitle() + " (Provenance: " + col.getProvenance() + ")");
            System.out.println("   Related collections: " + col.getRelatedCollectionIds());
        }

        System.out.println("\nSearch objects with title 'Codex' limited to collection 'col-001':");
        List<DigitalObject> found = dams.searchObjectsByTitle("Codex", List.of("col-001"));
        for (DigitalObject obj : found) {
            System.out.println(" - Found: " + obj.getPrimaryTitle() + " in repo " + obj.getRepositoryId());
            System.out.println("   Belongs to collections: " + obj.getCollectionIds());
            System.out.println("   Origin: " + obj.getOriginInfo());
            System.out.println("   Rights status: " + obj.getRightsMetadata().getCopyrightStatus());
            System.out.println("   Geo Context: " + obj.getGeoCoordinates());
            System.out.println("   Components in order:");
            for (ObjectComponent comp : obj.getComponents()) {
                System.out.println("     [" + comp.getOrder() + "] " + comp.getPrimaryTitle());
                for (ContentFile cf : comp.getFiles()) {
                    System.out.println("       File: " + cf.getFileName() + " (" + cf.getFileSize() + " bytes, Format: " + cf.getFileFormat() + ")");
                }
            }
        }

        // 7. Search by role (illustrator)
        System.out.println("\nSearch objects by name role 'illustrator':");
        List<DigitalObject> byRole = dams.searchObjectsByNameAndRole("Thomas", "illustrator");
        System.out.println(" - Match count: " + byRole.size());

        // 8. Preservation Manager integrity alert simulation
        System.out.println("\nPreservation test: Simulating checksum alteration on master file...");
        fileMasterTiff.updateChecksum("corrupted_hash_value_xyz");
        List<ContentFile> compromised = dams.getCompromisedFiles();
        System.out.println("Compromised files identified by Preservation Manager: " + compromised.size());
        for (ContentFile cf : compromised) {
            System.out.println(" - Integrity Warning: " + cf.getFileName() + " (Stored hash differs from original)");
        }

        // 9. DAMS Manager listing of events across lifecycle
        System.out.println("\nDAMS Event History Audit Log:");
        for (DamsEvent evt : dams.getAllRecordedEvents()) {
            System.out.println(" * " + evt);
        }

        System.out.println("\n=== DAMS Demo Completed Successfully ===");
    }
}
