import java.util.ArrayList;
import java.util.List;

public class RightsMetadata {
    private CopyrightStatus copyrightStatus;
    private final List<StatuteInfo> statutes = new ArrayList<>();
    private String license;
    private String otherRights;
    private final List<PolicyRestriction> policyRestrictions = new ArrayList<>();
    private final List<RightsUsageRule> usageRules = new ArrayList<>();

    public RightsMetadata() {}

    public RightsMetadata(CopyrightStatus copyrightStatus, String license, String otherRights) {
        this.copyrightStatus = copyrightStatus;
        this.license = license;
        this.otherRights = otherRights;
    }

    public CopyrightStatus getCopyrightStatus() {
        return copyrightStatus;
    }

    public void setCopyrightStatus(CopyrightStatus copyrightStatus) {
        this.copyrightStatus = copyrightStatus;
    }

    public List<StatuteInfo> getStatutes() {
        return statutes;
    }

    public void addStatute(StatuteInfo statute) {
        this.statutes.add(statute);
    }

    public String getLicense() {
        return license;
    }

    public void setLicense(String license) {
        this.license = license;
    }

    public String getOtherRights() {
        return otherRights;
    }

    public void setOtherRights(String otherRights) {
        this.otherRights = otherRights;
    }

    public List<PolicyRestriction> getPolicyRestrictions() {
        return policyRestrictions;
    }

    public void addPolicyRestriction(PolicyRestriction restriction) {
        this.policyRestrictions.add(restriction);
    }

    public List<RightsUsageRule> getUsageRules() {
        return usageRules;
    }

    public void addUsageRule(RightsUsageRule rule) {
        this.usageRules.add(rule);
    }
}
