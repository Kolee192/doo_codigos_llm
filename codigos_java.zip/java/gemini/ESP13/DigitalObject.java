import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DigitalObject {
    private final String id;
    private final String repositoryId;
    private final List<String> collectionIds = new ArrayList<>();
    private final Map<String, String> titles = new HashMap<>(); // type -> title
    private String date;
    private final List<String> languages = new ArrayList<>();
    private final List<NameAssociation> names = new ArrayList<>();
    private final List<SubjectHeading> subjects = new ArrayList<>();
    private OriginInfo originInfo;
    private final Map<String, String> notes = new HashMap<>(); // facet -> note
    private GeoCoordinates geoCoordinates;
    private RightsMetadata rightsMetadata = new RightsMetadata();
    private final List<ExternalDescription> externalDescriptions = new ArrayList<>();
    private final List<ContentFile> directFiles = new ArrayList<>();
    private final List<ObjectComponent> components = new ArrayList<>(); // ordered components
    private final List<DamsEvent> lifecycleEvents = new ArrayList<>();

    public DigitalObject(String id, String repositoryId, String primaryTitle) {
        this.id = id;
        this.repositoryId = repositoryId;
        this.titles.put("primary", primaryTitle);
    }

    public String getId() {
        return id;
    }

    public String getRepositoryId() {
        return repositoryId;
    }

    public List<String> getCollectionIds() {
        return collectionIds;
    }

    public void addCollectionId(String collectionId) {
        if (!collectionIds.contains(collectionId)) {
            collectionIds.add(collectionId);
        }
    }

    public String getPrimaryTitle() {
        return titles.getOrDefault("primary", titles.values().stream().findFirst().orElse("Untitled Object"));
    }

    public Map<String, String> getTitles() {
        return titles;
    }

    public void setTitle(String form, String title) {
        titles.put(form, title);
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<String> getLanguages() {
        return languages;
    }

    public void addLanguage(String language) {
        if (!languages.contains(language)) {
            languages.add(language);
        }
    }

    public List<NameAssociation> getNames() {
        return names;
    }

    public void addName(NameAssociation name) {
        this.names.add(name);
    }

    public List<SubjectHeading> getSubjects() {
        return subjects;
    }

    public void addSubject(SubjectHeading subject) {
        this.subjects.add(subject);
    }

    public OriginInfo getOriginInfo() {
        return originInfo;
    }

    public void setOriginInfo(OriginInfo originInfo) {
        this.originInfo = originInfo;
    }

    public Map<String, String> getNotes() {
        return notes;
    }

    public void putNote(String facet, String content) {
        notes.put(facet, content);
    }

    public GeoCoordinates getGeoCoordinates() {
        return geoCoordinates;
    }

    public void setGeoCoordinates(GeoCoordinates geoCoordinates) {
        this.geoCoordinates = geoCoordinates;
    }

    public RightsMetadata getRightsMetadata() {
        return rightsMetadata;
    }

    public void setRightsMetadata(RightsMetadata rightsMetadata) {
        this.rightsMetadata = rightsMetadata;
    }

    public List<ExternalDescription> getExternalDescriptions() {
        return externalDescriptions;
    }

    public void addExternalDescription(ExternalDescription description) {
        this.externalDescriptions.add(description);
    }

    public List<ContentFile> getDirectFiles() {
        return directFiles;
    }

    public void addFile(ContentFile file) {
        this.directFiles.add(file);
    }

    public List<ObjectComponent> getComponents() {
        return components;
    }

    public void addComponent(ObjectComponent component) {
        components.add(component);
        components.sort((a, b) -> Integer.compare(a.getOrder(), b.getOrder()));
    }

    public List<ContentFile> getAllFiles() {
        List<ContentFile> all = new ArrayList<>(directFiles);
        collectComponentFiles(components, all);
        return all;
    }

    private void collectComponentFiles(List<ObjectComponent> compList, List<ContentFile> result) {
        for (ObjectComponent comp : compList) {
            result.addAll(comp.getFiles());
            collectComponentFiles(comp.getChildComponents(), result);
        }
    }

    public List<DamsEvent> getLifecycleEvents() {
        return lifecycleEvents;
    }

    public void recordEvent(DamsEvent event) {
        this.lifecycleEvents.add(event);
    }

    public RightsMetadata effectiveRightsForComponent(ObjectComponent comp) {
        if (comp.getComponentRights() != null) {
            return comp.getComponentRights();
        }
        return this.rightsMetadata;
    }

    @Override
    public String toString() {
        return "DigitalObject[id=" + id + ", title=" + getPrimaryTitle() + ", repo=" + repositoryId + "]";
    }
}
