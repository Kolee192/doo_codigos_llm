import java.util.ArrayList;
import java.util.List;

public class Repository {
    private final String id;
    private String name;
    private String contactEmail;
    private String contactPhone;
    private String address;
    private final List<RepositoryChangeListener> listeners = new ArrayList<>();

    public interface RepositoryChangeListener {
        void onRepositoryUpdated(Repository repo);
    }

    public Repository(String id, String name, String contactEmail, String contactPhone, String address) {
        this.id = id;
        this.name = name;
        this.contactEmail = contactEmail;
        this.contactPhone = contactPhone;
        this.address = address;
    }

    public void addListener(RepositoryChangeListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeListener(RepositoryChangeListener listener) {
        listeners.remove(listener);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void updateInfo(String name, String contactEmail, String contactPhone, String address) {
        this.name = name;
        this.contactEmail = contactEmail;
        this.contactPhone = contactPhone;
        this.address = address;
        notifyListeners();
    }

    private void notifyListeners() {
        for (RepositoryChangeListener listener : new ArrayList<>(listeners)) {
            listener.onRepositoryUpdated(this);
        }
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public String getAddress() {
        return address;
    }

    @Override
    public String toString() {
        return "Repository[id=" + id + ", name=" + name + ", contact=" + contactEmail + "]";
    }
}
