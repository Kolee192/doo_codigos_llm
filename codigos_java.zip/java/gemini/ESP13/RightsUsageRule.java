import java.time.LocalDate;

public class RightsUsageRule {
    public enum RuleType {
        PERMITTED,
        RESTRICTED
    }

    private String action; // e.g., "Display", "Download", "Commercial Use"
    private RuleType ruleType;
    private LocalDate startDate;
    private LocalDate endDate;

    public RightsUsageRule(String action, RuleType ruleType, LocalDate startDate, LocalDate endDate) {
        this.action = action;
        this.ruleType = ruleType;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public RuleType getRuleType() {
        return ruleType;
    }

    public void setRuleType(RuleType ruleType) {
        this.ruleType = ruleType;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public boolean isActiveOn(LocalDate date) {
        if (startDate != null && date.isBefore(startDate)) {
            return false;
        }
        if (endDate != null && date.isAfter(endDate)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return ruleType + " action '" + action + "' from " + startDate + " to " + endDate;
    }
}
