import java.time.LocalDate;

public class PolicyRestriction {
    private String policyName;
    private String restrictionDetails;
    private LocalDate expirationDate;

    public PolicyRestriction(String policyName, String restrictionDetails, LocalDate expirationDate) {
        this.policyName = policyName;
        this.restrictionDetails = restrictionDetails;
        this.expirationDate = expirationDate;
    }

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getRestrictionDetails() {
        return restrictionDetails;
    }

    public void setRestrictionDetails(String restrictionDetails) {
        this.restrictionDetails = restrictionDetails;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Override
    public String toString() {
        return policyName + ": " + restrictionDetails + " [Expires: " + expirationDate + "]";
    }
}
