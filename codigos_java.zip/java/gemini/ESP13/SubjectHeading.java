public class SubjectHeading {
    public enum SubjectType {
        TOPIC,
        TITLE,
        GENRE_FORM,
        GEOGRAPHIC,
        FUNCTION,
        OCCUPATION,
        NAME,
        CARTOGRAPHICS
    }

    private final String heading;
    private final SubjectType type;

    public SubjectHeading(String heading, SubjectType type) {
        this.heading = heading;
        this.type = type;
    }

    public String getHeading() {
        return heading;
    }

    public SubjectType getType() {
        return type;
    }

    @Override
    public String toString() {
        return heading + " [" + type + "]";
    }
}
