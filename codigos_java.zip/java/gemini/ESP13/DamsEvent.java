import java.time.LocalDateTime;

public class DamsEvent {
    private final String eventId;
    private final String eventType;
    private final LocalDateTime timestamp;
    private final String agentId;
    private final String outcome;
    private final String targetId;

    public DamsEvent(String eventId, String eventType, LocalDateTime timestamp, String agentId, String outcome, String targetId) {
        this.eventId = eventId;
        this.eventType = eventType;
        this.timestamp = timestamp;
        this.agentId = agentId;
        this.outcome = outcome;
        this.targetId = targetId;
    }

    public String getEventId() {
        return eventId;
    }

    public String getEventType() {
        return eventType;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getAgentId() {
        return agentId;
    }

    public String getOutcome() {
        return outcome;
    }

    public String getTargetId() {
        return targetId;
    }

    @Override
    public String toString() {
        return "[" + timestamp + "] " + eventType + " on " + targetId + " by " + agentId + " -> " + outcome;
    }
}
