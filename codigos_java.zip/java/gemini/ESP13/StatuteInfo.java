import java.time.LocalDate;

public class StatuteInfo {
    private String statuteName;
    private String jurisdiction;
    private LocalDate expirationDate;

    public StatuteInfo(String statuteName, String jurisdiction, LocalDate expirationDate) {
        this.statuteName = statuteName;
        this.jurisdiction = jurisdiction;
        this.expirationDate = expirationDate;
    }

    public String getStatuteName() {
        return statuteName;
    }

    public void setStatuteName(String statuteName) {
        this.statuteName = statuteName;
    }

    public String getJurisdiction() {
        return jurisdiction;
    }

    public void setJurisdiction(String jurisdiction) {
        this.jurisdiction = jurisdiction;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Override
    public String toString() {
        return statuteName + " (" + jurisdiction + "), Expires: " + expirationDate;
    }
}
