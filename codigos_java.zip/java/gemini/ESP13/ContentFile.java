import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ContentFile {
    private final String id;
    private String fileName;
    private long fileSize; // in bytes
    private final LocalDateTime creationDate;
    private String fileFormat;
    private String formatVersion;
    private String checksum;
    private final String checksumAlgorithm;
    private String originalChecksum;
    private String sourceCaptureHardware;
    private String sourceCaptureSoftware;
    private boolean isMaster;
    private boolean integrityQuestioned;
    private final List<DamsEvent> lifecycleEvents = new ArrayList<>();

    public ContentFile(String id, String fileName, long fileSize, LocalDateTime creationDate,
                       String fileFormat, String formatVersion, String checksum, String checksumAlgorithm,
                       boolean isMaster) {
        this.id = id;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.creationDate = creationDate;
        this.fileFormat = fileFormat;
        this.formatVersion = formatVersion;
        this.checksum = checksum;
        this.originalChecksum = checksum;
        this.checksumAlgorithm = checksumAlgorithm;
        this.isMaster = isMaster;
        this.integrityQuestioned = false;
    }

    public String getId() {
        return id;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public String getFileFormat() {
        return fileFormat;
    }

    public void setFileFormat(String fileFormat, String formatVersion) {
        this.fileFormat = fileFormat;
        this.formatVersion = formatVersion;
    }

    public String getFormatVersion() {
        return formatVersion;
    }

    public String getChecksum() {
        return checksum;
    }

    public String getChecksumAlgorithm() {
        return checksumAlgorithm;
    }

    public String getOriginalChecksum() {
        return originalChecksum;
    }

    public boolean isMaster() {
        return isMaster;
    }

    public boolean isChecksumChanged() {
        return originalChecksum != null && !originalChecksum.equals(checksum);
    }

    public void updateChecksum(String newChecksum) {
        this.checksum = newChecksum;
        if (!this.checksum.equals(this.originalChecksum)) {
            this.integrityQuestioned = true;
        }
    }

    public boolean isIntegrityQuestioned() {
        return integrityQuestioned || isChecksumChanged();
    }

    public void setIntegrityQuestioned(boolean integrityQuestioned) {
        this.integrityQuestioned = integrityQuestioned;
    }

    public String getSourceCaptureHardware() {
        return sourceCaptureHardware;
    }

    public void setSourceCaptureHardware(String sourceCaptureHardware) {
        this.sourceCaptureHardware = sourceCaptureHardware;
    }

    public String getSourceCaptureSoftware() {
        return sourceCaptureSoftware;
    }

    public void setSourceCaptureSoftware(String sourceCaptureSoftware) {
        this.sourceCaptureSoftware = sourceCaptureSoftware;
    }

    public void setSourceCaptureInfo(String hardware, String software) {
        this.sourceCaptureHardware = hardware;
        this.sourceCaptureSoftware = software;
    }

    public List<DamsEvent> getLifecycleEvents() {
        return lifecycleEvents;
    }

    public void recordEvent(DamsEvent event) {
        lifecycleEvents.add(event);
    }

    @Override
    public String toString() {
        return "ContentFile[id=" + id + ", name=" + fileName + ", size=" + fileSize + " bytes, format=" + fileFormat + " " + formatVersion + "]";
    }
}
