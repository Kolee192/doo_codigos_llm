public class NameAssociation {
    private final String name;
    private final String role; // e.g. "creator", "source", "subject", "illustrator", "photographer"

    public NameAssociation(String name, String role) {
        this.name = name;
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    @Override
    public String toString() {
        return name + " (" + role + ")";
    }
}
