import java.time.LocalDate;

public class CopyrightStatus {
    private boolean underCopyright;
    private String rightsHolder;
    private LocalDate copyrightExpirationDate;
    private String jurisdictionStatute;

    public CopyrightStatus(boolean underCopyright, String rightsHolder, LocalDate copyrightExpirationDate, String jurisdictionStatute) {
        this.underCopyright = underCopyright;
        this.rightsHolder = rightsHolder;
        this.copyrightExpirationDate = copyrightExpirationDate;
        this.jurisdictionStatute = jurisdictionStatute;
    }

    public boolean isUnderCopyright() {
        return underCopyright;
    }

    public void setUnderCopyright(boolean underCopyright) {
        this.underCopyright = underCopyright;
    }

    public String getRightsHolder() {
        return rightsHolder;
    }

    public void setRightsHolder(String rightsHolder) {
        this.rightsHolder = rightsHolder;
    }

    public LocalDate getCopyrightExpirationDate() {
        return copyrightExpirationDate;
    }

    public void setCopyrightExpirationDate(LocalDate copyrightExpirationDate) {
        this.copyrightExpirationDate = copyrightExpirationDate;
    }

    public String getJurisdictionStatute() {
        return jurisdictionStatute;
    }

    public void setJurisdictionStatute(String jurisdictionStatute) {
        this.jurisdictionStatute = jurisdictionStatute;
    }

    @Override
    public String toString() {
        return "UnderCopyright: " + underCopyright + ", Holder: " + rightsHolder + ", Expires: " + copyrightExpirationDate + ", Statute: " + jurisdictionStatute;
    }
}
