public class User {
    private final String id;
    private final String name;
    private final UserRole role;
    private final String unitId; // library unit / repository id if applicable

    public User(String id, String name, UserRole role, String unitId) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.unitId = unitId;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public UserRole getRole() {
        return role;
    }

    public String getUnitId() {
        return unitId;
    }

    public boolean canCurateUnit(String targetUnitId) {
        if (role == UserRole.DAMS_MANAGER) {
            return true;
        }
        if ((role == UserRole.REPOSITORY_MANAGER || role == UserRole.REPOSITORY_STAFF) &&
                unitId != null && unitId.equals(targetUnitId)) {
            return true;
        }
        return false;
    }
}
