import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DigitalCollection {
    public enum CompositionType {
        SHARED_PROVENANCE,
        PART_OF_SINGLE_PROVENANCE,
        ASSEMBLED
    }

    private final String id;
    private final String repositoryId;
    private final boolean formalCollection;
    private CompositionType compositionType;
    private String provenance;

    private final Map<String, String> titles = new HashMap<>(); // form -> title
    private String inclusiveDates;
    private String bulkDates;
    private final List<String> languages = new ArrayList<>();
    private final List<NameAssociation> names = new ArrayList<>();
    private final List<SubjectHeading> subjects = new ArrayList<>();
    private final Map<String, String> notes = new HashMap<>();
    private GeoCoordinates geoCoordinates;
    private final List<ExternalDescription> externalDescriptions = new ArrayList<>();

    private final List<String> relatedCollectionIds = new ArrayList<>();
    private final List<String> memberCollectionIds = new ArrayList<>();
    private final List<String> memberObjectIds = new ArrayList<>();
    private final List<DamsEvent> lifecycleEvents = new ArrayList<>();

    public DigitalCollection(String id, String repositoryId, String primaryTitle, boolean formalCollection, CompositionType compositionType, String provenance) {
        this.id = id;
        this.repositoryId = repositoryId;
        this.formalCollection = formalCollection;
        this.compositionType = compositionType;
        this.provenance = provenance;
        this.titles.put("primary", primaryTitle);
    }

    public String getId() {
        return id;
    }

    public String getRepositoryId() {
        return repositoryId;
    }

    public boolean isFormalCollection() {
        return formalCollection;
    }

    public CompositionType getCompositionType() {
        return compositionType;
    }

    public void setCompositionType(CompositionType compositionType) {
        this.compositionType = compositionType;
    }

    public String getProvenance() {
        return provenance;
    }

    public void setProvenance(String provenance) {
        this.provenance = provenance;
    }

    public String getPrimaryTitle() {
        return titles.getOrDefault("primary", titles.values().stream().findFirst().orElse("Untitled Collection"));
    }

    public Map<String, String> getTitles() {
        return titles;
    }

    public void setTitle(String form, String title) {
        this.titles.put(form, title);
    }

    public String getInclusiveDates() {
        return inclusiveDates;
    }

    public void setInclusiveDates(String inclusiveDates) {
        this.inclusiveDates = inclusiveDates;
    }

    public String getBulkDates() {
        return bulkDates;
    }

    public void setBulkDates(String bulkDates) {
        this.bulkDates = bulkDates;
    }

    public List<String> getLanguages() {
        return languages;
    }

    public void addLanguage(String language) {
        if (!languages.contains(language)) {
            languages.add(language);
        }
    }

    public List<NameAssociation> getNames() {
        return names;
    }

    public void addName(NameAssociation name) {
        this.names.add(name);
    }

    public List<SubjectHeading> getSubjects() {
        return subjects;
    }

    public void addSubject(SubjectHeading subject) {
        this.subjects.add(subject);
    }

    public Map<String, String> getNotes() {
        return notes;
    }

    public void putNote(String facet, String note) {
        this.notes.put(facet, note);
    }

    public GeoCoordinates getGeoCoordinates() {
        return geoCoordinates;
    }

    public void setGeoCoordinates(GeoCoordinates geoCoordinates) {
        this.geoCoordinates = geoCoordinates;
    }

    public List<ExternalDescription> getExternalDescriptions() {
        return externalDescriptions;
    }

    public void addExternalDescription(ExternalDescription externalDescription) {
        this.externalDescriptions.add(externalDescription);
    }

    public List<String> getRelatedCollectionIds() {
        return relatedCollectionIds;
    }

    public void addRelatedCollection(String otherCollectionId) {
        if (!relatedCollectionIds.contains(otherCollectionId) && !otherCollectionId.equals(this.id)) {
            relatedCollectionIds.add(otherCollectionId);
        }
    }

    public List<String> getMemberCollectionIds() {
        return memberCollectionIds;
    }

    public void addMemberCollection(String subCollectionId) {
        if (!memberCollectionIds.contains(subCollectionId)) {
            memberCollectionIds.add(subCollectionId);
        }
    }

    public List<String> getMemberObjectIds() {
        return memberObjectIds;
    }

    public void addMemberObject(String objectId) {
        if (!memberObjectIds.contains(objectId)) {
            memberObjectIds.add(objectId);
        }
    }

    public List<DamsEvent> getLifecycleEvents() {
        return lifecycleEvents;
    }

    public void recordEvent(DamsEvent event) {
        this.lifecycleEvents.add(event);
    }

    @Override
    public String toString() {
        return "DigitalCollection[id=" + id + ", title=" + getPrimaryTitle() + ", repo=" + repositoryId + "]";
    }
}
