public class MockExternalSocialClient implements ExternalServiceAuthenticator, ExternalServiceClient {
    private final String serviceName;

    public MockExternalSocialClient(String serviceName) {
        this.serviceName = serviceName;
    }

    @Override
    public String getServiceName() {
        return serviceName;
    }

    @Override
    public boolean authenticate(User user, ExternalServiceAccount account, String credential) {
        if (account == null || credential == null || credential.isBlank()) {
            return false;
        }
        boolean success = credential.startsWith("valid_auth_token");
        account.setAuthenticated(success);
        return success;
    }

    @Override
    public boolean publish(ExternalServiceAccount account, Content content) {
        if (account == null || !account.isAuthenticated()) {
            System.out.println("[" + serviceName + "] Cannot publish: external account is not authenticated.");
            return false;
        }
        System.out.println("[" + serviceName + "] Successfully published content (" + content.getTitle() + ") to " + account.getUsername());
        return true;
    }
}
