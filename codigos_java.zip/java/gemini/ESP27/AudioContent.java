public class AudioContent extends Content {
    private String audioUrl;
    private int durationSeconds;

    public AudioContent(String id, String title, String audioUrl, int durationSeconds) {
        super(id, title, ContentType.AUDIO);
        this.audioUrl = audioUrl != null ? audioUrl : "";
        this.durationSeconds = Math.max(durationSeconds, 0);
    }

    public String getAudioUrl() {
        return audioUrl;
    }

    public void setAudioUrl(String audioUrl) {
        this.audioUrl = audioUrl != null ? audioUrl : "";
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    public void setDurationSeconds(int durationSeconds) {
        this.durationSeconds = Math.max(durationSeconds, 0);
    }

    @Override
    public String getPayloadSummary() {
        return "Audio(url=" + audioUrl + ", duration=" + durationSeconds + "s)";
    }
}
