import java.util.Objects;

public abstract class Content {
    private final String id;
    private String title;
    private final ContentType type;

    public Content(String id, String title, ContentType type) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Content ID cannot be empty");
        if (title == null || title.isBlank()) throw new IllegalArgumentException("Content title cannot be empty");
        if (type == null) throw new IllegalArgumentException("Content type cannot be null");
        this.id = id;
        this.title = title;
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.isBlank()) throw new IllegalArgumentException("Content title cannot be empty");
        this.title = title;
    }

    public ContentType getType() {
        return type;
    }

    public abstract String getPayloadSummary();

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Content content = (Content) o;
        return Objects.equals(id, content.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Content[" + type + "]{id='" + id + "', title='" + title + "', payload=" + getPayloadSummary() + "}";
    }
}
