import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class CampaignSchedule {
    private final Map<LocalDateTime, List<CampaignAction>> scheduleMap = new TreeMap<>();

    public synchronized void scheduleAction(LocalDateTime time, CampaignAction action) {
        if (time == null || action == null) {
            throw new IllegalArgumentException("Time and action cannot be null");
        }
        scheduleMap.computeIfAbsent(time, k -> new ArrayList<>()).add(action);
        action.setStatus(ActionStatus.SCHEDULED);
        action.setExecutionTimestamp(time);
    }

    public synchronized Map<LocalDateTime, List<CampaignAction>> getSchedule() {
        Map<LocalDateTime, List<CampaignAction>> view = new TreeMap<>();
        for (Map.Entry<LocalDateTime, List<CampaignAction>> entry : scheduleMap.entrySet()) {
            view.put(entry.getKey(), Collections.unmodifiableList(entry.getValue()));
        }
        return Collections.unmodifiableMap(view);
    }

    public synchronized List<CampaignAction> pollDueActions(LocalDateTime currentTime) {
        List<CampaignAction> dueActions = new ArrayList<>();
        List<LocalDateTime> dueTimes = new ArrayList<>();
        for (Map.Entry<LocalDateTime, List<CampaignAction>> entry : scheduleMap.entrySet()) {
            if (!entry.getKey().isAfter(currentTime)) {
                dueActions.addAll(entry.getValue());
                dueTimes.add(entry.getKey());
            }
        }
        for (LocalDateTime time : dueTimes) {
            scheduleMap.remove(time);
        }
        return dueActions;
    }
}
