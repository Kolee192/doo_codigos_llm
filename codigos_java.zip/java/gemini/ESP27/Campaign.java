import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Campaign {
    private final String id;
    private String name;
    private final Product product;
    private final List<Content> contents = new ArrayList<>();
    private final CampaignSchedule schedule = new CampaignSchedule();
    private final Set<String> allowedUsers = new HashSet<>();
    private final Set<String> allowedGroups = new HashSet<>();

    public Campaign(String id, String name, Product product) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Campaign ID cannot be empty");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Campaign name cannot be empty");
        if (product == null) throw new IllegalArgumentException("Campaign product cannot be null");
        this.id = id;
        this.name = name;
        this.product = product;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Campaign name cannot be empty");
        this.name = name;
    }

    public Product getProduct() {
        return product;
    }

    public synchronized void addContent(Content content) {
        if (content != null && !contents.contains(content)) {
            contents.add(content);
        }
    }

    public synchronized boolean removeContent(Content content) {
        return contents.remove(content);
    }

    public synchronized List<Content> getContents() {
        return Collections.unmodifiableList(new ArrayList<>(contents));
    }

    public CampaignSchedule getSchedule() {
        return schedule;
    }

    public synchronized void allowUser(String username) {
        if (username != null && !username.isBlank()) {
            allowedUsers.add(username);
        }
    }

    public synchronized void allowGroup(String groupName) {
        if (groupName != null && !groupName.isBlank()) {
            allowedGroups.add(groupName);
        }
    }

    public synchronized boolean hasAccess(User user) {
        if (user == null) return false;
        if (user.getAccountType() == UserAccountType.SYSTEM_ADMINISTRATOR) return true;
        return allowedUsers.contains(user.getUsername()) || allowedGroups.contains(user.getGroupMembership());
    }

    public synchronized Set<String> getAllowedUsers() {
        return Collections.unmodifiableSet(new HashSet<>(allowedUsers));
    }

    public synchronized Set<String> getAllowedGroups() {
        return Collections.unmodifiableSet(new HashSet<>(allowedGroups));
    }
}
