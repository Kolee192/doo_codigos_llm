public class TextContent extends Content {
    private String body;

    public TextContent(String id, String title, String body) {
        super(id, title, ContentType.TEXT);
        this.body = body != null ? body : "";
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body != null ? body : "";
    }

    @Override
    public String getPayloadSummary() {
        return "\"" + (body.length() > 30 ? body.substring(0, 27) + "..." : body) + "\"";
    }
}
