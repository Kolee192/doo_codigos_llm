import java.util.Objects;

public class Product {
    private final String id;
    private final String name;

    public Product(String id, String name) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Product ID cannot be empty");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Product name cannot be empty");
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return Objects.equals(id, product.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Product{" + "id='" + id + '\'' + ", name='" + name + '\'' + '}';
    }
}
