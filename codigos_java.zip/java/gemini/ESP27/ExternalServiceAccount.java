import java.util.Objects;

public class ExternalServiceAccount {
    private final String serviceName;
    private final String externalAccountId;
    private final String username;
    private boolean authenticated;

    public ExternalServiceAccount(String serviceName, String externalAccountId, String username) {
        if (serviceName == null || serviceName.isBlank()) throw new IllegalArgumentException("Service name cannot be empty");
        if (externalAccountId == null || externalAccountId.isBlank()) throw new IllegalArgumentException("Account ID cannot be empty");
        this.serviceName = serviceName;
        this.externalAccountId = externalAccountId;
        this.username = username != null ? username : externalAccountId;
        this.authenticated = false;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getExternalAccountId() {
        return externalAccountId;
    }

    public String getUsername() {
        return username;
    }

    public boolean isAuthenticated() {
        return authenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        this.authenticated = authenticated;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExternalServiceAccount that = (ExternalServiceAccount) o;
        return Objects.equals(serviceName, that.serviceName) && Objects.equals(externalAccountId, that.externalAccountId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(serviceName, externalAccountId);
    }

    @Override
    public String toString() {
        return serviceName + ":" + username + (authenticated ? " [Authenticated]" : " [Unauthenticated]");
    }
}
