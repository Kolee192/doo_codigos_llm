public enum UserAccountType {
    STANDARD,
    SYSTEM_ADMINISTRATOR
}
