import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MashbotSystem {
    private final Map<String, User> users = new HashMap<>();
    private final Set<String> activeSessions = new HashSet<>();
    private final Map<String, Product> products = new HashMap<>();
    private final Map<String, Campaign> campaigns = new HashMap<>();
    private final Map<String, ExternalServiceClient> externalClients = new HashMap<>();
    private final Map<String, ExternalServiceAuthenticator> externalAuthenticators = new HashMap<>();

    public MashbotSystem() {
    }

    public synchronized User registerUser(String username, String password, String name, String email,
                                          String groupMembership, UserAccountType accountType) {
        if (users.containsKey(username)) {
            throw new IllegalArgumentException("User with username " + username + " already exists.");
        }
        User newUser = new User(username, password, name, email, groupMembership, accountType);
        users.put(username, newUser);
        return newUser;
    }

    public synchronized boolean login(String username, String password) {
        User user = users.get(username);
        if (user == null) {
            return false;
        }
        if (!user.isActive()) {
            return false;
        }
        if (user.getPassword().equals(password)) {
            activeSessions.add(username);
            return true;
        }
        return false;
    }

    public synchronized void logout(String username) {
        activeSessions.remove(username);
    }

    public synchronized boolean isUserLoggedIn(String username) {
        return activeSessions.contains(username);
    }

    private void ensureLoggedIn(String username) {
        if (!isUserLoggedIn(username)) {
            throw new SecurityException("User " + username + " must be logged in to perform this operation.");
        }
    }

    public synchronized void modifyUserProfile(String loggedInUsername, String newName, String newEmail) {
        ensureLoggedIn(loggedInUsername);
        User user = users.get(loggedInUsername);
        if (user == null || !user.isActive()) {
            throw new IllegalStateException("User account is inactive or not found.");
        }
        if (newName != null && !newName.isBlank()) {
            user.setName(newName);
        }
        if (newEmail != null && !newEmail.isBlank()) {
            user.setEmail(newEmail);
        }
    }

    public synchronized void resetPassword(String loggedInUsername, String oldPassword, String newPassword) {
        ensureLoggedIn(loggedInUsername);
        User user = users.get(loggedInUsername);
        if (user == null || !user.isActive()) {
            throw new IllegalStateException("User account is inactive or not found.");
        }
        if (!user.getPassword().equals(oldPassword)) {
            throw new IllegalArgumentException("Incorrect current password.");
        }
        user.setPassword(newPassword);
    }

    public synchronized boolean deactivateUser(String targetUsername) {
        User target = users.get(targetUsername);
        if (target == null) {
            throw new IllegalArgumentException("User " + targetUsername + " not found.");
        }
        if (target.getAccountType() == UserAccountType.SYSTEM_ADMINISTRATOR) {
            throw new UnsupportedOperationException("Cannot deactivate System Administrator account.");
        }
        target.setActive(false);
        activeSessions.remove(targetUsername);
        return true;
    }

    public synchronized boolean undisableUser(String targetUsername) {
        User target = users.get(targetUsername);
        if (target == null) {
            throw new IllegalArgumentException("User " + targetUsername + " not found.");
        }
        target.setActive(true);
        return true;
    }

    public synchronized boolean deleteUser(String targetUsername) {
        User target = users.get(targetUsername);
        if (target == null) {
            throw new IllegalArgumentException("User " + targetUsername + " not found.");
        }
        if (target.getAccountType() == UserAccountType.SYSTEM_ADMINISTRATOR) {
            throw new UnsupportedOperationException("Cannot delete System Administrator account.");
        }
        if (target.hasHistory()) {
            throw new IllegalStateException("Cannot delete user with existing history. Deactivate instead.");
        }
        users.remove(targetUsername);
        activeSessions.remove(targetUsername);
        return true;
    }

    public synchronized void registerProduct(Product product) {
        if (product != null) {
            products.put(product.getId(), product);
        }
    }

    public synchronized Product getProduct(String id) {
        return products.get(id);
    }

    public synchronized void registerCampaign(Campaign campaign) {
        if (campaign != null) {
            campaigns.put(campaign.getId(), campaign);
        }
    }

    public synchronized Campaign getCampaign(String id) {
        return campaigns.get(id);
    }

    public synchronized void registerExternalService(ExternalServiceClient client, ExternalServiceAuthenticator authenticator) {
        if (client != null) {
            externalClients.put(client.getServiceName(), client);
        }
        if (authenticator != null && client != null) {
            externalAuthenticators.put(client.getServiceName(), authenticator);
        }
    }

    public synchronized boolean authenticateExternalAccount(String username, ExternalServiceAccount account, String credential) {
        ensureLoggedIn(username);
        User user = users.get(username);
        ExternalServiceAuthenticator authenticator = externalAuthenticators.get(account.getServiceName());
        if (authenticator == null) {
            throw new IllegalArgumentException("No authenticator registered for service: " + account.getServiceName());
        }
        boolean success = authenticator.authenticate(user, account, credential);
        if (success) {
            user.linkExternalAccount(account);
        }
        return success;
    }

    public synchronized CampaignAction createContent(String username, Campaign campaign, Content content) {
        ensureLoggedIn(username);
        User user = users.get(username);
        validateCampaignAccess(user, campaign);
        if (!user.hasRole(campaign.getProduct(), AccountRole.CONTRIBUTOR)) {
            throw new SecurityException("User must have CONTRIBUTOR role on product " + campaign.getProduct().getName());
        }

        campaign.addContent(content);
        CampaignAction action = new CampaignAction(UUID.randomUUID().toString(), ActionType.CREATE, content, username);
        user.addHistory("Created content: " + content.getTitle() + " in campaign " + campaign.getName());
        return action;
    }

    public synchronized CampaignAction importContent(String username, Campaign campaign, Content existingContent) {
        ensureLoggedIn(username);
        User user = users.get(username);
        validateCampaignAccess(user, campaign);
        if (!user.hasRole(campaign.getProduct(), AccountRole.CONTRIBUTOR)) {
            throw new SecurityException("User must have CONTRIBUTOR role on product " + campaign.getProduct().getName());
        }

        campaign.addContent(existingContent);
        CampaignAction action = new CampaignAction(UUID.randomUUID().toString(), ActionType.IMPORT, existingContent, username);
        user.addHistory("Imported content: " + existingContent.getTitle() + " into campaign " + campaign.getName());
        return action;
    }

    public synchronized CampaignAction editContent(String username, Campaign campaign, Content content, String newTitle) {
        ensureLoggedIn(username);
        User user = users.get(username);
        validateCampaignAccess(user, campaign);
        if (!user.hasRole(campaign.getProduct(), AccountRole.CONTRIBUTOR)) {
            throw new SecurityException("User must have CONTRIBUTOR role on product " + campaign.getProduct().getName());
        }
        content.setTitle(newTitle);
        CampaignAction action = new CampaignAction(UUID.randomUUID().toString(), ActionType.EDIT, content, username);
        user.addHistory("Edited content: " + content.getId() + " new title " + newTitle);
        return action;
    }

    public synchronized CampaignAction deleteContent(String username, Campaign campaign, Content content) {
        ensureLoggedIn(username);
        User user = users.get(username);
        validateCampaignAccess(user, campaign);
        if (!user.hasRole(campaign.getProduct(), AccountRole.CONTRIBUTOR)) {
            throw new SecurityException("User must have CONTRIBUTOR role on product " + campaign.getProduct().getName());
        }
        campaign.removeContent(content);
        CampaignAction action = new CampaignAction(UUID.randomUUID().toString(), ActionType.DELETE, content, username);
        user.addHistory("Deleted content: " + content.getTitle());
        return action;
    }

    public synchronized void submitActionForApproval(String username, Campaign campaign, CampaignAction action) {
        ensureLoggedIn(username);
        User user = users.get(username);
        validateCampaignAccess(user, campaign);
        if (!user.hasRole(campaign.getProduct(), AccountRole.CONTRIBUTOR)) {
            throw new SecurityException("Only contributors can submit actions for approval.");
        }
        action.setStatus(ActionStatus.SUBMITTED_FOR_APPROVAL);
        user.addHistory("Submitted action " + action.getId() + " for approval");
    }

    public synchronized void approveAction(String username, Campaign campaign, CampaignAction action) {
        ensureLoggedIn(username);
        User user = users.get(username);
        validateCampaignAccess(user, campaign);
        if (!user.hasRole(campaign.getProduct(), AccountRole.APPROVER)) {
            throw new SecurityException("User must have APPROVER role on product " + campaign.getProduct().getName());
        }
        if (action.getStatus() != ActionStatus.SUBMITTED_FOR_APPROVAL) {
            throw new IllegalStateException("Action is not awaiting approval.");
        }
        action.setStatus(ActionStatus.APPROVED);
        action.setApproverUsername(username);
        user.addHistory("Approved action " + action.getId());
    }

    public synchronized void scheduleAction(String username, Campaign campaign, CampaignAction action, LocalDateTime scheduledTime) {
        ensureLoggedIn(username);
        User user = users.get(username);
        validateCampaignAccess(user, campaign);
        if (!user.hasRole(campaign.getProduct(), AccountRole.PUBLISHER)) {
            throw new SecurityException("User must have PUBLISHER role on product " + campaign.getProduct().getName());
        }
        if (action.getStatus() != ActionStatus.APPROVED && action.getStatus() != ActionStatus.DRAFT) {
            throw new IllegalStateException("Only approved or initiated actions can be scheduled.");
        }
        campaign.getSchedule().scheduleAction(scheduledTime, action);
        user.addHistory("Scheduled action " + action.getId() + " for " + scheduledTime);
    }

    public synchronized boolean initiateActionImmediately(String username, Campaign campaign, CampaignAction action,
                                                          ExternalServiceAccount externalAccount) {
        ensureLoggedIn(username);
        User user = users.get(username);
        validateCampaignAccess(user, campaign);
        if (!user.hasRole(campaign.getProduct(), AccountRole.PUBLISHER)) {
            throw new SecurityException("User must have PUBLISHER role on product " + campaign.getProduct().getName());
        }
        if (action.getStatus() != ActionStatus.APPROVED && action.getStatus() != ActionStatus.DRAFT) {
            throw new IllegalStateException("Action is not approved or initiated for publishing.");
        }

        ExternalServiceClient client = externalClients.get(externalAccount.getServiceName());
        if (client == null) {
            throw new IllegalArgumentException("No client found for external service: " + externalAccount.getServiceName());
        }
        boolean success = client.publish(externalAccount, action.getTargetContent());
        if (success) {
            action.setStatus(ActionStatus.EXECUTED);
            action.setExecutionTimestamp(LocalDateTime.now());
            user.addHistory("Executed action " + action.getId() + " via " + externalAccount.getServiceName());
        }
        return success;
    }

    public synchronized List<CampaignAction> processScheduledActions(LocalDateTime currentTime, ExternalServiceAccount defaultExternalAccount) {
        List<CampaignAction> processed = new ArrayList<>();
        for (Campaign campaign : campaigns.values()) {
            List<CampaignAction> dueActions = campaign.getSchedule().pollDueActions(currentTime);
            for (CampaignAction action : dueActions) {
                ExternalServiceClient client = externalClients.get(defaultExternalAccount.getServiceName());
                if (client != null && client.publish(defaultExternalAccount, action.getTargetContent())) {
                    action.setStatus(ActionStatus.EXECUTED);
                    processed.add(action);
                }
            }
        }
        return processed;
    }

    private void validateCampaignAccess(User user, Campaign campaign) {
        if (!campaign.hasAccess(user)) {
            throw new SecurityException("User " + user.getUsername() + " does not have permission for campaign " + campaign.getName());
        }
    }

    public User getUser(String username) {
        return users.get(username);
    }

    public List<User> getAllUsers() {
        return Collections.unmodifiableList(new ArrayList<>(users.values()));
    }
}
