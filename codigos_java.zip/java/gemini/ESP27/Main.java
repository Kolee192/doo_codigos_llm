import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Mashbot Campaigns Demonstration ===");

        MashbotSystem system = new MashbotSystem();

        // 1. Setup External Services
        MockExternalSocialClient twitterClient = new MockExternalSocialClient("Twitter");
        MockExternalSocialClient youtubeClient = new MockExternalSocialClient("YouTube");
        system.registerExternalService(twitterClient, twitterClient);
        system.registerExternalService(youtubeClient, youtubeClient);

        // 2. Setup Products and Campaigns
        Product mobileApp = new Product("PROD-01", "Mashbot Mobile App");
        Product webApp = new Product("PROD-02", "Mashbot Web Suite");
        system.registerProduct(mobileApp);
        system.registerProduct(webApp);

        Campaign summerCampaign = new Campaign("CAMP-01", "Summer Launch 2025", mobileApp);
        summerCampaign.allowGroup("Marketing");
        summerCampaign.allowUser("charlie_contributor");
        summerCampaign.allowUser("alice_approver");
        summerCampaign.allowUser("peter_publisher");
        system.registerCampaign(summerCampaign);

        // 3. User Creation (0240 - 0320)
        User admin = system.registerUser(
                "sysadmin", "AdminPass123", "System Administrator", "admin@mashbot.com",
                "Administration", UserAccountType.SYSTEM_ADMINISTRATOR
        );
        User contributor = system.registerUser(
                "charlie_contributor", "Pass123!", "Charlie Writer", "charlie@mashbot.com",
                "Marketing", UserAccountType.STANDARD
        );
        User approver = system.registerUser(
                "alice_approver", "Pass123!", "Alice Lead", "alice@mashbot.com",
                "Marketing", UserAccountType.STANDARD
        );
        User publisher = system.registerUser(
                "peter_publisher", "Pass123!", "Peter Distribution", "peter@mashbot.com",
                "Marketing", UserAccountType.STANDARD
        );
        User temporaryUser = system.registerUser(
                "temp_user", "TempPass123", "Temporary User", "temp@mashbot.com",
                "Guest", UserAccountType.STANDARD
        );

        // 4. Role Assignments for Individual Products (0140 - 0200)
        contributor.assignRole(mobileApp, AccountRole.CONTRIBUTOR);
        approver.assignRole(mobileApp, AccountRole.APPROVER);
        publisher.assignRole(mobileApp, AccountRole.PUBLISHER);

        // 5. User Account Modification and Password Change (0330 - 0370, 0440 - 0470)
        system.login("charlie_contributor", "Pass123!");
        system.modifyUserProfile("charlie_contributor", "Charlie Senior Writer", "charlie.sr@mashbot.com");
        system.resetPassword("charlie_contributor", "Pass123!", "NewSecretPass456!");
        system.logout("charlie_contributor");

        // Verify login with new password
        boolean reloginSuccess = system.login("charlie_contributor", "NewSecretPass456!");
        System.out.println("Charlie re-login with updated password: " + (reloginSuccess ? "SUCCESS" : "FAILED"));

        // 6. Content Creation & Import (0210, 0540 - 0580)
        Content textArticle = new TextContent("C-001", "Mobile App Launch Article", "Experience the new era of marketing.");
        Content bannerImage = new ImageContent("C-002", "App Banner", "https://mashbot.cdn/banner.png", "1920x1080");
        Content promoAudio = new AudioContent("C-003", "Podcast Jingle", "https://mashbot.cdn/jingle.mp3", 30);
        Content launchVideo = new VideoContent("C-004", "Feature Video", "https://mashbot.cdn/feature.mp4", "mp4", 120);

        CampaignAction action1 = system.createContent("charlie_contributor", summerCampaign, textArticle);
        CampaignAction action2 = system.importContent("charlie_contributor", summerCampaign, bannerImage);
        CampaignAction action3 = system.createContent("charlie_contributor", summerCampaign, launchVideo);

        System.out.println("Campaign Contents: " + summerCampaign.getContents());

        // 7. Contributor Submits for Approval (0210)
        system.submitActionForApproval("charlie_contributor", summerCampaign, action1);
        system.submitActionForApproval("charlie_contributor", summerCampaign, action3);
        system.logout("charlie_contributor");

        // 8. Approver Approves Content (0220)
        system.login("alice_approver", "Pass123!");
        system.approveAction("alice_approver", summerCampaign, action1);
        system.approveAction("alice_approver", summerCampaign, action3);
        System.out.println("Action 1 status after Alice approval: " + action1.getStatus());
        system.logout("alice_approver");

        // 9. External Service Account Linking and Authentication (0590 - 0610)
        system.login("peter_publisher", "Pass123!");
        ExternalServiceAccount twitterAccount = new ExternalServiceAccount("Twitter", "tw_101", "@MashbotOfficial");
        boolean authResult = system.authenticateExternalAccount("peter_publisher", twitterAccount, "valid_auth_token_xyz");
        System.out.println("External account authentication status: " + authResult);

        // 10. Publisher Publishes Immediately and Schedules Future Actions (0230, 0480 - 0530)
        system.initiateActionImmediately("peter_publisher", summerCampaign, action1, twitterAccount);

        LocalDateTime scheduledTime = LocalDateTime.now().plusHours(2);
        system.scheduleAction("peter_publisher", summerCampaign, action3, scheduledTime);
        System.out.println("Campaign Scheduled Items Count: " + summerCampaign.getSchedule().getSchedule().size());

        // Process scheduled actions simulating arrival at schedule time
        System.out.println("Simulating arrival at scheduled time...");
        var processedActions = system.processScheduledActions(scheduledTime.plusMinutes(1), twitterAccount);
        System.out.println("Processed scheduled actions count: " + processedActions.size());
        system.logout("peter_publisher");

        // 11. Account Deactivation vs Deletion (0380 - 0430)
        System.out.println("\n--- Testing Deactivation, Undisable, and Deletion Policies ---");

        // Charlie has history -> Cannot delete, only deactivate
        try {
            system.deleteUser("charlie_contributor");
            System.out.println("ERROR: Deleted user with history!");
        } catch (IllegalStateException e) {
            System.out.println("Expected rejection: " + e.getMessage());
        }

        // Deactivating Charlie
        system.deactivateUser("charlie_contributor");
        boolean charlieLoginWhenDeactivated = system.login("charlie_contributor", "NewSecretPass456!");
        System.out.println("Deactivated Charlie login allowed? " + charlieLoginWhenDeactivated);

        // Undisabling Charlie
        system.undisableUser("charlie_contributor");
        boolean charlieLoginReenabled = system.login("charlie_contributor", "NewSecretPass456!");
        System.out.println("Re-enabled Charlie login allowed? " + charlieLoginReenabled);
        system.logout("charlie_contributor");

        // Deleting user without history -> Should succeed
        boolean tempDeleted = system.deleteUser("temp_user");
        System.out.println("User without history deleted successfully: " + tempDeleted);

        // Testing System Administrator protection
        try {
            system.deactivateUser("sysadmin");
            System.out.println("ERROR: Deactivated Admin!");
        } catch (UnsupportedOperationException e) {
            System.out.println("Expected rejection: " + e.getMessage());
        }

        System.out.println("\nAll demonstration scenarios completed successfully!");
    }
}
