public enum AccountRole {
    CONTRIBUTOR,
    APPROVER,
    PUBLISHER
}
