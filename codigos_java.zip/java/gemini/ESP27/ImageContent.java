public class ImageContent extends Content {
    private String imageUrl;
    private String resolution;

    public ImageContent(String id, String title, String imageUrl, String resolution) {
        super(id, title, ContentType.IMAGE);
        this.imageUrl = imageUrl != null ? imageUrl : "";
        this.resolution = resolution != null ? resolution : "unknown";
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl != null ? imageUrl : "";
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution != null ? resolution : "unknown";
    }

    @Override
    public String getPayloadSummary() {
        return "Image(url=" + imageUrl + ", res=" + resolution + ")";
    }
}
