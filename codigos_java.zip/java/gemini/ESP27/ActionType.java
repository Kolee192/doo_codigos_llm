public enum ActionType {
    CREATE,
    IMPORT,
    EDIT,
    DELETE,
    PUBLISH
}
