public enum ActionStatus {
    DRAFT,
    SUBMITTED_FOR_APPROVAL,
    APPROVED,
    REJECTED,
    SCHEDULED,
    EXECUTED
}
