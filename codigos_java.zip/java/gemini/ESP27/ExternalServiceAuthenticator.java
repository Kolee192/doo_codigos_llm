public interface ExternalServiceAuthenticator {
    boolean authenticate(User user, ExternalServiceAccount account, String credential);
}
