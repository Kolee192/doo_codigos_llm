public enum ContentType {
    TEXT,
    IMAGE,
    AUDIO,
    VIDEO
}
