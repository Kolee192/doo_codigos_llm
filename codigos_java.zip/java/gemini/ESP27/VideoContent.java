public class VideoContent extends Content {
    private String videoUrl;
    private String format;
    private int durationSeconds;

    public VideoContent(String id, String title, String videoUrl, String format, int durationSeconds) {
        super(id, title, ContentType.VIDEO);
        this.videoUrl = videoUrl != null ? videoUrl : "";
        this.format = format != null ? format : "mp4";
        this.durationSeconds = Math.max(durationSeconds, 0);
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl != null ? videoUrl : "";
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format != null ? format : "mp4";
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    public void setDurationSeconds(int durationSeconds) {
        this.durationSeconds = Math.max(durationSeconds, 0);
    }

    @Override
    public String getPayloadSummary() {
        return "Video(url=" + videoUrl + ", format=" + format + ", duration=" + durationSeconds + "s)";
    }
}
