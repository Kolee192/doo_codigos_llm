public interface ExternalServiceClient {
    String getServiceName();
    boolean publish(ExternalServiceAccount account, Content content);
}
