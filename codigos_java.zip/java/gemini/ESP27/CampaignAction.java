import java.time.LocalDateTime;

public class CampaignAction {
    private final String id;
    private final ActionType type;
    private final Content targetContent;
    private final String initiatorUsername;
    private final LocalDateTime createdTimestamp;
    private ActionStatus status;
    private String approverUsername;
    private LocalDateTime executionTimestamp;

    public CampaignAction(String id, ActionType type, Content targetContent, String initiatorUsername) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Action ID cannot be empty");
        if (type == null) throw new IllegalArgumentException("ActionType cannot be null");
        if (initiatorUsername == null || initiatorUsername.isBlank()) throw new IllegalArgumentException("Initiator cannot be empty");
        this.id = id;
        this.type = type;
        this.targetContent = targetContent;
        this.initiatorUsername = initiatorUsername;
        this.createdTimestamp = LocalDateTime.now();
        this.status = ActionStatus.DRAFT;
    }

    public String getId() {
        return id;
    }

    public ActionType getType() {
        return type;
    }

    public Content getTargetContent() {
        return targetContent;
    }

    public String getInitiatorUsername() {
        return initiatorUsername;
    }

    public LocalDateTime getCreatedTimestamp() {
        return createdTimestamp;
    }

    public ActionStatus getStatus() {
        return status;
    }

    public void setStatus(ActionStatus status) {
        this.status = status;
    }

    public String getApproverUsername() {
        return approverUsername;
    }

    public void setApproverUsername(String approverUsername) {
        this.approverUsername = approverUsername;
    }

    public LocalDateTime getExecutionTimestamp() {
        return executionTimestamp;
    }

    public void setExecutionTimestamp(LocalDateTime executionTimestamp) {
        this.executionTimestamp = executionTimestamp;
    }

    @Override
    public String toString() {
        return "CampaignAction{" +
                "id='" + id + '\'' +
                ", type=" + type +
                ", content=" + (targetContent != null ? targetContent.getTitle() : "none") +
                ", initiator='" + initiatorUsername + '\'' +
                ", status=" + status +
                ", approver='" + approverUsername + '\'' +
                '}';
    }
}
