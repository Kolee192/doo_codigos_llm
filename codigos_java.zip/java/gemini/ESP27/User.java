import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class User {
    private final String username;
    private String password;
    private String name;
    private String email;
    private String groupMembership;
    private final UserAccountType accountType;
    private boolean active = true;

    private final Map<String, Set<AccountRole>> productRoles = new HashMap<>();
    private final List<String> history = new ArrayList<>();
    private final List<ExternalServiceAccount> externalAccounts = new ArrayList<>();

    public User(String username, String password, String name, String email, String groupMembership, UserAccountType accountType) {
        if (username == null || username.isBlank()) throw new IllegalArgumentException("Username is required");
        if (password == null || password.isBlank()) throw new IllegalArgumentException("Password is required");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name is required");
        if (email == null || email.isBlank()) throw new IllegalArgumentException("Email is required");
        if (groupMembership == null || groupMembership.isBlank()) throw new IllegalArgumentException("Group membership is required");
        if (accountType == null) throw new IllegalArgumentException("Account type is required");

        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.groupMembership = groupMembership;
        this.accountType = accountType;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password == null || password.isBlank()) throw new IllegalArgumentException("Password cannot be empty");
        this.password = password;
        addHistory("Password changed");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name cannot be empty");
        this.name = name;
        addHistory("Name updated to: " + name);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email == null || email.isBlank()) throw new IllegalArgumentException("Email cannot be empty");
        this.email = email;
        addHistory("Email updated to: " + email);
    }

    public String getGroupMembership() {
        return groupMembership;
    }

    public void setGroupMembership(String groupMembership) {
        if (groupMembership == null || groupMembership.isBlank()) throw new IllegalArgumentException("Group membership cannot be empty");
        this.groupMembership = groupMembership;
        addHistory("Group updated to: " + groupMembership);
    }

    public UserAccountType getAccountType() {
        return accountType;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
        addHistory("Account active state changed to: " + active);
    }

    public synchronized void assignRole(Product product, AccountRole role) {
        if (product == null || role == null) return;
        productRoles.computeIfAbsent(product.getId(), k -> EnumSet.noneOf(AccountRole.class)).add(role);
        addHistory("Assigned role " + role + " on product " + product.getName());
    }

    public synchronized void removeRole(Product product, AccountRole role) {
        if (product == null || role == null) return;
        Set<AccountRole> roles = productRoles.get(product.getId());
        if (roles != null) {
            roles.remove(role);
            addHistory("Removed role " + role + " on product " + product.getName());
        }
    }

    public synchronized boolean hasRole(Product product, AccountRole role) {
        if (product == null || role == null) return false;
        Set<AccountRole> roles = productRoles.get(product.getId());
        return roles != null && roles.contains(role);
    }

    public synchronized Set<AccountRole> getRolesForProduct(Product product) {
        if (product == null) return Collections.emptySet();
        Set<AccountRole> roles = productRoles.get(product.getId());
        return roles != null ? Collections.unmodifiableSet(roles) : Collections.emptySet();
    }

    public synchronized void addHistory(String record) {
        if (record != null && !record.isBlank()) {
            history.add(record);
        }
    }

    public synchronized List<String> getHistory() {
        return Collections.unmodifiableList(new ArrayList<>(history));
    }

    public synchronized boolean hasHistory() {
        return !history.isEmpty();
    }

    public synchronized void linkExternalAccount(ExternalServiceAccount account) {
        if (account != null && !externalAccounts.contains(account)) {
            externalAccounts.add(account);
            addHistory("Linked external account: " + account);
        }
    }

    public synchronized List<ExternalServiceAccount> getExternalAccounts() {
        return Collections.unmodifiableList(new ArrayList<>(externalAccounts));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(username, user.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username);
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", group='" + groupMembership + '\'' +
                ", type=" + accountType +
                ", active=" + active +
                '}';
    }
}
