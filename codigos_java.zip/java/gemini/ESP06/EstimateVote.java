import java.time.Instant;

public class EstimateVote {
    private final String estimatorId;
    private Card card;
    private final Instant timestamp;

    public EstimateVote(String estimatorId, Card card) {
        this.estimatorId = estimatorId;
        this.card = card;
        this.timestamp = Instant.now();
    }

    public String getEstimatorId() {
        return estimatorId;
    }

    public Card getCard() {
        return card;
    }

    public void setCard(Card card) {
        this.card = card;
    }

    public Instant getTimestamp() {
        return timestamp;
    }
}
