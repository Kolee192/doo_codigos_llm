import java.time.Duration;
import java.time.Instant;

public class CountdownTimer {
    private static final long DEFAULT_DURATION_SECONDS = 120; // 2 minutes
    private Instant startedAt;
    private boolean isRunning;

    public CountdownTimer() {
        this.isRunning = false;
    }

    public synchronized void start() {
        this.startedAt = Instant.now();
        this.isRunning = true;
    }

    public synchronized void reset() {
        this.startedAt = null;
        this.isRunning = false;
    }

    public synchronized boolean isRunning() {
        if (!isRunning) return false;
        if (getRemainingSeconds() <= 0) {
            isRunning = false;
            return false;
        }
        return true;
    }

    public synchronized long getRemainingSeconds() {
        if (!isRunning || startedAt == null) {
            return DEFAULT_DURATION_SECONDS;
        }
        long elapsed = Duration.between(startedAt, Instant.now()).toSeconds();
        long remaining = DEFAULT_DURATION_SECONDS - elapsed;
        return Math.max(0, remaining);
    }

    public synchronized String getFormattedRemaining() {
        long sec = getRemainingSeconds();
        long minutes = sec / 60;
        long seconds = sec % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
}
