public enum RoundStatus {
    VOTING,
    REVEALED,
    ACCEPTED
}
