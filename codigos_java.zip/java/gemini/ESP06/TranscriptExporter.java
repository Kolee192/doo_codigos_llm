import java.util.List;
import java.util.Map;

public class TranscriptExporter {

    public static String toCsv(Game game) {
        StringBuilder sb = new StringBuilder();
        // UTF-8 CSV header
        sb.append("Story ID,Story Title,Story Description,Round,Estimator Name,Estimate,Final Estimate\n");
        for (Story story : game.getStories()) {
            String finalEst = story.getFinalEstimate() != null ? String.valueOf(story.getFinalEstimate()) : "N/A";
            List<Round> rounds = story.getRounds();
            if (rounds.isEmpty()) {
                sb.append(escapeCsv(story.getId())).append(",")
                        .append(escapeCsv(story.getTitle())).append(",")
                        .append(escapeCsv(story.getDescription())).append(",")
                        .append("0,,,").append(finalEst).append("\n");
            } else {
                for (Round round : rounds) {
                    Map<String, EstimateVote> votes = round.getVotes();
                    for (Estimator estimator : game.getEstimators()) {
                        EstimateVote vote = votes.get(estimator.getId());
                        String voteVal = (vote != null) ? vote.getCard().getLabel() : "No vote";
                        sb.append(escapeCsv(story.getId())).append(",")
                                .append(escapeCsv(story.getTitle())).append(",")
                                .append(escapeCsv(story.getDescription())).append(",")
                                .append(round.getRoundNumber()).append(",")
                                .append(escapeCsv(estimator.getName())).append(",")
                                .append(escapeCsv(voteVal)).append(",")
                                .append(finalEst).append("\n");
                    }
                }
            }
        }
        return sb.toString();
    }

    public static String toAnonymizedCsv(Game game) {
        StringBuilder sb = new StringBuilder();
        sb.append("Story ID,Round,Anonymous Estimator,Vote Value,Final Estimate\n");
        for (Story story : game.getStories()) {
            String finalEst = story.getFinalEstimate() != null ? String.valueOf(story.getFinalEstimate()) : "N/A";
            for (Round round : story.getRounds()) {
                for (Estimator estimator : game.getEstimators()) {
                    EstimateVote vote = round.getVotes().get(estimator.getId());
                    String voteVal = (vote != null) ? String.valueOf(vote.getCard().getValue()) : "none";
                    sb.append(escapeCsv(story.getId())).append(",")
                            .append(round.getRoundNumber()).append(",")
                            .append(escapeCsv(estimator.getAnonymousCode())).append(",")
                            .append(escapeCsv(voteVal)).append(",")
                            .append(finalEst).append("\n");
                }
            }
        }
        return sb.toString();
    }

    public static String toXhtml(Game game, UserAccount moderator) {
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n")
                .append("  \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n")
                .append("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">\n")
                .append("<head>\n")
                .append("  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n")
                .append("  <title>Game Transcript: ").append(escapeXml(game.getName())).append("</title>\n")
                .append("  <style type=\"text/css\">\n")
                .append("    body { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; margin: 30px; background: #fff; color: #222; }\n")
                .append("    h1, h2, h3 { color: #2c3e50; }\n")
                .append("    table { border-collapse: collapse; width: 100%; margin-bottom: 25px; }\n")
                .append("    th, td { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }\n")
                .append("    th { background-color: #f2f2f2; }\n")
                .append("    .estimator-avatar { width: 24px; height: 24px; vertical-align: middle; border-radius: 50%; margin-right: 6px; }\n")
                .append("    .summary-box { background: #f9f9f9; padding: 15px; border-left: 4px solid #3498db; margin-bottom: 20px; }\n")
                .append("  </style>\n")
                .append("</head>\n")
                .append("<body>\n")
                .append("  <h1>Game Transcript: ").append(escapeXml(game.getName())).append("</h1>\n")
                .append("  <div class=\"summary-box\">\n")
                .append("    <p><strong>Description:</strong> ").append(escapeXml(game.getDescription())).append("</p>\n")
                .append("    <p><strong>Scale:</strong> ").append(escapeXml(game.getDeckType().getDisplayName())).append("</p>\n")
                .append("    <p><strong>Date &amp; Time:</strong> ")
                .append(escapeXml(moderator != null ? moderator.formatDateTime(game.getCreatedAt()) : game.getCreatedAt().toString()))
                .append("</p>\n")
                .append("  </div>\n")
                .append("  <h2>Stories and Estimates</h2>\n");

        for (Story story : game.getStories()) {
            sb.append("  <h3>Story: ").append(escapeXml(story.getTitle())).append("</h3>\n")
                    .append("  <p><strong>Description:</strong> <pre>").append(escapeXml(story.getDescription())).append("</pre></p>\n")
                    .append("  <p><strong>Agreed Final Estimate:</strong> ")
                    .append(story.getFinalEstimate() != null ? story.getFinalEstimate() : "Not finalized")
                    .append("</p>\n");

            if (!story.getRounds().isEmpty()) {
                sb.append("  <table>\n")
                        .append("    <thead>\n")
                        .append("      <tr><th>Round</th><th>Estimator</th><th>Estimate Card</th></tr>\n")
                        .append("    </thead>\n")
                        .append("    <tbody>\n");

                for (Round r : story.getRounds()) {
                    for (Estimator est : game.getEstimators()) {
                        EstimateVote vote = r.getVotes().get(est.getId());
                        String voteCard = (vote != null) ? vote.getCard().getLabel() : "-";
                        sb.append("      <tr>\n")
                                .append("        <td>").append(r.getRoundNumber()).append("</td>\n")
                                .append("        <td><img class=\"estimator-avatar\" src=\"").append(escapeXml(est.getAvatarUrl()))
                                .append("\" alt=\"Photo\" /> ").append(escapeXml(est.getName())).append("</td>\n")
                                .append("        <td>").append(escapeXml(voteCard)).append("</td>\n")
                                .append("      </tr>\n");
                    }
                }
                sb.append("    </tbody>\n").append("  </table>\n");
            } else {
                sb.append("  <p><em>No rounds played for this item.</em></p>\n");
            }
        }

        sb.append("</body>\n</html>");
        return sb.toString();
    }

    private static String escapeCsv(String val) {
        if (val == null) return "\"\"";
        return "\"" + val.replace("\"", "\"\"") + "\"";
    }

    private static String escapeXml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }
}
