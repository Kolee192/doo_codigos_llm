import java.time.Instant;
import java.util.*;

public class Round {
    private final int roundNumber;
    private final Map<String, EstimateVote> votes;
    private RoundStatus status;
    private Double acceptedEstimate;
    private final Instant startedAt;
    private Instant endedAt;

    public Round(int roundNumber) {
        this.roundNumber = roundNumber;
        this.votes = new LinkedHashMap<>();
        this.status = RoundStatus.VOTING;
        this.startedAt = Instant.now();
    }

    public int getRoundNumber() {
        return roundNumber;
    }

    public synchronized void recordVote(String estimatorId, Card card) {
        if (status != RoundStatus.VOTING) {
            throw new IllegalStateException("Voting has concluded for this round.");
        }
        EstimateVote vote = votes.get(estimatorId);
        if (vote != null) {
            vote.setCard(card);
        } else {
            votes.put(estimatorId, new EstimateVote(estimatorId, card));
        }
    }

    public synchronized boolean hasVoted(String estimatorId) {
        return votes.containsKey(estimatorId);
    }

    public synchronized Card getVote(String estimatorId) {
        EstimateVote vote = votes.get(estimatorId);
        return vote != null ? vote.getCard() : null;
    }

    public synchronized Map<String, EstimateVote> getVotes() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(votes));
    }

    public synchronized int getVoteCount() {
        return votes.size();
    }

    public synchronized void reveal() {
        if (this.status == RoundStatus.VOTING) {
            this.status = RoundStatus.REVEALED;
        }
    }

    public synchronized boolean isRevealed() {
        return this.status == RoundStatus.REVEALED || this.status == RoundStatus.ACCEPTED;
    }

    public synchronized void acceptEstimate(double estimate) {
        this.acceptedEstimate = estimate;
        this.status = RoundStatus.ACCEPTED;
        this.endedAt = Instant.now();
    }

    public synchronized RoundStatus getStatus() {
        return status;
    }

    public synchronized Double getAcceptedEstimate() {
        return acceptedEstimate;
    }

    public synchronized OptionalDouble calculateAverage() {
        if (votes.isEmpty()) return OptionalDouble.empty();
        return votes.values().stream()
                .mapToDouble(v -> v.getCard().getValue())
                .average();
    }

    public synchronized boolean isUnanimous() {
        if (votes.isEmpty()) return false;
        double first = votes.values().iterator().next().getCard().getValue();
        for (EstimateVote vote : votes.values()) {
            if (Double.compare(vote.getCard().getValue(), first) != 0) {
                return false;
            }
        }
        return true;
    }

    public synchronized Optional<Double> getUnanimousValue() {
        if (isUnanimous()) {
            return Optional.of(votes.values().iterator().next().getCard().getValue());
        }
        return Optional.empty();
    }

    public Instant getStartedAt() {
        return startedAt;
    }

    public Instant getEndedAt() {
        return endedAt;
    }
}
