import java.time.Instant;
import java.util.*;

public class Game {
    public static final int MAX_ESTIMATORS = 15;

    private final String id;
    private final String moderatorUsername;
    private String name;
    private String description;
    private final DeckType deckType;
    private final List<Estimator> estimators;
    private final List<Story> stories;
    private Story currentStory;
    private final CountdownTimer timer;
    private final Instant createdAt;

    public Game(String id, String moderatorUsername, String name, String description, DeckType deckType) {
        this.id = id;
        this.moderatorUsername = moderatorUsername;
        this.name = name;
        this.description = description;
        this.deckType = deckType != null ? deckType : DeckType.MODIFIED_FIBONACCI;
        this.estimators = new ArrayList<>();
        this.stories = new ArrayList<>();
        this.timer = new CountdownTimer();
        this.createdAt = Instant.now();
    }

    public String getId() {
        return id;
    }

    public String getModeratorUsername() {
        return moderatorUsername;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public DeckType getDeckType() {
        return deckType;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public CountdownTimer getTimer() {
        return timer;
    }

    public String getInvitationUrl(String baseUrl) {
        return baseUrl + "/games/" + id + "/join";
    }

    public synchronized Estimator join(String estimatorId, String name, String avatarUrl) {
        if (estimators.size() >= MAX_ESTIMATORS) {
            throw new IllegalStateException("Game is full. Maximum " + MAX_ESTIMATORS + " estimators allowed.");
        }
        for (Estimator e : estimators) {
            if (e.getId().equals(estimatorId)) {
                return e;
            }
        }
        char codeLetter = (char) ('A' + estimators.size());
        String anonCode = "Estimator " + codeLetter;
        Estimator estimator = new Estimator(estimatorId, name, avatarUrl, anonCode);
        estimators.add(estimator);
        return estimator;
    }

    public synchronized List<Estimator> getEstimators() {
        return Collections.unmodifiableList(new ArrayList<>(estimators));
    }

    public synchronized void addStory(Story story) {
        stories.add(story);
    }

    public synchronized boolean editStory(String storyId, String newTitle, String newDescription) {
        for (Story s : stories) {
            if (s.getId().equals(storyId)) {
                s.setTitle(newTitle);
                s.setDescription(newDescription);
                return true;
            }
        }
        return false;
    }

    public synchronized boolean deleteStory(String storyId) {
        if (currentStory != null && currentStory.getId().equals(storyId)) {
            currentStory = null;
        }
        return stories.removeIf(s -> s.getId().equals(storyId));
    }

    public synchronized List<Story> getStories() {
        return Collections.unmodifiableList(new ArrayList<>(stories));
    }

    public synchronized Story getStory(String storyId) {
        return stories.stream().filter(s -> s.getId().equals(storyId)).findFirst().orElse(null);
    }

    public synchronized Story selectStoryToEstimate(String storyId) {
        Story story = getStory(storyId);
        if (story == null) {
            throw new IllegalArgumentException("Story not found: " + storyId);
        }
        this.currentStory = story;
        story.startNewRound();
        this.timer.reset();
        return story;
    }

    public synchronized Story getCurrentStory() {
        return currentStory;
    }

    public synchronized boolean submitEstimate(String estimatorId, Card card) {
        if (currentStory == null) {
            throw new IllegalStateException("No story is currently selected for estimation.");
        }
        Round round = currentStory.getCurrentRound();
        if (round == null || round.isRevealed()) {
            throw new IllegalStateException("Current round is not active for voting.");
        }

        round.recordVote(estimatorId, card);

        // Check if all joined estimators have now voted
        if (!estimators.isEmpty() && round.getVoteCount() >= estimators.size()) {
            round.reveal();
            timer.reset(); // Two-minute timer resets itself as soon as all play an estimate
            return true;
        }
        return false;
    }

    public synchronized void forceShowEstimates() {
        if (currentStory != null && currentStory.getCurrentRound() != null) {
            currentStory.getCurrentRound().reveal();
        }
    }

    public synchronized void acceptAgreedEstimate(double estimate) {
        if (currentStory != null && currentStory.getCurrentRound() != null) {
            Round round = currentStory.getCurrentRound();
            round.acceptEstimate(estimate);
            currentStory.setFinalEstimate(estimate);
        }
    }

    public synchronized void acceptAverageEstimate() {
        if (currentStory != null && currentStory.getCurrentRound() != null) {
            Round round = currentStory.getCurrentRound();
            OptionalDouble avg = round.calculateAverage();
            if (avg.isPresent()) {
                acceptAgreedEstimate(avg.getAsDouble());
            } else {
                throw new IllegalStateException("No votes to average.");
            }
        }
    }

    public synchronized boolean hasAutoSuggestedEstimate() {
        if (currentStory != null && currentStory.getCurrentRound() != null) {
            Round round = currentStory.getCurrentRound();
            return round.isRevealed() && round.isUnanimous();
        }
        return false;
    }

    public synchronized Optional<Double> getAutoSuggestedEstimate() {
        if (hasAutoSuggestedEstimate()) {
            return currentStory.getCurrentRound().getUnanimousValue();
        }
        return Optional.empty();
    }
}
