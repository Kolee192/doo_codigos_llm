import java.time.ZoneId;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("=================================================================");
        System.out.println("  PLANNING POKER SYSTEM - SPECIFICATION VERIFICATION & DEMO");
        System.out.println("=================================================================\n");

        PlanningPokerSystem system = new PlanningPokerSystem("https://planningpoker.app");

        // 1. Moderator Account Creation, Login, Timezone, Password Reminder
        System.out.println("1. Setting up Moderator Account with Tokyo Timezone & Unicode:");
        UserAccount mod = system.createAccount("sarah_scrum", "SecretPass123", "Sarah Müller (サラ)", "sarah@example.com", ZoneId.of("Asia/Tokyo"));
        System.out.println("   Account created: " + mod.getFullName() + " | Timezone: " + mod.getTimezone());

        // Password reminder test
        String reminder = system.sendPasswordReminder("sarah@example.com");
        System.out.println("   Password Reminder Email Generated:\n" + reminder.indent(4));

        // Authenticate
        UserAccount loggedIn = system.login("sarah_scrum", "SecretPass123");
        System.out.println("   Login successful for: " + loggedIn.getUsername() + "\n");

        // 2. Game Creation (Deck selection: Modified Fibonacci vs Powers of 2, Predictable URL)
        System.out.println("2. Creating Games with Modified Fibonacci & Powers of 2:");
        Game game = system.createGame(mod.getUsername(), "Payment Gateway Sprint Planning (スプリント計画)",
                "Estimating items for Q3 payment services checkout pipeline.", DeckType.MODIFIED_FIBONACCI);

        String inviteUrl = system.getJoinUrl(game.getId());
        System.out.println("   Game: " + game.getName());
        System.out.println("   Deck Selected: " + game.getDeckType().getDisplayName() + " -> " + game.getDeckType().getCards());
        System.out.println("   Sensible Invite URL: " + inviteUrl + "\n");

        // 3. Estimator Joining (Up to 15 estimators, photos/avatars, immediate visibility)
        System.out.println("3. Estimators Joining Game via Invitation URL:");
        Estimator alice = system.joinGame(game.getId(), "Alice", "https://cdn.example.com/photos/alice.png");
        Estimator bob = system.joinGame(game.getId(), "Bob (ボブ)", "https://cdn.example.com/photos/bob.png");
        Estimator charlie = system.joinGame(game.getId(), "Charlie", "https://cdn.example.com/photos/charlie.png");
        System.out.println("   Joined: " + alice.getName() + " (Avatar: " + alice.getAvatarUrl() + ")");
        System.out.println("   Joined: " + bob.getName() + " (Avatar: " + bob.getAvatarUrl() + ")");
        System.out.println("   Joined: " + charlie.getName() + " (Avatar: " + charlie.getAvatarUrl() + ")");
        System.out.println("   Total estimators currently: " + game.getEstimators().size() + " / " + Game.MAX_ESTIMATORS + "\n");

        // 4. Story Management (Multi-line text, Spreadsheet Import, Add, Edit, Delete)
        System.out.println("4. Story Management & Spreadsheet Import (CSV/TSV):");
        system.importStoriesSpreadsheet(game.getId(),
                "Stripe ApplePay Integration\tSupport 1-click checkout with ApplePay tokenization.\n" +
                "Multi-Currency FX Support,Enable dynamic currency conversion for EUR, JPY and USD.\n" +
                "Deprecated Legacy SOAP API\tSafely decommission old SOAP endpoints.");

        // Add story with multi-line text field
        Story customStory = system.addStory(game.getId(), "3-D Secure 2.0 Auth",
                "Implement 3DS v2 challenge flows for SCA compliance.\nMust support fallback to frictionless flow.");

        // Edit story to better reflect team understanding
        game.editStory(customStory.getId(), "3-D Secure 2.0 Auth (SCA Compliant)",
                "Implement 3DS v2 challenge & frictionless flows.\nIncludes biometric test coverage.");

        // Delete unnecessary story
        Story toDelete = system.addStory(game.getId(), "Obsolete Task", "To be deleted.");
        game.deleteStory(toDelete.getId());

        System.out.println("   All Stories currently in session:");
        for (Story s : game.getStories()) {
            System.out.println("   - [" + s.getId() + "] " + s.getTitle() + " (Estimated: " + s.isEstimated() + ")");
        }
        System.out.println();

        // 5. Estimation Round 1: Cards consistency, changing minds, 2-minute timer
        System.out.println("5. Starting Round for: " + customStory.getTitle());
        system.selectItemForEstimation(game.getId(), customStory.getId());
        CountdownTimer timer = game.getTimer();
        timer.start();
        System.out.println("   Two-minute countdown timer started: " + timer.getFormattedRemaining());

        // Estimator plays card, changes estimate before reveal
        System.out.println("   Alice plays 5...");
        system.castEstimate(game.getId(), alice.getId(), new Card(5.0, "5"));
        System.out.println("   Immediate status check -> Has Alice voted? " +
                customStory.getCurrentRound().hasVoted(alice.getId()) + " | Has Bob voted? " +
                customStory.getCurrentRound().hasVoted(bob.getId()));

        System.out.println("   Alice changes mind to 8 before reveal...");
        system.castEstimate(game.getId(), alice.getId(), new Card(8.0, "8"));

        System.out.println("   Bob plays 8...");
        system.castEstimate(game.getId(), bob.getId(), new Card(8.0, "8"));

        // Moderator force reveal or auto reveal when last plays
        System.out.println("   Charlie plays 8 (last estimator plays card)...");
        system.castEstimate(game.getId(), charlie.getId(), new Card(8.0, "8"));

        // All voted -> Auto revealed and timer reset
        System.out.println("   All voted! Round revealed automatically? " + customStory.getCurrentRound().isRevealed());
        System.out.println("   Timer reset on completion? " + (!timer.isRunning()) + " (Remaining: " + timer.getFormattedRemaining() + ")");

        // Unanimous auto-fill check
        if (game.hasAutoSuggestedEstimate()) {
            double autoVal = game.getAutoSuggestedEstimate().get();
            System.out.println("   Unanimous agreement detected! Auto-filled estimate field: " + autoVal);
            game.acceptAgreedEstimate(autoVal);
            System.out.println("   Accepted unanimous estimate: " + customStory.getFinalEstimate() + " story points.");
        }
        System.out.println();

        // 6. Re-estimating a story later in session & Accepting Average
        System.out.println("6. Re-estimating Story Later in Session & Accept Average:");
        Story firstStory = game.getStories().get(0);
        system.selectItemForEstimation(game.getId(), firstStory.getId());
        System.out.println("   Round 1 for: " + firstStory.getTitle());
        system.castEstimate(game.getId(), alice.getId(), new Card(3.0, "3"));
        system.castEstimate(game.getId(), bob.getId(), new Card(5.0, "5"));
        // Moderator decides to show estimates immediately before Charlie votes
        System.out.println("   Moderator triggers immediate reveal before Charlie submits...");
        game.forceShowEstimates();
        System.out.println("   Round is revealed: " + firstStory.getCurrentRound().isRevealed());

        // Re-estimate Round 2 for the same story
        System.out.println("   Starting Re-estimate (Round 2) for same story...");
        system.selectItemForEstimation(game.getId(), firstStory.getId());
        system.castEstimate(game.getId(), alice.getId(), new Card(5.0, "5"));
        system.castEstimate(game.getId(), bob.getId(), new Card(8.0, "8"));
        system.castEstimate(game.getId(), charlie.getId(), new Card(8.0, "8"));

        // Show prior estimates history across rounds
        System.out.println("   Prior Estimates History for " + firstStory.getTitle() + ":");
        for (Round r : firstStory.getRounds()) {
            System.out.print("     Round " + r.getRoundNumber() + " -> ");
            r.getVotes().forEach((eId, v) -> System.out.print("[" + eId + ": " + v.getCard().getLabel() + "] "));
            System.out.println();
        }

        // Accept average
        game.acceptAverageEstimate();
        System.out.println("   Accepted Average Estimate: " + String.format("%.2f", firstStory.getFinalEstimate()));
        System.out.println();

        // 7. Transcripts and Exports (CSV, Anonymized Research CSV, XHTML Standards-compliant)
        System.out.println("7. Transcripts and Local Exports (CSV & XHTML):");
        String csvTranscript = TranscriptExporter.toCsv(game);
        System.out.println("   Standard CSV Transcript:\n" + csvTranscript.indent(4));

        String anonymizedCsv = TranscriptExporter.toAnonymizedCsv(game);
        System.out.println("   Researcher Anonymized Data (Estimator A, Estimator B...):\n" + anonymizedCsv.indent(4));

        String xhtmlTranscript = TranscriptExporter.toXhtml(game, mod);
        System.out.println("   XHTML Compliant Export Preview (First 400 chars):");
        System.out.println(xhtmlTranscript.substring(0, Math.min(400, xhtmlTranscript.length())).indent(4) + "...\n");

        // 8. Error Pages and Standards
        System.out.println("8. W3C Compliant Error Page Rendering (e.g. 404 Not Found):");
        String errorPage = ErrorPageRenderer.render(404, "Game Not Found", "The estimation session you are looking for has expired or was removed.", "/browse");
        System.out.println(errorPage.substring(0, Math.min(300, errorPage.length())).indent(4) + "...\n");

        // 9. Definitions / Glossary for Developers
        System.out.println("9. Developer Glossary of Standard Terms:");
        Glossary.getDefinitions().forEach((term, def) ->
                System.out.println("   * " + term + ": " + def));
        System.out.println();

        // 10. Mike's Metrics Dashboard
        System.out.println("10. Mike's Usage Metrics Dashboard:");
        System.out.print(system.getMetrics().generateReport().indent(4));

        // 11. Cleanup / Account & Game Deletion
        System.out.println("11. Testing Game & Account Deletion:");
        system.deleteAccount(mod.getId());
        System.out.println("   Account and associated games successfully removed from indexed database: "
                + (system.getRepository().findUserById(mod.getId()) == null));

        System.out.println("\nAll user stories and requirements verified successfully!");
    }
}
