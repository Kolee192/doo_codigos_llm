import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Facade coordinating planning poker operations, persistence, metrics, and security.
 */
public class PlanningPokerSystem {
    private final String baseUrl;
    private final DatabaseIndexRepository repository;
    private final SystemMetrics metrics;
    private final AtomicInteger idCounter = new AtomicInteger(100);

    public PlanningPokerSystem(String baseUrl) {
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.repository = new DatabaseIndexRepository();
        this.metrics = new SystemMetrics();
    }

    // Account Management
    public UserAccount createAccount(String username, String password, String fullName, String email, ZoneId timezone) {
        if (repository.findUserByUsername(username) != null) {
            throw new IllegalArgumentException("Username already exists: " + username);
        }
        if (repository.findUserByEmail(email) != null) {
            throw new IllegalArgumentException("Email already registered: " + email);
        }
        String id = "usr_" + idCounter.incrementAndGet();
        UserAccount account = new UserAccount(id, username, password, fullName, email, timezone);
        repository.indexUser(account);
        metrics.recordAccountCreated();
        return account;
    }

    public UserAccount login(String username, String password) {
        UserAccount account = repository.findUserByUsername(username);
        if (account == null || !account.getPassword().equals(password)) {
            throw new SecurityException("Invalid username or password.");
        }
        return account;
    }

    public void updateAccountDetails(String userId, String fullName, String email, ZoneId timezone) {
        UserAccount account = repository.findUserById(userId);
        if (account == null) {
            throw new NoSuchElementException("User not found: " + userId);
        }
        account.setFullName(fullName);
        account.setEmail(email);
        account.setTimezone(timezone);
        repository.indexUser(account);
    }

    public void deleteAccount(String userId) {
        UserAccount account = repository.findUserById(userId);
        if (account != null) {
            // Delete all games owned by this moderator
            List<Game> games = repository.findGamesByModerator(account.getUsername());
            for (Game g : games) {
                repository.removeGame(g.getId());
            }
            repository.removeUser(userId);
        }
    }

    public String sendPasswordReminder(String email) {
        UserAccount account = repository.findUserByEmail(email);
        if (account == null) {
            throw new NoSuchElementException("No account found for email: " + email);
        }
        // Generates reminder email notification content
        return "To: " + account.getEmail() + "\n" +
                "Subject: Password Reminder for Planning Poker\n\n" +
                "Hello " + account.getFullName() + ",\n" +
                "Your password for username '" + account.getUsername() + "' is: " + account.getPassword() + "\n" +
                "Please log in at: " + baseUrl + "/login\n";
    }

    // Game Management
    public Game createGame(String moderatorUsername, String name, String description, DeckType deckType) {
        UserAccount mod = repository.findUserByUsername(moderatorUsername);
        if (mod == null) {
            throw new IllegalArgumentException("Moderator user does not exist: " + moderatorUsername);
        }
        String id = "game_" + idCounter.incrementAndGet();
        Game game = new Game(id, moderatorUsername, name, description, deckType);
        repository.indexGame(game);
        metrics.recordGameCreated();
        return game;
    }

    public List<Game> browsePreviousGames(String moderatorUsername) {
        return repository.findGamesByModerator(moderatorUsername);
    }

    public void deleteGame(String gameId) {
        repository.removeGame(gameId);
    }

    public Game getGame(String gameId) {
        return repository.findGameById(gameId);
    }

    public String getJoinUrl(String gameId) {
        return baseUrl + "/games/" + gameId + "/join";
    }

    // Estimator actions
    public Estimator joinGame(String gameId, String estimatorName, String avatarUrl) {
        Game game = repository.findGameById(gameId);
        if (game == null) {
            throw new NoSuchElementException("Game not found: " + gameId);
        }
        String estimatorId = "est_" + idCounter.incrementAndGet();
        Estimator estimator = game.join(estimatorId, estimatorName, avatarUrl);
        metrics.recordEstimatorJoined();
        return estimator;
    }

    // Story Management
    public Story addStory(String gameId, String title, String description) {
        Game game = repository.findGameById(gameId);
        if (game == null) throw new NoSuchElementException("Game not found");
        String storyId = "story_" + idCounter.incrementAndGet();
        Story story = new Story(storyId, title, description);
        game.addStory(story);
        metrics.recordStoryCreated();
        return story;
    }

    public void importStoriesSpreadsheet(String gameId, String spreadsheetText) {
        if (spreadsheetText == null || spreadsheetText.isBlank()) return;
        String[] lines = spreadsheetText.split("\\r?\\n");
        for (String line : lines) {
            if (line.trim().isEmpty()) continue;
            // Support tab or comma-separated: Title [delimiter] Description
            String[] parts = line.contains("\t") ? line.split("\t", 2) : line.split(",", 2);
            String title = parts[0].trim();
            String desc = parts.length > 1 ? parts[1].trim() : "";
            addStory(gameId, title, desc);
        }
    }

    public Story selectItemForEstimation(String gameId, String storyId) {
        Game game = repository.findGameById(gameId);
        if (game == null) throw new NoSuchElementException("Game not found");
        Story story = game.selectStoryToEstimate(storyId);
        metrics.recordRoundPlayed();
        return story;
    }

    public void castEstimate(String gameId, String estimatorId, Card card) {
        Game game = repository.findGameById(gameId);
        if (game == null) throw new NoSuchElementException("Game not found");
        game.submitEstimate(estimatorId, card);
        metrics.recordVoteCast();
    }

    public SystemMetrics getMetrics() {
        return metrics;
    }

    public DatabaseIndexRepository getRepository() {
        return repository;
    }

    public String getBaseUrl() {
        return baseUrl;
    }
}
