public class ErrorPageRenderer {

    public static String render(int statusCode, String title, String message, String backUrl) {
        return "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n" +
                "  \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n" +
                "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">\n" +
                "<head>\n" +
                "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" +
                "  <title>" + statusCode + " - " + escapeXml(title) + "</title>\n" +
                "  <style type=\"text/css\">\n" +
                "    body { font-family: Arial, Helvetica, sans-serif; background-color: #f8f9fa; color: #333; margin: 40px; }\n" +
                "    .error-card { background: #fff; border: 1px solid #ddd; border-radius: 6px; padding: 24px; max-width: 600px; margin: 0 auto; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }\n" +
                "    h1 { color: #d9534f; margin-top: 0; }\n" +
                "    p { line-height: 1.5; }\n" +
                "    a { color: #0275d8; text-decoration: none; font-weight: bold; }\n" +
                "    a:hover { text-decoration: underline; }\n" +
                "  </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "  <div class=\"error-card\" role=\"alert\">\n" +
                "    <h1>" + statusCode + ": " + escapeXml(title) + "</h1>\n" +
                "    <p>" + escapeXml(message) + "</p>\n" +
                "    <p><a href=\"" + escapeXml(backUrl) + "\">&laquo; Return to Application</a></p>\n" +
                "  </div>\n" +
                "</body>\n" +
                "</html>";
    }

    private static String escapeXml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }
}
