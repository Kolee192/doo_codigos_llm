import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public enum DeckType {
    MODIFIED_FIBONACCI("Modified Fibonacci", List.of(
            new Card(0.0, "0"),
            new Card(0.5, "1/2"),
            new Card(1.0, "1"),
            new Card(2.0, "2"),
            new Card(3.0, "3"),
            new Card(5.0, "5"),
            new Card(8.0, "8"),
            new Card(13.0, "13"),
            new Card(20.0, "20"),
            new Card(40.0, "40"),
            new Card(100.0, "100")
    )),
    POWERS_OF_TWO("Powers of 2", List.of(
            new Card(0.0, "0"),
            new Card(1.0, "1"),
            new Card(2.0, "2"),
            new Card(4.0, "4"),
            new Card(8.0, "8"),
            new Card(16.0, "16"),
            new Card(32.0, "32"),
            new Card(64.0, "64")
    ));

    private final String displayName;
    private final List<Card> cards;

    DeckType(String displayName, List<Card> cards) {
        this.displayName = displayName;
        this.cards = Collections.unmodifiableList(cards);
    }

    public String getDisplayName() {
        return displayName;
    }

    public List<Card> getCards() {
        return cards;
    }
}
