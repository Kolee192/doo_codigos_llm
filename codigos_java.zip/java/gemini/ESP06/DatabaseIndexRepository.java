import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simulates indexed repository for optimal database performance and fast query lookups.
 */
public class DatabaseIndexRepository {
    // Primary indexes
    private final Map<String, UserAccount> usersById = new ConcurrentHashMap<>();
    private final Map<String, Game> gamesById = new ConcurrentHashMap<>();

    // Secondary / Foreign-Key indexes
    private final Map<String, UserAccount> usersByUsername = new ConcurrentHashMap<>();
    private final Map<String, UserAccount> usersByEmail = new ConcurrentHashMap<>();
    private final Map<String, List<String>> gameIdsByModerator = new ConcurrentHashMap<>();

    // User indexing operations
    public void indexUser(UserAccount account) {
        usersById.put(account.getId(), account);
        usersByUsername.put(account.getUsername().toLowerCase(), account);
        usersByEmail.put(account.getEmail().toLowerCase(), account);
    }

    public void removeUser(String userId) {
        UserAccount account = usersById.remove(userId);
        if (account != null) {
            usersByUsername.remove(account.getUsername().toLowerCase());
            usersByEmail.remove(account.getEmail().toLowerCase());
        }
    }

    public UserAccount findUserById(String id) {
        return usersById.get(id);
    }

    public UserAccount findUserByUsername(String username) {
        return usersByUsername.get(username.toLowerCase());
    }

    public UserAccount findUserByEmail(String email) {
        return usersByEmail.get(email.toLowerCase());
    }

    // Game indexing operations
    public void indexGame(Game game) {
        gamesById.put(game.getId(), game);
        gameIdsByModerator.computeIfAbsent(game.getModeratorUsername().toLowerCase(), k -> new ArrayList<>())
                .add(game.getId());
    }

    public void removeGame(String gameId) {
        Game game = gamesById.remove(gameId);
        if (game != null) {
            List<String> list = gameIdsByModerator.get(game.getModeratorUsername().toLowerCase());
            if (list != null) {
                list.remove(gameId);
            }
        }
    }

    public Game findGameById(String gameId) {
        return gamesById.get(gameId);
    }

    public List<Game> findGamesByModerator(String username) {
        List<String> ids = gameIdsByModerator.getOrDefault(username.toLowerCase(), Collections.emptyList());
        List<Game> result = new ArrayList<>();
        for (String id : ids) {
            Game g = gamesById.get(id);
            if (g != null) {
                result.add(g);
            }
        }
        return result;
    }
}
