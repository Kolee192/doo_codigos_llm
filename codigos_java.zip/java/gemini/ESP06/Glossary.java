import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class Glossary {
    private static final Map<String, String> TERMS = new LinkedHashMap<>();

    static {
        TERMS.put("Planning Poker", "A consensus-based, gamified technique for estimating effort or relative size of development goals in Agile.");
        TERMS.put("Moderator", "The facilitator who leads the planning session, controls items to estimate, and records final estimates.");
        TERMS.put("Estimator", "A team member who participates in sizing stories by submitting card votes.");
        TERMS.put("Story / Item", "A unit of work or user requirement presented for sizing.");
        TERMS.put("Draw / Round", "A single voting cycle where participants independently select a card for the active item.");
        TERMS.put("Reveal", "The event where all estimator cards are shown simultaneously to avoid bias.");
        TERMS.put("Modified Fibonacci", "Sequence {0, 0.5, 1, 2, 3, 5, 8, 13, 20, 40, 100} reflecting increased uncertainty with larger size.");
        TERMS.put("Powers of 2", "Sequence {0, 1, 2, 4, 8, 16, 32, 64} used as an alternative sizing scale.");
        TERMS.put("Countdown Timer", "A 2-minute timeboxing mechanism to keep team discussions concise and focused.");
    }

    public static Map<String, String> getDefinitions() {
        return Collections.unmodifiableMap(TERMS);
    }
}
