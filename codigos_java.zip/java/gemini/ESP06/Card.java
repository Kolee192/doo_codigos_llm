import java.util.Objects;

public class Card implements Comparable<Card> {
    private final double value;
    private final String label;

    public Card(double value, String label) {
        this.value = value;
        this.label = label;
    }

    public Card(double value) {
        this(value, formatValue(value));
    }

    private static String formatValue(double val) {
        if (val == (long) val) {
            return String.format("%d", (long) val);
        } else {
            return String.format("%s", val);
        }
    }

    public double getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    @Override
    public int compareTo(Card other) {
        return Double.compare(this.value, other.value);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Card card)) return false;
        return Double.compare(card.value, value) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }

    @Override
    public String toString() {
        return label;
    }
}
