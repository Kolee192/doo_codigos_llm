import java.util.Objects;

public class Estimator {
    private final String id;
    private final String name;
    private final String avatarUrl;
    private final String anonymousCode;

    public Estimator(String id, String name, String avatarUrl, String anonymousCode) {
        this.id = id;
        this.name = name;
        this.avatarUrl = avatarUrl != null && !avatarUrl.isBlank() ? avatarUrl : "default_avatar.png";
        this.anonymousCode = anonymousCode;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public String getAnonymousCode() {
        return anonymousCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Estimator estimator)) return false;
        return Objects.equals(id, estimator.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
