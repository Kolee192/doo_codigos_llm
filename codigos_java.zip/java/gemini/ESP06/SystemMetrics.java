import java.util.concurrent.atomic.AtomicLong;

public class SystemMetrics {
    private final AtomicLong accountsCreated = new AtomicLong();
    private final AtomicLong gamesCreated = new AtomicLong();
    private final AtomicLong storiesCreated = new AtomicLong();
    private final AtomicLong roundsPlayed = new AtomicLong();
    private final AtomicLong totalVotesCast = new AtomicLong();
    private final AtomicLong totalEstimatorsJoined = new AtomicLong();

    public void recordAccountCreated() { accountsCreated.incrementAndGet(); }
    public void recordGameCreated() { gamesCreated.incrementAndGet(); }
    public void recordStoryCreated() { storiesCreated.incrementAndGet(); }
    public void recordRoundPlayed() { roundsPlayed.incrementAndGet(); }
    public void recordVoteCast() { totalVotesCast.incrementAndGet(); }
    public void recordEstimatorJoined() { totalEstimatorsJoined.incrementAndGet(); }

    public long getAccountsCreated() { return accountsCreated.get(); }
    public long getGamesCreated() { return gamesCreated.get(); }
    public long getStoriesCreated() { return storiesCreated.get(); }
    public long getRoundsPlayed() { return roundsPlayed.get(); }
    public long getTotalVotesCast() { return totalVotesCast.get(); }
    public long getTotalEstimatorsJoined() { return totalEstimatorsJoined.get(); }

    public String generateReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Planning Poker System Metrics (Mike's Dashboard) ===\n");
        sb.append(String.format("Total Accounts Created:    %d\n", accountsCreated.get()));
        sb.append(String.format("Total Games Created:       %d\n", gamesCreated.get()));
        sb.append(String.format("Total Stories Created:     %d\n", storiesCreated.get()));
        sb.append(String.format("Total Rounds Played:       %d\n", roundsPlayed.get()));
        sb.append(String.format("Total Votes Cast:          %d\n", totalVotesCast.get()));
        sb.append(String.format("Total Estimators Joined:   %d\n", totalEstimatorsJoined.get()));
        return sb.toString();
    }
}
