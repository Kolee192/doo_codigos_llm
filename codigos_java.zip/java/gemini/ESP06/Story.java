import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Story {
    private final String id;
    private String title;
    private String description;
    private final List<Round> rounds;
    private Double finalEstimate;
    private final Instant createdAt;

    public Story(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.rounds = new ArrayList<>();
        this.finalEstimate = null;
        this.createdAt = Instant.now();
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getFinalEstimate() {
        return finalEstimate;
    }

    public void setFinalEstimate(Double finalEstimate) {
        this.finalEstimate = finalEstimate;
    }

    public boolean isEstimated() {
        return finalEstimate != null;
    }

    public synchronized Round startNewRound() {
        Round round = new Round(rounds.size() + 1);
        rounds.add(round);
        return round;
    }

    public synchronized Round getCurrentRound() {
        if (rounds.isEmpty()) {
            return null;
        }
        return rounds.get(rounds.size() - 1);
    }

    public synchronized List<Round> getRounds() {
        return Collections.unmodifiableList(new ArrayList<>(rounds));
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Story story)) return false;
        return Objects.equals(id, story.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
