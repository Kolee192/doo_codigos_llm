import java.util.ArrayList;
import java.util.List;

public class MediaAdministration {
    private List<Medium> media;

    public MediaAdministration() {
        this.media = new ArrayList<>();
    }

    public void addMedium(Medium medium) {
        media.add(medium);
    }

    public boolean removeMedium(String partialShelfmark) {
        return media.removeIf(m -> m.getPartialShelfmark().equalsIgnoreCase(partialShelfmark));
    }

    public Medium findMediumByPartialShelfmark(String partialShelfmark) {
        for (Medium m : media) {
            if (m.getPartialShelfmark().equalsIgnoreCase(partialShelfmark)) {
                return m;
            }
        }
        return null;
    }

    public Instance findInstanceByShelfmark(String shelfmark) {
        for (Medium m : media) {
            Instance inst = m.findInstance(shelfmark);
            if (inst != null) {
                return inst;
            }
        }
        return null;
    }

    public Medium findMediumByInstanceShelfmark(String shelfmark) {
        for (Medium m : media) {
            if (m.findInstance(shelfmark) != null) {
                return m;
            }
        }
        return null;
    }

    public List<Medium> searchMedia(List<String> titles, MediaType mediaType, String keyword, Integer year) {
        List<Medium> results = new ArrayList<>();
        for (Medium m : media) {
            boolean matches = true;

            if (titles != null && !titles.isEmpty()) {
                boolean titleMatches = false;
                for (String t : titles) {
                    if (m.getTitle().toLowerCase().contains(t.toLowerCase()) ||
                            m.getAdditionalTitle().toLowerCase().contains(t.toLowerCase())) {
                        titleMatches = true;
                        break;
                    }
                }
                if (!titleMatches) matches = false;
            }

            if (matches && mediaType != null && m.getMediaType() != mediaType) {
                matches = false;
            }

            if (matches && keyword != null && !keyword.isEmpty()) {
                boolean kwMatch = false;
                for (String kw : m.getKeywords()) {
                    if (kw.equalsIgnoreCase(keyword)) {
                        kwMatch = true;
                        break;
                    }
                }
                if (!kwMatch) matches = false;
            }

            if (matches && year != null && m.getYearOfPublication() != year) {
                matches = false;
            }

            if (matches) {
                results.add(m);
            }
        }
        return results;
    }

    public List<Medium> getAllMedia() {
        return media;
    }
}
