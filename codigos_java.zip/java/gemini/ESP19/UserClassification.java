public enum UserClassification {
    STAFF,
    STUDENT,
    PUPIL,
    GUEST
}
