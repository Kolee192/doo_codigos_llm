import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotificationService {
    private Map<String, List<String>> userMessages = new HashMap<>();

    public void sendMessage(String userNumber, String message) {
        userMessages.computeIfAbsent(userNumber, k -> new ArrayList<>()).add(message);
        System.out.println("[NOTIFICATION to " + userNumber + "]: " + message);
    }

    public List<String> getMessages(String userNumber) {
        return userMessages.getOrDefault(userNumber, new ArrayList<>());
    }
}
