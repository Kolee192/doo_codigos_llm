import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class UserAccount {
    private String userNumber;
    private UserClassification classification;
    private String name;
    private Address address;
    private String phoneNumber;
    private String email;
    private LocalDate validUntil;
    private boolean locked;
    private List<String> borrowedInstances; // shelfmarks
    private List<String> reservedInstances; // shelfmarks
    private List<Fee> unpaidFees;

    public UserAccount(String userNumber, UserClassification classification, String name,
                       Address address, String phoneNumber, String email, LocalDate validUntil) {
        this.userNumber = userNumber;
        this.classification = classification;
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.validUntil = validUntil;
        this.locked = false;
        this.borrowedInstances = new ArrayList<>();
        this.reservedInstances = new ArrayList<>();
        this.unpaidFees = new ArrayList<>();
    }

    public String getUserNumber() {
        return userNumber;
    }

    public UserClassification getClassification() {
        return classification;
    }

    public void setClassification(UserClassification classification) {
        this.classification = classification;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getValidUntil() {
        return validUntil;
    }

    public void setValidUntil(LocalDate validUntil) {
        this.validUntil = validUntil;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public List<String> getBorrowedInstances() {
        return borrowedInstances;
    }

    public List<String> getReservedInstances() {
        return reservedInstances;
    }

    public List<Fee> getUnpaidFees() {
        return unpaidFees;
    }

    public double getTotalUnpaidFees() {
        double total = 0.0;
        for (Fee fee : unpaidFees) {
            total += fee.getAmount();
        }
        return total;
    }

    public void addFee(double amount, String reason) {
        this.unpaidFees.add(new Fee(amount, reason));
    }

    public void payFees() {
        this.unpaidFees.clear();
    }

    public boolean isValid() {
        return validUntil != null && !validUntil.isBefore(LocalDate.now());
    }

    public void addBorrowedInstance(String shelfmark) {
        if (!borrowedInstances.contains(shelfmark)) {
            borrowedInstances.add(shelfmark);
        }
    }

    public void removeBorrowedInstance(String shelfmark) {
        borrowedInstances.remove(shelfmark);
    }

    public void addReservedInstance(String shelfmark) {
        if (!reservedInstances.contains(shelfmark)) {
            reservedInstances.add(shelfmark);
        }
    }

    public void removeReservedInstance(String shelfmark) {
        reservedInstances.remove(shelfmark);
    }

    @Override
    public String toString() {
        return "UserAccount{" +
                "userNumber='" + userNumber + '\'' +
                ", name='" + name + '\'' +
                ", classification=" + classification +
                ", validUntil=" + validUntil +
                ", locked=" + locked +
                ", borrowed=" + borrowedInstances.size() +
                ", reserved=" + reservedInstances.size() +
                ", unpaidFees=" + getTotalUnpaidFees() +
                '}';
    }
}
