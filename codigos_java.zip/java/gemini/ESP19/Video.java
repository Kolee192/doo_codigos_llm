import java.util.ArrayList;
import java.util.List;

public class Video extends Medium {
    private String genre;
    private List<String> actors;

    public Video(String partialShelfmark, List<String> authors, String title, String additionalTitle,
                 int yearOfPublication, List<String> keywords, String genre, List<String> actors) {
        super(partialShelfmark, MediaType.VIDEO, authors, title, additionalTitle, yearOfPublication, keywords);
        this.genre = genre;
        this.actors = actors != null ? new ArrayList<>(actors) : new ArrayList<>();
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public List<String> getActors() {
        return actors;
    }

    public void addActor(String actor) {
        this.actors.add(actor);
    }
}
