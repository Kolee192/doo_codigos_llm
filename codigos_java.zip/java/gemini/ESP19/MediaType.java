public enum MediaType {
    BOOK,
    MAGAZINE,
    VIDEO,
    CD
}
