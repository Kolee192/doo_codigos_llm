import java.time.LocalDate;

public class Fee {
    private double amount;
    private String reason;
    private LocalDate dateAssigned;

    public Fee(double amount, String reason) {
        this.amount = amount;
        this.reason = reason;
        this.dateAssigned = LocalDate.now();
    }

    public double getAmount() {
        return amount;
    }

    public String getReason() {
        return reason;
    }

    public LocalDate getDateAssigned() {
        return dateAssigned;
    }

    @Override
    public String toString() {
        return String.format("%.2f EUR (%s on %s)", amount, reason, dateAssigned);
    }
}
