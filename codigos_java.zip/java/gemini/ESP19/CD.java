import java.util.ArrayList;
import java.util.List;

public class CD extends Medium {
    private String genre;
    private List<String> trackTitles;
    private List<String> artists;

    public CD(String partialShelfmark, List<String> authors, String title, String additionalTitle,
              int yearOfPublication, List<String> keywords, String genre, List<String> trackTitles, List<String> artists) {
        super(partialShelfmark, MediaType.CD, authors, title, additionalTitle, yearOfPublication, keywords);
        this.genre = genre;
        this.trackTitles = trackTitles != null ? new ArrayList<>(trackTitles) : new ArrayList<>();
        this.artists = artists != null ? new ArrayList<>(artists) : new ArrayList<>();
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public List<String> getTrackTitles() {
        return trackTitles;
    }

    public void addTrackTitle(String trackTitle) {
        this.trackTitles.add(trackTitle);
    }

    public List<String> getArtists() {
        return artists;
    }

    public void addArtist(String artist) {
        this.artists.add(artist);
    }
}
