import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class UserAdministration {
    private Map<String, UserAccount> users;

    public UserAdministration() {
        this.users = new HashMap<>();
    }

    public void addUser(UserAccount account) {
        users.put(account.getUserNumber(), account);
    }

    public UserAccount getUser(String userNumber) {
        return users.get(userNumber);
    }

    public boolean removeUser(String userNumber) {
        return users.remove(userNumber) != null;
    }

    public Collection<UserAccount> getAllUsers() {
        return users.values();
    }

    public boolean exists(String userNumber) {
        return users.containsKey(userNumber);
    }
}
