import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LibrarySystem {
    private UserAdministration userAdmin;
    private MediaAdministration mediaAdmin;
    private NotificationService notificationService;

    public static final int DEFAULT_RENTAL_DAYS = 28; // 4 weeks
    public static final int EXTENSION_DAYS = 14;     // 2 weeks
    public static final int MAX_BORROW_LIMIT = 30;
    public static final double MAX_UNPAID_FEE_LIMIT = 20.0;
    public static final int RESERVATION_HOLD_DAYS = 7;

    public LibrarySystem() {
        this.userAdmin = new UserAdministration();
        this.mediaAdmin = new MediaAdministration();
        this.notificationService = new NotificationService();
    }

    public UserAdministration getUserAdmin() {
        return userAdmin;
    }

    public MediaAdministration getMediaAdmin() {
        return mediaAdmin;
    }

    public NotificationService getNotificationService() {
        return notificationService;
    }

    // --- Validation logic ---
    public LibraryOperationResult validateUserAccount(String userNumber) {
        UserAccount user = userAdmin.getUser(userNumber);
        if (user == null) {
            return new LibraryOperationResult(false, "User account does not exist.");
        }
        if (!user.isValid()) {
            return new LibraryOperationResult(false, "User account is expired/closed.");
        }
        // Automatic lock checks
        if (user.getBorrowedInstances().size() > MAX_BORROW_LIMIT) {
            user.setLocked(true);
            return new LibraryOperationResult(false, "User account is locked: borrowed more than " + MAX_BORROW_LIMIT + " items.");
        }
        if (user.getTotalUnpaidFees() > MAX_UNPAID_FEE_LIMIT) {
            user.setLocked(true);
            return new LibraryOperationResult(false, "User account is locked: unpaid fees exceed limit of " + MAX_UNPAID_FEE_LIMIT + " EUR.");
        }
        // Check overdue
        for (String sm : user.getBorrowedInstances()) {
            Instance inst = mediaAdmin.findInstanceByShelfmark(sm);
            if (inst != null && inst.getReturnDate() != null && inst.getReturnDate().isBefore(LocalDate.now())) {
                user.setLocked(true);
                return new LibraryOperationResult(false, "User account is locked: instance " + sm + " is overdue.");
            }
        }
        if (user.isLocked()) {
            return new LibraryOperationResult(false, "User account is locked.");
        }
        return new LibraryOperationResult(true, "User account is valid.");
    }

    // --- Use Case 4.1: Search medium ---
    public List<Medium> searchMedium(List<String> titles, MediaType mediaType, String keyword, Integer year) {
        return mediaAdmin.searchMedia(titles, mediaType, keyword, year);
    }

    // --- Use Case 4.2: Reserve instance ---
    public LibraryOperationResult reserveInstance(String shelfmark, String userNumber) {
        LibraryOperationResult userCheck = validateUserAccount(userNumber);
        if (!userCheck.isSuccess()) {
            return userCheck;
        }

        Instance instance = mediaAdmin.findInstanceByShelfmark(shelfmark);
        if (instance == null) {
            return new LibraryOperationResult(false, "Instance not found for shelfmark: " + shelfmark);
        }

        if (instance.getStatus() == InstanceStatus.SORTED_OUT ||
                instance.getStatus() == InstanceStatus.MISSING ||
                instance.getStatus() == InstanceStatus.ACQUISITION_PROCESS ||
                instance.getStatus() == InstanceStatus.READING_ROOM) {
            return new LibraryOperationResult(false, "Instance is not in a reservable state: " + instance.getStatus());
        }

        if (instance.getReservationList().contains(userNumber)) {
            return new LibraryOperationResult(false, "User has already reserved this instance.");
        }

        UserAccount user = userAdmin.getUser(userNumber);
        instance.getReservationList().add(userNumber);
        user.addReservedInstance(shelfmark);

        if (instance.getStatus() == InstanceStatus.AVAILABLE) {
            instance.setStatus(InstanceStatus.RESERVED_AND_AVAILABLE);
            instance.setReservationDate(LocalDate.now());
            notificationService.sendMessage(userNumber, "Instance " + shelfmark + " is now reserved and available for pickup.");
        } else if (instance.getStatus() == InstanceStatus.BORROWED) {
            instance.setStatus(InstanceStatus.RESERVED_AND_BORROWED);
        }

        return new LibraryOperationResult(true, "Instance reserved successfully. Status is now: " + instance.getStatus());
    }

    // --- Use Case 4.3: Borrow instance ---
    public LibraryOperationResult borrowInstances(String userNumber, List<String> shelfmarks, List<LibraryReceipt> receiptHolder) {
        LibraryOperationResult userCheck = validateUserAccount(userNumber);
        if (!userCheck.isSuccess()) {
            return userCheck;
        }

        UserAccount user = userAdmin.getUser(userNumber);
        List<String> successfullyBorrowed = new ArrayList<>();
        LocalDate dueDate = LocalDate.now().plusDays(DEFAULT_RENTAL_DAYS);

        for (String shelfmark : shelfmarks) {
            Instance instance = mediaAdmin.findInstanceByShelfmark(shelfmark);
            if (instance == null) {
                return new LibraryOperationResult(false, "Instance not found: " + shelfmark);
            }

            boolean canBorrow = false;
            if (instance.getStatus() == InstanceStatus.AVAILABLE) {
                canBorrow = true;
            } else if (instance.getStatus() == InstanceStatus.RESERVED_AND_AVAILABLE) {
                String firstInLine = instance.getReservationList().peek();
                if (firstInLine != null && firstInLine.equals(userNumber)) {
                    canBorrow = true;
                    instance.getReservationList().poll();
                    user.removeReservedInstance(shelfmark);
                } else {
                    return new LibraryOperationResult(false, "Instance " + shelfmark + " is reserved by another user.");
                }
            }

            if (!canBorrow) {
                return new LibraryOperationResult(false, "Instance " + shelfmark + " cannot be borrowed. Status: " + instance.getStatus());
            }

            // Register borrow
            user.addBorrowedInstance(shelfmark);
            BorrowRecord record = new BorrowRecord(userNumber, LocalDate.now(), dueDate);
            instance.getBorrowingHistory().add(record);
            instance.setReturnDate(dueDate);
            instance.setCurrentRentalDays(DEFAULT_RENTAL_DAYS);

            if (!instance.getReservationList().isEmpty()) {
                instance.setStatus(InstanceStatus.RESERVED_AND_BORROWED);
            } else {
                instance.setStatus(InstanceStatus.BORROWED);
            }

            instance.setLocked(false);
            successfullyBorrowed.add(shelfmark);
        }

        if (!successfullyBorrowed.isEmpty()) {
            LibraryReceipt receipt = new LibraryReceipt(userNumber, LocalDate.now(), successfullyBorrowed, dueDate);
            if (receiptHolder != null) {
                receiptHolder.add(receipt);
            }
            return new LibraryOperationResult(true, "Successfully borrowed: " + successfullyBorrowed);
        } else {
            return new LibraryOperationResult(false, "No instances were borrowed.");
        }
    }

    // --- Use Case 4.4: Extend rental period of instance ---
    public LibraryOperationResult extendRentalPeriod(String userNumber, String shelfmark) {
        LibraryOperationResult userCheck = validateUserAccount(userNumber);
        if (!userCheck.isSuccess()) {
            return userCheck;
        }

        UserAccount user = userAdmin.getUser(userNumber);
        if (!user.getBorrowedInstances().contains(shelfmark)) {
            return new LibraryOperationResult(false, "User does not have instance " + shelfmark + " borrowed.");
        }

        Instance instance = mediaAdmin.findInstanceByShelfmark(shelfmark);
        if (instance == null) {
            return new LibraryOperationResult(false, "Instance not found.");
        }

        // Validate that instance is not reserved by another user
        if (!instance.getReservationList().isEmpty()) {
            return new LibraryOperationResult(false, "Cannot extend rental period: instance is reserved by another user.");
        }

        // Validate maximum rental time
        if (instance.getCurrentRentalDays() + EXTENSION_DAYS > instance.getMaxRentalDays()) {
            return new LibraryOperationResult(false, "Cannot extend: maximum rental period of " +
                    instance.getMaxRentalDays() + " days would be exceeded.");
        }

        // Extend
        instance.setCurrentRentalDays(instance.getCurrentRentalDays() + EXTENSION_DAYS);
        LocalDate newDueDate = instance.getReturnDate().plusDays(EXTENSION_DAYS);
        instance.setReturnDate(newDueDate);

        BorrowRecord currentRecord = instance.getCurrentBorrowRecord();
        if (currentRecord != null) {
            currentRecord.setDueDate(newDueDate);
        }

        return new LibraryOperationResult(true, "Rental period extended. New due date: " + newDueDate);
    }

    // --- Use Case 4.5: Return instance ---
    public LibraryOperationResult returnInstance(String shelfmark) {
        Instance instance = mediaAdmin.findInstanceByShelfmark(shelfmark);
        if (instance == null) {
            return new LibraryOperationResult(false, "Instance not found for shelfmark: " + shelfmark);
        }

        instance.setLocked(true);

        if (instance.getStatus() != InstanceStatus.BORROWED &&
                instance.getStatus() != InstanceStatus.RESERVED_AND_BORROWED) {
            instance.setLocked(false);
            return new LibraryOperationResult(false, "Error: Instance does not have status BORROWED or RESERVED_AND_BORROWED.");
        }

        BorrowRecord record = instance.getCurrentBorrowRecord();
        if (record != null) {
            record.setReturnDate(LocalDate.now());
            String borrowerUserNumber = record.getUserNumber();
            UserAccount borrower = userAdmin.getUser(borrowerUserNumber);
            if (borrower != null) {
                borrower.removeBorrowedInstance(shelfmark);
            }
        }

        instance.setReturnDate(null);
        instance.setCurrentRentalDays(0);

        if (!instance.getReservationList().isEmpty()) {
            instance.setStatus(InstanceStatus.RESERVED_AND_AVAILABLE);
            instance.setReservationDate(LocalDate.now());
            String nextUserNumber = instance.getReservationList().peek();
            notificationService.sendMessage(nextUserNumber, "Reserved instance " + shelfmark + " is now available for pickup.");
        } else {
            instance.setStatus(InstanceStatus.AVAILABLE);
        }

        instance.setLocked(false);
        return new LibraryOperationResult(true, "Instance " + shelfmark + " returned successfully. Status: " + instance.getStatus());
    }

    // --- 4.6 Automated Checks: reminders, release expired reservations ---
    public void performAutomatedMaintenance() {
        LocalDate today = LocalDate.now();

        // 1. Remind overdue users
        for (UserAccount user : userAdmin.getAllUsers()) {
            for (String sm : user.getBorrowedInstances()) {
                Instance inst = mediaAdmin.findInstanceByShelfmark(sm);
                if (inst != null && inst.getReturnDate() != null && inst.getReturnDate().isBefore(today)) {
                    notificationService.sendMessage(user.getUserNumber(), "REMINDER: Borrowed item " + sm +
                            " was due on " + inst.getReturnDate() + " and is OVERDUE.");
                    user.setLocked(true);
                }
            }
        }

        // 2. Release expired reservations
        for (Medium medium : mediaAdmin.getAllMedia()) {
            for (Instance inst : medium.getInstances()) {
                if (inst.getStatus() == InstanceStatus.RESERVED_AND_AVAILABLE && inst.getReservationDate() != null) {
                    if (inst.getReservationDate().plusDays(RESERVATION_HOLD_DAYS).isBefore(today)) {
                        String expiredUser = inst.getReservationList().poll();
                        if (expiredUser != null) {
                            UserAccount u = userAdmin.getUser(expiredUser);
                            if (u != null) {
                                u.removeReservedInstance(inst.getShelfmark());
                            }
                            notificationService.sendMessage(expiredUser, "Your reservation for " +
                                    inst.getShelfmark() + " has expired.");
                        }

                        if (!inst.getReservationList().isEmpty()) {
                            inst.setReservationDate(today);
                            String nextUser = inst.getReservationList().peek();
                            notificationService.sendMessage(nextUser, "Instance " + inst.getShelfmark() +
                                    " is now available for your pickup.");
                        } else {
                            inst.setStatus(InstanceStatus.AVAILABLE);
                            inst.setReservationDate(null);
                        }
                    }
                }
            }
        }
    }

    // --- Librarian Operations ---
    public void createAccount(UserAccount account) {
        userAdmin.addUser(account);
    }

    public boolean editUser(String userNumber, String name, Address address, String phone, String email) {
        UserAccount user = userAdmin.getUser(userNumber);
        if (user != null) {
            user.setName(name);
            user.setAddress(address);
            user.setPhoneNumber(phone);
            user.setEmail(email);
            return true;
        }
        return false;
    }

    public boolean deleteUser(String userNumber) {
        return userAdmin.removeUser(userNumber);
    }

    public boolean extendUserAccountValidity(String userNumber, LocalDate newValidityDate) {
        UserAccount user = userAdmin.getUser(userNumber);
        if (user != null) {
            user.setValidUntil(newValidityDate);
            return true;
        }
        return false;
    }

    public void addMedium(Medium medium) {
        mediaAdmin.addMedium(medium);
    }

    public boolean deleteMedium(String partialShelfmark) {
        return mediaAdmin.removeMedium(partialShelfmark);
    }

    public boolean addInstanceToMedium(String partialShelfmark, Instance instance) {
        Medium medium = mediaAdmin.findMediumByPartialShelfmark(partialShelfmark);
        if (medium != null) {
            medium.addInstance(instance);
            return true;
        }
        return false;
    }

    public boolean changeInstanceStatus(String shelfmark, InstanceStatus newStatus) {
        Instance inst = mediaAdmin.findInstanceByShelfmark(shelfmark);
        if (inst != null) {
            inst.setStatus(newStatus);
            return true;
        }
        return false;
    }

    public boolean removeInstance(String shelfmark) {
        Medium medium = mediaAdmin.findMediumByInstanceShelfmark(shelfmark);
        if (medium != null) {
            return medium.removeInstance(shelfmark);
        }
        return false;
    }
}
