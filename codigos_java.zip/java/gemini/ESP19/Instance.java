import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Instance {
    private String shelfmark; // RVK shelfmark, e.g., 100/ST 230 B198-1(2)+9
    private InstanceStatus status;
    private LocalDate returnDate;
    private List<BorrowRecord> borrowingHistory;
    private Queue<String> reservationList; // FIFO list of userNumbers
    private List<String> components;
    private String comments;
    private int currentRentalDays;
    private int maxRentalDays;
    private boolean locked;
    private LocalDate reservationDate;

    public Instance(String shelfmark) {
        this.shelfmark = shelfmark;
        this.status = InstanceStatus.ACQUISITION_PROCESS;
        this.returnDate = null;
        this.borrowingHistory = new ArrayList<>();
        this.reservationList = new LinkedList<>();
        this.components = new ArrayList<>();
        this.comments = "";
        this.currentRentalDays = 0;
        this.maxRentalDays = 84; // 12 weeks maximum rental time
        this.locked = false;
        this.reservationDate = null;
    }

    public String getShelfmark() {
        return shelfmark;
    }

    public InstanceStatus getStatus() {
        return status;
    }

    public void setStatus(InstanceStatus status) {
        this.status = status;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public List<BorrowRecord> getBorrowingHistory() {
        return borrowingHistory;
    }

    public Queue<String> getReservationList() {
        return reservationList;
    }

    public List<String> getComponents() {
        return components;
    }

    public void addComponent(String component) {
        this.components.add(component);
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public int getCurrentRentalDays() {
        return currentRentalDays;
    }

    public void setCurrentRentalDays(int currentRentalDays) {
        this.currentRentalDays = currentRentalDays;
    }

    public int getMaxRentalDays() {
        return maxRentalDays;
    }

    public void setMaxRentalDays(int maxRentalDays) {
        this.maxRentalDays = maxRentalDays;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public LocalDate getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDate reservationDate) {
        this.reservationDate = reservationDate;
    }

    public BorrowRecord getCurrentBorrowRecord() {
        for (int i = borrowingHistory.size() - 1; i >= 0; i--) {
            BorrowRecord record = borrowingHistory.get(i);
            if (!record.isReturned()) {
                return record;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "Instance{" +
                "shelfmark='" + shelfmark + '\'' +
                ", status=" + status +
                ", returnDate=" + returnDate +
                ", reservations=" + reservationList.size() +
                ", components=" + components +
                '}';
    }
}
