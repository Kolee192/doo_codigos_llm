import java.time.LocalDate;

public class BorrowRecord {
    private String userNumber;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate;

    public BorrowRecord(String userNumber, LocalDate borrowDate, LocalDate dueDate) {
        this.userNumber = userNumber;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.returnDate = null;
    }

    public String getUserNumber() {
        return userNumber;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public boolean isReturned() {
        return returnDate != null;
    }

    @Override
    public String toString() {
        return "BorrowRecord [userNumber=" + userNumber + ", borrowed=" + borrowDate +
                ", due=" + dueDate + ", returned=" + (returnDate != null ? returnDate : "NOT YET") + "]";
    }
}
