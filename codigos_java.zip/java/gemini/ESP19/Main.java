import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("    LIBRARY SYSTEM DEMONSTRATION");
        System.out.println("==================================================");

        LibrarySystem system = new LibrarySystem();

        // 1. Librarian creates users
        Address addr1 = new Address("Main St", "12", "93053", "Regensburg");
        UserAccount user1 = new UserAccount("U1001", UserClassification.STUDENT, "Alice Smith",
                addr1, "0151-123456", "alice@example.com", LocalDate.now().plusYears(1));

        Address addr2 = new Address("Campus Way", "4", "93053", "Regensburg");
        UserAccount user2 = new UserAccount("U1002", UserClassification.STAFF, "Bob Miller",
                addr2, "0151-654321", "bob@example.com", LocalDate.now().plusYears(2));

        system.createAccount(user1);
        system.createAccount(user2);
        System.out.println("Created users: " + user1.getName() + " (" + user1.getUserNumber() + "), "
                + user2.getName() + " (" + user2.getUserNumber() + ")");

        // 2. Librarian adds media and instances
        Book book = new Book("ST 230 B198", List.of("Gamma", "Helm", "Johnson", "Vlissides"),
                "Design Patterns", "Elements of Reusable Object-Oriented Software",
                1994, List.of("Software", "OOD", "Patterns"),
                "Addison-Wesley", "Boston", null, "978-0201633610");

        Instance inst1 = new Instance("100/ST 230 B198-1(1)+1");
        inst1.setStatus(InstanceStatus.AVAILABLE);
        inst1.addComponent("Companion CD");

        Instance inst2 = new Instance("100/ST 230 B198-1(1)+2");
        inst2.setStatus(InstanceStatus.AVAILABLE);

        book.addInstance(inst1);
        book.addInstance(inst2);
        system.addMedium(book);

        CD cd = new CD("MU 100 B200", List.of("Ludwig van Beethoven"),
                "Symphony No. 9", null, 1824, List.of("Classical", "Orchestra"),
                "Classical", List.of("Ode to Joy"), List.of("Berlin Philharmonic"));
        Instance cdInst = new Instance("100/MU 100 B200-1(1)+1");
        cdInst.setStatus(InstanceStatus.AVAILABLE);
        cd.addInstance(cdInst);
        system.addMedium(cd);

        System.out.println("Added media: " + book.getTitle() + " and " + cd.getTitle());

        // 3. User searches medium (Use Case 4.1)
        System.out.println("\n--- 3. Search Medium ---");
        List<Medium> searchResults = system.searchMedium(List.of("Design"), MediaType.BOOK, "Patterns", null);
        System.out.println("Search query: Title contains 'Design', Type: BOOK, Keyword: 'Patterns'");
        for (Medium m : searchResults) {
            System.out.println("Found: " + m);
            for (Instance inst : m.getInstances()) {
                System.out.println("   -> Instance shelfmark: " + inst.getShelfmark() + " | Status: " + inst.getStatus());
            }
        }

        // 4. User borrows an instance (Use Case 4.3)
        System.out.println("\n--- 4. Borrow Instance ---");
        List<LibraryReceipt> receipts = new ArrayList<>();
        LibraryOperationResult borrowRes = system.borrowInstances("U1001", List.of("100/ST 230 B198-1(1)+1"), receipts);
        System.out.println(borrowRes);
        if (!receipts.isEmpty()) {
            System.out.println(receipts.get(0));
        }

        // 5. Another user reserves the currently borrowed instance (Use Case 4.2)
        System.out.println("\n--- 5. Reserve Instance ---");
        LibraryOperationResult reserveRes = system.reserveInstance("100/ST 230 B198-1(1)+1", "U1002");
        System.out.println("Bob reserves Alice's borrowed book: " + reserveRes);

        // 6. User attempts to extend rental period (fails because another user has reserved it) (Use Case 4.4)
        System.out.println("\n--- 6. Extend Rental Period (expected failure due to reservation) ---");
        LibraryOperationResult extendRes = system.extendRentalPeriod("U1001", "100/ST 230 B198-1(1)+1");
        System.out.println("Alice attempts to extend: " + extendRes);

        // 7. User returns the instance (Use Case 4.5)
        System.out.println("\n--- 7. Return Instance ---");
        LibraryOperationResult returnRes = system.returnInstance("100/ST 230 B198-1(1)+1");
        System.out.println("Alice returns book: " + returnRes);

        // 8. Bob now borrows the reserved and available instance
        System.out.println("\n--- 8. Borrow Reserved Instance ---");
        List<LibraryReceipt> bobReceipts = new ArrayList<>();
        LibraryOperationResult bobBorrowRes = system.borrowInstances("U1002", List.of("100/ST 230 B198-1(1)+1"), bobReceipts);
        System.out.println("Bob borrows book: " + bobBorrowRes);

        // 9. Bob extends rental period (success now because no pending reservation)
        System.out.println("\n--- 9. Extend Rental Period (Success) ---");
        LibraryOperationResult bobExtendRes = system.extendRentalPeriod("U1002", "100/ST 230 B198-1(1)+1");
        System.out.println("Bob extends: " + bobExtendRes);

        // 10. Automated checks maintenance demonstration (Use Case 4.6)
        System.out.println("\n--- 10. Automated Maintenance Demonstration ---");
        system.performAutomatedMaintenance();

        System.out.println("\nDemo completed successfully.");
    }
}
