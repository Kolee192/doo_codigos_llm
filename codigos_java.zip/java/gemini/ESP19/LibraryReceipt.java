import java.time.LocalDate;
import java.util.List;

public class LibraryReceipt {
    private String userNumber;
    private LocalDate transactionDate;
    private List<String> borrowedShelfmarks;
    private LocalDate dueDate;

    public LibraryReceipt(String userNumber, LocalDate transactionDate, List<String> borrowedShelfmarks, LocalDate dueDate) {
        this.userNumber = userNumber;
        this.transactionDate = transactionDate;
        this.borrowedShelfmarks = borrowedShelfmarks;
        this.dueDate = dueDate;
    }

    public String getUserNumber() {
        return userNumber;
    }

    public LocalDate getTransactionDate() {
        return transactionDate;
    }

    public List<String> getBorrowedShelfmarks() {
        return borrowedShelfmarks;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    @Override
    public String toString() {
        return "=== Library Borrowing Receipt ===\n" +
                "User: " + userNumber + "\n" +
                "Date: " + transactionDate + "\n" +
                "Due Date: " + dueDate + "\n" +
                "Items: " + String.join(", ", borrowedShelfmarks) + "\n" +
                "=================================";
    }
}
