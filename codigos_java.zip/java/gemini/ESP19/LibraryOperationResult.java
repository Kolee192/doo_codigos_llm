public class LibraryOperationResult {
    private boolean success;
    private String message;

    public LibraryOperationResult(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return (success ? "SUCCESS: " : "FAILED: ") + message;
    }
}
