import java.util.ArrayList;
import java.util.List;

public abstract class Medium {
    private String partialShelfmark;
    private MediaType mediaType;
    private List<String> authors;
    private String title;
    private String additionalTitle;
    private int yearOfPublication;
    private List<String> keywords;
    private List<Instance> instances;

    public Medium(String partialShelfmark, MediaType mediaType, List<String> authors,
                  String title, String additionalTitle, int yearOfPublication, List<String> keywords) {
        this.partialShelfmark = partialShelfmark;
        this.mediaType = mediaType;
        this.authors = authors != null ? new ArrayList<>(authors) : new ArrayList<>();
        this.title = title;
        this.additionalTitle = additionalTitle != null ? additionalTitle : "";
        this.yearOfPublication = yearOfPublication;
        this.keywords = keywords != null ? new ArrayList<>(keywords) : new ArrayList<>();
        this.instances = new ArrayList<>();
    }

    public String getPartialShelfmark() {
        return partialShelfmark;
    }

    public MediaType getMediaType() {
        return mediaType;
    }

    public List<String> getAuthors() {
        return authors;
    }

    public void addAuthor(String author) {
        this.authors.add(author);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAdditionalTitle() {
        return additionalTitle;
    }

    public void setAdditionalTitle(String additionalTitle) {
        this.additionalTitle = additionalTitle;
    }

    public int getYearOfPublication() {
        return yearOfPublication;
    }

    public void setYearOfPublication(int yearOfPublication) {
        this.yearOfPublication = yearOfPublication;
    }

    public List<String> getKeywords() {
        return keywords;
    }

    public void addKeyword(String keyword) {
        this.keywords.add(keyword);
    }

    public List<Instance> getInstances() {
        return instances;
    }

    public void addInstance(Instance instance) {
        instances.add(instance);
    }

    public boolean removeInstance(String shelfmark) {
        return instances.removeIf(inst -> inst.getShelfmark().equalsIgnoreCase(shelfmark));
    }

    public Instance findInstance(String shelfmark) {
        for (Instance inst : instances) {
            if (inst.getShelfmark().equalsIgnoreCase(shelfmark)) {
                return inst;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "[" + mediaType + "] " + title + " (" + yearOfPublication + ") by " + String.join(", ", authors);
    }
}
