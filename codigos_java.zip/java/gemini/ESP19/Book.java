import java.util.List;

public class Book extends Medium {
    private String publisher;
    private String placeOfPublication;
    private String editor;
    private String isbn;

    public Book(String partialShelfmark, List<String> authors, String title, String additionalTitle,
                int yearOfPublication, List<String> keywords, String publisher, String placeOfPublication,
                String editor, String isbn) {
        super(partialShelfmark, MediaType.BOOK, authors, title, additionalTitle, yearOfPublication, keywords);
        this.publisher = publisher;
        this.placeOfPublication = placeOfPublication;
        this.editor = editor;
        this.isbn = isbn;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getPlaceOfPublication() {
        return placeOfPublication;
    }

    public void setPlaceOfPublication(String placeOfPublication) {
        this.placeOfPublication = placeOfPublication;
    }

    public String getEditor() {
        return editor;
    }

    public void setEditor(String editor) {
        this.editor = editor;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}
