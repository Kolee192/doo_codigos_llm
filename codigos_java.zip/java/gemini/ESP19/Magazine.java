import java.util.ArrayList;
import java.util.List;

public class Magazine extends Medium {
    private String publisher;
    private List<String> articles;

    public Magazine(String partialShelfmark, List<String> authors, String title, String additionalTitle,
                    int yearOfPublication, List<String> keywords, String publisher, List<String> articles) {
        super(partialShelfmark, MediaType.MAGAZINE, authors, title, additionalTitle, yearOfPublication, keywords);
        this.publisher = publisher;
        this.articles = articles != null ? new ArrayList<>(articles) : new ArrayList<>();
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public List<String> getArticles() {
        return articles;
    }

    public void addArticle(String article) {
        this.articles.add(article);
    }
}
