import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ErrorReportingService {
    private static final ErrorReportingService INSTANCE = new ErrorReportingService();
    private final List<String> errorLogs = Collections.synchronizedList(new ArrayList<>());

    private ErrorReportingService() {}

    public static ErrorReportingService getInstance() {
        return INSTANCE;
    }

    public void reportError(String context, Throwable throwable) {
        String logEntry = String.format("[%s] ERROR in %s: %s",
                Instant.now(),
                context,
                throwable != null ? throwable.getMessage() : "Unknown error");
        errorLogs.add(logEntry);
        // Automated quiet recovery logging without interrupting client experience
    }

    public List<String> getErrorLogs() {
        return new ArrayList<>(errorLogs);
    }

    public void clearLogs() {
        errorLogs.clear();
    }
}
