public class UploadedImage {
    private final String filename;
    private final int width;
    private final int height;
    private final ColorRGB[][] pixels;

    public UploadedImage(String filename, int width, int height) {
        this.filename = filename != null ? filename : "image.png";
        this.width = Math.max(1, width);
        this.height = Math.max(1, height);
        this.pixels = new ColorRGB[this.height][this.width];
        for (int y = 0; y < this.height; y++) {
            for (int x = 0; x < this.width; x++) {
                pixels[y][x] = new ColorRGB(255, 255, 255);
            }
        }
    }

    public void setPixel(int x, int y, ColorRGB color) {
        if (x >= 0 && x < width && y >= 0 && y < height) {
            pixels[y][x] = color != null ? color : new ColorRGB(0, 0, 0);
        }
    }

    public ColorRGB getPixel(int x, int y) {
        int clampedX = Math.max(0, Math.min(width - 1, x));
        int clampedY = Math.max(0, Math.min(height - 1, y));
        return pixels[clampedY][clampedX];
    }

    public ColorRGB getBlendedRegionColor(int startX, int startY, int regionWidth, int regionHeight) {
        int x1 = Math.max(0, startX);
        int y1 = Math.max(0, startY);
        int x2 = Math.min(width, startX + regionWidth);
        int y2 = Math.min(height, startY + regionHeight);

        long rSum = 0;
        long gSum = 0;
        long bSum = 0;
        int count = 0;

        for (int y = y1; y < y2; y++) {
            for (int x = x1; x < x2; x++) {
                ColorRGB c = pixels[y][x];
                rSum += c.getRed();
                gSum += c.getGreen();
                bSum += c.getBlue();
                count++;
            }
        }

        if (count == 0) {
            return getPixel(startX, startY);
        }
        return new ColorRGB((int)(rSum / count), (int)(gSum / count), (int)(bSum / count));
    }

    public String getFilename() {
        return filename;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
