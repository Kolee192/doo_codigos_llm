import java.util.Optional;

public class User {
    private final String userId;
    private final String username;
    private final boolean isAdministrative;
    private final AdminLevel adminLevel;

    public User(String userId, String username) {
        this(userId, username, false, null);
    }

    public User(String userId, String username, boolean isAdministrative, AdminLevel adminLevel) {
        if (userId == null || userId.isBlank()) {
            throw new IllegalArgumentException("User ID cannot be empty");
        }
        this.userId = userId;
        this.username = username != null ? username : userId;
        this.isAdministrative = isAdministrative;
        this.adminLevel = isAdministrative ? (adminLevel != null ? adminLevel : AdminLevel.LEVEL_1) : null;
    }

    public String getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public boolean isAdministrative() {
        return isAdministrative;
    }

    public Optional<AdminLevel> getAdminLevel() {
        return Optional.ofNullable(adminLevel);
    }

    @Override
    public String toString() {
        if (!isAdministrative) {
            return String.format("User[Default]: %s (%s)", username, userId);
        }
        return String.format("User[Admin L%d]: %s (%s)", adminLevel.getRank(), username, userId);
    }
}
