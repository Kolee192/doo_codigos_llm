public enum AdminLevel {
    LEVEL_1(1, "Level 1 Administrator (Add permissions)"),
    LEVEL_2(2, "Level 2 Administrator (Add, Update permissions)"),
    LEVEL_3(3, "Level 3 Administrator (Add, Update, Delete, All permissions)");

    private final int rank;
    private final String description;

    AdminLevel(int rank, String description) {
        this.rank = rank;
        this.description = description;
    }

    public int getRank() {
        return rank;
    }

    public String getDescription() {
        return description;
    }
}
