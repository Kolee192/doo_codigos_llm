import java.util.List;
import java.util.Optional;

public class ColorTranslator {
    private final ColorSearchEngine searchEngine;

    public ColorTranslator(ColorSearchEngine searchEngine) {
        this.searchEngine = searchEngine;
    }

    public Optional<Paint> translate(String oldPaintNumber, String oldCollection, String targetCollection) {
        try {
            Optional<Paint> oldPaintOpt = searchEngine.getDatabase().findByNumber(oldCollection, oldPaintNumber);
            if (oldPaintOpt.isEmpty()) {
                return Optional.empty();
            }

            Paint oldPaint = oldPaintOpt.get();
            List<Paint> targetPaints = searchEngine.getDatabase().getByCollection(targetCollection);
            if (targetPaints.isEmpty()) {
                return Optional.empty();
            }

            List<Paint> nearest = searchEngine.findNearest(oldPaint.getColor(), targetPaints, 1);
            return nearest.isEmpty() ? Optional.empty() : Optional.of(nearest.get(0));
        } catch (Exception e) {
            ErrorReportingService.getInstance().reportError("ColorTranslator.translate", e);
            return Optional.empty();
        }
    }
}
