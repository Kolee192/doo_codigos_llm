import java.time.Duration;
import java.time.Instant;

public class UserSession {
    public static final Duration EXPIRATION_TTL = Duration.ofDays(30);

    private final String sessionId;
    private final User user;
    private final UserColorPalette colorPalette;
    private Instant lastAccessed;

    public UserSession(String sessionId, User user) {
        this.sessionId = sessionId;
        this.user = user != null ? user : new User("guest_" + sessionId, "Guest");
        this.colorPalette = new UserColorPalette();
        this.lastAccessed = Instant.now();
    }

    public String getSessionId() {
        return sessionId;
    }

    public User getUser() {
        return user;
    }

    public UserColorPalette getColorPalette() {
        touch();
        return colorPalette;
    }

    public Instant getLastAccessed() {
        return lastAccessed;
    }

    public void touch() {
        this.lastAccessed = Instant.now();
    }

    public void setLastAccessed(Instant instant) {
        this.lastAccessed = instant;
    }

    public boolean isExpired(Instant currentInstant) {
        return Duration.between(lastAccessed, currentInstant).compareTo(EXPIRATION_TTL) > 0;
    }
}
