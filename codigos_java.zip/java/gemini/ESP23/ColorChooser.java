public class ColorChooser {
    // Utility supporting pointing-device coordinates (x, y) on a 256x256 color palette canvas
    public ColorRGB selectFromPaletteMap(int mouseX, int mouseY, int hueIndex) {
        int x = Math.max(0, Math.min(255, mouseX));
        int y = Math.max(0, Math.min(255, mouseY));
        int hue = Math.max(0, Math.min(359, hueIndex));

        float saturation = x / 255.0f;
        float brightness = 1.0f - (y / 255.0f);

        return hsbToRgb(hue, saturation, brightness);
    }

    // Direct RGB selection (supports keyboard input navigation as required for accessibility)
    public ColorRGB selectFromRgbValues(int red, int green, int blue) {
        return new ColorRGB(red, green, blue);
    }

    private ColorRGB hsbToRgb(int hue, float saturation, float brightness) {
        float r = 0, g = 0, b = 0;
        if (saturation == 0) {
            r = g = b = brightness;
        } else {
            float h = (hue - (float) Math.floor(hue / 360.0f) * 360.0f) / 60.0f;
            int i = (int) h;
            float f = h - i;
            float p = brightness * (1.0f - saturation);
            float q = brightness * (1.0f - saturation * f);
            float t = brightness * (1.0f - (saturation * (1.0f - f)));
            switch (i) {
                case 0 -> { r = brightness; g = t; b = p; }
                case 1 -> { r = q; g = brightness; b = p; }
                case 2 -> { r = p; g = brightness; b = t; }
                case 3 -> { r = p; g = q; b = brightness; }
                case 4 -> { r = t; g = p; b = brightness; }
                case 5 -> { r = brightness; g = p; b = q; }
            }
        }
        return new ColorRGB(Math.round(r * 255), Math.round(g * 255), Math.round(b * 255));
    }
}
