import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class PaintDatabase {
    private final Map<String, Paint> paints = new ConcurrentHashMap<>();

    private String makeKey(String collection, String paintNumber) {
        return collection.trim().toUpperCase() + "::" + paintNumber.trim().toUpperCase();
    }

    public synchronized void addPaint(Paint paint) {
        if (paint == null) throw new IllegalArgumentException("Paint cannot be null");
        String key = makeKey(paint.getCollection(), paint.getPaintNumber());
        paints.put(key, paint);
    }

    public synchronized boolean updatePaint(Paint paint) {
        if (paint == null) return false;
        String key = makeKey(paint.getCollection(), paint.getPaintNumber());
        if (paints.containsKey(key)) {
            paints.put(key, paint);
            return true;
        }
        return false;
    }

    public synchronized boolean deletePaint(String collection, String paintNumber) {
        if (collection == null || paintNumber == null) return false;
        String key = makeKey(collection, paintNumber);
        return paints.remove(key) != null;
    }

    public Optional<Paint> findByNumber(String collection, String paintNumber) {
        if (collection == null || paintNumber == null) return Optional.empty();
        return Optional.ofNullable(paints.get(makeKey(collection, paintNumber)));
    }

    public List<Paint> getAllPaints() {
        return new ArrayList<>(paints.values());
    }

    public List<Paint> getByCollection(String collection) {
        if (collection == null) return Collections.emptyList();
        List<Paint> result = new ArrayList<>();
        for (Paint p : paints.values()) {
            if (p.getCollection().equalsIgnoreCase(collection.trim())) {
                result.add(p);
            }
        }
        return result;
    }

    public Set<String> getCollections() {
        Set<String> collections = new HashSet<>();
        for (Paint p : paints.values()) {
            collections.add(p.getCollection());
        }
        return collections;
    }
}
