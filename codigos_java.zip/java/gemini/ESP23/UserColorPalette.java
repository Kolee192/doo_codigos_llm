import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UserColorPalette {
    private final List<ColorRGB> savedColors = new ArrayList<>();
    private final List<String> recentSearches = new ArrayList<>();
    private final List<UploadedImage> uploadedImages = new ArrayList<>();

    public synchronized void addSavedColor(ColorRGB color) {
        if (color != null && !savedColors.contains(color)) {
            savedColors.add(color);
        }
    }

    public synchronized void recordSearch(String searchQuery) {
        if (searchQuery != null && !searchQuery.isBlank()) {
            recentSearches.remove(searchQuery);
            recentSearches.add(0, searchQuery);
            if (recentSearches.size() > 50) {
                recentSearches.remove(recentSearches.size() - 1);
            }
        }
    }

    public synchronized void addUploadedImage(UploadedImage image) {
        if (image != null) {
            uploadedImages.add(image);
        }
    }

    public synchronized List<ColorRGB> getSavedColors() {
        return Collections.unmodifiableList(new ArrayList<>(savedColors));
    }

    public synchronized List<String> getRecentSearches() {
        return Collections.unmodifiableList(new ArrayList<>(recentSearches));
    }

    public synchronized List<UploadedImage> getUploadedImages() {
        return Collections.unmodifiableList(new ArrayList<>(uploadedImages));
    }

    public synchronized void clear() {
        savedColors.clear();
        recentSearches.clear();
        uploadedImages.clear();
    }
}
