import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== ColorKast Paint Application for ABC Paint ===");

        // 1. Initialize databases and core services
        PaintDatabase db = new PaintDatabase();
        ColorSearchEngine searchEngine = new ColorSearchEngine(db);
        ColorTranslator translator = new ColorTranslator(searchEngine);
        ClosestColorTool closestColorTool = new ClosestColorTool(searchEngine);
        ColorSampleMatcher sampleMatcher = new ColorSampleMatcher(searchEngine);
        AdminService adminService = new AdminService(db);
        SessionManager sessionManager = new SessionManager();
        ColorChooser colorChooser = new ColorChooser();

        // 2. Setup theme mechanism for ABC Paint website integration
        Theme abcTheme = Theme.abcPaintCorporate();
        System.out.println("\n[Theme Mechanism] Loaded Theme: " + abcTheme.getThemeName());
        System.out.println("CSS root styles: " + abcTheme.renderCss());

        // 3. User Setup (Default and Administrative subclasses L1, L2, L3)
        User defaultUser = new User("guest-101", "John Doe (Default Consumer)");
        User adminL1 = new User("admin-01", "Alice L1", true, AdminLevel.LEVEL_1);
        User adminL2 = new User("admin-02", "Bob L2", true, AdminLevel.LEVEL_2);
        User adminL3 = new User("admin-03", "Carol L3", true, AdminLevel.LEVEL_3);

        adminService.registerUser(adminL1);
        adminService.registerUser(adminL2);
        adminService.registerUser(adminL3);

        System.out.println("\n[Users Initialized]");
        System.out.println("  - " + defaultUser);
        System.out.println("  - " + adminL1);
        System.out.println("  - " + adminL2);
        System.out.println("  - " + adminL3);

        // 4. Administrative operations: adding paints into Old and New collections
        System.out.println("\n--- Administrative Interface: Adding Paint Line ---");
        // Old Product Line (mechanical hand-select palette board system data)
        adminService.addPaint(adminL1, new Paint("OLD-101", "Classic Navy", "OldScheme", new ColorRGB(15, 30, 85)));
        adminService.addPaint(adminL1, new Paint("OLD-102", "Colonial Red", "OldScheme", new ColorRGB(180, 25, 30)));
        adminService.addPaint(adminL1, new Paint("OLD-103", "Meadow Green", "OldScheme", new ColorRGB(40, 130, 45)));

        // New Product Line (ColorKast transition palette)
        adminService.addPaint(adminL1, new Paint("NEW-201", "Midnight Cobalt", "NewScheme", new ColorRGB(18, 32, 90)));
        adminService.addPaint(adminL1, new Paint("NEW-202", "Sunset Crimson", "NewScheme", new ColorRGB(185, 20, 25)));
        adminService.addPaint(adminL1, new Paint("NEW-203", "Alpine Forest", "NewScheme", new ColorRGB(38, 128, 50)));
        adminService.addPaint(adminL1, new Paint("NEW-204", "Ocean Breeze", "NewScheme", new ColorRGB(50, 150, 200)));

        System.out.println("Added paints successfully. Total paints in DB: " + db.getAllPaints().size());

        // Test Administrative hierarchy permissions
        System.out.println("\n--- Testing Admin Permission Hierarchy ---");
        // L1 tries to update (should fail)
        Paint updatedPaint = new Paint("NEW-201", "Cobalt Blue v2", "NewScheme", new ColorRGB(20, 35, 95));
        boolean l1Update = adminService.updatePaint(adminL1, updatedPaint);
        System.out.println("Admin L1 attempts to update paint: " + (l1Update ? "SUCCESS" : "REJECTED (as expected)"));

        // L2 updates (should succeed)
        boolean l2Update = adminService.updatePaint(adminL2, updatedPaint);
        System.out.println("Admin L2 attempts to update paint: " + (l2Update ? "SUCCESS" : "FAILED"));

        // L2 tries to delete (should fail)
        boolean l2Delete = adminService.deletePaint(adminL2, "NewScheme", "NEW-204");
        System.out.println("Admin L2 attempts to delete paint: " + (l2Delete ? "SUCCESS" : "REJECTED (as expected)"));

        // L3 deletes (should succeed)
        boolean l3Delete = adminService.deletePaint(adminL3, "NewScheme", "NEW-204");
        System.out.println("Admin L3 attempts to delete paint: " + (l3Delete ? "SUCCESS" : "FAILED"));

        // Admin User creation permission hierarchy
        boolean l1CreateL2 = adminService.createAdminUser(adminL1, "admin-sub", "Sub Admin", AdminLevel.LEVEL_2);
        System.out.println("Admin L1 attempts to create Admin L2: " + (l1CreateL2 ? "ALLOWED" : "REJECTED (as expected)"));
        boolean l3CreateL2 = adminService.createAdminUser(adminL3, "admin-04", "David L2", AdminLevel.LEVEL_2);
        System.out.println("Admin L3 creates Admin L2: " + (l3CreateL2 ? "SUCCESS" : "FAILED"));

        // 5. Old-to-New Scheme Translator
        System.out.println("\n--- Old to New Product-Line Translator ---");
        Optional<Paint> translated = translator.translate("OLD-101", "OldScheme", "NewScheme");
        translated.ifPresent(p -> System.out.println("OLD-101 (Classic Navy) translated to NewScheme: " + p));

        // 6. Color Chooser (pointing device & keyboard values)
        System.out.println("\n--- Color Chooser Utility ---");
        ColorRGB chosenFromMap = colorChooser.selectFromPaletteMap(128, 128, 210);
        ColorRGB chosenFromKeyb = colorChooser.selectFromRgbValues(18, 30, 88);
        System.out.println("Color picked via Pointing Device (x=128, y=128): " + chosenFromMap);
        System.out.println("Color picked via Keyboard Direct Input: " + chosenFromKeyb);

        // 7. Closest Color Tool in RGB color space
        System.out.println("\n--- Closest Colors Tool ---");
        List<Paint> closestList = closestColorTool.findClosestByPaintNumber("OLD-102", "OldScheme", "NewScheme", 2);
        System.out.println("Closest paints to OLD-102 in 'NewScheme':");
        for (Paint p : closestList) {
            System.out.println("  -> " + p);
        }

        // 8. Color Search Engine (all collections & query by hex / name)
        System.out.println("\n--- Color Search Engine ---");
        List<Paint> searchResults = searchEngine.search("Midnight", null, 5);
        System.out.println("Search results for query 'Midnight':");
        searchResults.forEach(p -> System.out.println("  -> " + p));

        // 9. Color Sample Matcher with Uploaded Image
        System.out.println("\n--- Color Sample Matcher ---");
        UploadedImage uploadedImg = new UploadedImage("living_room_wall.jpg", 10, 10);
        // Paint a section of the image with a shade of green
        for (int y = 0; y < 5; y++) {
            for (int x = 0; x < 5; x++) {
                uploadedImg.setPixel(x, y, new ColorRGB(36, 125, 48));
            }
        }
        ColorRGB blended = sampleMatcher.sampleBlendedRegion(uploadedImg, 0, 0, 3, 3);
        System.out.println("Sampled blended color from uploaded image: " + blended);
        List<Paint> matchedPaints = sampleMatcher.matchBlendedRegion(uploadedImg, 0, 0, 3, 3, "NewScheme", 1);
        System.out.println("Best matching paint for uploaded sample: " + matchedPaints.get(0));

        // 10. Persistent Session & User Color Palette (30-day lifecycle)
        System.out.println("\n--- User Session & Persistent Palette ---");
        UserSession session = sessionManager.createSession(defaultUser);
        UserColorPalette palette = session.getColorPalette();
        palette.addSavedColor(chosenFromKeyb);
        palette.recordSearch("Midnight");
        palette.addUploadedImage(uploadedImg);

        System.out.println("Session ID: " + session.getSessionId());
        System.out.println("Saved Colors in Palette: " + palette.getSavedColors());
        System.out.println("Recent Searches in Palette: " + palette.getRecentSearches());
        System.out.println("Uploaded Images stored in Palette: " + palette.getUploadedImages().size());

        // Simulate session aging and 30-day purge
        System.out.println("\n--- 30-Day Session Cleanup Test ---");
        // Artificially age the session to 31 days ago
        session.setLastAccessed(Instant.now().minus(31, ChronoUnit.DAYS));
        System.out.println("Active sessions before cleanup: " + sessionManager.getActiveSessionCount());
        int purged = sessionManager.cleanExpiredSessions(Instant.now());
        System.out.println("Purged expired sessions count: " + purged);
        System.out.println("Active sessions after cleanup: " + sessionManager.getActiveSessionCount());

        // 11. Error Reporting Utility Check
        System.out.println("\n--- Error Reporting Utility ---");
        System.out.println("Error logs recorded quietly without breaking user workflow: " +
                ErrorReportingService.getInstance().getErrorLogs().size());
        for (String log : ErrorReportingService.getInstance().getErrorLogs()) {
            System.out.println("  " + log);
        }

        System.out.println("\n=== All ColorKast components executed successfully. ===");
    }
}
