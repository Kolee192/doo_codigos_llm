import java.util.*;

public class ColorSearchEngine {
    private final PaintDatabase database;

    public ColorSearchEngine(PaintDatabase database) {
        this.database = Objects.requireNonNull(database, "PaintDatabase cannot be null");
    }

    public List<Paint> search(String query, String collectionFilter, int limit) {
        try {
            List<Paint> pool = (collectionFilter == null || collectionFilter.isBlank())
                    ? database.getAllPaints()
                    : database.getByCollection(collectionFilter);

            if (query == null || query.isBlank()) {
                return pool.stream().limit(Math.max(1, limit)).toList();
            }

            String q = query.trim();

            if (q.startsWith("#") || (q.length() == 6 && q.matches("^[0-9a-fA-F]{6}$"))) {
                try {
                    ColorRGB target = ColorRGB.fromHex(q);
                    return findNearest(target, pool, limit);
                } catch (Exception ignored) {
                    // fall back to text matching
                }
            }

            List<Paint> exactNumberMatches = new ArrayList<>();
            List<Paint> nameMatches = new ArrayList<>();

            for (Paint p : pool) {
                if (p.getPaintNumber().equalsIgnoreCase(q)) {
                    exactNumberMatches.add(p);
                } else if (p.getPaintName().toLowerCase().contains(q.toLowerCase())) {
                    nameMatches.add(p);
                }
            }

            List<Paint> combined = new ArrayList<>(exactNumberMatches);
            for (Paint p : nameMatches) {
                if (!combined.contains(p)) {
                    combined.add(p);
                }
            }

            if (combined.isEmpty()) {
                return Collections.emptyList();
            }

            return combined.subList(0, Math.min(combined.size(), Math.max(1, limit)));
        } catch (Exception e) {
            ErrorReportingService.getInstance().reportError("ColorSearchEngine.search", e);
            return Collections.emptyList();
        }
    }

    public List<Paint> findNearest(ColorRGB targetColor, List<Paint> candidates, int limit) {
        try {
            if (candidates == null || candidates.isEmpty() || targetColor == null) {
                return Collections.emptyList();
            }
            List<Paint> sorted = new ArrayList<>(candidates);
            sorted.sort(Comparator.comparingDouble(p -> p.getColor().distanceTo(targetColor)));
            return sorted.subList(0, Math.min(sorted.size(), Math.max(1, limit)));
        } catch (Exception e) {
            ErrorReportingService.getInstance().reportError("ColorSearchEngine.findNearest", e);
            return Collections.emptyList();
        }
    }

    public PaintDatabase getDatabase() {
        return database;
    }
}
