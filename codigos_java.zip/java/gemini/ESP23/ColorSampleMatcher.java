import java.util.List;

public class ColorSampleMatcher {
    private final ColorSearchEngine searchEngine;

    public ColorSampleMatcher(ColorSearchEngine searchEngine) {
        this.searchEngine = searchEngine;
    }

    public ColorRGB samplePixel(UploadedImage image, int x, int y) {
        return image.getPixel(x, y);
    }

    public ColorRGB sampleBlendedRegion(UploadedImage image, int startX, int startY, int w, int h) {
        return image.getBlendedRegionColor(startX, startY, w, h);
    }

    public List<Paint> matchPixel(UploadedImage image, int x, int y, String targetCollection, int count) {
        ColorRGB sampled = samplePixel(image, x, y);
        List<Paint> pool = (targetCollection == null || targetCollection.isBlank())
                ? searchEngine.getDatabase().getAllPaints()
                : searchEngine.getDatabase().getByCollection(targetCollection);
        return searchEngine.findNearest(sampled, pool, count);
    }

    public List<Paint> matchBlendedRegion(UploadedImage image, int x, int y, int w, int h, String targetCollection, int count) {
        ColorRGB sampled = sampleBlendedRegion(image, x, y, w, h);
        List<Paint> pool = (targetCollection == null || targetCollection.isBlank())
                ? searchEngine.getDatabase().getAllPaints()
                : searchEngine.getDatabase().getByCollection(targetCollection);
        return searchEngine.findNearest(sampled, pool, count);
    }
}
