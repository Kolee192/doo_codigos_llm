public class Theme {
    private final String themeName;
    private final String primaryColorHex;
    private final String secondaryColorHex;
    private final String fontFamily;

    public Theme(String themeName, String primaryColorHex, String secondaryColorHex, String fontFamily) {
        this.themeName = themeName != null ? themeName : "ABC-Default";
        this.primaryColorHex = primaryColorHex != null ? primaryColorHex : "#003366";
        this.secondaryColorHex = secondaryColorHex != null ? secondaryColorHex : "#FFCC00";
        this.fontFamily = fontFamily != null ? fontFamily : "Arial, sans-serif";
    }

    public static Theme abcPaintCorporate() {
        return new Theme("ABC Paint Corporate", "#1A365D", "#D69E2E", "Helvetica, Arial, sans-serif");
    }

    public String renderCss() {
        return String.format(
                "/* Theme: %s */ :root { --abc-primary: %s; --abc-secondary: %s; --abc-font: %s; }",
                themeName, primaryColorHex, secondaryColorHex, fontFamily
        );
    }

    public String getThemeName() {
        return themeName;
    }
}
