import java.util.Objects;

public class ColorRGB {
    private final int red;
    private final int green;
    private final int blue;

    public ColorRGB(int red, int green, int blue) {
        this.red = clamp(red);
        this.green = clamp(green);
        this.blue = clamp(blue);
    }

    public static ColorRGB fromHex(String hex) {
        if (hex == null) {
            throw new IllegalArgumentException("Hex string cannot be null");
        }
        String cleanHex = hex.trim().replace("#", "");
        if (cleanHex.length() != 6) {
            throw new IllegalArgumentException("Hex color must be 6 hex characters");
        }
        int r = Integer.parseInt(cleanHex.substring(0, 2), 16);
        int g = Integer.parseInt(cleanHex.substring(2, 4), 16);
        int b = Integer.parseInt(cleanHex.substring(4, 6), 16);
        return new ColorRGB(r, g, b);
    }

    private static int clamp(int val) {
        return Math.max(0, Math.min(255, val));
    }

    public int getRed() {
        return red;
    }

    public int getGreen() {
        return green;
    }

    public int getBlue() {
        return blue;
    }

    public double distanceTo(ColorRGB other) {
        if (other == null) {
            return Double.MAX_VALUE;
        }
        long dr = (long) this.red - other.red;
        long dg = (long) this.green - other.green;
        long db = (long) this.blue - other.blue;
        return Math.sqrt(dr * dr + dg * dg + db * db);
    }

    public String toHex() {
        return String.format("#%02X%02X%02X", red, green, blue);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ColorRGB colorRGB)) return false;
        return red == colorRGB.red && green == colorRGB.green && blue == colorRGB.blue;
    }

    @Override
    public int hashCode() {
        return Objects.hash(red, green, blue);
    }

    @Override
    public String toString() {
        return String.format("RGB(%d, %d, %d) [%s]", red, green, blue, toHex());
    }
}
