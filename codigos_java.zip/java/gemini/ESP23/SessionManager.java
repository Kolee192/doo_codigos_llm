import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SessionManager {
    private final Map<String, UserSession> sessions = new ConcurrentHashMap<>();

    public UserSession createSession(User user) {
        String sessionId = UUID.randomUUID().toString();
        UserSession session = new UserSession(sessionId, user);
        sessions.put(sessionId, session);
        return session;
    }

    public Optional<UserSession> getSession(String sessionId) {
        if (sessionId == null) return Optional.empty();
        UserSession session = sessions.get(sessionId);
        if (session != null) {
            if (session.isExpired(Instant.now())) {
                sessions.remove(sessionId);
                return Optional.empty();
            }
            session.touch();
            return Optional.of(session);
        }
        return Optional.empty();
    }

    public int cleanExpiredSessions(Instant referenceInstant) {
        int removedCount = 0;
        for (Map.Entry<String, UserSession> entry : sessions.entrySet()) {
            if (entry.getValue().isExpired(referenceInstant)) {
                sessions.remove(entry.getKey());
                removedCount++;
            }
        }
        return removedCount;
    }

    public int getActiveSessionCount() {
        return sessions.size();
    }
}
