import java.util.Objects;

public class Paint {
    private final String paintNumber;
    private String paintName;
    private String collection;
    private ColorRGB color;

    public Paint(String paintNumber, String paintName, String collection, ColorRGB color) {
        if (paintNumber == null || paintNumber.isBlank()) {
            throw new IllegalArgumentException("Paint number cannot be empty");
        }
        this.paintNumber = paintNumber.trim();
        this.paintName = paintName != null ? paintName.trim() : "";
        this.collection = collection != null ? collection.trim() : "Default";
        this.color = Objects.requireNonNull(color, "Color cannot be null");
    }

    public String getPaintNumber() {
        return paintNumber;
    }

    public String getPaintName() {
        return paintName;
    }

    public void setPaintName(String paintName) {
        this.paintName = paintName != null ? paintName.trim() : "";
    }

    public String getCollection() {
        return collection;
    }

    public void setCollection(String collection) {
        this.collection = collection != null ? collection.trim() : "Default";
    }

    public ColorRGB getColor() {
        return color;
    }

    public void setColor(ColorRGB color) {
        this.color = Objects.requireNonNull(color, "Color cannot be null");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Paint paint)) return false;
        return paintNumber.equalsIgnoreCase(paint.paintNumber) &&
                collection.equalsIgnoreCase(paint.collection);
    }

    @Override
    public int hashCode() {
        return Objects.hash(paintNumber.toUpperCase(), collection.toUpperCase());
    }

    @Override
    public String toString() {
        return String.format("[%s] #%s - %s (%s)", collection, paintNumber, paintName, color);
    }
}
