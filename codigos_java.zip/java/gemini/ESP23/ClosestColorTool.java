import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class ClosestColorTool {
    private final ColorSearchEngine searchEngine;

    public ClosestColorTool(ColorSearchEngine searchEngine) {
        this.searchEngine = searchEngine;
    }

    public List<Paint> findClosestByPaintNumber(String paintNumber, String collection, String targetCollection, int count) {
        try {
            Optional<Paint> basePaintOpt = searchEngine.getDatabase().findByNumber(collection, paintNumber);
            if (basePaintOpt.isEmpty()) {
                return Collections.emptyList();
            }
            ColorRGB baseColor = basePaintOpt.get().getColor();
            return findClosestByColor(baseColor, targetCollection, count);
        } catch (Exception e) {
            ErrorReportingService.getInstance().reportError("ClosestColorTool.findClosestByPaintNumber", e);
            return Collections.emptyList();
        }
    }

    public List<Paint> findClosestByColor(ColorRGB color, String targetCollection, int count) {
        try {
            List<Paint> candidates = (targetCollection == null || targetCollection.isBlank())
                    ? searchEngine.getDatabase().getAllPaints()
                    : searchEngine.getDatabase().getByCollection(targetCollection);

            return searchEngine.findNearest(color, candidates, count);
        } catch (Exception e) {
            ErrorReportingService.getInstance().reportError("ClosestColorTool.findClosestByColor", e);
            return Collections.emptyList();
        }
    }
}
