import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AdminService {
    private final PaintDatabase database;
    private final Map<String, User> userAccounts = new ConcurrentHashMap<>();

    public AdminService(PaintDatabase database) {
        this.database = database;
    }

    public boolean canAdd(User user) {
        return user != null && user.isAdministrative() && user.getAdminLevel().isPresent();
    }

    public boolean canUpdate(User user) {
        return user != null && user.isAdministrative() &&
                user.getAdminLevel().map(l -> l.getRank() >= AdminLevel.LEVEL_2.getRank()).orElse(false);
    }

    public boolean canDelete(User user) {
        return user != null && user.isAdministrative() &&
                user.getAdminLevel().map(l -> l.getRank() >= AdminLevel.LEVEL_3.getRank()).orElse(false);
    }

    public boolean canCreateAdminUser(User creator, AdminLevel targetLevel) {
        if (creator == null || !creator.isAdministrative() || creator.getAdminLevel().isEmpty()) {
            return false;
        }
        int creatorRank = creator.getAdminLevel().get().getRank();
        return creatorRank >= targetLevel.getRank();
    }

    public boolean addPaint(User admin, Paint paint) {
        if (!canAdd(admin)) {
            ErrorReportingService.getInstance().reportError(
                    "AdminService.addPaint",
                    new SecurityException("User " + (admin != null ? admin.getUsername() : "null") + " has insufficient permission to add paint"));
            return false;
        }
        database.addPaint(paint);
        return true;
    }

    public boolean updatePaint(User admin, Paint paint) {
        if (!canUpdate(admin)) {
            ErrorReportingService.getInstance().reportError(
                    "AdminService.updatePaint",
                    new SecurityException("User " + (admin != null ? admin.getUsername() : "null") + " has insufficient permission to update paint"));
            return false;
        }
        return database.updatePaint(paint);
    }

    public boolean deletePaint(User admin, String collection, String paintNumber) {
        if (!canDelete(admin)) {
            ErrorReportingService.getInstance().reportError(
                    "AdminService.deletePaint",
                    new SecurityException("User " + (admin != null ? admin.getUsername() : "null") + " has insufficient permission to delete paint"));
            return false;
        }
        return database.deletePaint(collection, paintNumber);
    }

    public boolean createAdminUser(User creator, String newUserId, String newUsername, AdminLevel level) {
        if (!canCreateAdminUser(creator, level)) {
            ErrorReportingService.getInstance().reportError(
                    "AdminService.createAdminUser",
                    new SecurityException("User " + (creator != null ? creator.getUsername() : "null") + " cannot create admin user of rank " + level.getRank()));
            return false;
        }
        User newUser = new User(newUserId, newUsername, true, level);
        userAccounts.put(newUserId, newUser);
        return true;
    }

    public void registerUser(User user) {
        if (user != null) {
            userAccounts.put(user.getUserId(), user);
        }
    }

    public User getUser(String userId) {
        return userAccounts.get(userId);
    }
}
