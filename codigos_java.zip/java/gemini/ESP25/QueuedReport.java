public class QueuedReport {
    private final String reportJobId;
    private final String templateName;
    private final String requestedByStaffId;
    private int queuePosition;

    public QueuedReport(String reportJobId, String templateName, String requestedByStaffId, int queuePosition) {
        this.reportJobId = reportJobId;
        this.templateName = templateName;
        this.requestedByStaffId = requestedByStaffId;
        this.queuePosition = queuePosition;
    }

    public String getReportJobId() {
        return reportJobId;
    }

    public String getTemplateName() {
        return templateName;
    }

    public String getRequestedByStaffId() {
        return requestedByStaffId;
    }

    public int getQueuePosition() {
        return queuePosition;
    }

    public void setQueuePosition(int queuePosition) {
        this.queuePosition = queuePosition;
    }
}
