public enum ChargeType {
    OVERDUE_FINE,
    DAMAGED_ITEM,
    LOST_ITEM,
    GENERAL_FEE
}
