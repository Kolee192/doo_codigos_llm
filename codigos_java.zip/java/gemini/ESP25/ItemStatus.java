public enum ItemStatus {
    AVAILABLE,
    CHECKED_OUT,
    IN_TRANSIT,
    MISSING,
    DAMAGED,
    DISCARD_WEED,
    LONG_OVERDUE
}
