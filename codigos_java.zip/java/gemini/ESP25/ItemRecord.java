import java.time.LocalDate;

public class ItemRecord {
    private final String id;
    private final String bibId;
    private String barcode;
    private String callNumber;
    private String itemType;
    private String format;
    private String genre;
    private ItemStatus status;
    private double price;
    private String currentBranchId;
    private String originalBranchId;
    private String systemId;
    private boolean uncataloged;
    private LocalDate lastCheckoutDate;
    private int daysInTransit;
    private int monthsInStatus;
    private int renewalCount;
    private int checkoutCount;
    private int daysToReturnTotal;

    public ItemRecord(String id, String bibId, String barcode, String callNumber, String itemType,
                      String format, String genre, ItemStatus status, double price,
                      String currentBranchId, String systemId, boolean uncataloged) {
        this.id = id;
        this.bibId = bibId;
        this.barcode = barcode;
        this.callNumber = callNumber;
        this.itemType = itemType;
        this.format = format;
        this.genre = genre;
        this.status = status;
        this.price = price;
        this.currentBranchId = currentBranchId;
        this.originalBranchId = currentBranchId;
        this.systemId = systemId;
        this.uncataloged = uncataloged;
    }

    public String getId() {
        return id;
    }

    public String getBibId() {
        return bibId;
    }

    public String getBarcode() {
        return barcode;
    }

    public String getCallNumber() {
        return callNumber;
    }

    public void setCallNumber(String callNumber) {
        this.callNumber = callNumber;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public String getFormat() {
        return format;
    }

    public String getGenre() {
        return genre;
    }

    public ItemStatus getStatus() {
        return status;
    }

    public void setStatus(ItemStatus status) {
        this.status = status;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCurrentBranchId() {
        return currentBranchId;
    }

    public void setCurrentBranchId(String currentBranchId) {
        this.currentBranchId = currentBranchId;
    }

    public String getOriginalBranchId() {
        return originalBranchId;
    }

    public void setOriginalBranchId(String originalBranchId) {
        this.originalBranchId = originalBranchId;
    }

    public String getSystemId() {
        return systemId;
    }

    public boolean isUncataloged() {
        return uncataloged;
    }

    public LocalDate getLastCheckoutDate() {
        return lastCheckoutDate;
    }

    public void setLastCheckoutDate(LocalDate lastCheckoutDate) {
        this.lastCheckoutDate = lastCheckoutDate;
    }

    public int getDaysInTransit() {
        return daysInTransit;
    }

    public void setDaysInTransit(int daysInTransit) {
        this.daysInTransit = daysInTransit;
    }

    public int getMonthsInStatus() {
        return monthsInStatus;
    }

    public void setMonthsInStatus(int monthsInStatus) {
        this.monthsInStatus = monthsInStatus;
    }

    public int getRenewalCount() {
        return renewalCount;
    }

    public void incrementRenewals() {
        this.renewalCount++;
    }

    public int getCheckoutCount() {
        return checkoutCount;
    }

    public void incrementCheckouts(int returnDays) {
        this.checkoutCount++;
        this.daysToReturnTotal += returnDays;
    }

    public double getAverageReturnDays() {
        return checkoutCount == 0 ? 0.0 : (double) daysToReturnTotal / checkoutCount;
    }
}
