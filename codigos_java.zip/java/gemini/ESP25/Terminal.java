public class Terminal {
    private final String id;
    private final String branchId;
    private final boolean isPublic;

    public Terminal(String id, String branchId, boolean isPublic) {
        this.id = id;
        this.branchId = branchId;
        this.isPublic = isPublic;
    }

    public String getId() {
        return id;
    }

    public String getBranchId() {
        return branchId;
    }

    public boolean isPublic() {
        return isPublic;
    }
}
