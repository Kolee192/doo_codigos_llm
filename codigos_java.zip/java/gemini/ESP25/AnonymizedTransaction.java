import java.time.LocalDateTime;

public class AnonymizedTransaction {
    private final String transactionType;
    private final LocalDateTime timestamp;
    private final String branchId;
    private final String systemId;
    private final String patronAgeRange;
    private final String patronCounty;
    private final String patronZip;
    private final String patronType;

    public AnonymizedTransaction(TransactionRecord original) {
        this.transactionType = original.getTransactionType();
        this.timestamp = original.getTimestamp();
        this.branchId = original.getBranchId();
        this.systemId = original.getSystemId();
        this.patronAgeRange = original.getPatronAgeRange();
        this.patronCounty = original.getPatronCounty();
        this.patronZip = original.getPatronZip();
        this.patronType = original.getPatronType();
    }

    public String getTransactionType() {
        return transactionType;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getBranchId() {
        return branchId;
    }

    public String getSystemId() {
        return systemId;
    }

    public String getPatronAgeRange() {
        return patronAgeRange;
    }

    public String getPatronCounty() {
        return patronCounty;
    }

    public String getPatronZip() {
        return patronZip;
    }

    public String getPatronType() {
        return patronType;
    }
}
