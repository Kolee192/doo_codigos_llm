import java.util.ArrayList;
import java.util.List;

public class BibRecord {
    private final String id;
    private final String title;
    private final String author;
    private final List<String> itemIds = new ArrayList<>();

    public BibRecord(String id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public List<String> getItemIds() {
        return itemIds;
    }

    public void addItemId(String itemId) {
        itemIds.add(itemId);
    }

    public void removeItemId(String itemId) {
        itemIds.remove(itemId);
    }
}
