import java.util.*;

public class LibraryRepository {
    private final Map<String, LibrarySystem> systems = new HashMap<>();
    private final Map<String, Branch> branches = new HashMap<>();
    private final Map<String, Patron> patrons = new HashMap<>();
    private final Map<String, BibRecord> bibs = new HashMap<>();
    private final Map<String, ItemRecord> items = new HashMap<>();
    private final List<HoldRequest> holds = new ArrayList<>();
    private final List<TransactionRecord> transactions = new ArrayList<>();
    private final List<AnonymizedTransaction> archivedDemographics = new ArrayList<>();

    public void addSystem(LibrarySystem sys) {
        systems.put(sys.getId(), sys);
    }

    public void addBranch(Branch branch) {
        branches.put(branch.getId(), branch);
        LibrarySystem sys = systems.get(branch.getSystemId());
        if (sys != null) {
            sys.addBranch(branch);
        }
    }

    public void addPatron(Patron patron) {
        patrons.put(patron.getId(), patron);
    }

    public void addBib(BibRecord bib) {
        bibs.put(bib.getId(), bib);
    }

    public void addItem(ItemRecord item) {
        items.put(item.getId(), item);
        BibRecord bib = bibs.get(item.getBibId());
        if (bib != null) {
            bib.addItemId(item.getId());
        }
    }

    public void addHold(HoldRequest hold) {
        holds.add(hold);
    }

    public void addTransaction(TransactionRecord tx) {
        transactions.add(tx);
    }

    public void archiveTransactionDemographics(TransactionRecord tx) {
        archivedDemographics.add(new AnonymizedTransaction(tx));
    }

    public Map<String, LibrarySystem> getSystems() {
        return systems;
    }

    public Map<String, Branch> getBranches() {
        return branches;
    }

    public Map<String, Patron> getPatrons() {
        return patrons;
    }

    public Map<String, BibRecord> getBibs() {
        return bibs;
    }

    public Map<String, ItemRecord> getItems() {
        return items;
    }

    public List<HoldRequest> getHolds() {
        return holds;
    }

    public List<TransactionRecord> getTransactions() {
        return transactions;
    }

    public List<AnonymizedTransaction> getArchivedDemographics() {
        return archivedDemographics;
    }
}
