import java.time.LocalDate;

public class Payment {
    private final String id;
    private final String patronId;
    private final String branchId;
    private final double amount;
    private final PaymentMethod method;
    private final LocalDate date;

    public Payment(String id, String patronId, String branchId, double amount, PaymentMethod method, LocalDate date) {
        this.id = id;
        this.patronId = patronId;
        this.branchId = branchId;
        this.amount = amount;
        this.method = method;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public String getPatronId() {
        return patronId;
    }

    public String getBranchId() {
        return branchId;
    }

    public double getAmount() {
        return amount;
    }

    public PaymentMethod getMethod() {
        return method;
    }

    public LocalDate getDate() {
        return date;
    }
}
