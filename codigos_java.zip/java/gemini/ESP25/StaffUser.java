import java.util.HashSet;
import java.util.Set;

public class StaffUser {
    private final String id;
    private final String username;
    private final String password;
    private final String swipeCardId;
    private final Role role;
    private final String branchId;
    private final String systemId;
    private final Set<String> permissions = new HashSet<>();

    public StaffUser(String id, String username, String password, String swipeCardId, Role role, String branchId, String systemId) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.swipeCardId = swipeCardId;
        this.role = role;
        this.branchId = branchId;
        this.systemId = systemId;
        assignDefaultPermissions();
    }

    private void assignDefaultPermissions() {
        permissions.add("RUN_REPORT");
        if (role == Role.LOCAL_SYS_ADMIN || role == Role.LIBRARY_MANAGER || role == Role.LIBRARY_DIRECTOR || role == Role.GLOBAL_SYS_ADMIN) {
            permissions.add("CREATE_REPORT");
            permissions.add("CLONE_REPORT");
            permissions.add("MANAGE_FOLDERS");
            permissions.add("ACCESS_ALL_TABLES");
        }
        if (role == Role.GLOBAL_SYS_ADMIN || role == Role.LOCAL_SYS_ADMIN) {
            permissions.add("PURGE_RECORDS");
            permissions.add("TRANSFER_BATCH");
        }
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getSwipeCardId() {
        return swipeCardId;
    }

    public Role getRole() {
        return role;
    }

    public String getBranchId() {
        return branchId;
    }

    public String getSystemId() {
        return systemId;
    }

    public boolean hasPermission(String permission) {
        return permissions.contains(permission);
    }

    public void addPermission(String permission) {
        permissions.add(permission);
    }
}
