import java.util.HashMap;
import java.util.Map;

public class AuthenticationService {
    private final Map<String, StaffUser> usersByUsername = new HashMap<>();
    private final Map<String, StaffUser> usersByCard = new HashMap<>();

    public void registerStaff(StaffUser staff) {
        usersByUsername.put(staff.getUsername(), staff);
        if (staff.getSwipeCardId() != null) {
            usersByCard.put(staff.getSwipeCardId(), staff);
        }
    }

    public StaffUser loginWithCredentials(String username, String password) {
        StaffUser user = usersByUsername.get(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    public StaffUser loginWithCardSwipe(String swipeCardId) {
        return usersByCard.get(swipeCardId);
    }
}
