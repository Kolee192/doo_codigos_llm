import java.time.LocalDate;
import java.util.*;

public class ItemTransferUtility {
    public static class TransferJob {
        private final String jobId;
        private final List<String> itemIds;
        private final String targetBranchId;
        private final LocalDate revertDate;
        private final boolean autoRevert;

        public TransferJob(String jobId, List<String> itemIds, String targetBranchId, LocalDate revertDate, boolean autoRevert) {
            this.jobId = jobId;
            this.itemIds = itemIds;
            this.targetBranchId = targetBranchId;
            this.revertDate = revertDate;
            this.autoRevert = autoRevert;
        }

        public String getJobId() {
            return jobId;
        }

        public List<String> getItemIds() {
            return itemIds;
        }

        public String getTargetBranchId() {
            return targetBranchId;
        }

        public LocalDate getRevertDate() {
            return revertDate;
        }

        public boolean isAutoRevert() {
            return autoRevert;
        }
    }

    private final Map<String, QueryDefinition> savedTransferQueries = new HashMap<>();
    private final List<TransferJob> transferJobs = new ArrayList<>();

    public void saveQuery(String queryName, QueryDefinition query) {
        savedTransferQueries.put(queryName, query);
    }

    public QueryDefinition getSavedQuery(String queryName) {
        return savedTransferQueries.get(queryName);
    }

    public List<ItemRecord> generatePullList(LibraryRepository repository, QueryDefinition query) {
        List<ItemRecord> pullList = new ArrayList<>();
        for (ItemRecord item : repository.getItems().values()) {
            boolean match = true;
            for (QueryCriteria crit : query.getCriteria()) {
                String val = getItemFieldValue(item, crit.getField());
                if (!crit.matches(val)) {
                    match = false;
                    break;
                }
            }
            if (match) {
                pullList.add(item);
            }
        }
        return pullList;
    }

    public TransferJob transferBatch(LibraryRepository repo, List<String> itemIds, String targetBranchId, LocalDate revertDate) {
        for (String id : itemIds) {
            ItemRecord item = repo.getItems().get(id);
            if (item != null) {
                item.setCurrentBranchId(targetBranchId);
            }
        }
        TransferJob job = new TransferJob(UUID.randomUUID().toString(), itemIds, targetBranchId, revertDate, revertDate != null);
        transferJobs.add(job);
        return job;
    }

    public void revertBatchIfDue(LibraryRepository repo, LocalDate today) {
        for (TransferJob job : transferJobs) {
            if (job.isAutoRevert() && !today.isBefore(job.getRevertDate())) {
                for (String id : job.getItemIds()) {
                    ItemRecord item = repo.getItems().get(id);
                    if (item != null) {
                        item.setCurrentBranchId(item.getOriginalBranchId());
                    }
                }
            }
        }
    }

    private String getItemFieldValue(ItemRecord item, String field) {
        return switch (field.toLowerCase()) {
            case "callnumber" -> item.getCallNumber();
            case "itemtype" -> item.getItemType();
            case "genre" -> item.getGenre();
            case "format" -> item.getFormat();
            case "branch" -> item.getCurrentBranchId();
            case "status" -> item.getStatus().name();
            default -> "";
        };
    }
}
