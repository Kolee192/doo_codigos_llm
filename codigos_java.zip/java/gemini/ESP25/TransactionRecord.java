import java.time.LocalDateTime;

public class TransactionRecord {
    private final String id;
    private final LocalDateTime timestamp;
    private final String terminalId;
    private final String branchId;
    private final String systemId;
    private final String patronId;
    private final String itemId;
    private final String transactionType; // CHECKOUT, CHECKIN, HOLD_PLACED, HOLD_FILLED, PAYMENT
    private final CheckOutType checkOutType;
    private final CheckInType checkInType;
    private final HoldSource holdSource;
    private final String patronAgeRange;
    private final String patronType;
    private final String patronCounty;
    private final String patronZip;

    public TransactionRecord(String id, LocalDateTime timestamp, String terminalId, String branchId,
                             String systemId, String patronId, String itemId, String transactionType,
                             CheckOutType checkOutType, CheckInType checkInType, HoldSource holdSource,
                             String patronAgeRange, String patronType, String patronCounty, String patronZip) {
        this.id = id;
        this.timestamp = timestamp;
        this.terminalId = terminalId;
        this.branchId = branchId;
        this.systemId = systemId;
        this.patronId = patronId;
        this.itemId = itemId;
        this.transactionType = transactionType;
        this.checkOutType = checkOutType;
        this.checkInType = checkInType;
        this.holdSource = holdSource;
        this.patronAgeRange = patronAgeRange;
        this.patronType = patronType;
        this.patronCounty = patronCounty;
        this.patronZip = patronZip;
    }

    public String getId() {
        return id;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getTerminalId() {
        return terminalId;
    }

    public String getBranchId() {
        return branchId;
    }

    public String getSystemId() {
        return systemId;
    }

    public String getPatronId() {
        return patronId;
    }

    public String getItemId() {
        return itemId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public CheckOutType getCheckOutType() {
        return checkOutType;
    }

    public CheckInType getCheckInType() {
        return checkInType;
    }

    public HoldSource getHoldSource() {
        return holdSource;
    }

    public String getPatronAgeRange() {
        return patronAgeRange;
    }

    public String getPatronType() {
        return patronType;
    }

    public String getPatronCounty() {
        return patronCounty;
    }

    public String getPatronZip() {
        return patronZip;
    }
}
