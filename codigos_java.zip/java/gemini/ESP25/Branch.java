import java.util.HashMap;
import java.util.Map;

public class Branch {
    private final String id;
    private final String name;
    private final String systemId;
    private final String county;
    private final int totalCapacity;
    private final Map<String, Double> shelfSpaceAllocation = new HashMap<>(); // genre/format -> shelf capacity %

    public Branch(String id, String name, String systemId, String county, int totalCapacity) {
        this.id = id;
        this.name = name;
        this.systemId = systemId;
        this.county = county;
        this.totalCapacity = totalCapacity;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSystemId() {
        return systemId;
    }

    public String getCounty() {
        return county;
    }

    public int totalCapacity() {
        return totalCapacity;
    }

    public Map<String, Double> getShelfSpaceAllocation() {
        return shelfSpaceAllocation;
    }

    public void setShelfSpaceAllocation(String category, double percentage) {
        shelfSpaceAllocation.put(category, percentage);
    }
}
