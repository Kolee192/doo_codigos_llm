import java.time.LocalDate;

public class Charge {
    private final String id;
    private final String patronId;
    private final String itemId;
    private final String branchId;
    private final ChargeType chargeType;
    private final double amount;
    private double balanceRemaining;
    private final LocalDate dateAccrued;

    public Charge(String id, String patronId, String itemId, String branchId,
                  ChargeType chargeType, double amount, LocalDate dateAccrued) {
        this.id = id;
        this.patronId = patronId;
        this.itemId = itemId;
        this.branchId = branchId;
        this.chargeType = chargeType;
        this.amount = amount;
        this.balanceRemaining = amount;
        this.dateAccrued = dateAccrued;
    }

    public String getId() {
        return id;
    }

    public String getPatronId() {
        return patronId;
    }

    public String getItemId() {
        return itemId;
    }

    public String getBranchId() {
        return branchId;
    }

    public ChargeType getChargeType() {
        return chargeType;
    }

    public double getAmount() {
        return amount;
    }

    public double getBalanceRemaining() {
        return balanceRemaining;
    }

    public void reduceBalance(double payment) {
        this.balanceRemaining = Math.max(0.0, this.balanceRemaining - payment);
    }

    public LocalDate getDateAccrued() {
        return dateAccrued;
    }
}
