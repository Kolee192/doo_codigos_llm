import java.time.LocalDate;
import java.util.*;

public class FinancialLedger {
    private final List<Charge> charges = new ArrayList<>();
    private final List<Payment> payments = new ArrayList<>();
    private final List<AuditEntry> auditEntries = new ArrayList<>();
    private final Map<String, Double> waivedByBranch = new HashMap<>();

    public void addCharge(Charge charge) {
        charges.add(charge);
    }

    public void applyPayment(Payment payment, String chargeId) {
        payments.add(payment);
        for (Charge charge : charges) {
            if (charge.getId().equals(chargeId)) {
                double applied = Math.min(payment.getAmount(), charge.getBalanceRemaining());
                charge.reduceBalance(applied);
                auditEntries.add(new AuditEntry(
                        UUID.randomUUID().toString(),
                        payment.getId(),
                        chargeId,
                        payment.getPatronId(),
                        payment.getBranchId(),
                        applied,
                        "PAYMENT",
                        payment.getDate()
                ));
                break;
            }
        }
    }

    public void waiveCharge(String chargeId, String staffBranchId, double amount, LocalDate date) {
        for (Charge charge : charges) {
            if (charge.getId().equals(chargeId)) {
                double applied = Math.min(amount, charge.getBalanceRemaining());
                charge.reduceBalance(applied);
                waivedByBranch.put(staffBranchId, waivedByBranch.getOrDefault(staffBranchId, 0.0) + applied);
                auditEntries.add(new AuditEntry(
                        UUID.randomUUID().toString(),
                        "WAIVER-" + UUID.randomUUID().toString().substring(0, 5),
                        chargeId,
                        charge.getPatronId(),
                        staffBranchId,
                        applied,
                        "WAIVER",
                        date
                ));
                break;
            }
        }
    }

    public double getPatronBalance(String patronId) {
        return charges.stream()
                .filter(c -> c.getPatronId().equals(patronId))
                .mapToDouble(Charge::getBalanceRemaining)
                .sum();
    }

    public List<Charge> getCharges() {
        return charges;
    }

    public List<Payment> getPayments() {
        return payments;
    }

    public List<AuditEntry> getAuditEntries() {
        return auditEntries;
    }

    public double getWaivedAmountForBranch(String branchId) {
        return waivedByBranch.getOrDefault(branchId, 0.0);
    }
}
