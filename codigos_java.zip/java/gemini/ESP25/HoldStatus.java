public enum HoldStatus {
    ACTIVE,
    FROZEN,
    FROZEN_UNTIL,
    FILLED
}
