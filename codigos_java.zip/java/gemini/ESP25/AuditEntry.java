import java.time.LocalDate;

public class AuditEntry {
    private final String entryId;
    private final String paymentOrWaiverId;
    private final String chargeId;
    private final String patronId;
    private final String branchId;
    private final double amountApplied;
    private final String actionType; // PAYMENT, WAIVER
    private final LocalDate timestamp;

    public AuditEntry(String entryId, String paymentOrWaiverId, String chargeId,
                      String patronId, String branchId, double amountApplied,
                      String actionType, LocalDate timestamp) {
        this.entryId = entryId;
        this.paymentOrWaiverId = paymentOrWaiverId;
        this.chargeId = chargeId;
        this.patronId = patronId;
        this.branchId = branchId;
        this.amountApplied = amountApplied;
        this.actionType = actionType;
        this.timestamp = timestamp;
    }

    public String getEntryId() {
        return entryId;
    }

    public String getPaymentOrWaiverId() {
        return paymentOrWaiverId;
    }

    public String getChargeId() {
        return chargeId;
    }

    public String getPatronId() {
        return patronId;
    }

    public String getBranchId() {
        return branchId;
    }

    public double getAmountApplied() {
        return amountApplied;
    }

    public String getActionType() {
        return actionType;
    }

    public LocalDate getTimestamp() {
        return timestamp;
    }
}
