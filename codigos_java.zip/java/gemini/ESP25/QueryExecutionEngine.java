import java.util.*;

public class QueryExecutionEngine {
    public QueryResult executeQuery(StaffUser user, QueryDefinition query, LibraryRepository repository) {
        // Enforce field/table access permissions
        if (!user.hasPermission("ACCESS_ALL_TABLES") && query.getTargetRecordType().equalsIgnoreCase("PATRON")) {
            throw new SecurityException("Staff member " + user.getUsername() + " not authorized to query Patron records directly.");
        }

        List<Map<String, String>> results = new ArrayList<>();
        if ("ITEM".equalsIgnoreCase(query.getTargetRecordType())) {
            for (ItemRecord item : repository.getItems().values()) {
                if (evalItem(item, query)) {
                    Map<String, String> row = new LinkedHashMap<>();
                    for (String field : query.getSelectedFields()) {
                        row.put(field, getItemValue(item, field));
                    }
                    results.add(row);
                }
            }
        } else if ("PATRON".equalsIgnoreCase(query.getTargetRecordType())) {
            for (Patron patron : repository.getPatrons().values()) {
                if (evalPatron(patron, query)) {
                    Map<String, String> row = new LinkedHashMap<>();
                    for (String field : query.getSelectedFields()) {
                        row.put(field, getPatronValue(patron, field));
                    }
                    results.add(row);
                }
            }
        }
        return new QueryResult(query, results);
    }

    private boolean evalItem(ItemRecord item, QueryDefinition query) {
        if (query.getCriteria().isEmpty()) return true;
        boolean isAnd = "AND".equalsIgnoreCase(query.getBooleanLogic());
        for (QueryCriteria crit : query.getCriteria()) {
            boolean matches = crit.matches(getItemValue(item, crit.getField()));
            if (isAnd && !matches) return false;
            if (!isAnd && matches) return true;
        }
        return isAnd;
    }

    private boolean evalPatron(Patron patron, QueryDefinition query) {
        if (query.getCriteria().isEmpty()) return true;
        boolean isAnd = "AND".equalsIgnoreCase(query.getBooleanLogic());
        for (QueryCriteria crit : query.getCriteria()) {
            boolean matches = crit.matches(getPatronValue(patron, crit.getField()));
            if (isAnd && !matches) return false;
            if (!isAnd && matches) return true;
        }
        return isAnd;
    }

    private String getItemValue(ItemRecord item, String field) {
        return switch (field.toLowerCase()) {
            case "id" -> item.getId();
            case "barcode" -> item.getBarcode();
            case "callnumber" -> item.getCallNumber();
            case "status" -> item.getStatus().name();
            case "price" -> String.valueOf(item.getPrice());
            case "branch" -> item.getCurrentBranchId();
            case "itemtype" -> item.getItemType();
            case "genre" -> item.getGenre();
            case "format" -> item.getFormat();
            default -> "";
        };
    }

    private String getPatronValue(Patron p, String field) {
        return switch (field.toLowerCase()) {
            case "id" -> p.getId();
            case "name" -> p.getName();
            case "county" -> p.getCounty();
            case "agerange" -> p.getAgeRange();
            case "zipcode" -> p.getZipCode();
            case "homebranch" -> p.getHomeBranchId();
            case "patrontype" -> p.getPatronType();
            case "language" -> p.getPreferredLanguage();
            default -> "";
        };
    }
}
