import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ReportQueueService {
    private final List<QueuedReport> queue = new ArrayList<>();

    public synchronized QueuedReport enqueueReport(String templateName, String staffId) {
        int position = queue.size() + 1;
        QueuedReport job = new QueuedReport(UUID.randomUUID().toString(), templateName, staffId, position);
        queue.add(job);
        return job;
    }

    public synchronized int getQueuePosition(String reportJobId) {
        for (QueuedReport job : queue) {
            if (job.getReportJobId().equals(reportJobId)) {
                return job.getQueuePosition();
            }
        }
        return -1;
    }

    public synchronized void processNext() {
        if (!queue.isEmpty()) {
            queue.remove(0);
            for (int i = 0; i < queue.size(); i++) {
                queue.get(i).setQueuePosition(i + 1);
            }
        }
    }
}
