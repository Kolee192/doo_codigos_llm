import java.time.LocalDate;

public class Patron {
    private final String id;
    private final String name;
    private final boolean hasCard;
    private final String ageRange;
    private final String zipCode;
    private final String county;
    private final String homeBranchId;
    private final String patronType;
    private final String preferredLanguage;
    private LocalDate lastActivityDate;

    public Patron(String id, String name, boolean hasCard, String ageRange, String zipCode,
                  String county, String homeBranchId, String patronType, String preferredLanguage,
                  LocalDate lastActivityDate) {
        this.id = id;
        this.name = name;
        this.hasCard = hasCard;
        this.ageRange = ageRange;
        this.zipCode = zipCode;
        this.county = county;
        this.homeBranchId = homeBranchId;
        this.patronType = patronType;
        this.preferredLanguage = preferredLanguage;
        this.lastActivityDate = lastActivityDate;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public boolean isHasCard() {
        return hasCard;
    }

    public String getAgeRange() {
        return ageRange;
    }

    public String getZipCode() {
        return zipCode;
    }

    public String getCounty() {
        return county;
    }

    public String getHomeBranchId() {
        return homeBranchId;
    }

    public String getPatronType() {
        return patronType;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public LocalDate getLastActivityDate() {
        return lastActivityDate;
    }

    public void setLastActivityDate(LocalDate lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }
}
