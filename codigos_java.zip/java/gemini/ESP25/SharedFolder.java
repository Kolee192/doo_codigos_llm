import java.util.HashSet;
import java.util.Set;

public class SharedFolder {
    private final String id;
    private final String name;
    private final Set<String> allowedStaffIds = new HashSet<>();
    private final Set<String> allowedSystemIds = new HashSet<>();

    public SharedFolder(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void grantAccessToStaff(String staffId) {
        allowedStaffIds.add(staffId);
    }

    public void grantAccessToSystem(String systemId) {
        allowedSystemIds.add(systemId);
    }

    public boolean canAccess(StaffUser staff) {
        if (staff.getRole() == Role.GLOBAL_SYS_ADMIN) return true;
        return allowedStaffIds.contains(staff.getId()) || allowedSystemIds.contains(staff.getSystemId());
    }
}
