import java.util.List;
import java.util.Map;

public class QueryResult {
    private final QueryDefinition querySelections;
    private final List<Map<String, String>> results;

    public QueryResult(QueryDefinition querySelections, List<Map<String, String>> results) {
        this.querySelections = querySelections;
        this.results = results;
    }

    public QueryDefinition getQuerySelections() {
        return querySelections;
    }

    public List<Map<String, String>> getResults() {
        return results;
    }
}
