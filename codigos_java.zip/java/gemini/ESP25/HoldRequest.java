import java.time.LocalDateTime;

public class HoldRequest {
    private final String id;
    private final String bibId;
    private final String itemId;
    private final String patronId;
    private final String pickupBranchId;
    private final LocalDateTime requestDate;
    private final HoldSource source;
    private HoldStatus status;

    public HoldRequest(String id, String bibId, String itemId, String patronId,
                       String pickupBranchId, LocalDateTime requestDate, HoldSource source,
                       HoldStatus status) {
        this.id = id;
        this.bibId = bibId;
        this.itemId = itemId;
        this.patronId = patronId;
        this.pickupBranchId = pickupBranchId;
        this.requestDate = requestDate;
        this.source = source;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getBibId() {
        return bibId;
    }

    public String getItemId() {
        return itemId;
    }

    public String getPatronId() {
        return patronId;
    }

    public String getPickupBranchId() {
        return pickupBranchId;
    }

    public LocalDateTime getRequestDate() {
        return requestDate;
    }

    public HoldSource getSource() {
        return source;
    }

    public HoldStatus getStatus() {
        return status;
    }

    public void setStatus(HoldStatus status) {
        this.status = status;
    }
}
