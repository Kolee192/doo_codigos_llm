public enum CheckInType {
    BOOK_DROP,
    TERMINAL,
    SELF_SERVICE
}
