import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== PINES Integrated Library System Starting Up ===");

        // Setup base repository and ledger
        LibraryRepository repo = new LibraryRepository();
        FinancialLedger ledger = new FinancialLedger();
        DeletionTracker deletionTracker = new DeletionTracker();
        ReportingService reportingService = new ReportingService(repo, ledger, deletionTracker);
        AuthenticationService authService = new AuthenticationService();
        ReportQueueService queueService = new ReportQueueService();
        QueryExecutionEngine queryEngine = new QueryExecutionEngine();
        ItemTransferUtility transferUtility = new ItemTransferUtility();

        // 1. Organization Setup
        LibrarySystem pcls = new LibrarySystem("SYS-01", "Peach County Library System");
        repo.addSystem(pcls);

        Branch branchA = new Branch("BR-A", "Athens Regional Library", "SYS-01", "Clarke", 50000);
        Branch branchB = new Branch("BR-B", "Bogart Branch", "SYS-01", "Oconee", 20000);
        branchA.setShelfSpaceAllocation("Book - Adult Fiction", 35.0);
        branchA.setShelfSpaceAllocation("Book - Children", 25.0);
        branchA.setShelfSpaceAllocation("DVD - Movie", 15.0);

        repo.addBranch(branchA);
        repo.addBranch(branchB);

        // 2. Staff & Streamlined Login (PINES-001)
        StaffUser adminUser = new StaffUser("ST-01", "ladmin", "pass123", "CARD-9991", Role.LOCAL_SYS_ADMIN, "BR-A", "SYS-01");
        StaffUser clerkUser = new StaffUser("ST-02", "deskclerk", "pass123", "CARD-2234", Role.STAFF, "BR-A", "SYS-01");
        authService.registerStaff(adminUser);
        authService.registerStaff(clerkUser);

        StaffUser loggedInViaSwipe = authService.loginWithCardSwipe("CARD-9991");
        System.out.println("Login Test (PINES-001): Swiped Card for Staff " + (loggedInViaSwipe != null ? loggedInViaSwipe.getUsername() : "Failed"));

        // 3. Patrons Setup (PINES-023)
        Patron p1 = new Patron("P-01", "Alice Miller", true, "30-39", "30601", "Clarke", "BR-A", "ADULT", "ENG", LocalDate.now().minusDays(10));
        Patron p2 = new Patron("P-02", "Bob Jones", true, "12-18", "30602", "Clarke", "BR-A", "JUVENILE", "SPA", LocalDate.now().minusDays(150));
        Patron p3 = new Patron("P-03", "Charlie Brown", false, "65+", "30677", "Oconee", "INVALID-BR", "SENIOR", "ENG", LocalDate.now().minusDays(400));
        repo.addPatron(p1);
        repo.addPatron(p2);
        repo.addPatron(p3);

        // 4. Bib & Item Catalog Setup
        BibRecord bib1 = new BibRecord("BIB-100", "Gone with the Wind", "Margaret Mitchell");
        BibRecord bib2 = new BibRecord("BIB-200", "To Kill a Mockingbird", "Harper Lee");
        BibRecord bib3 = new BibRecord("BIB-300", "Empty Bib With No Items", "Anonymous");
        repo.addBib(bib1);
        repo.addBib(bib2);
        repo.addBib(bib3);

        ItemRecord item1 = new ItemRecord("ITEM-01", "BIB-100", "30001001", "FIC MIT", "BOOK", "Book", "Adult Fiction", ItemStatus.AVAILABLE, 24.95, "BR-A", "SYS-01", false);
        ItemRecord item2 = new ItemRecord("ITEM-02", "BIB-100", "30001002", "FIC MIT", "BOOK", "Book", "Adult Fiction", ItemStatus.IN_TRANSIT, 24.95, "BR-A", "SYS-01", false);
        item2.setDaysInTransit(14); // > X days in transit
        ItemRecord item3 = new ItemRecord("ITEM-03", "BIB-200", "30002001", "FIC LEE", "BOOK", "Book", "Adult Fiction", ItemStatus.MISSING, 18.50, "BR-A", "SYS-01", false);
        item3.setMonthsInStatus(7); // missing > 6 months
        ItemRecord item4 = new ItemRecord("ITEM-04", "BIB-200", "30002002", "SUPER_LONG_CALL_NUM_1234567890_OVERFLOW", "INVALID_TYPE", "DVD", "Movie", ItemStatus.AVAILABLE, 29.99, "BR-B", "SYS-01", false);
        ItemRecord item5 = new ItemRecord("ITEM-05", "BIB-100", "30009999", "UNCAT-BOARD", "BOARD", "Board Book", "Children", ItemStatus.AVAILABLE, 7.99, "BR-A", "SYS-01", true);

        item1.incrementCheckouts(7);
        item1.incrementRenewals();
        item1.setLastCheckoutDate(LocalDate.now().minusDays(20));

        repo.addItem(item1);
        repo.addItem(item2);
        repo.addItem(item3);
        repo.addItem(item4);
        repo.addItem(item5);

        // 5. Holds Setup (PINES-029, PINES-030)
        HoldRequest h1 = new HoldRequest("H-1", "BIB-100", "ITEM-02", "P-01", "BR-A", LocalDateTime.now().minusDays(2), HoldSource.REMOTE, HoldStatus.ACTIVE);
        HoldRequest h2 = new HoldRequest("H-2", "BIB-200", null, "P-02", "BR-A", LocalDateTime.now().minusDays(1), HoldSource.PUBLIC_COMPUTER, HoldStatus.FROZEN);
        repo.addHold(h1);
        repo.addHold(h2);

        // 6. Transactions & Demographics Archive (PINES-006, PINES-013, PINES-025, PINES-026, PINES-027, PINES-028)
        TransactionRecord tx1 = new TransactionRecord("TX-1", LocalDateTime.now().minusHours(2), "TERM-1", "BR-A", "SYS-01",
                "P-01", "ITEM-01", "CHECKOUT", CheckOutType.STAFF_CHECKOUT, null, null, "30-39", "ADULT", "Clarke", "30601");
        TransactionRecord tx2 = new TransactionRecord("TX-2", LocalDateTime.now().minusHours(1), "TERM-1", "BR-A", "SYS-01",
                "P-01", "ITEM-01", "CHECKOUT", CheckOutType.ONLINE_RENEWAL, null, null, "30-39", "ADULT", "Clarke", "30601");
        TransactionRecord tx3 = new TransactionRecord("TX-3", LocalDateTime.now().minusMinutes(30), "TERM-2", "BR-A", "SYS-01",
                "P-01", "ITEM-01", "CHECKIN", null, CheckInType.BOOK_DROP, null, "30-39", "ADULT", "Clarke", "30601");

        repo.addTransaction(tx1);
        repo.addTransaction(tx2);
        repo.addTransaction(tx3);

        // Archive protecting privacy
        repo.archiveTransactionDemographics(tx1);
        repo.archiveTransactionDemographics(tx2);
        repo.archiveTransactionDemographics(tx3);

        // 7. Financial & Auditing Setup (PINES-031 to PINES-035)
        Charge c1 = new Charge("CHG-1", "P-01", "ITEM-03", "BR-A", ChargeType.LOST_ITEM, 18.50, LocalDate.now().minusDays(15));
        Charge c2 = new Charge("CHG-2", "P-02", "ITEM-01", "BR-A", ChargeType.OVERDUE_FINE, 4.00, LocalDate.now().minusDays(5));
        ledger.addCharge(c1);
        ledger.addCharge(c2);

        Payment pay1 = new Payment("PAY-1", "P-01", "BR-A", 10.00, PaymentMethod.OPAC, LocalDate.now());
        ledger.applyPayment(pay1, "CHG-1");
        ledger.waiveCharge("CHG-2", "BR-A", 4.00, LocalDate.now());

        System.out.println("Patron P-01 balance after $10 payment: $" + ledger.getPatronBalance("P-01"));
        System.out.println("Patron P-02 balance after full waiver: $" + ledger.getPatronBalance("P-02"));
        System.out.println("Audit trail entries count: " + ledger.getAuditEntries().size());

        // 8. Report Template, Permission & Query Execution (PINES-002, 003, 004, 008, 009)
        SharedFolder adminFolder = new SharedFolder("FLD-01", "System Administrator Reports");
        adminFolder.grantAccessToSystem("SYS-01");

        QueryDefinition weedingQuery = new QueryDefinition("ITEM");
        weedingQuery.addSelectedField("id");
        weedingQuery.addSelectedField("callNumber");
        weedingQuery.addSelectedField("status");
        weedingQuery.addCriterion(new QueryCriteria("status", "EQUALS", "AVAILABLE"));

        ReportTemplate weedTemplate = new ReportTemplate("TPL-01", "Weeding Candidates", "FLD-01", weedingQuery);
        weedTemplate.allowFilterAlteration("callNumber");
        weedTemplate.allowDisplayFieldAlteration("barcode");

        System.out.println("\nTemplate Filter check: can alter callNumber? " + weedTemplate.canAlterFilter("callNumber") +
                " | can alter status? " + weedTemplate.canAlterFilter("status"));

        QueuedReport queued = queueService.enqueueReport(weedTemplate.getName(), clerkUser.getId());
        System.out.println("Enqueued Report Job: " + queued.getReportJobId() + " at Queue Position: " + queueService.getQueuePosition(queued.getReportJobId()));

        QueryResult qResult = queryEngine.executeQuery(clerkUser, weedingQuery, repo);
        System.out.println("Query Selection Display (PINES-008): " + qResult.getQuerySelections().getCriteria());
        System.out.println("Query Result Size: " + qResult.getResults().size());

        // 9. Board Reports & Demographics (PINES-005, PINES-012, PINES-013)
        System.out.println("\nBoard Report (by branch): " + reportingService.generateBoardReport("branch"));
        System.out.println("Branch A Use Analysis (PINES-012): " + reportingService.analyzeBranchUse("BR-A"));
        System.out.println("Anonymized Transactions by County (PINES-013): " + reportingService.getAnonymizedTransactionsByRegion());

        // 10. Periodic Reports (PINES-007)
        System.out.println("\nPeriodic Reports:");
        System.out.println("1. Bib Records with holds: " + reportingService.getBibRecordsWithHolds().size());
        System.out.println("2. In-transit items > 5 days (PINES-020): " + reportingService.getInTransitItemsExceedingDays(5).size());
        System.out.println("3. Last copies in SYS-01: " + reportingService.getLastCopiesInSystem("SYS-01").size());
        System.out.println("4. Items with invalid item type: " + reportingService.getItemsWithInvalidItemType(Set.of("BOOK", "BOARD")).size());
        System.out.println("5. In-transit items with outstanding hold: " + reportingService.getInTransitItemsWithOutstandingHold().size());
        System.out.println("6. Long call numbers (> 20 chars): " + reportingService.getItemsWithLongCallNumber(20).size());
        System.out.println("7. Missing/Damaged items: " + reportingService.getMissingItemsPerBranch("BR-A").size());
        System.out.println("8. Bib records with NO items attached: " + reportingService.getBibsWithNoItems().size());
        System.out.println("9. Patrons with invalid home library: " + reportingService.getPatronsWithInvalidHomeLibrary().size());

        // 11. Inventory & Shelf Space (PINES-014, PINES-015, PINES-016, PINES-017)
        System.out.println("\nBranch A Volume & Capacity: " + reportingService.getBranchVolumeReport("BR-A"));
        System.out.println("Branch A Shelf Space Analysis: " + reportingService.getShelfSpaceReport("BR-A"));

        // 12. Batch Item Transfer Utility (PINES-018)
        ItemTransferUtility.TransferJob transferJob = transferUtility.transferBatch(repo, List.of("ITEM-01"), "BR-B", LocalDate.now().plusDays(30));
        System.out.println("Transferred ITEM-01 to BR-B for outreach: " + repo.getItems().get("ITEM-01").getCurrentBranchId());
        transferUtility.revertBatchIfDue(repo, LocalDate.now().plusDays(35));
        System.out.println("After Reversion Date, ITEM-01 location reverted to: " + repo.getItems().get("ITEM-01").getCurrentBranchId());

        // 13. Record Purging & Deletions Tracking (PINES-021, PINES-022)
        List<ItemRecord> purgeCandidates = reportingService.identifyItemsToPurge(6);
        System.out.println("\nPurge Candidates (missing > 6 months or weed): " + purgeCandidates.size());
        if (!purgeCandidates.isEmpty()) {
            reportingService.purgeItem(purgeCandidates.get(0).getId(), adminUser);
            System.out.println("Purged item " + purgeCandidates.get(0).getId() + ". Deletion records tracked: " + deletionTracker.countDeletions(null, "SYS-01", "ITEM"));
        }

        // 14. Inactive Patrons & Financial Reports (PINES-024, PINES-031, PINES-034)
        System.out.println("Inactive patrons (> 90 days): " + reportingService.getInactivePatrons(90, LocalDate.now(), "SYS-01").size());
        System.out.println("Total Collection Value: $" + reportingService.calculateCollectionValue(null, null, null));
        System.out.println("Patrons with balance > $5: " + reportingService.getPatronsWithBalanceExceeding(5.00).size());
        System.out.println("Accrued Charges by Type: " + reportingService.getChargesAccruedByType());
        System.out.println("Payments by Method: " + reportingService.getPaymentsByMethod());

        System.out.println("\n=== All PINES System Requirements Demonstrated Successfully ===");
    }
}
