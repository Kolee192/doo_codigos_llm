import java.util.ArrayList;
import java.util.List;

public class QueryDefinition {
    private final String targetRecordType; // ITEM, PATRON, BIB, TRANSACTION
    private final List<String> selectedFields = new ArrayList<>();
    private final List<QueryCriteria> criteria = new ArrayList<>();
    private String booleanLogic = "AND"; // AND / OR

    public QueryDefinition(String targetRecordType) {
        this.targetRecordType = targetRecordType;
    }

    public String getTargetRecordType() {
        return targetRecordType;
    }

    public List<String> getSelectedFields() {
        return selectedFields;
    }

    public void addSelectedField(String field) {
        selectedFields.add(field);
    }

    public List<QueryCriteria> getCriteria() {
        return criteria;
    }

    public void addCriterion(QueryCriteria criterion) {
        criteria.add(criterion);
    }

    public String getBooleanLogic() {
        return booleanLogic;
    }

    public void setBooleanLogic(String booleanLogic) {
        this.booleanLogic = booleanLogic;
    }
}
