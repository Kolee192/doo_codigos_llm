import java.util.regex.Pattern;

public class QueryCriteria {
    private final String field;
    private final String operator; // EQUALS, REGEX, GREATER_THAN, LESS_THAN, IN_PICKLIST
    private final String value;

    public QueryCriteria(String field, String operator, String value) {
        this.field = field;
        this.operator = operator;
        this.value = value;
    }

    public String getField() {
        return field;
    }

    public String getOperator() {
        return operator;
    }

    public String getValue() {
        return value;
    }

    public boolean matches(String fieldValue) {
        if (fieldValue == null) return false;
        return switch (operator) {
            case "EQUALS" -> fieldValue.equalsIgnoreCase(value);
            case "REGEX" -> Pattern.compile(value).matcher(fieldValue).find();
            case "GREATER_THAN" -> Double.parseDouble(fieldValue) > Double.parseDouble(value);
            case "LESS_THAN" -> Double.parseDouble(fieldValue) < Double.parseDouble(value);
            case "IN_PICKLIST" -> {
                String[] items = value.split(",");
                for (String it : items) {
                    if (it.trim().equalsIgnoreCase(fieldValue)) yield true;
                }
                yield false;
            }
            default -> false;
        };
    }

    @Override
    public String toString() {
        return field + " " + operator + " '" + value + "'";
    }
}
