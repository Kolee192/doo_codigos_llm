import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DeletionTracker {
    public static class DeletionRecord {
        private final String recordType; // ITEM, PATRON, BIB
        private final String recordId;
        private final String branchId;
        private final String systemId;
        private final LocalDate date;

        public DeletionRecord(String recordType, String recordId, String branchId, String systemId, LocalDate date) {
            this.recordType = recordType;
            this.recordId = recordId;
            this.branchId = branchId;
            this.systemId = systemId;
            this.date = date;
        }

        public String getRecordType() {
            return recordType;
        }

        public String getRecordId() {
            return recordId;
        }

        public String getBranchId() {
            return branchId;
        }

        public String getSystemId() {
            return systemId;
        }

        public LocalDate getDate() {
            return date;
        }
    }

    private final List<DeletionRecord> records = new ArrayList<>();

    public void recordDeletion(String type, String id, String branchId, String systemId, LocalDate date) {
        records.add(new DeletionRecord(type, id, branchId, systemId, date));
    }

    public long countDeletions(String branchId, String systemId, String type) {
        return records.stream().filter(r -> {
            boolean matchesBranch = (branchId == null || r.getBranchId().equals(branchId));
            boolean matchesSys = (systemId == null || r.getSystemId().equals(systemId));
            boolean matchesType = (type == null || r.getRecordType().equalsIgnoreCase(type));
            return matchesBranch && matchesSys && matchesType;
        }).count();
    }
}
