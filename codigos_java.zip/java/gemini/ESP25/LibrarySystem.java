import java.util.ArrayList;
import java.util.List;

public class LibrarySystem {
    private final String id;
    private final String name;
    private final List<Branch> branches = new ArrayList<>();

    public LibrarySystem(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Branch> getBranches() {
        return branches;
    }

    public void addBranch(Branch branch) {
        branches.add(branch);
    }
}
