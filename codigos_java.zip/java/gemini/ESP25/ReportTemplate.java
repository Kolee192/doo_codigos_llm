import java.util.HashSet;
import java.util.Set;

public class ReportTemplate {
    private final String id;
    private final String name;
    private final String folderId;
    private final QueryDefinition baseQuery;
    private final Set<String> alterableFilters = new HashSet<>();
    private final Set<String> alterableDisplayFields = new HashSet<>();

    public ReportTemplate(String id, String name, String folderId, QueryDefinition baseQuery) {
        this.id = id;
        this.name = name;
        this.folderId = folderId;
        this.baseQuery = baseQuery;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getFolderId() {
        return folderId;
    }

    public QueryDefinition getBaseQuery() {
        return baseQuery;
    }

    public Set<String> getAlterableFilters() {
        return alterableFilters;
    }

    public void allowFilterAlteration(String filterField) {
        alterableFilters.add(filterField);
    }

    public Set<String> getAlterableDisplayFields() {
        return alterableDisplayFields;
    }

    public void allowDisplayFieldAlteration(String displayField) {
        alterableDisplayFields.add(displayField);
    }

    public boolean canAlterFilter(String field) {
        return alterableFilters.contains(field);
    }

    public boolean canAlterDisplayField(String field) {
        return alterableDisplayFields.contains(field);
    }
}
