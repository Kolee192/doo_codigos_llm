public enum PaymentMethod {
    STAFF_DESK,
    SELF_CHECK,
    OPAC
}
