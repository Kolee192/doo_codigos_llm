import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class ReportingService {
    private final LibraryRepository repository;
    private final FinancialLedger ledger;
    private final DeletionTracker deletionTracker;

    public ReportingService(LibraryRepository repository, FinancialLedger ledger, DeletionTracker deletionTracker) {
        this.repository = repository;
        this.ledger = ledger;
        this.deletionTracker = deletionTracker;
    }

    // PINES-005: Board Reports & Activity cross-tabulated
    public Map<String, Object> generateBoardReport(String groupBy) {
        Map<String, Object> report = new LinkedHashMap<>();
        Map<String, Long> checkouts = new HashMap<>();
        Map<String, Long> checkins = new HashMap<>();
        Map<String, Long> holdsPlaced = new HashMap<>();
        Map<String, Long> holdsFilled = new HashMap<>();

        for (TransactionRecord tx : repository.getTransactions()) {
            String key = switch (groupBy.toLowerCase()) {
                case "branch" -> tx.getBranchId();
                case "terminal" -> tx.getTerminalId();
                case "system" -> tx.getSystemId();
                case "hour" -> String.valueOf(tx.getTimestamp().getHour());
                case "agerange" -> tx.getPatronAgeRange();
                case "patrontype" -> tx.getPatronType();
                case "location" -> tx.getPatronCounty();
                default -> "All";
            };

            switch (tx.getTransactionType()) {
                case "CHECKOUT" -> checkouts.put(key, checkouts.getOrDefault(key, 0L) + 1);
                case "CHECKIN" -> checkins.put(key, checkins.getOrDefault(key, 0L) + 1);
                case "HOLD_PLACED" -> holdsPlaced.put(key, holdsPlaced.getOrDefault(key, 0L) + 1);
                case "HOLD_FILLED" -> holdsFilled.put(key, holdsFilled.getOrDefault(key, 0L) + 1);
            }
        }
        report.put("checkouts", checkouts);
        report.put("checkins", checkins);
        report.put("holdsPlaced", holdsPlaced);
        report.put("holdsFilled", holdsFilled);
        return report;
    }

    // PINES-007: Periodic reports implementations
    public List<BibRecord> getBibRecordsWithHolds() {
        Set<String> bibIdsWithHolds = new HashSet<>();
        for (HoldRequest hold : repository.getHolds()) {
            if (hold.getStatus() == HoldStatus.ACTIVE) {
                bibIdsWithHolds.add(hold.getBibId());
            }
        }
        List<BibRecord> results = new ArrayList<>();
        for (String id : bibIdsWithHolds) {
            BibRecord bib = repository.getBibs().get(id);
            if (bib != null) results.add(bib);
        }
        return results;
    }

    public List<ItemRecord> getItemsNotCheckedOutInDays(int days, LocalDate referenceDate) {
        List<ItemRecord> results = new ArrayList<>();
        for (ItemRecord item : repository.getItems().values()) {
            if (item.getLastCheckoutDate() == null || ChronoUnit.DAYS.between(item.getLastCheckoutDate(), referenceDate) > days) {
                results.add(item);
            }
        }
        return results;
    }

    public List<HoldRequest> getItemLevelHolds() {
        List<HoldRequest> results = new ArrayList<>();
        for (HoldRequest hold : repository.getHolds()) {
            if (hold.getItemId() != null) {
                results.add(hold);
            }
        }
        return results;
    }

    public List<ItemRecord> getItemsWithInvalidItemType(Set<String> validTypes) {
        List<ItemRecord> results = new ArrayList<>();
        for (ItemRecord item : repository.getItems().values()) {
            if (!validTypes.contains(item.getItemType())) {
                results.add(item);
            }
        }
        return results;
    }

    public List<ItemRecord> getInTransitItemsWithOutstandingHold() {
        Set<String> heldItemIds = new HashSet<>();
        for (HoldRequest hold : repository.getHolds()) {
            if (hold.getItemId() != null && hold.getStatus() == HoldStatus.ACTIVE) {
                heldItemIds.add(hold.getItemId());
            }
        }
        List<ItemRecord> results = new ArrayList<>();
        for (ItemRecord item : repository.getItems().values()) {
            if (item.getStatus() == ItemStatus.IN_TRANSIT && heldItemIds.contains(item.getId())) {
                results.add(item);
            }
        }
        return results;
    }

    public List<ItemRecord> getInTransitItemsExceedingDays(int days) {
        List<ItemRecord> results = new ArrayList<>();
        for (ItemRecord item : repository.getItems().values()) {
            if (item.getStatus() == ItemStatus.IN_TRANSIT && item.getDaysInTransit() > days) {
                results.add(item);
            }
        }
        return results;
    }

    public List<ItemRecord> getLastCopiesInSystem(String systemId) {
        Map<String, List<ItemRecord>> itemsByBib = new HashMap<>();
        for (ItemRecord item : repository.getItems().values()) {
            if (item.getSystemId().equals(systemId)) {
                itemsByBib.computeIfAbsent(item.getBibId(), k -> new ArrayList<>()).add(item);
            }
        }
        List<ItemRecord> lastCopies = new ArrayList<>();
        for (List<ItemRecord> copies : itemsByBib.values()) {
            if (copies.size() == 1) {
                lastCopies.add(copies.get(0));
            }
        }
        return lastCopies;
    }

    public List<ItemRecord> getItemsWithLongCallNumber(int maxLength) {
        List<ItemRecord> results = new ArrayList<>();
        for (ItemRecord item : repository.getItems().values()) {
            if (item.getCallNumber() != null && item.getCallNumber().length() > maxLength) {
                results.add(item);
            }
        }
        return results;
    }

    public List<ItemRecord> getMissingItemsPerBranch(String branchId) {
        List<ItemRecord> results = new ArrayList<>();
        for (ItemRecord item : repository.getItems().values()) {
            if ((branchId == null || item.getCurrentBranchId().equals(branchId)) &&
                (item.getStatus() == ItemStatus.MISSING || item.getStatus() == ItemStatus.DAMAGED)) {
                results.add(item);
            }
        }
        return results;
    }

    public List<BibRecord> getBibsWithNoItems() {
        List<BibRecord> results = new ArrayList<>();
        for (BibRecord bib : repository.getBibs().values()) {
            if (bib.getItemIds().isEmpty()) {
                results.add(bib);
            }
        }
        return results;
    }

    public List<Patron> getPatronsWithInvalidHomeLibrary() {
        List<Patron> results = new ArrayList<>();
        for (Patron p : repository.getPatrons().values()) {
            if (!repository.getBranches().containsKey(p.getHomeBranchId())) {
                results.add(p);
            }
        }
        return results;
    }

    // PINES-012: Behavior and use analysis
    public Map<String, Object> analyzeBranchUse(String branchId) {
        Map<String, Object> stats = new HashMap<>();
        long totalBranchCheckouts = 0;
        long totalBranchRenewals = 0;

        for (TransactionRecord tx : repository.getTransactions()) {
            if (tx.getBranchId().equals(branchId) && "CHECKOUT".equals(tx.getTransactionType())) {
                totalBranchCheckouts++;
                if (tx.getCheckOutType() == CheckOutType.STAFF_RENEWAL ||
                    tx.getCheckOutType() == CheckOutType.SELF_RENEWAL ||
                    tx.getCheckOutType() == CheckOutType.ONLINE_RENEWAL ||
                    tx.getCheckOutType() == CheckOutType.OPAC_RENEWAL) {
                    totalBranchRenewals++;
                }
            }
        }
        double renewalPercent = totalBranchCheckouts == 0 ? 0 : (double) totalBranchRenewals / totalBranchCheckouts * 100.0;
        stats.put("totalCheckouts", totalBranchCheckouts);
        stats.put("totalRenewals", totalBranchRenewals);
        stats.put("renewalPercentage", renewalPercent);
        return stats;
    }

    // PINES-013: Demographic Statistics (Anonymized)
    public Map<String, Long> getAnonymizedTransactionsByRegion() {
        Map<String, Long> counts = new HashMap<>();
        for (AnonymizedTransaction at : repository.getArchivedDemographics()) {
            counts.put(at.getPatronCounty(), counts.getOrDefault(at.getPatronCounty(), 0L) + 1);
        }
        return counts;
    }

    public Map<String, Long> getAnonymizedTransactionsByAgeRange() {
        Map<String, Long> counts = new HashMap<>();
        for (AnonymizedTransaction at : repository.getArchivedDemographics()) {
            counts.put(at.getPatronAgeRange(), counts.getOrDefault(at.getPatronAgeRange(), 0L) + 1);
        }
        return counts;
    }

    // PINES-014 & PINES-015: Material volume and Capacity
    public Map<String, Object> getBranchVolumeReport(String branchId) {
        Map<String, Object> stats = new LinkedHashMap<>();
        int total = 0;
        int onShelf = 0;
        int outCirc = 0;
        int adultFiction = 0;
        int boardBooks = 0;

        for (ItemRecord item : repository.getItems().values()) {
            if (item.getCurrentBranchId().equals(branchId)) {
                total++;
                if (item.getStatus() == ItemStatus.AVAILABLE) onShelf++;
                if (item.getStatus() == ItemStatus.CHECKED_OUT) outCirc++;
                if ("Adult Fiction".equalsIgnoreCase(item.getGenre())) adultFiction++;
                if ("Board Book".equalsIgnoreCase(item.getFormat())) boardBooks++;
            }
        }
        Branch branch = repository.getBranches().get(branchId);
        int cap = branch != null ? branch.totalCapacity() : 0;
        double capacityPercent = cap == 0 ? 0.0 : ((double) total / cap) * 100.0;

        stats.put("totalItems", total);
        stats.put("onShelf", onShelf);
        stats.put("inCirculation", outCirc);
        stats.put("adultFiction", adultFiction);
        stats.put("boardBooks", boardBooks);
        stats.put("totalCapacity", cap);
        stats.put("capacityUtilizationPercent", capacityPercent);
        return stats;
    }

    // PINES-016: Shelf Space Report
    public Map<String, Map<String, Double>> getShelfSpaceReport(String branchId) {
        Branch branch = repository.getBranches().get(branchId);
        Map<String, Map<String, Double>> report = new HashMap<>();
        Map<String, Integer> categoryItems = new HashMap<>();
        Map<String, Integer> categoryCircs = new HashMap<>();
        int totalItems = 0;
        int totalCircs = 0;

        for (ItemRecord item : repository.getItems().values()) {
            if (item.getCurrentBranchId().equals(branchId)) {
                totalItems++;
                String cat = item.getFormat() + " - " + item.getGenre();
                categoryItems.put(cat, categoryItems.getOrDefault(cat, 0) + 1);
                categoryCircs.put(cat, categoryCircs.getOrDefault(cat, 0) + item.getCheckoutCount());
                totalCircs += item.getCheckoutCount();
            }
        }

        for (String cat : categoryItems.keySet()) {
            Map<String, Double> breakdown = new HashMap<>();
            double itemPct = totalItems == 0 ? 0.0 : ((double) categoryItems.get(cat) / totalItems) * 100.0;
            double circPct = totalCircs == 0 ? 0.0 : ((double) categoryCircs.getOrDefault(cat, 0) / totalCircs) * 100.0;
            double shelfPct = (branch != null) ? branch.getShelfSpaceAllocation().getOrDefault(cat, 0.0) : 0.0;

            breakdown.put("percentCollection", itemPct);
            breakdown.put("percentCirculation", circPct);
            breakdown.put("percentShelfSpace", shelfPct);
            report.put(cat, breakdown);
        }
        return report;
    }

    // PINES-021: Item Purging
    public List<ItemRecord> identifyItemsToPurge(int missingMonthsThreshold) {
        List<ItemRecord> candidates = new ArrayList<>();
        for (ItemRecord item : repository.getItems().values()) {
            if (item.getStatus() == ItemStatus.DISCARD_WEED ||
               (item.getStatus() == ItemStatus.MISSING && item.getMonthsInStatus() >= missingMonthsThreshold)) {
                candidates.add(item);
            }
        }
        return candidates;
    }

    public void purgeItem(String itemId, StaffUser staff) {
        ItemRecord item = repository.getItems().remove(itemId);
        if (item != null) {
            BibRecord bib = repository.getBibs().get(item.getBibId());
            if (bib != null) {
                bib.removeItemId(itemId);
                if (bib.getItemIds().isEmpty()) {
                    repository.getBibs().remove(bib.getId());
                    deletionTracker.recordDeletion("BIB", bib.getId(), item.getCurrentBranchId(), item.getSystemId(), LocalDate.now());
                }
            }
            deletionTracker.recordDeletion("ITEM", itemId, item.getCurrentBranchId(), item.getSystemId(), LocalDate.now());
        }
    }

    // PINES-024: Inactive Patrons Report
    public List<Patron> getInactivePatrons(int days, LocalDate today, String systemId) {
        List<Patron> inactive = new ArrayList<>();
        for (Patron p : repository.getPatrons().values()) {
            Branch b = repository.getBranches().get(p.getHomeBranchId());
            if (systemId == null || (b != null && b.getSystemId().equals(systemId))) {
                if (p.getLastActivityDate() == null || ChronoUnit.DAYS.between(p.getLastActivityDate(), today) > days) {
                    inactive.add(p);
                }
            }
        }
        return inactive;
    }

    // PINES-027, PINES-028, PINES-029: Detailed Counts
    public Map<String, Long> getCheckInBreakdown() {
        Map<String, Long> map = new HashMap<>();
        for (TransactionRecord tx : repository.getTransactions()) {
            if ("CHECKIN".equals(tx.getTransactionType()) && tx.getCheckInType() != null) {
                map.put(tx.getCheckInType().name(), map.getOrDefault(tx.getCheckInType().name(), 0L) + 1);
            }
        }
        return map;
    }

    public Map<String, Long> getCheckOutBreakdown() {
        Map<String, Long> map = new HashMap<>();
        for (TransactionRecord tx : repository.getTransactions()) {
            if ("CHECKOUT".equals(tx.getTransactionType()) && tx.getCheckOutType() != null) {
                map.put(tx.getCheckOutType().name(), map.getOrDefault(tx.getCheckOutType().name(), 0L) + 1);
            }
        }
        return map;
    }

    public Map<String, Long> getHoldSourceBreakdown() {
        Map<String, Long> map = new HashMap<>();
        for (HoldRequest hold : repository.getHolds()) {
            map.put(hold.getSource().name(), map.getOrDefault(hold.getSource().name(), 0L) + 1);
        }
        return map;
    }

    public Map<String, Long> getHoldStatusBreakdown() {
        Map<String, Long> map = new HashMap<>();
        for (HoldRequest hold : repository.getHolds()) {
            map.put(hold.getStatus().name(), map.getOrDefault(hold.getStatus().name(), 0L) + 1);
        }
        return map;
    }

    // PINES-031: Value of items report
    public double calculateCollectionValue(String filterStatus, String filterFormat, String branchId) {
        double total = 0.0;
        for (ItemRecord item : repository.getItems().values()) {
            boolean statusMatch = (filterStatus == null || item.getStatus().name().equalsIgnoreCase(filterStatus));
            boolean formatMatch = (filterFormat == null || item.getFormat().equalsIgnoreCase(filterFormat));
            boolean branchMatch = (branchId == null || item.getCurrentBranchId().equalsIgnoreCase(branchId));

            if (statusMatch && formatMatch && branchMatch) {
                total += item.getPrice();
            }
        }
        return total;
    }

    // PINES-034: Financial reports
    public List<Patron> getPatronsWithBalanceExceeding(double minBalance) {
        List<Patron> results = new ArrayList<>();
        for (Patron p : repository.getPatrons().values()) {
            if (ledger.getPatronBalance(p.getId()) > minBalance) {
                results.add(p);
            }
        }
        return results;
    }

    public Map<ChargeType, Double> getChargesAccruedByType() {
        Map<ChargeType, Double> map = new HashMap<>();
        for (Charge charge : ledger.getCharges()) {
            map.put(charge.getChargeType(), map.getOrDefault(charge.getChargeType(), 0.0) + charge.getAmount());
        }
        return map;
    }

    public Map<PaymentMethod, Double> getPaymentsByMethod() {
        Map<PaymentMethod, Double> map = new HashMap<>();
        for (Payment payment : ledger.getPayments()) {
            map.put(payment.getMethod(), map.getOrDefault(payment.getMethod(), 0.0) + payment.getAmount());
        }
        return map;
    }
}
