public class UserDocumentation {
    public static String getGuide() {
        return """
            ======================================================================
                         RECYCLEHUB PLATFORM - USER DOCUMENTATION
            ======================================================================
            Welcome to the RecycleHub Web Application!
            
            1. ANONYMOUS BROWSING:
               - Enter a valid 5-digit US ZIP code to view recycling centers, public
                 bins, special drop-off sites, and safe disposal events.
               - Click on facility addresses to directly open navigation in Google Maps.
               - Filter facilities based on accepted waste materials (Plastic, Glass,
                 Electronics, Batteries, etc.) and check daily operating hours.
               
            2. CREATING AN ACCOUNT & PROFILE:
               - Sign up to bookmark favorite recycling & donation centers.
               - Upload your weekly schedule to obtain automatic center suggestions.
               - Link your verified email address for event alerts and password resets.
               - Request home waste pick-up with flexible scheduling.
               
            3. EARNING REWARDS:
               - Earn reward points for every kilogram of waste recycled or dropped off.
               - Check your transaction history and past contributions anytime.
               
            4. FACILITY REPRESENTATIVES & SUPERUSERS:
               - Update material acceptance policies, operating hours, and reply
                 to community inquiries directly.
               - Analyze visitor statistics and scheduled drop-offs.
               
            5. ADMINISTRATORS & EXECUTIVES:
               - Real-time platform status monitoring, neighborhood drop-off trends,
                 IP safety blocks, user error logs, and activity fee accounting.
            ======================================================================
            """;
    }
}
