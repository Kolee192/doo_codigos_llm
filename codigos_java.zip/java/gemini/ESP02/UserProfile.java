import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class UserProfile {
    private final String id;
    private final String username;
    private String email;
    private String passwordHash;
    private String encryptedPersonalInfo; // Encrypted phone/SSN/personal identity info
    private final String ipAddress;
    private UserRole role;
    private final Set<String> favoriteFacilityIds;
    private int rewardPoints;
    private UserSchedule weekSchedule;
    private String associatedFacilityId; // For facility reps/superusers

    public UserProfile(String id, String username, String email, String passwordHash, String encryptedPersonalInfo, String ipAddress, UserRole role) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
        this.encryptedPersonalInfo = encryptedPersonalInfo;
        this.ipAddress = ipAddress;
        this.role = role;
        this.favoriteFacilityIds = new HashSet<>();
        this.rewardPoints = 0;
        this.weekSchedule = new UserSchedule();
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getEncryptedPersonalInfo() {
        return encryptedPersonalInfo;
    }

    public void setEncryptedPersonalInfo(String encryptedPersonalInfo) {
        this.encryptedPersonalInfo = encryptedPersonalInfo;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public Set<String> getFavoriteFacilityIds() {
        return Collections.unmodifiableSet(favoriteFacilityIds);
    }

    public void addFavoriteFacility(String facilityId) {
        favoriteFacilityIds.add(facilityId);
    }

    public void removeFavoriteFacility(String facilityId) {
        favoriteFacilityIds.remove(facilityId);
    }

    public int getRewardPoints() {
        return rewardPoints;
    }

    public void addRewardPoints(int points) {
        this.rewardPoints += points;
    }

    public UserSchedule getWeekSchedule() {
        return weekSchedule;
    }

    public void setWeekSchedule(UserSchedule weekSchedule) {
        this.weekSchedule = weekSchedule;
    }

    public String getAssociatedFacilityId() {
        return associatedFacilityId;
    }

    public void setAssociatedFacilityId(String associatedFacilityId) {
        this.associatedFacilityId = associatedFacilityId;
    }

    public String resetPasswordWithTemporary() {
        String tempPass = "Temp#" + UUID.randomUUID().toString().substring(0, 8);
        this.passwordHash = SecurityUtils.hash(tempPass);
        return tempPass;
    }

    @Override
    public String toString() {
        return "UserProfile[" + username + " (" + role + "), Email: " + email + ", Rewards: " + rewardPoints + " pts]";
    }
}
