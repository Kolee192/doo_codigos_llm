public enum UserRole {
    CITIZEN,
    FACILITY_REP,
    SUPERUSER,
    EMPLOYEE,
    HR_OFFICER,
    ACCOUNTANT,
    ADMIN,
    EXECUTIVE
}
