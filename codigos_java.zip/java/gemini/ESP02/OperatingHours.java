import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.EnumMap;
import java.util.Map;

public class OperatingHours {
    public static class TimeSlot {
        private final LocalTime openTime;
        private final LocalTime closeTime;

        public TimeSlot(LocalTime openTime, LocalTime closeTime) {
            this.openTime = openTime;
            this.closeTime = closeTime;
        }

        public LocalTime getOpenTime() {
            return openTime;
        }

        public LocalTime getCloseTime() {
            return closeTime;
        }

        public boolean covers(LocalTime time) {
            return !time.isBefore(openTime) && !time.isAfter(closeTime);
        }

        @Override
        public String toString() {
            return openTime + " - " + closeTime;
        }
    }

    private final Map<DayOfWeek, TimeSlot> schedule = new EnumMap<>(DayOfWeek.class);

    public void setHours(DayOfWeek day, LocalTime open, LocalTime close) {
        schedule.put(day, new TimeSlot(open, close));
    }

    public TimeSlot getHours(DayOfWeek day) {
        return schedule.get(day);
    }

    public boolean isOpen(DayOfWeek day, LocalTime time) {
        TimeSlot slot = schedule.get(day);
        return slot != null && slot.covers(time);
    }

    public Map<DayOfWeek, TimeSlot> getAllHours() {
        return new EnumMap<>(schedule);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (DayOfWeek day : DayOfWeek.values()) {
            TimeSlot slot = schedule.get(day);
            sb.append(day).append(": ").append(slot != null ? slot.toString() : "Closed").append("; ");
        }
        return sb.toString();
    }
}
