import java.time.LocalDateTime;

public class FacilityCommunication {
    private final String id;
    private final String facilityId;
    private final String sender;
    private final String message;
    private final LocalDateTime sentAt;

    public FacilityCommunication(String id, String facilityId, String sender, String message) {
        this.id = id;
        this.facilityId = facilityId;
        this.sender = sender;
        this.message = message;
        this.sentAt = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public String getSender() {
        return sender;
    }

    public String getMessage() {
        return message;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    @Override
    public String toString() {
        return "[" + sentAt + "] Facility " + facilityId + " <-> " + sender + ": " + message;
    }
}
