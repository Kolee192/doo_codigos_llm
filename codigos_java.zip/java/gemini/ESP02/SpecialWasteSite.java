import java.util.Collections;
import java.util.Set;

public class SpecialWasteSite {
    private final String id;
    private final String name;
    private final Address address;
    private final Set<WasteType> acceptedSpecialTypes;
    private final String safetyProtocols;

    public SpecialWasteSite(String id, String name, Address address, Set<WasteType> acceptedSpecialTypes, String safetyProtocols) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.acceptedSpecialTypes = acceptedSpecialTypes;
        this.safetyProtocols = safetyProtocols;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return address;
    }

    public Set<WasteType> getAcceptedSpecialTypes() {
        return Collections.unmodifiableSet(acceptedSpecialTypes);
    }

    public String getSafetyProtocols() {
        return safetyProtocols;
    }

    @Override
    public String toString() {
        return "SpecialWasteSite[" + id + "] " + name + " at " + address + " Accepts: " + acceptedSpecialTypes;
    }
}
