import java.time.LocalDateTime;

public class TransactionRecord {
    private final String id;
    private final String userId;
    private final String facilityId;
    private final WasteType wasteType;
    private final double quantityKg;
    private final int rewardPointsEarned;
    private final double activityFee;
    private final LocalDateTime timestamp;

    public TransactionRecord(String id, String userId, String facilityId, WasteType wasteType, double quantityKg, int rewardPointsEarned, double activityFee) {
        this.id = id;
        this.userId = userId;
        this.facilityId = facilityId;
        this.wasteType = wasteType;
        this.quantityKg = quantityKg;
        this.rewardPointsEarned = rewardPointsEarned;
        this.activityFee = activityFee;
        this.timestamp = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public String getUserId() {
        return userId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public WasteType getWasteType() {
        return wasteType;
    }

    public double getQuantityKg() {
        return quantityKg;
    }

    public int getRewardPointsEarned() {
        return rewardPointsEarned;
    }

    public double getActivityFee() {
        return activityFee;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "Transaction[" + id + "] Date: " + timestamp + " Type: " + wasteType + " " + quantityKg + "kg Points: +" + rewardPointsEarned + " Fee: $" + String.format("%.2f", activityFee);
    }
}
