import java.time.LocalDate;
import java.time.LocalTime;

public class SafeDisposalEvent {
    private final String id;
    private final String title;
    private final Address address;
    private final LocalDate eventDate;
    private final LocalTime startTime;
    private final LocalTime endTime;
    private final String description;

    public SafeDisposalEvent(String id, String title, Address address, LocalDate eventDate, LocalTime startTime, LocalTime endTime, String description) {
        this.id = id;
        this.title = title;
        this.address = address;
        this.eventDate = eventDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public Address getAddress() {
        return address;
    }

    public LocalDate getEventDate() {
        return eventDate;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "Event[" + id + "]: " + title + " on " + eventDate + " (" + startTime + "-" + endTime + ") at " + address;
    }
}
