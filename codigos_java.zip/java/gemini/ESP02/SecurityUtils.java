import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public final class SecurityUtils {
    private SecurityUtils() {}

    public static String hash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encoded = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(encoded);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }

    public static String encryptData(String rawData, String secretKey) {
        byte[] rawBytes = rawData.getBytes(StandardCharsets.UTF_8);
        byte[] keyBytes = secretKey.getBytes(StandardCharsets.UTF_8);
        byte[] xorBytes = new byte[rawBytes.length];
        for (int i = 0; i < rawBytes.length; i++) {
            xorBytes[i] = (byte) (rawBytes[i] ^ keyBytes[i % keyBytes.length]);
        }
        return Base64.getEncoder().encodeToString(xorBytes);
    }

    public static String decryptData(String encryptedBase64, String secretKey) {
        byte[] decoded = Base64.getDecoder().decode(encryptedBase64);
        byte[] keyBytes = secretKey.getBytes(StandardCharsets.UTF_8);
        byte[] rawBytes = new byte[decoded.length];
        for (int i = 0; i < decoded.length; i++) {
            rawBytes[i] = (byte) (decoded[i] ^ keyBytes[i % keyBytes.length]);
        }
        return new String(rawBytes, StandardCharsets.UTF_8);
    }
}
