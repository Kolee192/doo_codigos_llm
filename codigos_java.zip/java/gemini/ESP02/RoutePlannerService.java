import java.util.List;

public class RoutePlannerService {
    public NeighborhoodRoutePlan createOptimalRoute(String routeId, String neighborhood, List<Address> addresses) {
        NeighborhoodRoutePlan plan = new NeighborhoodRoutePlan(routeId, neighborhood);
        int seq = 1;
        for (Address addr : addresses) {
            plan.addStep(new RouteStep(seq, addr, "Drop-off / Pick-up Node", 1.8 * seq));
            seq++;
        }
        return plan;
    }
}
