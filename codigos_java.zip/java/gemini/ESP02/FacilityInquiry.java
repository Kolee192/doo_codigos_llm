import java.time.LocalDateTime;

public class FacilityInquiry {
    private final String id;
    private final String userId;
    private final String facilityId;
    private final String question;
    private String answer;
    private final LocalDateTime askedAt;
    private LocalDateTime answeredAt;

    public FacilityInquiry(String id, String userId, String facilityId, String question) {
        this.id = id;
        this.userId = userId;
        this.facilityId = facilityId;
        this.question = question;
        this.askedAt = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public String getUserId() {
        return userId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public LocalDateTime getAskedAt() {
        return askedAt;
    }

    public LocalDateTime getAnsweredAt() {
        return answeredAt;
    }

    public void reply(String answer) {
        this.answer = answer;
        this.answeredAt = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "Inquiry[" + id + "] Q: " + question + (answer != null ? " | Reply: " + answer : " (Pending answer)");
    }
}
