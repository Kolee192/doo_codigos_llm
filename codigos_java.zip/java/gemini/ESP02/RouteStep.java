public class RouteStep {
    private final int sequence;
    private final Address address;
    private final String description;
    private final double distanceKm;

    public RouteStep(int sequence, Address address, String description, double distanceKm) {
        this.sequence = sequence;
        this.address = address;
        this.description = description;
        this.distanceKm = distanceKm;
    }

    public int getSequence() {
        return sequence;
    }

    public Address getAddress() {
        return address;
    }

    public String getDescription() {
        return description;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    @Override
    public String toString() {
        return sequence + ". " + description + " at " + address.getFullAddress() + " (~" + distanceKm + " km)";
    }
}
