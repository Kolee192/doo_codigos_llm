import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class Address {
    private final String street;
    private final String city;
    private final String state;
    private final String zipCode;
    private final double latitude;
    private final double longitude;

    public Address(String street, String city, String state, String zipCode, double latitude, double longitude) {
        this.street = street;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getFullAddress() {
        return street + ", " + city + ", " + state + " " + zipCode;
    }

    public String getGoogleMapsUrl() {
        String query = URLEncoder.encode(getFullAddress(), StandardCharsets.UTF_8);
        return "https://www.google.com/maps/search/?api=1&query=" + query;
    }

    @Override
    public String toString() {
        return getFullAddress();
    }
}
