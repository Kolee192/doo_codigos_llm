public class Employee {
    private final String id;
    private final String name;
    private final String department;
    private final String position;
    private final double salary;
    private final String email;
    private final String phone;

    public Employee(String id, String name, String department, String position, double salary, String email, String phone) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.position = position;
        this.salary = salary;
        this.email = email;
        this.phone = phone;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    @Override
    public String toString() {
        return "Employee #" + id + ": " + name + " (" + department + " - " + position + ") Salary: $" + salary + ", Contact: " + email + ", " + phone;
    }
}
