import java.util.Collections;
import java.util.Set;

public class PublicBin {
    private final String id;
    private final Address address;
    private final Set<WasteType> acceptedTypes;
    private final String description;

    public PublicBin(String id, Address address, Set<WasteType> acceptedTypes, String description) {
        this.id = id;
        this.address = address;
        this.acceptedTypes = acceptedTypes;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public Address getAddress() {
        return address;
    }

    public Set<WasteType> getAcceptedTypes() {
        return Collections.unmodifiableSet(acceptedTypes);
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "PublicBin #" + id + " at " + address + " for " + acceptedTypes;
    }
}
