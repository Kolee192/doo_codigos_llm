import java.util.Arrays;
import java.util.List;

public enum WasteType {
    PLASTIC,
    GLASS,
    METAL,
    PAPER,
    CARDBOARD,
    ELECTRONICS,
    BATTERIES,
    HAZARDOUS,
    ORGANIC,
    TEXTILES;

    public static List<WasteType> specialWasteTypes() {
        return Arrays.asList(ELECTRONICS, BATTERIES, HAZARDOUS);
    }
}
