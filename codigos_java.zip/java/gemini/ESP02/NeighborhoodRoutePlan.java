import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NeighborhoodRoutePlan {
    private final String routeId;
    private final String neighborhoodName;
    private final List<RouteStep> steps;

    public NeighborhoodRoutePlan(String routeId, String neighborhoodName) {
        this.routeId = routeId;
        this.neighborhoodName = neighborhoodName;
        this.steps = new ArrayList<>();
    }

    public void addStep(RouteStep step) {
        steps.add(step);
    }

    public String getRouteId() {
        return routeId;
    }

    public String getNeighborhoodName() {
        return neighborhoodName;
    }

    public List<RouteStep> getSteps() {
        return Collections.unmodifiableList(steps);
    }

    public double getTotalDistanceKm() {
        return steps.stream().mapToDouble(RouteStep::getDistanceKm).sum();
    }
}
