import java.time.LocalDateTime;

public class FeedbackMessage {
    private final String id;
    private final String userEmail;
    private final String subject;
    private final String message;
    private final LocalDateTime submittedAt;
    private boolean resolved;

    public FeedbackMessage(String id, String userEmail, String subject, String message) {
        this.id = id;
        this.userEmail = userEmail;
        this.subject = subject;
        this.message = message;
        this.submittedAt = LocalDateTime.now();
        this.resolved = false;
    }

    public String getId() {
        return id;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getSubject() {
        return subject;
    }

    public String getMessage() {
        return message;
    }

    public LocalDateTime getSubmittedAt() {
        return submittedAt;
    }

    public boolean isResolved() {
        return resolved;
    }

    public void setResolved(boolean resolved) {
        this.resolved = resolved;
    }

    @Override
    public String toString() {
        return "Feedback[" + id + " from " + userEmail + "]: " + subject + " - " + message + " (Resolved: " + resolved + ")";
    }
}
