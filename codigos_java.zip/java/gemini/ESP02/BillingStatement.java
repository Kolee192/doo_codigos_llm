import java.time.LocalDate;
import java.util.List;

public class BillingStatement {
    private final String invoiceNumber;
    private final LocalDate issueDate;
    private final List<TransactionRecord> transactions;
    private final double totalActivityFees;

    public BillingStatement(String invoiceNumber, LocalDate issueDate, List<TransactionRecord> transactions) {
        this.invoiceNumber = invoiceNumber;
        this.issueDate = issueDate;
        this.transactions = transactions;
        this.totalActivityFees = transactions.stream().mapToDouble(TransactionRecord::getActivityFee).sum();
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public List<TransactionRecord> getTransactions() {
        return transactions;
    }

    public double getTotalActivityFees() {
        return totalActivityFees;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== BILLING STATEMENT ===").append("\n");
        sb.append("Invoice #: ").append(invoiceNumber).append(" | Date: ").append(issueDate).append("\n");
        sb.append("Activity Count: ").append(transactions.size()).append("\n");
        for (TransactionRecord record : transactions) {
            sb.append("  - Tx: ").append(record.getId())
              .append(" | ").append(record.getWasteType())
              .append(" | Fee: $").append(String.format("%.2f", record.getActivityFee()))
              .append("\n");
        }
        sb.append("Total Activity Fees Payable: $").append(String.format("%.2f", totalActivityFees));
        return sb.toString();
    }
}
