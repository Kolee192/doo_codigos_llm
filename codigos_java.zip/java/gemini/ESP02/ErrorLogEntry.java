import java.time.LocalDateTime;

public class ErrorLogEntry {
    private final String id;
    private final String ipAddress;
    private final String userEmail;
    private final String errorDetails;
    private final LocalDateTime timestamp;

    public ErrorLogEntry(String id, String ipAddress, String userEmail, String errorDetails) {
        this.id = id;
        this.ipAddress = ipAddress;
        this.userEmail = userEmail;
        this.errorDetails = errorDetails;
        this.timestamp = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "[" + timestamp + "] IP: " + ipAddress + " (User: " + (userEmail != null ? userEmail : "Guest") + ") Error: " + errorDetails;
    }
}
