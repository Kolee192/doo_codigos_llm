import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Set;

public class PickupRequest {
    public enum Status {
        PENDING,
        ASSIGNED,
        COMPLETED,
        CANCELLED
    }

    private final String id;
    private final String userId;
    private final Address address;
    private final LocalDateTime requestedDateTime;
    private final boolean flexibleTimeWindow; // flexible pickup window
    private final Set<WasteType> wasteTypes;
    private Status status;
    private String assignedEmployeeId;

    public PickupRequest(String id, String userId, Address address, LocalDateTime requestedDateTime, boolean flexibleTimeWindow, Set<WasteType> wasteTypes) {
        this.id = id;
        this.userId = userId;
        this.address = address;
        this.requestedDateTime = requestedDateTime;
        this.flexibleTimeWindow = flexibleTimeWindow;
        this.wasteTypes = wasteTypes;
        this.status = Status.PENDING;
    }

    public String getId() {
        return id;
    }

    public String getUserId() {
        return userId;
    }

    public Address getAddress() {
        return address;
    }

    public LocalDateTime getRequestedDateTime() {
        return requestedDateTime;
    }

    public boolean isFlexibleTimeWindow() {
        return flexibleTimeWindow;
    }

    public Set<WasteType> getWasteTypes() {
        return Collections.unmodifiableSet(wasteTypes);
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getAssignedEmployeeId() {
        return assignedEmployeeId;
    }

    public void setAssignedEmployeeId(String assignedEmployeeId) {
        this.assignedEmployeeId = assignedEmployeeId;
    }

    @Override
    public String toString() {
        return "PickupRequest[" + id + "] User: " + userId + " at " + requestedDateTime + (flexibleTimeWindow ? " (Flexible)" : "") + " Status: " + status;
    }
}
