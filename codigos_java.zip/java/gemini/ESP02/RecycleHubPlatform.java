import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class RecycleHubPlatform {
    private static final String ENCRYPTION_KEY = "RecycleHubGlobalSecretKey#2024!";
    private static final Pattern ZIP_CODE_PATTERN = Pattern.compile("^\\d{5}$");

    private final Map<String, RecyclingFacility> facilities = new HashMap<>();
    private final Map<String, PublicBin> publicBins = new HashMap<>();
    private final Map<String, SpecialWasteSite> specialWasteSites = new HashMap<>();
    private final List<SafeDisposalEvent> safeDisposalEvents = new ArrayList<>();
    private final Map<String, UserProfile> users = new HashMap<>();
    private final Set<String> blockedIpAddresses = new HashSet<>();
    private final List<ErrorLogEntry> errorLogs = new ArrayList<>();
    private final List<FeedbackMessage> feedbackMessages = new ArrayList<>();
    private final List<FacilityInquiry> inquiries = new ArrayList<>();
    private final List<FacilityCommunication> facilityCommunications = new ArrayList<>();
    private final List<TransactionRecord> transactions = new ArrayList<>();
    private final List<PickupRequest> pickupRequests = new ArrayList<>();
    private final Map<String, Employee> employees = new HashMap<>();
    private final Set<String> subscribedNotificationEmails = new HashSet<>();
    private final RoutePlannerService routePlannerService = new RoutePlannerService();

    // ================= ZIP CODE VALIDATION =================
    public boolean isValidZipCode(String zipCode) {
        return zipCode != null && ZIP_CODE_PATTERN.matcher(zipCode.trim()).matches();
    }

    public void validateZipOrThrow(String zipCode, String callerIp) {
        if (!isValidZipCode(zipCode)) {
            String errorMsg = "Invalid zip code format: '" + zipCode + "'. Must be exactly 5 numeric digits.";
            logError(callerIp, null, errorMsg);
            throw new IllegalArgumentException(errorMsg);
        }
    }

    // ================= SECURITY & IP FILTER =================
    public void blockIp(String ipAddress) {
        blockedIpAddresses.add(ipAddress);
    }

    public void unblockIp(String ipAddress) {
        blockedIpAddresses.remove(ipAddress);
    }

    public boolean isIpBlocked(String ipAddress) {
        return blockedIpAddresses.contains(ipAddress);
    }

    public void verifyIpAccess(String ipAddress) {
        if (isIpBlocked(ipAddress)) {
            throw new SecurityException("Access denied: IP address " + ipAddress + " has been blocked by administrators.");
        }
    }

    public void logError(String ip, String userEmail, String details) {
        String logId = "ERR-" + (errorLogs.size() + 1);
        errorLogs.add(new ErrorLogEntry(logId, ip, userEmail, details));
    }

    public List<ErrorLogEntry> getErrorLogs() {
        return Collections.unmodifiableList(errorLogs);
    }

    // ================= USER & PROFILE MANAGEMENT =================
    public UserProfile registerUser(String username, String email, String password, String personalInfo, String ip, UserRole role) {
        verifyIpAccess(ip);
        if (users.containsKey(username)) {
            throw new IllegalArgumentException("Username already exists: " + username);
        }
        String id = "USR-" + (users.size() + 1);
        String passHash = SecurityUtils.hash(password);
        String encryptedInfo = SecurityUtils.encryptData(personalInfo, ENCRYPTION_KEY);
        UserProfile user = new UserProfile(id, username, email, passHash, encryptedInfo, ip, role);
        users.put(username, user);
        return user;
    }

    public UserProfile authenticate(String username, String password, String ip) {
        verifyIpAccess(ip);
        UserProfile user = users.get(username);
        if (user == null || !user.getPasswordHash().equals(SecurityUtils.hash(password))) {
            logError(ip, username, "Failed authentication attempt for user: " + username);
            throw new SecurityException("Invalid credentials.");
        }
        return user;
    }

    public String decryptUserPersonalInfo(UserProfile user) {
        return SecurityUtils.decryptData(user.getEncryptedPersonalInfo(), ENCRYPTION_KEY);
    }

    public void subscribeForEventNotifications(String email) {
        if (email != null && email.contains("@")) {
            subscribedNotificationEmails.add(email.trim());
        }
    }

    public Set<String> getSubscribedNotificationEmails() {
        return Collections.unmodifiableSet(subscribedNotificationEmails);
    }

    public String requestTemporaryPassword(String username, String email) {
        UserProfile user = users.get(username);
        if (user != null && user.getEmail().equalsIgnoreCase(email)) {
            return user.resetPasswordWithTemporary();
        }
        throw new IllegalArgumentException("User matching username and email not found.");
    }

    // ================= FACILITIES & PUBLIC DATA =================
    public void addFacility(RecyclingFacility facility) {
        facilities.put(facility.getId(), facility);
    }

    public void removeFacility(String facilityId) {
        facilities.remove(facilityId);
    }

    public RecyclingFacility getFacility(String facilityId) {
        return facilities.get(facilityId);
    }

    public Collection<RecyclingFacility> getAllFacilities() {
        return facilities.values();
    }

    public List<RecyclingFacility> findFacilitiesByZip(String zipCode, String callerIp) {
        verifyIpAccess(callerIp);
        validateZipOrThrow(zipCode, callerIp);
        return facilities.values().stream()
                .filter(RecyclingFacility::isActive)
                .filter(f -> f.getAddress().getZipCode().equals(zipCode))
                .peek(RecyclingFacility::incrementVisitCount)
                .collect(Collectors.toList());
    }

    public List<RecyclingFacility> findFacilitiesByWasteType(WasteType wasteType) {
        return facilities.values().stream()
                .filter(RecyclingFacility::isActive)
                .filter(f -> f.accepts(wasteType))
                .collect(Collectors.toList());
    }

    public List<RecyclingFacility> getEcoFriendlyFacilities() {
        return facilities.values().stream()
                .filter(RecyclingFacility::isActive)
                .filter(RecyclingFacility::isEcoFriendlyCertified)
                .collect(Collectors.toList());
    }

    public List<RecyclingFacility> recommendFacilitiesForUserSchedule(UserProfile user) {
        return facilities.values().stream()
                .filter(RecyclingFacility::isActive)
                .filter(f -> user.getWeekSchedule().fitsFacility(f))
                .collect(Collectors.toList());
    }

    // Public Bins, Special Drop-off Sites, Events
    public void addPublicBin(PublicBin bin) {
        publicBins.put(bin.getId(), bin);
    }

    public List<PublicBin> findPublicBinsAround(String zipCode, String callerIp) {
        verifyIpAccess(callerIp);
        validateZipOrThrow(zipCode, callerIp);
        return publicBins.values().stream()
                .filter(b -> b.getAddress().getZipCode().equals(zipCode))
                .collect(Collectors.toList());
    }

    public void addSpecialWasteSite(SpecialWasteSite site) {
        specialWasteSites.put(site.getId(), site);
    }

    public List<SpecialWasteSite> findSpecialWasteSitesAround(String zipCode, String callerIp) {
        verifyIpAccess(callerIp);
        validateZipOrThrow(zipCode, callerIp);
        return specialWasteSites.values().stream()
                .filter(s -> s.getAddress().getZipCode().equals(zipCode))
                .collect(Collectors.toList());
    }

    public void addSafeDisposalEvent(SafeDisposalEvent event) {
        safeDisposalEvents.add(event);
    }

    public List<SafeDisposalEvent> findEventsAround(String zipCode, String callerIp) {
        verifyIpAccess(callerIp);
        validateZipOrThrow(zipCode, callerIp);
        return safeDisposalEvents.stream()
                .filter(e -> e.getAddress().getZipCode().equals(zipCode))
                .collect(Collectors.toList());
    }

    // Visual ASCII Map generator for public centers and bins
    public String renderMapDisplay(String zipCode) {
        StringBuilder sb = new StringBuilder();
        sb.append("------------------------------------------------------------\n");
        sb.append("   MAP DISPLAY FOR ZIP CODE: ").append(zipCode).append("\n");
        sb.append("------------------------------------------------------------\n");
        sb.append("[REC-FACILITY]  (F)  |  [PUBLIC BIN] (B)  |  [SPECIAL SITE] (S)\n");
        sb.append("------------------------------------------------------------\n");
        facilities.values().stream().filter(f -> f.getAddress().getZipCode().equals(zipCode))
                .forEach(f -> sb.append(String.format(" (F) %-25s @ Lat: %.4f, Lon: %.4f | Link: %s\n",
                        f.getName(), f.getAddress().getLatitude(), f.getAddress().getLongitude(), f.getAddress().getGoogleMapsUrl())));

        publicBins.values().stream().filter(b -> b.getAddress().getZipCode().equals(zipCode))
                .forEach(b -> sb.append(String.format(" (B) %-25s @ Lat: %.4f, Lon: %.4f\n",
                        b.getDescription(), b.getAddress().getLatitude(), b.getAddress().getLongitude())));

        specialWasteSites.values().stream().filter(s -> s.getAddress().getZipCode().equals(zipCode))
                .forEach(s -> sb.append(String.format(" (S) %-25s @ Lat: %.4f, Lon: %.4f\n",
                        s.getName(), s.getAddress().getLatitude(), s.getAddress().getLongitude())));
        sb.append("------------------------------------------------------------\n");
        return sb.toString();
    }

    // ================= PICKUP & TRANSACTIONS & REWARDS =================
    public PickupRequest requestPickup(String username, Address address, LocalDateTime dateTime, boolean flexibleWindow, Set<WasteType> wasteTypes) {
        UserProfile user = users.get(username);
        if (user == null) throw new IllegalArgumentException("User not found: " + username);
        String id = "PICKUP-" + (pickupRequests.size() + 1);
        PickupRequest req = new PickupRequest(id, user.getId(), address, dateTime, flexibleWindow, wasteTypes);
        pickupRequests.add(req);
        return req;
    }

    public List<PickupRequest> getPickupRequests() {
        return Collections.unmodifiableList(pickupRequests);
    }

    public TransactionRecord recordWasteDropOff(String username, String facilityId, WasteType wasteType, double quantityKg, double fee) {
        UserProfile user = users.get(username);
        if (user == null) throw new IllegalArgumentException("User not found: " + username);
        RecyclingFacility facility = facilities.get(facilityId);
        if (facility == null) throw new IllegalArgumentException("Facility not found: " + facilityId);

        // Reward formula: 10 points per kg + bonus for eco-friendly facilities
        int points = (int) Math.round(quantityKg * 10);
        if (facility.isEcoFriendlyCertified()) {
            points += 5;
        }
        user.addRewardPoints(points);

        String txId = "TX-" + (transactions.size() + 1);
        TransactionRecord record = new TransactionRecord(txId, user.getId(), facilityId, wasteType, quantityKg, points, fee);
        transactions.add(record);
        return record;
    }

    public List<TransactionRecord> getUserTransactions(String username) {
        UserProfile user = users.get(username);
        if (user == null) return Collections.emptyList();
        return transactions.stream()
                .filter(t -> t.getUserId().equals(user.getId()))
                .collect(Collectors.toList());
    }

    // ================= INQUIRIES & COMMUNICATIONS =================
    public FacilityInquiry submitFacilityInquiry(String userId, String facilityId, String question) {
        String inquiryId = "INQ-" + (inquiries.size() + 1);
        FacilityInquiry inquiry = new FacilityInquiry(inquiryId, userId, facilityId, question);
        inquiries.add(inquiry);
        return inquiry;
    }

    public void answerFacilityInquiry(String inquiryId, String answer) {
        for (FacilityInquiry inq : inquiries) {
            if (inq.getId().equals(inquiryId)) {
                inq.reply(answer);
                return;
            }
        }
        throw new IllegalArgumentException("Inquiry not found: " + inquiryId);
    }

    public List<FacilityInquiry> getInquiriesForFacility(String facilityId) {
        return inquiries.stream()
                .filter(i -> i.getFacilityId().equals(facilityId))
                .collect(Collectors.toList());
    }

    public void sendFacilityMessage(String facilityId, String senderRole, String message) {
        facilityCommunications.add(new FacilityCommunication("MSG-" + (facilityCommunications.size() + 1), facilityId, senderRole, message));
    }

    public List<FacilityCommunication> getFacilityMessages(String facilityId) {
        return facilityCommunications.stream()
                .filter(c -> c.getFacilityId().equals(facilityId))
                .collect(Collectors.toList());
    }

    // ================= FEEDBACK & COMPLAINTS =================
    public void submitFeedback(String email, String subject, String message) {
        String id = "FB-" + (feedbackMessages.size() + 1);
        feedbackMessages.add(new FeedbackMessage(id, email, subject, message));
    }

    public List<FeedbackMessage> getFeedbackMessages() {
        return Collections.unmodifiableList(feedbackMessages);
    }

    // ================= HR & EMPLOYEES =================
    public void addEmployee(Employee emp) {
        employees.put(emp.getId(), emp);
    }

    public List<Employee> getHrEmployeeList(UserProfile hrUser) {
        if (hrUser.getRole() != UserRole.HR_OFFICER && hrUser.getRole() != UserRole.ADMIN && hrUser.getRole() != UserRole.EXECUTIVE) {
            throw new SecurityException("Unauthorized: Only HR officers or executives can view employee records.");
        }
        return new ArrayList<>(employees.values());
    }

    // ================= ACCOUNTING =================
    public BillingStatement generateBillingStatement(UserProfile accountantUser) {
        if (accountantUser.getRole() != UserRole.ACCOUNTANT && accountantUser.getRole() != UserRole.ADMIN && accountantUser.getRole() != UserRole.EXECUTIVE) {
            throw new SecurityException("Unauthorized: Only accountants or administrators can generate billing statements.");
        }
        return new BillingStatement("INV-" + System.currentTimeMillis(), LocalDate.now(), transactions);
    }

    // ================= ROUTE PLANNING =================
    public NeighborhoodRoutePlan planRouteForEmployee(String routeId, String neighborhood, List<Address> addresses) {
        return routePlannerService.createOptimalRoute(routeId, neighborhood, addresses);
    }

    // ================= ADMIN & EXECUTIVE DASHBOARDS =================
    public String getExecutivePerformanceReport(UserProfile executive) {
        if (executive.getRole() != UserRole.EXECUTIVE && executive.getRole() != UserRole.ADMIN) {
            throw new SecurityException("Unauthorized: Executive access required.");
        }
        double totalVolumeKg = transactions.stream().mapToDouble(TransactionRecord::getQuantityKg).sum();
        double totalFees = transactions.stream().mapToDouble(TransactionRecord::getActivityFee).sum();
        int totalPickups = pickupRequests.size();

        return String.format("""
            ==================================================
                   EXECUTIVE COMPANY PERFORMANCE REPORT
            ==================================================
            Total Facilities Registered: %d
            Total Registered Citizens   : %d
            Total Recycled Volume (Kg)  : %.2f kg
            Total Activity Fees Revenue : $%.2f
            Completed/Pending Pickups   : %d
            Total Subscribed Citizens   : %d
            ==================================================
            """, facilities.size(), users.size(), totalVolumeKg, totalFees, totalPickups, subscribedNotificationEmails.size());
    }

    public String getAdminDashboard() {
        Map<String, Long> neighborhoodCounts = facilities.values().stream()
                .collect(Collectors.groupingBy(f -> f.getAddress().getZipCode(), Collectors.counting()));

        return String.format("""
            ==================================================
                     ADMIN MONITOR & SERVICE DASHBOARD
            ==================================================
            System Status            : ONLINE (Encrypted AES/SHA-256)
            Monitored Facilities     : %d
            Total Public Bins        : %d
            Special Waste Sites      : %d
            Active Safe Events       : %d
            Blocked Spamming IPs     : %s
            Logged User Error Logs   : %d
            Pending Citizen Feedback : %d
            Neighborhood Facilities Distribution (by Zip):
            %s
            ==================================================
            """, facilities.size(), publicBins.size(), specialWasteSites.size(), safeDisposalEvents.size(),
                blockedIpAddresses.toString(), errorLogs.size(),
                feedbackMessages.stream().filter(f -> !f.isResolved()).count(),
                neighborhoodCounts.toString());
    }

    // ================= DEVELOPER API =================
    public DeveloperApiResponse<List<RecyclingFacility>> apiGetFacilitiesByZip(String zipCode, String apiKey) {
        if (apiKey == null || apiKey.isBlank()) {
            return new DeveloperApiResponse<>(false, "Invalid API key.", Collections.emptyList());
        }
        try {
            List<RecyclingFacility> result = findFacilitiesByZip(zipCode, "API-CLIENT");
            return new DeveloperApiResponse<>(true, "Facilities retrieved successfully.", result);
        } catch (Exception e) {
            return new DeveloperApiResponse<>(false, e.getMessage(), Collections.emptyList());
        }
    }
}
