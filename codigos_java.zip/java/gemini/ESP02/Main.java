import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        RecycleHubPlatform platform = new RecycleHubPlatform();

        // 1. Set up operating hours
        OperatingHours normalHours = new OperatingHours();
        normalHours.setHours(DayOfWeek.MONDAY, LocalTime.of(8, 0), LocalTime.of(17, 0));
        normalHours.setHours(DayOfWeek.TUESDAY, LocalTime.of(8, 0), LocalTime.of(17, 0));
        normalHours.setHours(DayOfWeek.WEDNESDAY, LocalTime.of(8, 0), LocalTime.of(17, 0));
        normalHours.setHours(DayOfWeek.THURSDAY, LocalTime.of(8, 0), LocalTime.of(17, 0));
        normalHours.setHours(DayOfWeek.FRIDAY, LocalTime.of(8, 0), LocalTime.of(18, 0));
        normalHours.setHours(DayOfWeek.SATURDAY, LocalTime.of(9, 0), LocalTime.of(14, 0));

        // 2. Onboard facilities (Admin / Superuser story)
        RecyclingFacility f1 = new RecyclingFacility("FAC-101", "GreenEarth Recycling Hub",
                new Address("123 Solar Way", "Austin", "TX", "78701", 30.2672, -97.7431),
                normalHours, true);
        f1.addAcceptedWasteType(WasteType.PLASTIC);
        f1.addAcceptedWasteType(WasteType.GLASS);
        f1.addAcceptedWasteType(WasteType.CARDBOARD);
        f1.addAcceptedWasteType(WasteType.PAPER);

        RecyclingFacility f2 = new RecyclingFacility("FAC-102", "Downtown Eco Center",
                new Address("456 Congress Ave", "Austin", "TX", "78701", 30.2685, -97.7420),
                normalHours, false);
        f2.addAcceptedWasteType(WasteType.METAL);
        f2.addAcceptedWasteType(WasteType.ELECTRONICS);
        f2.addAcceptedWasteType(WasteType.BATTERIES);

        platform.addFacility(f1);
        platform.addFacility(f2);

        // 3. Add Public Bins & Special Drop-off Sites & Safe Events
        platform.addPublicBin(new PublicBin("BIN-01",
                new Address("200 6th Street", "Austin", "TX", "78701", 30.2679, -97.7405),
                Set.of(WasteType.PLASTIC, WasteType.PAPER), "Dual Public Recycling Bin"));

        platform.addSpecialWasteSite(new SpecialWasteSite("SPEC-01", "Hazardous Chemical Depository",
                new Address("800 Riverside Dr", "Austin", "TX", "78701", 30.2541, -97.7411),
                Set.of(WasteType.HAZARDOUS, WasteType.BATTERIES), "Protective gear required upon drop-off."));

        platform.addSafeDisposalEvent(new SafeDisposalEvent("EVT-01", "Annual E-Waste Collection Drive",
                new Address("Civic Plaza, 301 W 2nd St", "Austin", "TX", "78701", 30.2655, -97.7471),
                LocalDate.now().plusDays(5), LocalTime.of(9, 0), LocalTime.of(15, 0),
                "Free safe drop-off for computers, screens, and lithium batteries."));

        System.out.println(">>> 1. ANONYMOUS BROWSING & GOOGLE MAPS LINK");
        List<RecyclingFacility> facilities78701 = platform.findFacilitiesByZip("78701", "192.168.1.50");
        for (RecyclingFacility f : facilities78701) {
            System.out.println("Facility: " + f.getName() + " | Hours: " + f.getOperatingHours().getHours(DayOfWeek.FRIDAY));
            System.out.println("  Map Link: " + f.getAddress().getGoogleMapsUrl());
        }

        System.out.println("\n>>> 2. ZIP CODE VALIDATION FEEDBACK");
        try {
            platform.findFacilitiesByZip("INVALID_ZIP", "192.168.1.50");
        } catch (IllegalArgumentException ex) {
            System.out.println("Validation Feedback: " + ex.getMessage());
        }

        System.out.println("\n>>> 3. ASCII MAP DISPLAY FOR PUBLIC SITES");
        System.out.println(platform.renderMapDisplay("78701"));

        System.out.println(">>> 4. USER REGISTRATION & ENCRYPTED PERSONAL DATA");
        UserProfile alice = platform.registerUser("alice_citizen", "alice@example.com", "Password#123",
                "SSN:999-88-7777, Phone:512-555-0199", "192.168.1.100", UserRole.CITIZEN);
        System.out.println("Registered User: " + alice.getUsername());
        System.out.println("Stored Encrypted Personal Info: " + alice.getEncryptedPersonalInfo());
        System.out.println("Decrypted Info (Secure View): " + platform.decryptUserPersonalInfo(alice));

        // Add favorite & upload user schedule
        alice.addFavoriteFacility(f1.getId());
        UserSchedule schedule = new UserSchedule();
        schedule.setAvailability(DayOfWeek.FRIDAY, LocalTime.of(10, 0), LocalTime.of(12, 0));
        schedule.setAvailability(DayOfWeek.SATURDAY, LocalTime.of(11, 0), LocalTime.of(13, 0));
        alice.setWeekSchedule(schedule);

        List<RecyclingFacility> recommendations = platform.recommendFacilitiesForUserSchedule(alice);
        System.out.println("Schedule Matches for Alice: " + recommendations.stream().map(RecyclingFacility::getName).toList());

        System.out.println("\n>>> 5. FLEXIBLE PICKUP & TRANSACTIONS & REWARDS");
        PickupRequest pickup = platform.requestPickup("alice_citizen",
                new Address("555 King St", "Austin", "TX", "78701", 30.2700, -97.7400),
                LocalDateTime.now().plusDays(2), true, Set.of(WasteType.PLASTIC, WasteType.GLASS));
        System.out.println("Pickup Created: " + pickup);

        TransactionRecord tx = platform.recordWasteDropOff("alice_citizen", f1.getId(), WasteType.PLASTIC, 12.5, 4.50);
        System.out.println("Drop-off Recorded: " + tx);
        System.out.println("Alice's Reward Balance: " + alice.getRewardPoints() + " points");

        System.out.println("\n>>> 6. FACILITY REPRESENTATIVE / SUPERUSER Q&A & STATS");
        FacilityInquiry inquiry = platform.submitFacilityInquiry(alice.getId(), f1.getId(), "Do you accept crushed glass?");
        System.out.println("Submitted Inquiry: " + inquiry);
        platform.answerFacilityInquiry(inquiry.getId(), "Yes, we accept sorted crushed glass containers.");
        System.out.println("Replied Inquiry: " + inquiry);
        System.out.println("Facility " + f1.getName() + " Page Visits: " + f1.getVisitCount());

        System.out.println("\n>>> 7. HR DEPARTMENT EMPLOYEE ACCESS");
        Employee emp = new Employee("EMP-900", "David Worker", "Logistics & Collection", "Route Driver", 52000.0, "david@recyclehub.com", "512-555-1212");
        platform.addEmployee(emp);

        UserProfile hrOfficer = platform.registerUser("sarah_hr", "hr@recyclehub.com", "HrPass#2024",
                "HR Master Access", "10.0.0.1", UserRole.HR_OFFICER);
        List<Employee> empList = platform.getHrEmployeeList(hrOfficer);
        System.out.println("HR Staff Roster: " + empList);

        System.out.println("\n>>> 8. ROUTE PLANNING FOR WORKERS");
        NeighborhoodRoutePlan route = platform.planRouteForEmployee("ROUTE-A1", "Downtown Austin",
                Arrays.asList(f1.getAddress(), f2.getAddress()));
        System.out.println("Route Steps for " + route.getNeighborhoodName() + " (Total " + route.getTotalDistanceKm() + " km):");
        route.getSteps().forEach(System.out::println);

        System.out.println("\n>>> 9. COMPANY ACCOUNTANT BILLING STATEMENT");
        UserProfile accountant = platform.registerUser("bob_accountant", "bob@recyclehub.com", "BobPass#2024",
                "Finance Dept", "10.0.0.2", UserRole.ACCOUNTANT);
        BillingStatement stmt = platform.generateBillingStatement(accountant);
        System.out.println(stmt);

        System.out.println("\n>>> 10. ADMIN DASHBOARD & SECURITY IP BLOCK");
        platform.blockIp("198.51.100.99");
        System.out.println(platform.getAdminDashboard());

        System.out.println(">>> 11. DEVELOPER API RESPONSE (FOR iOS APP)");
        DeveloperApiResponse<List<RecyclingFacility>> apiResponse = platform.apiGetFacilitiesByZip("78701", "iOS-SECRET-API-KEY-XYZ");
        System.out.println("API Success: " + apiResponse.isSuccess() + ", Message: " + apiResponse.getMessage());
        System.out.println("API Facilities Returned Count: " + apiResponse.getData().size());

        System.out.println("\n>>> 12. USER DOCUMENTATION GUIDE");
        System.out.println(UserDocumentation.getGuide());
    }
}
