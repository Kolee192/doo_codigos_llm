import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.EnumMap;
import java.util.Map;

public class UserSchedule {
    public static class AvailabilitySlot {
        private final LocalTime availableFrom;
        private final LocalTime availableTo;

        public AvailabilitySlot(LocalTime availableFrom, LocalTime availableTo) {
            this.availableFrom = availableFrom;
            this.availableTo = availableTo;
        }

        public LocalTime getAvailableFrom() {
            return availableFrom;
        }

        public LocalTime getAvailableTo() {
            return availableTo;
        }

        public boolean overlaps(LocalTime open, LocalTime close) {
            return !(availableTo.isBefore(open) || availableFrom.isAfter(close));
        }

        @Override
        public String toString() {
            return availableFrom + " to " + availableTo;
        }
    }

    private final Map<DayOfWeek, AvailabilitySlot> weekSchedule = new EnumMap<>(DayOfWeek.class);

    public void setAvailability(DayOfWeek day, LocalTime from, LocalTime to) {
        weekSchedule.put(day, new AvailabilitySlot(from, to));
    }

    public AvailabilitySlot getAvailability(DayOfWeek day) {
        return weekSchedule.get(day);
    }

    public Map<DayOfWeek, AvailabilitySlot> getWeekSchedule() {
        return new EnumMap<>(weekSchedule);
    }

    public boolean fitsFacility(RecyclingFacility facility) {
        OperatingHours hours = facility.getOperatingHours();
        if (hours == null) return false;
        for (Map.Entry<DayOfWeek, AvailabilitySlot> entry : weekSchedule.entrySet()) {
            OperatingHours.TimeSlot slot = hours.getHours(entry.getKey());
            if (slot != null && entry.getValue().overlaps(slot.getOpenTime(), slot.getCloseTime())) {
                return true;
            }
        }
        return false;
    }
}
