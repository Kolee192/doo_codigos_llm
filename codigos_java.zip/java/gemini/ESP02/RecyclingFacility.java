import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class RecyclingFacility {
    private final String id;
    private String name;
    private Address address;
    private OperatingHours operatingHours;
    private final Set<WasteType> acceptedWasteTypes;
    private boolean ecoFriendlyCertified;
    private boolean active;
    private int visitCount;

    public RecyclingFacility(String id, String name, Address address, OperatingHours operatingHours, boolean ecoFriendlyCertified) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.operatingHours = operatingHours;
        this.acceptedWasteTypes = new HashSet<>();
        this.ecoFriendlyCertified = ecoFriendlyCertified;
        this.active = true;
        this.visitCount = 0;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public OperatingHours getOperatingHours() {
        return operatingHours;
    }

    public void setOperatingHours(OperatingHours operatingHours) {
        this.operatingHours = operatingHours;
    }

    public Set<WasteType> getAcceptedWasteTypes() {
        return Collections.unmodifiableSet(acceptedWasteTypes);
    }

    public void addAcceptedWasteType(WasteType type) {
        this.acceptedWasteTypes.add(type);
    }

    public void removeAcceptedWasteType(WasteType type) {
        this.acceptedWasteTypes.remove(type);
    }

    public boolean accepts(WasteType type) {
        return acceptedWasteTypes.contains(type);
    }

    public boolean isEcoFriendlyCertified() {
        return ecoFriendlyCertified;
    }

    public void setEcoFriendlyCertified(boolean ecoFriendlyCertified) {
        this.ecoFriendlyCertified = ecoFriendlyCertified;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public int getVisitCount() {
        return visitCount;
    }

    public void incrementVisitCount() {
        this.visitCount++;
    }

    public boolean isOpenAt(DayOfWeek day, LocalTime time) {
        return operatingHours != null && operatingHours.isOpen(day, time);
    }

    @Override
    public String toString() {
        return "Facility[" + id + "]: " + name + " (" + (ecoFriendlyCertified ? "Eco-Friendly, " : "") + address + ") Accepts: " + acceptedWasteTypes;
    }
}
