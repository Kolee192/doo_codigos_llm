public class DeveloperApiResponse<T> {
    private final boolean success;
    private final String message;
    private final T data;

    public DeveloperApiResponse(boolean success, String message, T data) {
        this.success = success;
        this.message = message;
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }

    @Override
    public String toString() {
        return "ApiResponse[success=" + success + ", message='" + message + "', data=" + data + "]";
    }
}
