import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AuthenticationService {
    private final Map<String, User> usersByUsername = new HashMap<>();
    private final Map<String, String> resetTokens = new HashMap<>();

    public void registerUser(User user) {
        usersByUsername.put(user.getUsername(), user);
    }

    public User login(String username, String password, boolean isAdLogin) {
        User user = usersByUsername.get(username);
        if (user == null) {
            return null;
        }
        if (isAdLogin) {
            if (user.isActiveDirectoryUser()) {
                return user;
            }
            return null;
        }
        if (user.checkPassword(password)) {
            return user;
        }
        return null;
    }

    public String initiatePasswordReset(String username) {
        User user = usersByUsername.get(username);
        if (user == null) {
            return null;
        }
        String token = UUID.randomUUID().toString();
        resetTokens.put(token, username);
        return token;
    }

    public boolean completePasswordReset(String token, String newPassword) {
        String username = resetTokens.remove(token);
        if (username == null) {
            return false;
        }
        User user = usersByUsername.get(username);
        if (user != null) {
            user.setPassword(newPassword);
            return true;
        }
        return false;
    }
}
