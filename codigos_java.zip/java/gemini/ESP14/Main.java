import java.time.LocalDate;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("==================================================================");
        System.out.println("  ROCKEFELLER ARCHIVE CENTER (RAC) DIGITAL REPOSITORY DEMO");
        System.out.println("==================================================================");

        RepositoryService repo = new RepositoryService();

        // 1. Roles, Groups, and Users Setup
        UserGroup adminGroup = new UserGroup("GRP-ADMIN", "Administrators");
        adminGroup.addPermission(Permission.MANAGE_USERS);
        adminGroup.addPermission(Permission.READ_RESTRICTED);
        adminGroup.addPermission(Permission.APPLY_RESTRICTION);
        adminGroup.addPermission(Permission.APPLY_RIGHTS);
        adminGroup.addPermission(Permission.BATCH_EDIT);
        adminGroup.addPermission(Permission.DOWNLOAD_FILES);

        UserGroup archivistGroup = new UserGroup("GRP-ARCH", "Archivists");
        archivistGroup.addPermission(Permission.READ_PUBLIC);
        archivistGroup.addPermission(Permission.READ_RESTRICTED);
        archivistGroup.addPermission(Permission.UPLOAD_FILE);
        archivistGroup.addPermission(Permission.BATCH_EDIT);
        archivistGroup.addPermission(Permission.APPLY_RESTRICTION);
        archivistGroup.addPermission(Permission.APPLY_RIGHTS);
        archivistGroup.addPermission(Permission.PROCESS_IMAGES);
        archivistGroup.addPermission(Permission.DOWNLOAD_FILES);
        archivistGroup.addPermission(Permission.VIEW_NON_PUBLIC_AIDS);

        UserGroup researcherGroup = new UserGroup("GRP-RES", "Researchers");
        researcherGroup.addPermission(Permission.READ_PUBLIC);
        researcherGroup.addPermission(Permission.DOWNLOAD_FILES);

        UserGroup donorGroup = new UserGroup("GRP-DONOR", "Donor Representatives");
        donorGroup.addPermission(Permission.READ_PUBLIC);
        donorGroup.addPermission(Permission.READ_UNPROCESSED);
        donorGroup.addPermission(Permission.ACCRUAL_SUBMISSION);

        User archivist = new User("USR-1", "archivist_mary", "pwd123", "mary@rockarch.org",
                UserRole.ARCHIVIST, archivistGroup, true);
        User researcher = new User("USR-2", "dr_jones", "secret456", "jones@univ.edu",
                UserRole.RESEARCHER, researcherGroup, false);
        User donorRep = new User("USR-3", "rep_ford_fdn", "donorPass", "rep@fordfound.org",
                UserRole.DONOR_REPRESENTATIVE, donorGroup, false);
        donorRep.setInstitutionId("INST-FORD");

        repo.getAuthService().registerUser(archivist);
        repo.getAuthService().registerUser(researcher);
        repo.getAuthService().registerUser(donorRep);

        System.out.println("[+] Active Directory Authentication:");
        User loggedInAd = repo.getAuthService().login("archivist_mary", null, true);
        System.out.println("    Archivist AD Login successful: " + (loggedInAd != null));

        System.out.println("[+] Researcher Self-Service Password Reset:");
        String token = repo.getAuthService().initiatePasswordReset("dr_jones");
        boolean resetSuccess = repo.getAuthService().completePasswordReset(token, "brandNewPassword123");
        System.out.println("    Password reset completed: " + resetSuccess);

        // 2. Collection Creation & Accrual
        Collection rfDiariesCollection = new Collection("COLL-RF-DIARIES", "Rockefeller Foundation Program Officers Scanned Diaries", "RF", true);
        repo.addCollection(rfDiariesCollection);

        Collection fordUnprocessed = new Collection("COLL-FORD-UNPROC", "Ford Foundation Records (Unprocessed)", "INST-FORD", false);
        fordUnprocessed.setInventoryText("Box 1: Early Grant Letters 1952. Box 2: Field Reports 1953.");
        repo.addCollection(fordUnprocessed);

        // Incremental Accrual by Donor
        Accrual accrual = new Accrual("ACCR-001", "INST-FORD", "2023 Grant Files Transfer");
        ArchivalFile accrualFile = new ArchivalFile("RAC-DIG-FORD-01", "1955 Africa Program Report", MaterialType.TEXT_DOCUMENT);
        accrual.addFile(accrualFile);
        fordUnprocessed.addAccrual(accrual);
        System.out.println("[+] Incremental donor accrual registered for: " + fordUnprocessed.getName());

        // 3. Uploading Files & Automatic Derivative and Technical Metadata Generation
        byte[] dummyBytes = new byte[]{10, 20, 30, 40, 50, 60, 70, 80};
        ArchivalFile photo1 = repo.uploadSingleFile("Nelson Rockefeller at Press Conference 1968",
                MaterialType.PHOTOGRAPH, dummyBytes, "image/tiff", 4000, 3000);
        photo1.setPhotographer("Arthur Browne");
        photo1.addPersonRepresented("Nelson Rockefeller");
        photo1.setPlaceTaken("Albany, NY");
        photo1.setColorMode(ColorMode.BLACK_AND_WHITE);
        photo1.setDigitizationStandard(DigitizationStandard.PRESERVATION_STANDARD);
        photo1.setXDrivePath("X:\\Collections\\Photographs\\RockefellerNelson\\1968_001.tif");
        rfDiariesCollection.addFile(photo1);

        System.out.println("[+] Uploaded photo: " + photo1.getTitle() + " | ID: " + photo1.getId());
        System.out.println("    Auto-generated file size: " + photo1.getTechnicalMetadata().getFileSizeInBytes() + " bytes");
        System.out.println("    Thumbnail derivative generated: " + (photo1.getThumbnail() != null));

        // 4. Image Processing Operations: Rotate, Auto-contrast, Manual Levels
        ImageProcessor.rotate(photo1, 90);
        ImageProcessor.applyAutoContrastAndLevels(photo1);
        ImageProcessor.applyManualAdjustments(photo1, 1.15, 0.05, 1.0);
        System.out.println("    Image adjustments applied. Orientation embedded: "
                + photo1.getTechnicalMetadata().getEmbeddedHeaders().get("OrientationDegrees"));

        // 5. Rights Assignment and Restrictions
        RightsStatement publicDomain = new RightsStatement(RightsStatus.NO_COPYRIGHT_US,
                "No copyright known in the United States. Free public use.", true, true);
        RightsStatement inCopyright = new RightsStatement(RightsStatus.IN_COPYRIGHT,
                "Under copyright. Permission required for publication.", false, false);
        photo1.setRightsStatement(publicDomain);

        ArchivalFile sensitiveFile = repo.uploadSingleFile("Confidential Trustee Memo",
                MaterialType.TEXT_DOCUMENT, dummyBytes, "application/pdf", 0, 0);
        sensitiveFile.getRestriction().setRestricted(true);
        sensitiveFile.getRestriction().setRestrictedFromView(true);
        sensitiveFile.getRestriction().setEndDate(LocalDate.now().plusYears(5));
        sensitiveFile.getRestriction().setRestrictionDetails("Donor restriction: closed for 5 years");
        sensitiveFile.getRestriction().addAllowedIp("192.168.1.100"); // Reading Room IP

        System.out.println("[+] Restricted file: " + sensitiveFile.getTitle());
        System.out.println("    Is currently restricted: " + sensitiveFile.getRestriction().isRestricted());
        System.out.println("    Accessible from reading room IP (192.168.1.100): "
                + sensitiveFile.getRestriction().allowsAccess(researcher, "192.168.1.100"));
        System.out.println("    Accessible from home IP (203.0.113.4): "
                + sensitiveFile.getRestriction().allowsAccess(researcher, "203.0.113.4"));

        // 6. Time-based Redaction
        Redaction redaction = new Redaction("RED-1", "Redact SSN and personal addresses",
                "Paragraph 4, Page 2", LocalDate.now().plusYears(2));
        sensitiveFile.addRedaction(redaction);
        System.out.println("    Redaction active: " + redaction.isCurrentlyRedacted() + " (expires " + redaction.getExpirationDate() + ")");

        // 7. Staff Working Papers & Interdepartmental Forms
        ArchivalFile workingPaper = repo.uploadSingleFile("Preservation Strategy Working Paper",
                MaterialType.WORKING_PAPER, dummyBytes, "application/pdf", 0, 0);
        workingPaper.addTag("working-paper");
        workingPaper.addTag("preservation");

        ArchivalFile form = repo.uploadSingleFile("Interdepartmental Deaccession Form 2024",
                MaterialType.FORM, dummyBytes, "application/pdf", 0, 0);
        form.addTag("internal-form");
        System.out.println("[+] Staff documents uploaded: Working papers & Forms.");

        // 8. Scanned Diary Entry and OCR Search
        ArchivalFile diaryFile = repo.uploadSingleFile("Willits Diary - 1939 European Tour",
                MaterialType.DIARY, dummyBytes, "application/pdf", 0, 0);
        diaryFile.setOcrText("Met with European economic officers in Geneva regarding social science grants.");
        rfDiariesCollection.addFile(diaryFile);

        SearchCriteria diarySearch = new SearchCriteria();
        diarySearch.setIsDiary(true);
        diarySearch.setKeyword("Geneva");
        List<ArchivalFile> diaryResults = repo.search(diarySearch, researcher, "203.0.113.4");
        System.out.println("[+] OCR Keyword Search across diaries for 'Geneva': found " + diaryResults.size() + " matches.");

        // 9. Structured Citations and Social Sharing
        String citation = CitationGenerator.generateCitation(photo1, rfDiariesCollection);
        System.out.println("[+] Structured Citation:\n    " + citation);

        String socialLink = CitationGenerator.generateSocialMediaShareLink(photo1, "https://rockarch.org");
        System.out.println("[+] Social Media Share Link: " + socialLink);

        // 10. Email formatting with verified citation
        String emailText = repo.formatEmailWithCitation(photo1, "Dear Researcher, here is the reference to the photo you requested.");
        System.out.println("[+] Automated Citation Email Output:\n" + emailText.substring(0, Math.min(emailText.length(), 180)) + "...");

        // 11. Duplication / Analog Request Notification Check
        System.out.println("[+] Duplicate scanning prevention check:");
        boolean alreadyScanned = repo.isPhotoAlreadyScanned("Nelson Rockefeller");
        System.out.println("    Is 'Nelson Rockefeller' photo already scanned? " + alreadyScanned);
        MaterialRequest matReq = repo.submitMaterialRequest("dr_jones", "Nelson Rockefeller at Press Conference",
                MaterialRequest.RequestType.PHOTO_DUPLICATION_ORDER);
        System.out.println("    Notification sent to researcher that digital copy already exists: "
                + matReq.isExistingDigitalObjectNotificationSent());

        // 12. Online Licensing Form
        LicensingRequest licenseReq = repo.submitLicensingRequest("Dr. Jones", "jones@univ.edu",
                photo1.getId(), "Academic Book: 20th Century Politics", "Full page chapter frontispiece");
        licenseReq.setApproved(true);
        System.out.println("[+] Online Licensing Request submitted & approved for file: " + licenseReq.getFileId());

        // 13. Download Tracking
        repo.downloadFile(researcher, photo1.getId(), "203.0.113.4");
        System.out.println("[+] Download history for " + researcher.getUsername() + ": " + researcher.getDownloadHistory());
        System.out.println("    File usage tracking: " + photo1.getUsageHistory());

        // 14. Batch Metadata Editing
        repo.batchEditMetadata(List.of(photo1.getId()), "Arthur Browne (Chief RAC Photographer)", "Albany, New York State", null);
        System.out.println("[+] Batch metadata edited photographer: " + photo1.getPhotographer());

        // 15. Export Descriptive Data for Text Mining (JSON)
        String jsonExport = repo.exportDescriptiveDataJson();
        System.out.println("[+] Exported descriptive data for text mining (snippet):\n"
                + jsonExport.substring(0, Math.min(jsonExport.length(), 250)) + "\n    ...");

        System.out.println("==================================================================");
        System.out.println("  ALL ARCHIVAL WORKFLOW DEMONSTRATIONS COMPLETED SUCCESSFULLY");
        System.out.println("==================================================================");
    }
}
