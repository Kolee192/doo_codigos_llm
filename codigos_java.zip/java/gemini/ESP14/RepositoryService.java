import java.time.LocalDate;
import java.util.*;

public class RepositoryService {
    private final Map<String, ArchivalFile> files = new HashMap<>();
    private final Map<String, Collection> collections = new HashMap<>();
    private final Map<String, FileGroup> fileGroups = new HashMap<>();
    private final List<LicensingRequest> licensingRequests = new ArrayList<>();
    private final List<ResearcherReport> researcherReports = new ArrayList<>();
    private final List<UserInquiry> userInquiries = new ArrayList<>();
    private final List<MaterialRequest> materialRequests = new ArrayList<>();
    private final AuthenticationService authService = new AuthenticationService();

    public AuthenticationService getAuthService() {
        return authService;
    }

    public String generateUniqueFileId() {
        return "RAC-DIG-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public ArchivalFile uploadSingleFile(String title, MaterialType type, byte[] rawBytes, String mimeType, int width, int height) {
        String id = generateUniqueFileId();
        ArchivalFile file = new ArchivalFile(id, title, type);
        file.setRawContent(rawBytes);

        TechnicalMetadata tech = new TechnicalMetadata(rawBytes != null ? rawBytes.length : 0, mimeType, width, height, 300);
        tech.embedHeader("Source", "Rockefeller Archive Center Digital Asset Pipeline");
        tech.embedHeader("RACIdentifier", id);
        tech.embedHeader("UploadDate", LocalDate.now().toString());
        file.setTechnicalMetadata(tech);

        ImageProcessor.generateAccessDerivatives(file);
        files.put(id, file);
        return file;
    }

    public List<ArchivalFile> uploadGroup(List<ArchivalFile> uploadedFiles, String groupName) {
        String groupId = "GRP-" + UUID.randomUUID().toString().substring(0, 6);
        FileGroup group = new FileGroup(groupId, groupName);
        for (ArchivalFile f : uploadedFiles) {
            files.put(f.getId(), f);
            group.addFile(f);
        }
        fileGroups.put(groupId, group);
        return uploadedFiles;
    }

    public void addCollection(Collection collection) {
        collections.put(collection.getId(), collection);
    }

    public Collection getCollection(String id) {
        return collections.get(id);
    }

    public ArchivalFile getFile(String id) {
        return files.get(id);
    }

    public FileGroup getFileGroup(String id) {
        return fileGroups.get(id);
    }

    public boolean isPhotoAlreadyScanned(String titleOrKeyword) {
        for (ArchivalFile file : files.values()) {
            if (file.getMaterialType() == MaterialType.PHOTOGRAPH && file.isScanned()) {
                if (file.getTitle().toLowerCase().contains(titleOrKeyword.toLowerCase())) {
                    return true;
                }
            }
        }
        return false;
    }

    public void batchEditMetadata(List<String> fileIds, String photographer, String placeTaken, RightsStatement rights) {
        for (String id : fileIds) {
            ArchivalFile file = files.get(id);
            if (file != null) {
                if (photographer != null) {
                    file.setPhotographer(photographer);
                }
                if (placeTaken != null) {
                    file.setPlaceTaken(placeTaken);
                }
                if (rights != null) {
                    file.setRightsStatement(rights);
                }
            }
        }
    }

    public byte[] downloadFile(User user, String fileId, String ipAddress) {
        ArchivalFile file = files.get(fileId);
        if (file == null) {
            return null;
        }
        if (file.getRestriction().isRestrictedFromView() && !file.getRestriction().allowsAccess(user, ipAddress)) {
            return null;
        }
        if (!file.getRestriction().allowsAccess(user, ipAddress)) {
            return null;
        }
        if (user != null) {
            user.recordDownload(fileId);
            file.recordUsage("Downloaded by user: " + user.getUsername());
        } else {
            file.recordUsage("Downloaded anonymously from IP: " + ipAddress);
        }
        return file.getRawContent();
    }

    public List<ArchivalFile> search(SearchCriteria criteria, User user, String ipAddress) {
        List<ArchivalFile> results = new ArrayList<>();
        for (ArchivalFile file : files.values()) {
            if (file.getRestriction().isRestrictedFromView()) {
                if (!file.getRestriction().allowsAccess(user, ipAddress)) {
                    continue;
                }
            }

            if (criteria.getKeyword() != null && !criteria.getKeyword().isEmpty()) {
                String kw = criteria.getKeyword().toLowerCase();
                boolean matchesTitle = file.getTitle() != null && file.getTitle().toLowerCase().contains(kw);
                boolean matchesDesc = file.getDescription() != null && file.getDescription().toLowerCase().contains(kw);
                boolean matchesOcr = file.getOcrText() != null && file.getOcrText().toLowerCase().contains(kw);
                if (!matchesTitle && !matchesDesc && !matchesOcr) {
                    continue;
                }
            }

            if (criteria.getPhotographer() != null && !criteria.getPhotographer().isEmpty()) {
                if (file.getPhotographer() == null || !file.getPhotographer().equalsIgnoreCase(criteria.getPhotographer())) {
                    continue;
                }
            }

            if (criteria.getPersonRepresented() != null && !criteria.getPersonRepresented().isEmpty()) {
                if (!file.getPeopleRepresented().contains(criteria.getPersonRepresented())) {
                    continue;
                }
            }

            if (criteria.getPlaceTaken() != null && !criteria.getPlaceTaken().isEmpty()) {
                if (file.getPlaceTaken() == null || !file.getPlaceTaken().equalsIgnoreCase(criteria.getPlaceTaken())) {
                    continue;
                }
            }

            if (criteria.getTag() != null && !criteria.getTag().isEmpty()) {
                if (!file.getTags().contains(criteria.getTag())) {
                    continue;
                }
            }

            if (criteria.getMaterialType() != null) {
                if (file.getMaterialType() != criteria.getMaterialType()) {
                    continue;
                }
            }

            if (criteria.getRightsStatus() != null) {
                if (file.getRightsStatement() == null || file.getRightsStatement().getStatus() != criteria.getRightsStatus()) {
                    continue;
                }
            }

            if (criteria.getIsDiary() != null && criteria.getIsDiary()) {
                if (file.getMaterialType() != MaterialType.DIARY) {
                    continue;
                }
            }

            if (criteria.getIsSharableOnSocial() != null && criteria.getIsSharableOnSocial()) {
                if (file.getRightsStatement() == null || !file.getRightsStatement().isSocialMediaAllowed() || file.getRestriction().isRestricted()) {
                    continue;
                }
            }

            results.add(file);
        }
        return results;
    }

    public List<ArchivalFile> searchByImageHash(int queryHash) {
        List<ArchivalFile> matches = new ArrayList<>();
        for (ArchivalFile f : files.values()) {
            if (f.getPerceptualHash() == queryHash) {
                matches.add(f);
            }
        }
        return matches;
    }

    public List<ArchivalFile> browseCollection(String collectionId) {
        Collection c = collections.get(collectionId);
        return c != null ? c.getFiles() : Collections.emptyList();
    }

    public MaterialRequest submitMaterialRequest(String requesterId, String titleOrKeywords, MaterialRequest.RequestType type) {
        String reqId = "REQ-" + UUID.randomUUID().toString().substring(0, 6);
        MaterialRequest req = new MaterialRequest(reqId, requesterId, titleOrKeywords, type);
        if (isPhotoAlreadyScanned(titleOrKeywords)) {
            req.setExistingDigitalObjectNotificationSent(true);
        }
        materialRequests.add(req);
        return req;
    }

    public LicensingRequest submitLicensingRequest(String name, String email, String fileId, String publication, String intendedUse) {
        String id = "LIC-" + UUID.randomUUID().toString().substring(0, 6);
        LicensingRequest request = new LicensingRequest(id, name, email, fileId, publication, intendedUse);
        licensingRequests.add(request);
        return request;
    }

    public void addResearcherReport(ResearcherReport report) {
        researcherReports.add(report);
    }

    public List<ResearcherReport> getResearcherReports() {
        return Collections.unmodifiableList(researcherReports);
    }

    public void submitInquiry(UserInquiry inquiry) {
        userInquiries.add(inquiry);
    }

    public List<UserInquiry> getUserInquiries() {
        return Collections.unmodifiableList(userInquiries);
    }

    public String exportDescriptiveDataJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("[\n");
        int count = 0;
        for (ArchivalFile f : files.values()) {
            if (count > 0) sb.append(",\n");
            sb.append("  {\n");
            sb.append("    \"id\": \"").append(f.getId()).append("\",\n");
            sb.append("    \"title\": \"").append(f.getTitle()).append("\",\n");
            sb.append("    \"materialType\": \"").append(f.getMaterialType()).append("\",\n");
            sb.append("    \"ocrText\": \"").append(f.getOcrText() != null ? f.getOcrText().replace("\"", "\\\"") : "").append("\"\n");
            sb.append("  }");
            count++;
        }
        sb.append("\n]");
        return sb.toString();
    }

    public String formatEmailWithCitation(ArchivalFile file, String messageBody) {
        Collection coll = file.getCollectionId() != null ? collections.get(file.getCollectionId()) : null;
        String citation = CitationGenerator.generateCitation(file, coll);
        return "Subject: In reference to archival asset: " + file.getTitle() + "\n\n"
                + messageBody + "\n\n"
                + "--- Accurate Citation ---\n"
                + citation + "\n"
                + "RAC Identifier: " + file.getId() + "\n";
    }

    public List<ArchivalFile> getRestrictedFilesForStaff() {
        List<ArchivalFile> restricted = new ArrayList<>();
        for (ArchivalFile f : files.values()) {
            if (f.getRestriction().isRestricted()) {
                restricted.add(f);
            }
        }
        return restricted;
    }
}
