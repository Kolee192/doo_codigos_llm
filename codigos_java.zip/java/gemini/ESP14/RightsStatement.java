public class RightsStatement {
    private final RightsStatus status;
    private final String description;
    private final boolean publicWebAllowed;
    private final boolean socialMediaAllowed;

    public RightsStatement(RightsStatus status, String description, boolean publicWebAllowed, boolean socialMediaAllowed) {
        this.status = status;
        this.description = description;
        this.publicWebAllowed = publicWebAllowed;
        this.socialMediaAllowed = socialMediaAllowed;
    }

    public RightsStatus getStatus() {
        return status;
    }

    public String getDescription() {
        return description;
    }

    public boolean isPublicWebAllowed() {
        return publicWebAllowed;
    }

    public boolean isSocialMediaAllowed() {
        return socialMediaAllowed;
    }

    @Override
    public String toString() {
        return status.getDisplayName() + ": " + description + " (" + status.getUri() + ")";
    }
}
