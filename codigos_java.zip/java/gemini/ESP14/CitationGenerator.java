public class CitationGenerator {

    public static String generateCitation(ArchivalFile file, Collection collection) {
        String collName = collection != null ? collection.getName() : "General Collections";
        String creator = file.getPhotographer() != null ? file.getPhotographer() + ", " : "";
        String dateStr = file.getCreationDate() != null ? file.getCreationDate().toString() : "Undated";
        return String.format("%s\"%s\" (%s). %s, RAC Identifier: %s. Rockefeller Archive Center.",
                creator, file.getTitle(), dateStr, collName, file.getId());
    }

    public static String generateSocialMediaShareLink(ArchivalFile file, String baseUrl) {
        if (file.getRightsStatement() != null && !file.getRightsStatement().isSocialMediaAllowed()) {
            return null;
        }
        if (file.getRestriction().isRestricted()) {
            return null;
        }
        return baseUrl + "/share/" + file.getId();
    }
}
