import java.time.LocalDate;

public class MaterialRequest {
    public enum RequestType {
        ANALOG_READING_ROOM,
        PHOTO_DUPLICATION_ORDER
    }

    private final String id;
    private final String requesterId;
    private final String targetFileOrTitle;
    private final RequestType requestType;
    private final LocalDate requestDate;
    private boolean existingDigitalObjectNotificationSent;

    public MaterialRequest(String id, String requesterId, String targetFileOrTitle, RequestType requestType) {
        this.id = id;
        this.requesterId = requesterId;
        this.targetFileOrTitle = targetFileOrTitle;
        this.requestType = requestType;
        this.requestDate = LocalDate.now();
    }

    public String getId() {
        return id;
    }

    public String getRequesterId() {
        return requesterId;
    }

    public String getTargetFileOrTitle() {
        return targetFileOrTitle;
    }

    public RequestType getRequestType() {
        return requestType;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public boolean isExistingDigitalObjectNotificationSent() {
        return existingDigitalObjectNotificationSent;
    }

    public void setExistingDigitalObjectNotificationSent(boolean notificationSent) {
        this.existingDigitalObjectNotificationSent = notificationSent;
    }
}
