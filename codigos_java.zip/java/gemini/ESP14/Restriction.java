import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Restriction {
    private boolean restricted;
    private boolean restrictedFromView;
    private LocalDate endDate;
    private String restrictionDetails;
    private final Set<String> allowedIps = new HashSet<>();
    private final Set<String> allowedUserIds = new HashSet<>();

    public Restriction() {
        this.restricted = false;
        this.restrictedFromView = false;
    }

    public boolean isRestricted() {
        if (!restricted) {
            return false;
        }
        if (endDate != null && LocalDate.now().isAfter(endDate)) {
            restricted = false;
            restrictedFromView = false;
            return false;
        }
        return true;
    }

    public void setRestricted(boolean restricted) {
        this.restricted = restricted;
    }

    public boolean isRestrictedFromView() {
        return isRestricted() && restrictedFromView;
    }

    public void setRestrictedFromView(boolean restrictedFromView) {
        this.restrictedFromView = restrictedFromView;
        if (restrictedFromView) {
            this.restricted = true;
        }
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getRestrictionDetails() {
        return restrictionDetails;
    }

    public void setRestrictionDetails(String restrictionDetails) {
        this.restrictionDetails = restrictionDetails;
    }

    public void addAllowedIp(String ipAddress) {
        allowedIps.add(ipAddress);
    }

    public void addAllowedUser(String userId) {
        allowedUserIds.add(userId);
    }

    public boolean isIpAllowed(String ipAddress) {
        return allowedIps.isEmpty() || allowedIps.contains(ipAddress);
    }

    public boolean isUserAllowed(String userId) {
        return allowedUserIds.isEmpty() || allowedUserIds.contains(userId);
    }

    public boolean allowsAccess(User user, String ipAddress) {
        if (!isRestricted()) {
            return true;
        }
        if (user != null && user.hasPermission(Permission.READ_RESTRICTED)) {
            return true;
        }
        if (user != null && isUserAllowed(user.getId())) {
            return true;
        }
        if (ipAddress != null && isIpAllowed(ipAddress)) {
            return true;
        }
        return false;
    }
}
