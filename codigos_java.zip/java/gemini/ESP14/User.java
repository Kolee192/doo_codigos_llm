import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class User {
    private final String id;
    private String username;
    private String password;
    private String email;
    private UserRole role;
    private UserGroup group;
    private boolean activeDirectoryUser;
    private String institutionId;
    private final List<String> downloadHistory = new ArrayList<>();

    public User(String id, String username, String password, String email, UserRole role, UserGroup group, boolean activeDirectoryUser) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.role = role;
        this.group = group;
        this.activeDirectoryUser = activeDirectoryUser;
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public UserGroup getGroup() {
        return group;
    }

    public void setGroup(UserGroup group) {
        this.group = group;
    }

    public boolean isActiveDirectoryUser() {
        return activeDirectoryUser;
    }

    public void setActiveDirectoryUser(boolean activeDirectoryUser) {
        this.activeDirectoryUser = activeDirectoryUser;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public boolean checkPassword(String candidate) {
        return candidate != null && candidate.equals(this.password);
    }

    public void setPassword(String newPassword) {
        this.password = newPassword;
    }

    public boolean hasPermission(Permission permission) {
        return group != null && group.hasPermission(permission);
    }

    public void recordDownload(String fileId) {
        downloadHistory.add(fileId);
    }

    public List<String> getDownloadHistory() {
        return Collections.unmodifiableList(downloadHistory);
    }
}
