import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class UserGroup {
    private final String id;
    private String name;
    private final Set<Permission> permissions = new HashSet<>();
    private final Set<String> visibleMetadataFields = new HashSet<>();

    public UserGroup(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addPermission(Permission permission) {
        permissions.add(permission);
    }

    public void removePermission(Permission permission) {
        permissions.remove(permission);
    }

    public boolean hasPermission(Permission permission) {
        return permissions.contains(permission);
    }

    public Set<Permission> getPermissions() {
        return Collections.unmodifiableSet(permissions);
    }

    public void addVisibleMetadataField(String fieldName) {
        visibleMetadataFields.add(fieldName);
    }

    public boolean canSeeMetadataField(String fieldName) {
        return visibleMetadataFields.isEmpty() || visibleMetadataFields.contains(fieldName);
    }

    public Set<String> getVisibleMetadataFields() {
        return Collections.unmodifiableSet(visibleMetadataFields);
    }
}
