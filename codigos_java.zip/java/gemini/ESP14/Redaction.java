import java.time.LocalDate;

public class Redaction {
    private final String id;
    private final String description;
    private final String redactedPortionIdentifier;
    private final LocalDate expirationDate;

    public Redaction(String id, String description, String redactedPortionIdentifier, LocalDate expirationDate) {
        this.id = id;
        this.description = description;
        this.redactedPortionIdentifier = redactedPortionIdentifier;
        this.expirationDate = expirationDate;
    }

    public String getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String getRedactedPortionIdentifier() {
        return redactedPortionIdentifier;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public boolean isCurrentlyRedacted() {
        return expirationDate == null || LocalDate.now().isBefore(expirationDate) || LocalDate.now().isEqual(expirationDate);
    }
}
