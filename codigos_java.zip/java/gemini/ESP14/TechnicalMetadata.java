import java.util.HashMap;
import java.util.Map;

public class TechnicalMetadata {
    private long fileSizeInBytes;
    private String mimeType;
    private int width;
    private int height;
    private int dpi;
    private final Map<String, String> embeddedHeaders = new HashMap<>();

    public TechnicalMetadata(long fileSizeInBytes, String mimeType, int width, int height, int dpi) {
        this.fileSizeInBytes = fileSizeInBytes;
        this.mimeType = mimeType;
        this.width = width;
        this.height = height;
        this.dpi = dpi;
    }

    public long getFileSizeInBytes() {
        return fileSizeInBytes;
    }

    public void setFileSizeInBytes(long fileSizeInBytes) {
        this.fileSizeInBytes = fileSizeInBytes;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getDpi() {
        return dpi;
    }

    public void setDpi(int dpi) {
        this.dpi = dpi;
    }

    public void embedHeader(String key, String value) {
        embeddedHeaders.put(key, value);
    }

    public Map<String, String> getEmbeddedHeaders() {
        return embeddedHeaders;
    }
}
