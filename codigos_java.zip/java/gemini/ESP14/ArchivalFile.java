import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ArchivalFile {
    private final String id;
    private String title;
    private String description;
    private String collectionId;
    private MaterialType materialType;
    private ColorMode colorMode;
    private DigitizationStandard digitizationStandard;
    private LocalDate creationDate;
    private LocalDate digitizationDate;
    private boolean scanned;
    private String photographer;
    private final Set<String> peopleRepresented = new HashSet<>();
    private String placeTaken;
    private final Set<String> tags = new HashSet<>();
    private String ocrText;
    private String physicalLocation;
    private String xDrivePath;
    private boolean partialFolderDigitization;
    private String partialFolderNote;
    private byte[] rawContent;
    private int perceptualHash;

    private RightsStatement rightsStatement;
    private Restriction restriction = new Restriction();
    private TechnicalMetadata technicalMetadata;
    private final List<AccessDerivative> derivatives = new ArrayList<>();
    private final List<Redaction> redactions = new ArrayList<>();
    private final List<String> usageHistory = new ArrayList<>();

    public ArchivalFile(String id, String title, MaterialType materialType) {
        this.id = id;
        this.title = title;
        this.materialType = materialType;
        this.scanned = true;
        this.digitizationDate = LocalDate.now();
        this.digitizationStandard = DigitizationStandard.ACCESS_ONLY;
        this.colorMode = ColorMode.COLOR;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCollectionId() {
        return collectionId;
    }

    public void setCollectionId(String collectionId) {
        this.collectionId = collectionId;
    }

    public MaterialType getMaterialType() {
        return materialType;
    }

    public void setMaterialType(MaterialType materialType) {
        this.materialType = materialType;
    }

    public ColorMode getColorMode() {
        return colorMode;
    }

    public void setColorMode(ColorMode colorMode) {
        this.colorMode = colorMode;
    }

    public DigitizationStandard getDigitizationStandard() {
        return digitizationStandard;
    }

    public void setDigitizationStandard(DigitizationStandard digitizationStandard) {
        this.digitizationStandard = digitizationStandard;
    }

    public LocalDate getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDate creationDate) {
        this.creationDate = creationDate;
    }

    public LocalDate getDigitizationDate() {
        return digitizationDate;
    }

    public void setDigitizationDate(LocalDate digitizationDate) {
        this.digitizationDate = digitizationDate;
    }

    public boolean isScanned() {
        return scanned;
    }

    public void setScanned(boolean scanned) {
        this.scanned = scanned;
    }

    public String getPhotographer() {
        return photographer;
    }

    public void setPhotographer(String photographer) {
        this.photographer = photographer;
    }

    public void addPersonRepresented(String person) {
        peopleRepresented.add(person);
    }

    public Set<String> getPeopleRepresented() {
        return Collections.unmodifiableSet(peopleRepresented);
    }

    public String getPlaceTaken() {
        return placeTaken;
    }

    public void setPlaceTaken(String placeTaken) {
        this.placeTaken = placeTaken;
    }

    public void addTag(String tag) {
        tags.add(tag);
    }

    public Set<String> getTags() {
        return Collections.unmodifiableSet(tags);
    }

    public String getOcrText() {
        return ocrText;
    }

    public void setOcrText(String ocrText) {
        this.ocrText = ocrText;
    }

    public String getPhysicalLocation() {
        return physicalLocation;
    }

    public void setPhysicalLocation(String physicalLocation) {
        this.physicalLocation = physicalLocation;
    }

    public String getXDrivePath() {
        return xDrivePath;
    }

    public void setXDrivePath(String xDrivePath) {
        this.xDrivePath = xDrivePath;
    }

    public boolean isPartialFolderDigitization() {
        return partialFolderDigitization;
    }

    public void setPartialFolderDigitization(boolean partialFolderDigitization, String partialFolderNote) {
        this.partialFolderDigitization = partialFolderDigitization;
        this.partialFolderNote = partialFolderNote;
    }

    public String getPartialFolderNote() {
        return partialFolderNote;
    }

    public byte[] getRawContent() {
        return rawContent;
    }

    public void setRawContent(byte[] rawContent) {
        this.rawContent = rawContent;
        if (rawContent != null) {
            int hash = 1;
            for (byte b : rawContent) {
                hash = 31 * hash + b;
            }
            this.perceptualHash = hash;
        }
    }

    public int getPerceptualHash() {
        return perceptualHash;
    }

    public RightsStatement getRightsStatement() {
        return rightsStatement;
    }

    public void setRightsStatement(RightsStatement rightsStatement) {
        this.rightsStatement = rightsStatement;
    }

    public Restriction getRestriction() {
        return restriction;
    }

    public void setRestriction(Restriction restriction) {
        this.restriction = restriction;
    }

    public TechnicalMetadata getTechnicalMetadata() {
        return technicalMetadata;
    }

    public void setTechnicalMetadata(TechnicalMetadata technicalMetadata) {
        this.technicalMetadata = technicalMetadata;
    }

    public void addDerivative(AccessDerivative derivative) {
        derivatives.add(derivative);
    }

    public List<AccessDerivative> getDerivatives() {
        return Collections.unmodifiableList(derivatives);
    }

    public AccessDerivative getThumbnail() {
        for (AccessDerivative derivative : derivatives) {
            if (derivative.getType() == AccessDerivative.DerivativeType.THUMBNAIL) {
                return derivative;
            }
        }
        return null;
    }

    public List<AccessDerivative> getFilmClips() {
        List<AccessDerivative> clips = new ArrayList<>();
        for (AccessDerivative d : derivatives) {
            if (d.getType() == AccessDerivative.DerivativeType.STREAMING_CLIP) {
                clips.add(d);
            }
        }
        return clips;
    }

    public void addRedaction(Redaction redaction) {
        redactions.add(redaction);
    }

    public List<Redaction> getRedactions() {
        return Collections.unmodifiableList(redactions);
    }

    public void recordUsage(String notes) {
        usageHistory.add(notes);
    }

    public List<String> getUsageHistory() {
        return Collections.unmodifiableList(usageHistory);
    }
}
