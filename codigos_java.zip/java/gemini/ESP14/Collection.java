import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Collection {
    private final String id;
    private String name;
    private String donorId;
    private boolean processed;
    private String inventoryText;
    private final List<ArchivalFile> files = new ArrayList<>();
    private final List<Accrual> accruals = new ArrayList<>();

    public Collection(String id, String name, String donorId, boolean processed) {
        this.id = id;
        this.name = name;
        this.donorId = donorId;
        this.processed = processed;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDonorId() {
        return donorId;
    }

    public void setDonorId(String donorId) {
        this.donorId = donorId;
    }

    public boolean isProcessed() {
        return processed;
    }

    public void setProcessed(boolean processed) {
        this.processed = processed;
    }

    public String getInventoryText() {
        return inventoryText;
    }

    public void setInventoryText(String inventoryText) {
        this.inventoryText = inventoryText;
    }

    public void addFile(ArchivalFile file) {
        file.setCollectionId(this.id);
        files.add(file);
    }

    public List<ArchivalFile> getFiles() {
        return Collections.unmodifiableList(files);
    }

    public void addAccrual(Accrual accrual) {
        accruals.add(accrual);
        for (ArchivalFile file : accrual.getFiles()) {
            addFile(file);
        }
    }

    public List<Accrual> getAccruals() {
        return Collections.unmodifiableList(accruals);
    }
}
