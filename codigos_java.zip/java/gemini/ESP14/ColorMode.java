public enum ColorMode {
    COLOR,
    BLACK_AND_WHITE,
    GRAYSCALE
}
