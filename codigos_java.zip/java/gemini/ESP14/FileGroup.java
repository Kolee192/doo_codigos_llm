import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FileGroup {
    private final String id;
    private String name;
    private final List<ArchivalFile> files = new ArrayList<>();
    private final Restriction restriction = new Restriction();

    public FileGroup(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addFile(ArchivalFile file) {
        files.add(file);
    }

    public List<ArchivalFile> getFiles() {
        return Collections.unmodifiableList(files);
    }

    public Restriction getRestriction() {
        return restriction;
    }

    public void cascadeRestriction() {
        for (ArchivalFile file : files) {
            Restriction r = file.getRestriction();
            r.setRestricted(restriction.isRestricted());
            r.setRestrictedFromView(restriction.isRestrictedFromView());
            r.setEndDate(restriction.getEndDate());
            r.setRestrictionDetails(restriction.getRestrictionDetails());
        }
    }
}
