public enum DigitizationStandard {
    PRESERVATION_STANDARD,
    ACCESS_ONLY
}
