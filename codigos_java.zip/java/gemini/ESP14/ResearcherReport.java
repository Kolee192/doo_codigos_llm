import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ResearcherReport {
    private final String id;
    private final String title;
    private final String authorName;
    private final String content;
    private final LocalDate dateSubmitted;
    private final List<String> linkedCitations = new ArrayList<>();

    public ResearcherReport(String id, String title, String authorName, String content) {
        this.id = id;
        this.title = title;
        this.authorName = authorName;
        this.content = content;
        this.dateSubmitted = LocalDate.now();
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getContent() {
        return content;
    }

    public LocalDate getDateSubmitted() {
        return dateSubmitted;
    }

    public void addLinkedCitation(String citation) {
        linkedCitations.add(citation);
    }

    public List<String> getLinkedCitations() {
        return Collections.unmodifiableList(linkedCitations);
    }
}
