public class SearchCriteria {
    private String keyword;
    private String photographer;
    private String personRepresented;
    private String placeTaken;
    private String tag;
    private MaterialType materialType;
    private RightsStatus rightsStatus;
    private Boolean isDiary;
    private Boolean isSharableOnSocial;

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getPhotographer() {
        return photographer;
    }

    public void setPhotographer(String photographer) {
        this.photographer = photographer;
    }

    public String getPersonRepresented() {
        return personRepresented;
    }

    public void setPersonRepresented(String personRepresented) {
        this.personRepresented = personRepresented;
    }

    public String getPlaceTaken() {
        return placeTaken;
    }

    public void setPlaceTaken(String placeTaken) {
        this.placeTaken = placeTaken;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public MaterialType getMaterialType() {
        return materialType;
    }

    public void setMaterialType(MaterialType materialType) {
        this.materialType = materialType;
    }

    public RightsStatus getRightsStatus() {
        return rightsStatus;
    }

    public void setRightsStatus(RightsStatus rightsStatus) {
        this.rightsStatus = rightsStatus;
    }

    public Boolean getIsDiary() {
        return isDiary;
    }

    public void setIsDiary(Boolean isDiary) {
        this.isDiary = isDiary;
    }

    public Boolean getIsSharableOnSocial() {
        return isSharableOnSocial;
    }

    public void setIsSharableOnSocial(Boolean sharableOnSocial) {
        isSharableOnSocial = sharableOnSocial;
    }
}
