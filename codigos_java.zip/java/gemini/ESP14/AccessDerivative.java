public class AccessDerivative {
    public enum DerivativeType {
        THUMBNAIL,
        WEB_PREVIEW,
        STREAMING_CLIP,
        TEXT_OCR_SNIPPET
    }

    private final String id;
    private final DerivativeType type;
    private final String locationOrUrl;
    private final String description;

    public AccessDerivative(String id, DerivativeType type, String locationOrUrl, String description) {
        this.id = id;
        this.type = type;
        this.locationOrUrl = locationOrUrl;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public DerivativeType getType() {
        return type;
    }

    public String getLocationOrUrl() {
        return locationOrUrl;
    }

    public String getDescription() {
        return description;
    }
}
