import java.time.LocalDate;

public class LicensingRequest {
    private final String id;
    private final String requesterName;
    private final String requesterEmail;
    private final String fileId;
    private final String intendedPublication;
    private final String intendedUseDescription;
    private final LocalDate requestDate;
    private boolean approved;

    public LicensingRequest(String id, String requesterName, String requesterEmail, String fileId, String intendedPublication, String intendedUseDescription) {
        this.id = id;
        this.requesterName = requesterName;
        this.requesterEmail = requesterEmail;
        this.fileId = fileId;
        this.intendedPublication = intendedPublication;
        this.intendedUseDescription = intendedUseDescription;
        this.requestDate = LocalDate.now();
        this.approved = false;
    }

    public String getId() {
        return id;
    }

    public String getRequesterName() {
        return requesterName;
    }

    public String getRequesterEmail() {
        return requesterEmail;
    }

    public String getFileId() {
        return fileId;
    }

    public String getIntendedPublication() {
        return intendedPublication;
    }

    public String getIntendedUseDescription() {
        return intendedUseDescription;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }
}
