import java.time.LocalDate;

public class UserInquiry {
    private final String id;
    private final String userEmail;
    private final String fileId;
    private final String questionText;
    private final LocalDate inquiryDate;
    private String archivistResponse;

    public UserInquiry(String id, String userEmail, String fileId, String questionText) {
        this.id = id;
        this.userEmail = userEmail;
        this.fileId = fileId;
        this.questionText = questionText;
        this.inquiryDate = LocalDate.now();
    }

    public String getId() {
        return id;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getFileId() {
        return fileId;
    }

    public String getQuestionText() {
        return questionText;
    }

    public LocalDate getInquiryDate() {
        return inquiryDate;
    }

    public String getArchivistResponse() {
        return archivistResponse;
    }

    public void setArchivistResponse(String archivistResponse) {
        this.archivistResponse = archivistResponse;
    }
}
