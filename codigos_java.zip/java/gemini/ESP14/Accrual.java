import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Accrual {
    private final String id;
    private final String donorId;
    private final LocalDate accrualDate;
    private final String description;
    private final List<ArchivalFile> files = new ArrayList<>();

    public Accrual(String id, String donorId, String description) {
        this.id = id;
        this.donorId = donorId;
        this.description = description;
        this.accrualDate = LocalDate.now();
    }

    public String getId() {
        return id;
    }

    public String getDonorId() {
        return donorId;
    }

    public LocalDate getAccrualDate() {
        return accrualDate;
    }

    public String getDescription() {
        return description;
    }

    public void addFile(ArchivalFile file) {
        files.add(file);
    }

    public List<ArchivalFile> getFiles() {
        return Collections.unmodifiableList(files);
    }
}
