public enum RightsStatus {
    IN_COPYRIGHT("In Copyright", "http://rightsstatements.org/vocab/InC/1.0/"),
    NO_COPYRIGHT_US("No Copyright - United States", "http://rightsstatements.org/vocab/NoC-US/1.0/"),
    COPYRIGHT_UNDETERMINED("Copyright Undetermined", "http://rightsstatements.org/vocab/UND/1.0/"),
    CC_BY("Creative Commons Attribution (CC-BY 4.0)", "https://creativecommons.org/licenses/by/4.0/"),
    CC_BY_NC("Creative Commons Attribution-NonCommercial (CC-BY-NC 4.0)", "https://creativecommons.org/licenses/by-nc/4.0/");

    private final String displayName;
    private final String uri;

    RightsStatus(String displayName, String uri) {
        this.displayName = displayName;
        this.uri = uri;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getUri() {
        return uri;
    }
}
