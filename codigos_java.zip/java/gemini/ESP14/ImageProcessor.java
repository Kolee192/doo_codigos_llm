import java.util.UUID;

public class ImageProcessor {

    public static void rotate(ArchivalFile file, int degrees) {
        TechnicalMetadata meta = file.getTechnicalMetadata();
        if (meta != null && (degrees == 90 || degrees == 270)) {
            int w = meta.getWidth();
            meta.setWidth(meta.getHeight());
            meta.setHeight(w);
        }
        if (meta != null) {
            meta.embedHeader("OrientationDegrees", String.valueOf(degrees));
        }
    }

    public static void applyAutoContrastAndLevels(ArchivalFile file) {
        TechnicalMetadata meta = file.getTechnicalMetadata();
        if (meta != null) {
            meta.embedHeader("AutoContrastApplied", "true");
            meta.embedHeader("AutoLevelsApplied", "true");
        }
    }

    public static void applyManualAdjustments(ArchivalFile file, double contrast, double brightness, double gamma) {
        TechnicalMetadata meta = file.getTechnicalMetadata();
        if (meta != null) {
            meta.embedHeader("ManualContrast", String.valueOf(contrast));
            meta.embedHeader("ManualBrightness", String.valueOf(brightness));
            meta.embedHeader("ManualGamma", String.valueOf(gamma));
        }
    }

    public static void generateAccessDerivatives(ArchivalFile file) {
        String thumbId = "deriv-" + UUID.randomUUID();
        AccessDerivative thumb = new AccessDerivative(
                thumbId,
                AccessDerivative.DerivativeType.THUMBNAIL,
                "/derivatives/thumbnails/" + file.getId() + "_thumb.jpg",
                "150x150 thumbnail for fast browsing"
        );
        file.addDerivative(thumb);

        String previewId = "deriv-" + UUID.randomUUID();
        AccessDerivative preview = new AccessDerivative(
                previewId,
                AccessDerivative.DerivativeType.WEB_PREVIEW,
                "/derivatives/previews/" + file.getId() + "_preview.jpg",
                "Medium-res access derivative for web viewing"
        );
        file.addDerivative(preview);

        if (file.getMaterialType() == MaterialType.VIDEO || file.getMaterialType() == MaterialType.AUDIO) {
            String streamId = "deriv-" + UUID.randomUUID();
            AccessDerivative clip = new AccessDerivative(
                    streamId,
                    AccessDerivative.DerivativeType.STREAMING_CLIP,
                    "/streaming/" + file.getId() + ".mp4",
                    "Browser-compatible HLS/MP4 stream"
            );
            file.addDerivative(clip);
        }
    }
}
