import java.time.LocalDateTime;

public class HarvestJob {
    private final String id;
    private final String dataSourceId;
    private LocalDateTime scheduledTime;
    private HarvestJobStatus status;
    private String report;

    public HarvestJob(String id, String dataSourceId, LocalDateTime scheduledTime) {
        this.id = id;
        this.dataSourceId = dataSourceId;
        this.scheduledTime = scheduledTime;
        this.status = HarvestJobStatus.SCHEDULED;
        this.report = "Scheduled at " + LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public String getDataSourceId() {
        return dataSourceId;
    }

    public LocalDateTime getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(LocalDateTime scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public HarvestJobStatus getStatus() {
        return status;
    }

    public void setStatus(HarvestJobStatus status) {
        this.status = status;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }
}
