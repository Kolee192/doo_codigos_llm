import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class InstitutionResource {
    private final String id;
    private String name;
    private String contactEmail;
    private String address;
    private final Map<String, String> metadata = new HashMap<>();

    public InstitutionResource(String id, String name, String contactEmail, String address, Map<String, String> metadata) {
        this.id = id;
        this.name = name;
        this.contactEmail = contactEmail;
        this.address = address;
        if (metadata != null) {
            this.metadata.putAll(metadata);
        }
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(metadata);
    }

    public void updateMetadata(String key, String value) {
        metadata.put(key, value);
    }

    public boolean matchesKeyword(String keyword) {
        String lower = keyword.toLowerCase();
        if (id.toLowerCase().contains(lower) || name.toLowerCase().contains(lower) ||
                contactEmail.toLowerCase().contains(lower) || address.toLowerCase().contains(lower)) {
            return true;
        }
        for (Map.Entry<String, String> entry : metadata.entrySet()) {
            if (entry.getKey().toLowerCase().contains(lower) || entry.getValue().toLowerCase().contains(lower)) {
                return true;
            }
        }
        return false;
    }
}
