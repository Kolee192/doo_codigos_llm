public enum CriterionType {
    TAXONOMIC,
    DATASET,
    DEPTH,
    ALTITUDE,
    BASIS_OF_RECORD,
    GEOGRAPHIC,
    DATE
}
