import java.time.LocalDateTime;

public class AuditLogEntry {
    private final LocalDateTime timestamp;
    private final String actor;
    private final String action;
    private final String details;

    public AuditLogEntry(String actor, String action, String details) {
        this.timestamp = LocalDateTime.now();
        this.actor = actor;
        this.action = action;
        this.details = details;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getActor() {
        return actor;
    }

    public String getAction() {
        return action;
    }

    public String getDetails() {
        return details;
    }

    @Override
    public String toString() {
        return String.format("[%s] Actor: %s | Action: %s | Details: %s",
                timestamp, actor, action, details);
    }
}
