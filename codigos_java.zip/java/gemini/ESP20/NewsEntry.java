import java.time.LocalDateTime;

public class NewsEntry {
    private final String id;
    private String title;
    private String content;
    private final LocalDateTime publishedDate;

    public NewsEntry(String id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.publishedDate = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getPublishedDate() {
        return publishedDate;
    }
}
