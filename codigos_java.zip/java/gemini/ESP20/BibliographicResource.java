import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class BibliographicResource {
    private final String id;
    private String title;
    private String authors;
    private int year;
    private final Map<String, String> metadata = new HashMap<>();

    public BibliographicResource(String id, String title, String authors, int year, Map<String, String> metadata) {
        this.id = id;
        this.title = title;
        this.authors = authors;
        this.year = year;
        if (metadata != null) {
            this.metadata.putAll(metadata);
        }
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(metadata);
    }

    public void updateMetadata(String key, String value) {
        metadata.put(key, value);
    }

    public boolean matchesKeyword(String keyword) {
        String lower = keyword.toLowerCase();
        if (id.toLowerCase().contains(lower) || title.toLowerCase().contains(lower) || authors.toLowerCase().contains(lower)) {
            return true;
        }
        for (Map.Entry<String, String> entry : metadata.entrySet()) {
            if (entry.getKey().toLowerCase().contains(lower) || entry.getValue().toLowerCase().contains(lower)) {
                return true;
            }
        }
        return false;
    }
}
