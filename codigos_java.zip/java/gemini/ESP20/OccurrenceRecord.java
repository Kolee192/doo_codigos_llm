import java.time.LocalDate;

public class OccurrenceRecord {
    private final String id;
    private final String scientificName;
    private final String datasetId;
    private final double depth;
    private final double altitude;
    private final String basisOfRecord;
    private final String countryOrGeographic;
    private final double latitude;
    private final double longitude;
    private final LocalDate eventDate;
    private final String publisherEmail;

    public OccurrenceRecord(String id, String scientificName, String datasetId, double depth,
                            double altitude, String basisOfRecord, String countryOrGeographic,
                            double latitude, double longitude, LocalDate eventDate, String publisherEmail) {
        this.id = id;
        this.scientificName = scientificName;
        this.datasetId = datasetId;
        this.depth = depth;
        this.altitude = altitude;
        this.basisOfRecord = basisOfRecord;
        this.countryOrGeographic = countryOrGeographic;
        this.latitude = latitude;
        this.longitude = longitude;
        this.eventDate = eventDate;
        this.publisherEmail = publisherEmail;
    }

    public String getId() {
        return id;
    }

    public String getScientificName() {
        return scientificName;
    }

    public String getDatasetId() {
        return datasetId;
    }

    public double getDepth() {
        return depth;
    }

    public double getAltitude() {
        return altitude;
    }

    public String getBasisOfRecord() {
        return basisOfRecord;
    }

    public String getCountryOrGeographic() {
        return countryOrGeographic;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public LocalDate getEventDate() {
        return eventDate;
    }

    public String getPublisherEmail() {
        return publisherEmail;
    }

    @Override
    public String toString() {
        return String.format("%s | Taxon: %s | Dataset: %s | Depth: %.1fm | Alt: %.1fm | Basis: %s | Geo: %s (%.2f, %.2f) | Date: %s",
                id, scientificName, datasetId, depth, altitude, basisOfRecord, countryOrGeographic, latitude, longitude, eventDate);
    }
}
