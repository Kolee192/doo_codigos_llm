import java.time.LocalDateTime;

public class DataSource {
    public enum Type {
        GBIF_INDEX,
        IPT
    }

    private final String id;
    private final String name;
    private final Type type;
    private final String url;
    private final LocalDateTime registeredAt;

    public DataSource(String id, String name, Type type, String url) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.url = url;
        this.registeredAt = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Type getType() {
        return type;
    }

    public String getUrl() {
        return url;
    }

    public LocalDateTime getRegisteredAt() {
        return registeredAt;
    }

    @Override
    public String toString() {
        return "DataSource{" + "id='" + id + '\'' + ", name='" + name + '\'' + ", type=" + type + ", url='" + url + '\'' + '}';
    }
}
