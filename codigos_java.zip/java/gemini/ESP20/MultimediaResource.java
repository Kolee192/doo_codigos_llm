import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MultimediaResource {
    private final String id;
    private String title;
    private String mediaType;
    private byte[] data;
    private final Map<String, String> metadata = new HashMap<>();

    public MultimediaResource(String id, String title, String mediaType, byte[] data, Map<String, String> metadata) {
        this.id = id;
        this.title = title;
        this.mediaType = mediaType;
        this.data = data != null ? data.clone() : new byte[0];
        if (metadata != null) {
            this.metadata.putAll(metadata);
        }
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMediaType() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public byte[] getData() {
        return data.clone();
    }

    public void setData(byte[] data) {
        this.data = data != null ? data.clone() : new byte[0];
    }

    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(metadata);
    }

    public void updateMetadata(String key, String value) {
        metadata.put(key, value);
    }

    public boolean matchesKeyword(String keyword) {
        String lower = keyword.toLowerCase();
        if (id.toLowerCase().contains(lower) || title.toLowerCase().contains(lower) || mediaType.toLowerCase().contains(lower)) {
            return true;
        }
        for (Map.Entry<String, String> entry : metadata.entrySet()) {
            if (entry.getKey().toLowerCase().contains(lower) || entry.getValue().toLowerCase().contains(lower)) {
                return true;
            }
        }
        return false;
    }
}
