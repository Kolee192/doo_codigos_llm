import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Initializing Biodiversity Information System Demo ===");
        BiodiversityPortalSystem system = new BiodiversityPortalSystem();

        AdministrationService admin = system.getAdminService();
        DataManagerService dataManager = system.getDataManagerService();
        PortalManagerService portalManager = system.getPortalManagerService();
        VisitorService visitor = system.getVisitorService();

        // 1. Administrator & Security Officer (FR-A1 - FR-A17)
        System.out.println("\n--- Testing Administrator & Security Officer Features ---");
        admin.installModule("SpatialAnalysisModule");
        admin.installModule("DarwinCoreHarvesterModule");
        System.out.println("Installed Modules: " + admin.getInstalledModules());
        admin.uninstallModule("SpatialAnalysisModule");
        System.out.println("Installed Modules after uninstall: " + admin.getInstalledModules());

        admin.configureDistributionMapProjection("EPSG:3857");
        admin.configureDistributionMapDefaultExtent(new MapExtent(-20.0, 30.0, 40.0, 70.0));
        admin.editEmailServerConfiguration("smtp.biodiv.org", 465, "admin@biodiv.org");

        SpatialLayer layer1 = new SpatialLayer("L1", "Marine Protected Areas", true);
        SpatialLayer layer2 = new SpatialLayer("L2", "Forest Cover", false);
        admin.addSpatialLayer(layer1);
        admin.addSpatialLayer(layer2);
        admin.editSpatialLayerName("L1", "Global Marine Protected Areas");
        System.out.println("Layers configured: " + admin.getMapConfig().getLayers());

        admin.logError("HarvestService", "Timeout connecting to remote IPT", "at org.ipt.Client.connect()");
        System.out.println("Error logs count: " + admin.viewErrorLogs().size());
        System.out.println("Error log export snippet: " + admin.downloadErrorLogs().trim());

        // Security officer
        admin.createUserAccount("sec-officer", "alice", "alice@example.org", "Pass123!", Set.of(Role.DATA_MANAGER));
        admin.assignRoleToUser("sec-officer", "alice", Role.PORTAL_MANAGER);
        admin.editUserEmail("sec-officer", "alice", "alice.smith@example.org");
        System.out.println("Alice roles: " + admin.getUser("alice").getRoles());
        System.out.println("Audit logs count for this month: " +
                admin.downloadAuditLogEntriesForMonth(YearMonth.now()).split("\n").length);

        // 2. Data Manager (FR-DM1 - FR-DM37)
        System.out.println("\n--- Testing Data Manager Features ---");
        OccurrenceResource occRes = new OccurrenceResource("DS01", "Marine Survey 2023", Map.of("citation", "Smith et al."));
        OccurrenceRecord r1 = new OccurrenceRecord("REC01", "Balaenoptera musculus", "DS01", 15.0, 0.0,
                "HumanObservation", "North Atlantic", 54.3, -25.2, LocalDate.of(2023, 5, 12), "publisher@marine.org");
        OccurrenceRecord r2 = new OccurrenceRecord("REC02", "Delphinus delphis", "DS01", 5.0, 0.0,
                "HumanObservation", "North Atlantic", 50.1, -12.4, LocalDate.of(2023, 6, 20), "publisher@marine.org");
        occRes.addRecord(r1);
        occRes.addRecord(r2);
        dataManager.importOccurrenceResource(occRes);

        ChecklistResource checkRes = new ChecklistResource("CL01", "Cetacean Checklist", Map.of("author", "Cetacean Society"),
                List.of("Balaenoptera musculus", "Delphinus delphis", "Orcinus orca"));
        dataManager.importChecklistResource(checkRes);

        MultimediaResource mediaRes = new MultimediaResource("MM01", "Blue Whale Breaching", "image/jpeg",
                new byte[]{1, 2, 3, 4}, Map.of("license", "CC-BY 4.0"));
        dataManager.importMultimediaResource(mediaRes);

        BibliographicResource bibRes = new BibliographicResource("BIB01", "Marine Mammals of the Atlantic", "Smith J.",
                2022, Map.of("doi", "10.1000/182"));
        dataManager.importBibliographicResource(bibRes);

        InstitutionResource instRes = new InstitutionResource("INST01", "Oceanographic Institute", "info@ocean.org",
                "Harbor Rd 1", Map.of("country", "Norway"));
        dataManager.importInstitutionResource(instRes);

        ExpertResource expRes = new ExpertResource("EXP01", "Dr. Jane Doe", "jdoe@ocean.org",
                "Cetology", Map.of("qualification", "PhD"));
        dataManager.importExpertResource(expRes);

        dataManager.registerGbifIndexDataSource("GBIF01", "GBIF Central Registry", "https://api.gbif.org");
        dataManager.registerIptDataSource("IPT01", "National Node IPT", "https://ipt.node.org");
        System.out.println("Core consistency check: " + dataManager.checkCoreResourcesConsistency());

        HarvestJob job = dataManager.scheduleHarvestingJob("JOB01", "IPT01", LocalDateTime.now().plusHours(1));
        dataManager.triggerHarvestingJob("JOB01");
        System.out.println("Harvesting report: " + dataManager.viewHarvestReport("JOB01"));
        System.out.println("Restoration check: " + dataManager.requestRestorationOfLatestBackup());

        // 3. Portal Manager (FR-PM1 - FR-PM20)
        System.out.println("\n--- Testing Portal Manager Features ---");
        portalManager.configureDataMetricsVisibility(true);
        portalManager.changeLogo("https://portal.org/assets/logo.png");
        portalManager.changeNodeName("Global Marine Node");
        portalManager.changePortalBanner("https://portal.org/assets/banner.png");
        portalManager.configureContactPerson("John Contact", "contact@portal.org");
        portalManager.configureNetworkSummary("Affiliated with international biodiversity networks.");
        portalManager.setDefaultLanguage("en");
        portalManager.addAlternateLanguage("es");
        portalManager.addAlternateLanguage("fr");

        portalManager.contributePortalNews(new NewsEntry("NEWS01", "Portal Upgrade 2.0 Live", "We have updated all endpoints."));
        portalManager.contributeBlogPost(new BlogPost("BLOG01", "Tracking Whale Migration", "Recent sightings show...", "Dr. Doe"));
        portalManager.addMenuItem(new MenuItem("M1", "Home", "/", 1));
        portalManager.addMenuItem(new MenuItem("M2", "Data Search", "/search", 2));
        portalManager.addPage(new PortalPage("PAGE01", "About Node", "The node publishes open marine data."));
        portalManager.editHtmlMetadataTags("keywords", "biodiversity, gbif, occurrences, marine");

        // 4. Visitor & Registered Visitor (FR-V1 - FR-V42, FR-RV1 - FR-RV3)
        System.out.println("\n--- Testing Visitor & Registered Visitor Features ---");
        OccurrenceFilter filter = visitor.buildOccurrenceSelectionFilter("WhaleFilter");
        visitor.addTaxonomicCriterion(filter, "Balaenoptera");
        visitor.addDepthCriterion(filter, 0.0, 50.0);

        List<OccurrenceRecord> matched = visitor.selectOccurrenceRecords(filter);
        System.out.println("Records matching filter: " + matched.size());
        System.out.println(visitor.viewOccurrenceRecordSelectionAsTable(matched));
        System.out.println(visitor.viewDistributionMap(matched));

        String csvExport = visitor.exportOccurrenceRecordSelection(matched);
        System.out.println("Occurrence Export (CSV preview):\n" + csvExport.lines().findFirst().orElse("") + "\n" +
                csvExport.lines().skip(1).findFirst().orElse(""));

        byte[] mapSvg = visitor.exportDistributionMapAsImage(matched);
        System.out.println("Exported map image size: " + mapSvg.length + " bytes");

        List<String> searchResults = visitor.fullTextSearch("Whale");
        System.out.println("Full-text search results for 'Whale': " + searchResults);

        visitor.contactOccurrenceResourcePublisher("publisher@marine.org", "Question regarding REC01 location accuracy.");
        System.out.println("Publisher contact sent: " + visitor.getPublisherMessages().get(0));

        visitor.sendFeedbackToPortalContact("visitor@web.com", "Great search performance!");
        System.out.println("Feedback sent: " + visitor.getFeedbackMessages().get(0));

        System.out.println(visitor.viewDetailsForTaxon("Balaenoptera musculus"));
        System.out.println("Checklist export:\n" + visitor.exportChecklist("CL01").trim());
        System.out.println(visitor.accessDataMetricsDashboard());
        System.out.println("Share map tweet link: " + visitor.shareDistributionMapOnTwitter(matched));
        System.out.println("Relayed GBIF News: " + visitor.viewLatestRelayedGbifNews());

        // Registration, Login, Custom Filters
        User registeredUser = visitor.register("bob", "bob@research.org", "SecretPassword!");
        Optional<User> loggedIn = visitor.login("bob", "SecretPassword!");
        if (loggedIn.isPresent()) {
            User user = loggedIn.get();
            System.out.println("User " + user.getUsername() + " successfully logged in.");
            visitor.saveCustomFilter(user, filter);
            System.out.println("Saved filter count: " + user.getSavedFilters().size());
            OccurrenceFilter loaded = visitor.loadCustomFilter(user, "WhaleFilter");
            System.out.println("Loaded custom filter: " + loaded.getName());
            visitor.deleteCustomFilter(user, "WhaleFilter");
            System.out.println("Saved filter count after removal: " + user.getSavedFilters().size());
        }

        System.out.println("\n=== All Functional Requirements Verified Successfully ===");
    }
}
