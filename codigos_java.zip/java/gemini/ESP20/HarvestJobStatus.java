public enum HarvestJobStatus {
    SCHEDULED,
    RUNNING,
    COMPLETED,
    CANCELLED,
    FAILED
}
