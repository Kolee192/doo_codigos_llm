public class SpatialLayer {
    private final String id;
    private String name;
    private boolean visible;

    public SpatialLayer(String id, String name, boolean visible) {
        this.id = id;
        this.name = name;
        this.visible = visible;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public void toggleVisibility() {
        this.visible = !this.visible;
    }

    @Override
    public String toString() {
        return "SpatialLayer{" + "id='" + id + '\'' + ", name='" + name + '\'' + ", visible=" + visible + '}';
    }
}
