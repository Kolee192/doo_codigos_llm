import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PortalConfig {
    private boolean dataMetricsVisible = true;
    private String logoUrl = "default-logo.png";
    private String nodeName = "National Biodiversity Node";
    private String bannerUrl = "default-banner.png";
    private String contactName = "Portal Support";
    private String contactEmail = "support@portal.org";
    private String networkSummary = "Connected to Global Biodiversity Information Facility";
    private String defaultLanguage = "en";
    private final List<String> alternateLanguages = new ArrayList<>();
    private final Map<String, String> htmlMetaTags = new HashMap<>();

    public boolean isDataMetricsVisible() {
        return dataMetricsVisible;
    }

    public void setDataMetricsVisible(boolean dataMetricsVisible) {
        this.dataMetricsVisible = dataMetricsVisible;
    }

    public String getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(String logoUrl) {
        this.logoUrl = logoUrl;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getBannerUrl() {
        return bannerUrl;
    }

    public void setBannerUrl(String bannerUrl) {
        this.bannerUrl = bannerUrl;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getNetworkSummary() {
        return networkSummary;
    }

    public void setNetworkSummary(String networkSummary) {
        this.networkSummary = networkSummary;
    }

    public String getDefaultLanguage() {
        return defaultLanguage;
    }

    public void setDefaultLanguage(String defaultLanguage) {
        this.defaultLanguage = defaultLanguage;
    }

    public List<String> getAlternateLanguages() {
        return Collections.unmodifiableList(alternateLanguages);
    }

    public void addAlternateLanguage(String lang) {
        if (!alternateLanguages.contains(lang)) {
            alternateLanguages.add(lang);
        }
    }

    public boolean removeAlternateLanguage(String lang) {
        return alternateLanguages.remove(lang);
    }

    public Map<String, String> getHtmlMetaTags() {
        return Collections.unmodifiableMap(htmlMetaTags);
    }

    public void setHtmlMetaTag(String name, String content) {
        htmlMetaTags.put(name, content);
    }
}
