import java.time.LocalDate;

public class FilterCriterion {
    private final CriterionType type;
    private final String value;
    private final Double minNumeric;
    private final Double maxNumeric;
    private final LocalDate minDate;
    private final LocalDate maxDate;

    public FilterCriterion(CriterionType type, String value) {
        this(type, value, null, null, null, null);
    }

    public FilterCriterion(CriterionType type, Double minNumeric, Double maxNumeric) {
        this(type, null, minNumeric, maxNumeric, null, null);
    }

    public FilterCriterion(CriterionType type, LocalDate minDate, LocalDate maxDate) {
        this(type, null, null, null, minDate, maxDate);
    }

    private FilterCriterion(CriterionType type, String value, Double minNumeric, Double maxNumeric,
                            LocalDate minDate, LocalDate maxDate) {
        this.type = type;
        this.value = value;
        this.minNumeric = minNumeric;
        this.maxNumeric = maxNumeric;
        this.minDate = minDate;
        this.maxDate = maxDate;
    }

    public CriterionType getType() {
        return type;
    }

    public String getValue() {
        return value;
    }

    public Double getMinNumeric() {
        return minNumeric;
    }

    public Double getMaxNumeric() {
        return maxNumeric;
    }

    public LocalDate getMinDate() {
        return minDate;
    }

    public LocalDate getMaxDate() {
        return maxDate;
    }

    public boolean test(OccurrenceRecord record) {
        switch (type) {
            case TAXONOMIC:
                return value != null && record.getScientificName().toLowerCase().contains(value.toLowerCase());
            case DATASET:
                return value != null && record.getDatasetId().equalsIgnoreCase(value);
            case DEPTH:
                if (minNumeric != null && record.getDepth() < minNumeric) return false;
                if (maxNumeric != null && record.getDepth() > maxNumeric) return false;
                return true;
            case ALTITUDE:
                if (minNumeric != null && record.getAltitude() < minNumeric) return false;
                if (maxNumeric != null && record.getAltitude() > maxNumeric) return false;
                return true;
            case BASIS_OF_RECORD:
                return value != null && record.getBasisOfRecord().equalsIgnoreCase(value);
            case GEOGRAPHIC:
                return value != null && record.getCountryOrGeographic().toLowerCase().contains(value.toLowerCase());
            case DATE:
                if (minDate != null && record.getEventDate().isBefore(minDate)) return false;
                if (maxDate != null && record.getEventDate().isAfter(maxDate)) return false;
                return true;
            default:
                return true;
        }
    }

    @Override
    public String toString() {
        return "FilterCriterion{" + "type=" + type + ", value='" + value + '\'' +
                ", min=" + minNumeric + ", max=" + maxNumeric +
                ", minDate=" + minDate + ", maxDate=" + maxDate + '}';
    }
}
