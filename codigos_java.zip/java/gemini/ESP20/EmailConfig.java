public class EmailConfig {
    private String url;
    private int port;
    private String account;

    public EmailConfig(String url, int port, String account) {
        this.url = url;
        this.port = port;
        this.account = account;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    @Override
    public String toString() {
        return "EmailConfig[url=" + url + ", port=" + port + ", account=" + account + "]";
    }
}
