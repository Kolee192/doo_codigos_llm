public class MapExtent {
    private double minLongitude;
    private double minLatitude;
    private double maxLongitude;
    private double maxLatitude;

    public MapExtent(double minLongitude, double minLatitude, double maxLongitude, double maxLatitude) {
        this.minLongitude = minLongitude;
        this.minLatitude = minLatitude;
        this.maxLongitude = maxLongitude;
        this.maxLatitude = maxLatitude;
    }

    public double getMinLongitude() {
        return minLongitude;
    }

    public double getMinLatitude() {
        return minLatitude;
    }

    public double getMaxLongitude() {
        return maxLongitude;
    }

    public double getMaxLatitude() {
        return maxLatitude;
    }

    public void setExtent(double minLon, double minLat, double maxLon, double maxLat) {
        this.minLongitude = minLon;
        this.minLatitude = minLat;
        this.maxLongitude = maxLon;
        this.maxLatitude = maxLat;
    }

    public void pan(double deltaLon, double deltaLat) {
        this.minLongitude += deltaLon;
        this.maxLongitude += deltaLon;
        this.minLatitude += deltaLat;
        this.maxLatitude += deltaLat;
    }

    public void zoom(double factor) {
        double centerLon = (minLongitude + maxLongitude) / 2.0;
        double centerLat = (minLatitude + maxLatitude) / 2.0;
        double halfLonSpan = ((maxLongitude - minLongitude) * factor) / 2.0;
        double halfLatSpan = ((maxLatitude - minLatitude) * factor) / 2.0;
        this.minLongitude = centerLon - halfLonSpan;
        this.maxLongitude = centerLon + halfLonSpan;
        this.minLatitude = centerLat - halfLatSpan;
        this.maxLatitude = centerLat + halfLatSpan;
    }

    @Override
    public String toString() {
        return String.format("MapExtent[Lon: (%.2f to %.2f), Lat: (%.2f to %.2f)]",
                minLongitude, maxLongitude, minLatitude, maxLatitude);
    }
}
