import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PortalManagerService {
    private final PortalConfig portalConfig = new PortalConfig();
    private final Map<String, NewsEntry> newsEntries = new HashMap<>();
    private final Map<String, BlogPost> blogPosts = new HashMap<>();
    private final Map<String, MenuItem> menuItems = new HashMap<>();
    private final Map<String, PortalPage> portalPages = new HashMap<>();

    public PortalConfig getPortalConfig() {
        return portalConfig;
    }

    // FR-PM1
    public void configureDataMetricsVisibility(boolean visible) {
        portalConfig.setDataMetricsVisible(visible);
    }

    // FR-PM2
    public void changeLogo(String logoUrl) {
        portalConfig.setLogoUrl(logoUrl);
    }

    // FR-PM3
    public void changeNodeName(String nodeName) {
        portalConfig.setNodeName(nodeName);
    }

    // FR-PM4
    public void changePortalBanner(String bannerUrl) {
        portalConfig.setBannerUrl(bannerUrl);
    }

    // FR-PM5
    public void configureContactPerson(String name, String email) {
        portalConfig.setContactName(name);
        portalConfig.setContactEmail(email);
    }

    // FR-PM6
    public void configureNetworkSummary(String summary) {
        portalConfig.setNetworkSummary(summary);
    }

    // FR-PM7
    public void setDefaultLanguage(String languageCode) {
        portalConfig.setDefaultLanguage(languageCode);
    }

    // FR-PM8
    public void addAlternateLanguage(String languageCode) {
        portalConfig.addAlternateLanguage(languageCode);
    }

    // FR-PM9
    public boolean removeAlternateLanguage(String languageCode) {
        return portalConfig.removeAlternateLanguage(languageCode);
    }

    // FR-PM10
    public void contributePortalNews(NewsEntry news) {
        newsEntries.put(news.getId(), news);
    }

    // FR-PM11
    public boolean editPortalNews(String id, String title, String content) {
        NewsEntry entry = newsEntries.get(id);
        if (entry != null) {
            entry.setTitle(title);
            entry.setContent(content);
            return true;
        }
        return false;
    }

    // FR-PM12
    public boolean deletePortalNews(String id) {
        return newsEntries.remove(id) != null;
    }

    // FR-PM13
    public void contributeBlogPost(BlogPost post) {
        blogPosts.put(post.getId(), post);
    }

    // FR-PM14
    public boolean editBlogPost(String id, String title, String content) {
        BlogPost post = blogPosts.get(id);
        if (post != null) {
            post.setTitle(title);
            post.setContent(content);
            return true;
        }
        return false;
    }

    // FR-PM15
    public boolean deleteBlogPost(String id) {
        return blogPosts.remove(id) != null;
    }

    // FR-PM16
    public void addMenuItem(MenuItem item) {
        menuItems.put(item.getId(), item);
    }

    public boolean removeMenuItem(String id) {
        return menuItems.remove(id) != null;
    }

    public List<MenuItem> getMenuItemsOrdered() {
        List<MenuItem> list = new ArrayList<>(menuItems.values());
        list.sort(Comparator.comparingInt(MenuItem::getOrder));
        return list;
    }

    // FR-PM17
    public void addPage(PortalPage page) {
        portalPages.put(page.getId(), page);
    }

    // FR-PM18
    public boolean deletePage(String pageId) {
        return portalPages.remove(pageId) != null;
    }

    // FR-PM19
    public boolean editPage(String pageId, String title, String content) {
        PortalPage page = portalPages.get(pageId);
        if (page != null) {
            page.setTitle(title);
            page.setContent(content);
            return true;
        }
        return false;
    }

    // FR-PM20
    public void editHtmlMetadataTags(String name, String content) {
        portalConfig.setHtmlMetaTag(name, content);
    }

    public Map<String, NewsEntry> getNewsEntries() {
        return Collections.unmodifiableMap(newsEntries);
    }

    public Map<String, BlogPost> getBlogPosts() {
        return Collections.unmodifiableMap(blogPosts);
    }

    public Map<String, PortalPage> getPortalPages() {
        return Collections.unmodifiableMap(portalPages);
    }
}
