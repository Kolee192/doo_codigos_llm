import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChecklistResource {
    private final String id;
    private String title;
    private final Map<String, String> metadata = new HashMap<>();
    private final List<String> taxa = new ArrayList<>();

    public ChecklistResource(String id, String title, Map<String, String> metadata, List<String> taxa) {
        this.id = id;
        this.title = title;
        if (metadata != null) {
            this.metadata.putAll(metadata);
        }
        if (taxa != null) {
            this.taxa.addAll(taxa);
        }
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(metadata);
    }

    public void updateMetadata(String key, String value) {
        metadata.put(key, value);
    }

    public List<String> getTaxa() {
        return Collections.unmodifiableList(taxa);
    }

    public void addTaxon(String taxon) {
        taxa.add(taxon);
    }

    public boolean matchesKeyword(String keyword) {
        String lower = keyword.toLowerCase();
        if (id.toLowerCase().contains(lower) || title.toLowerCase().contains(lower)) return true;
        for (Map.Entry<String, String> entry : metadata.entrySet()) {
            if (entry.getKey().toLowerCase().contains(lower) || entry.getValue().toLowerCase().contains(lower)) {
                return true;
            }
        }
        for (String t : taxa) {
            if (t.toLowerCase().contains(lower)) return true;
        }
        return false;
    }
}
