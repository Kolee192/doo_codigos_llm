import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class VisitorService {
    private final AdministrationService adminService;
    private final DataManagerService dataManagerService;
    private final PortalManagerService portalManagerService;
    private final List<String> relayedGbifNews = new ArrayList<>();
    private final List<String> feedbackMessages = new ArrayList<>();
    private final List<String> publisherMessages = new ArrayList<>();

    public VisitorService(AdministrationService adminService,
                          DataManagerService dataManagerService,
                          PortalManagerService portalManagerService) {
        this.adminService = adminService;
        this.dataManagerService = dataManagerService;
        this.portalManagerService = portalManagerService;
        relayedGbifNews.add("GBIF News: Over 2.5 billion occurrence records now accessible globally.");
        relayedGbifNews.add("GBIF News: New Darwin Core archive publishing toolkit released.");
    }

    // FR-V1
    public OccurrenceFilter buildOccurrenceSelectionFilter(String filterName) {
        return new OccurrenceFilter(filterName);
    }

    // FR-V2
    public void addTaxonomicCriterion(OccurrenceFilter filter, String taxon) {
        filter.addCriterion(new FilterCriterion(CriterionType.TAXONOMIC, taxon));
    }

    // FR-V3
    public void addDatasetCriterion(OccurrenceFilter filter, String datasetId) {
        filter.addCriterion(new FilterCriterion(CriterionType.DATASET, datasetId));
    }

    // FR-V4
    public void addDepthCriterion(OccurrenceFilter filter, Double minDepth, Double maxDepth) {
        filter.addCriterion(new FilterCriterion(CriterionType.DEPTH, minDepth, maxDepth));
    }

    // FR-V5
    public void addAltitudeCriterion(OccurrenceFilter filter, Double minAltitude, Double maxAltitude) {
        filter.addCriterion(new FilterCriterion(CriterionType.ALTITUDE, minAltitude, maxAltitude));
    }

    // FR-V6
    public void addBasisOfRecordsCriterion(OccurrenceFilter filter, String basis) {
        filter.addCriterion(new FilterCriterion(CriterionType.BASIS_OF_RECORD, basis));
    }

    // FR-V7
    public void addGeographicCriterion(OccurrenceFilter filter, String geographic) {
        filter.addCriterion(new FilterCriterion(CriterionType.GEOGRAPHIC, geographic));
    }

    // FR-V8
    public void addDateCriterion(OccurrenceFilter filter, LocalDate minDate, LocalDate maxDate) {
        filter.addCriterion(new FilterCriterion(CriterionType.DATE, minDate, maxDate));
    }

    // FR-V9
    public void removeCriterion(OccurrenceFilter filter, CriterionType type) {
        filter.removeCriterion(type);
    }

    // FR-V10
    public List<OccurrenceRecord> selectOccurrenceRecords(OccurrenceFilter filter) {
        dataManagerService.recordUsage();
        List<OccurrenceRecord> results = new ArrayList<>();
        for (OccurrenceResource res : dataManagerService.getOccurrenceResources().values()) {
            for (OccurrenceRecord rec : res.getRecords()) {
                if (filter == null || filter.matches(rec)) {
                    results.add(rec);
                }
            }
        }
        return results;
    }

    // FR-V11
    public String viewDistributionMap(List<OccurrenceRecord> records) {
        dataManagerService.recordUsage();
        StringBuilder sb = new StringBuilder();
        sb.append("--- Distribution Map View ---\n");
        sb.append("Projection: ").append(adminService.getMapConfig().getProjection()).append("\n");
        sb.append("Active Layers: ");
        for (SpatialLayer l : adminService.getMapConfig().getLayers()) {
            if (l.isVisible()) {
                sb.append("[").append(l.getName()).append("] ");
            }
        }
        sb.append("\nPlotting ").append(records.size()).append(" points:\n");
        for (OccurrenceRecord rec : records) {
            sb.append(String.format(" * Point (Lat: %.2f, Lon: %.2f) -> %s\n",
                    rec.getLatitude(), rec.getLongitude(), rec.getScientificName()));
        }
        return sb.toString();
    }

    // FR-V12
    public String viewOccurrenceRecordSelectionAsTable(List<OccurrenceRecord> records) {
        dataManagerService.recordUsage();
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s | %-20s | %-12s | %-10s | %-10s | %-15s | %-12s\n",
                "ID", "Taxon", "Dataset", "Depth(m)", "Alt(m)", "Basis", "Date"));
        sb.append("--------------------------------------------------------------------------------------------\n");
        for (OccurrenceRecord r : records) {
            sb.append(String.format("%-10s | %-20s | %-12s | %-10.1f | %-10.1f | %-15s | %-12s\n",
                    r.getId(), r.getScientificName(), r.getDatasetId(), r.getDepth(), r.getAltitude(),
                    r.getBasisOfRecord(), r.getEventDate()));
        }
        return sb.toString();
    }

    // FR-V13
    public String exportOccurrenceRecordSelection(List<OccurrenceRecord> records) {
        dataManagerService.recordUsage();
        StringBuilder sb = new StringBuilder();
        sb.append("id,scientificName,datasetId,depth,altitude,basisOfRecord,geographic,latitude,longitude,date\n");
        for (OccurrenceRecord r : records) {
            sb.append(String.format("%s,\"%s\",%s,%.2f,%.2f,%s,\"%s\",%.4f,%.4f,%s\n",
                    r.getId(), r.getScientificName(), r.getDatasetId(), r.getDepth(), r.getAltitude(),
                    r.getBasisOfRecord(), r.getCountryOrGeographic(), r.getLatitude(), r.getLongitude(), r.getEventDate()));
        }
        return sb.toString();
    }

    // FR-V14
    public byte[] exportDistributionMapAsImage(List<OccurrenceRecord> records) {
        dataManagerService.recordUsage();
        String svg = "<svg xmlns='http://www.w3.org/2000/svg' width='800' height='400'>"
                + "<rect width='100%' height='100%' fill='#eef2f5'/>"
                + "<text x='20' y='30'>Occurrence Map (" + records.size() + " points)</text>";
        StringBuilder points = new StringBuilder();
        for (OccurrenceRecord r : records) {
            double x = ((r.getLongitude() + 180.0) / 360.0) * 800.0;
            double y = ((90.0 - r.getLatitude()) / 180.0) * 400.0;
            points.append(String.format("<circle cx='%.1f' cy='%.1f' r='4' fill='red' />", x, y));
        }
        svg = svg + points.toString() + "</svg>";
        return svg.getBytes(StandardCharsets.UTF_8);
    }

    // FR-V15
    public List<String> fullTextSearch(String term) {
        dataManagerService.recordUsage();
        List<String> results = new ArrayList<>();
        String lower = term.toLowerCase();

        dataManagerService.getOccurrenceResources().values().stream()
                .filter(r -> r.matchesKeyword(lower))
                .forEach(r -> results.add("Occurrence Resource: " + r.getTitle() + " (" + r.getId() + ")"));

        dataManagerService.getChecklistResources().values().stream()
                .filter(r -> r.matchesKeyword(lower))
                .forEach(r -> results.add("Checklist Resource: " + r.getTitle() + " (" + r.getId() + ")"));

        dataManagerService.getMultimediaResources().values().stream()
                .filter(r -> r.matchesKeyword(lower))
                .forEach(r -> results.add("Multimedia Resource: " + r.getTitle() + " (" + r.getId() + ")"));

        dataManagerService.getBibliographicResources().values().stream()
                .filter(r -> r.matchesKeyword(lower))
                .forEach(r -> results.add("Bibliographic Resource: " + r.getTitle() + " (" + r.getId() + ")"));

        dataManagerService.getInstitutionResources().values().stream()
                .filter(r -> r.matchesKeyword(lower))
                .forEach(r -> results.add("Institution Resource: " + r.getName() + " (" + r.getId() + ")"));

        dataManagerService.getExpertResources().values().stream()
                .filter(r -> r.matchesKeyword(lower))
                .forEach(r -> results.add("Expert Resource: " + r.getFullName() + " (" + r.getId() + ")"));

        portalManagerService.getNewsEntries().values().stream()
                .filter(n -> n.getTitle().toLowerCase().contains(lower) || n.getContent().toLowerCase().contains(lower))
                .forEach(n -> results.add("Portal News: " + n.getTitle()));

        portalManagerService.getBlogPosts().values().stream()
                .filter(b -> b.getTitle().toLowerCase().contains(lower) || b.getContent().toLowerCase().contains(lower))
                .forEach(b -> results.add("Blog Post: " + b.getTitle()));

        portalManagerService.getPortalPages().values().stream()
                .filter(p -> p.getTitle().toLowerCase().contains(lower) || p.getContent().toLowerCase().contains(lower))
                .forEach(p -> results.add("Portal Page: " + p.getTitle()));

        return results;
    }

    // FR-V16
    public void contactOccurrenceResourcePublisher(String publisherEmail, String message) {
        publisherMessages.add("To: " + publisherEmail + " | Msg: " + message);
    }

    // FR-V17
    public String exportChecklist(String checklistId) {
        ChecklistResource res = dataManagerService.getChecklistResources().get(checklistId);
        if (res == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append("# Checklist: ").append(res.getTitle()).append("\n");
        for (String taxon : res.getTaxa()) {
            sb.append(taxon).append("\n");
        }
        return sb.toString();
    }

    // FR-V18
    public String choosePreferredLanguage(String languageCode) {
        return "Language set to: " + languageCode;
    }

    // FR-V19
    public void sendFeedbackToPortalContact(String visitorEmail, String message) {
        feedbackMessages.add("From: " + visitorEmail + " | Message: " + message);
    }

    // FR-V20
    public List<BlogPost> viewLatestBlogPosts() {
        dataManagerService.recordUsage();
        return portalManagerService.getBlogPosts().values().stream()
                .sorted(Comparator.comparing(BlogPost::getPublishedDate).reversed())
                .collect(Collectors.toList());
    }

    // FR-V21
    public BlogPost readBlogPost(String id) {
        dataManagerService.recordUsage();
        return portalManagerService.getBlogPosts().get(id);
    }

    // FR-V22
    public List<NewsEntry> viewLatestPortalNews() {
        dataManagerService.recordUsage();
        return portalManagerService.getNewsEntries().values().stream()
                .sorted(Comparator.comparing(NewsEntry::getPublishedDate).reversed())
                .collect(Collectors.toList());
    }

    // FR-V23
    public NewsEntry readPortalNews(String id) {
        dataManagerService.recordUsage();
        return portalManagerService.getNewsEntries().get(id);
    }

    // FR-V24
    public String viewDetailsForTaxon(String taxonName) {
        dataManagerService.recordUsage();
        return "Taxon details for: " + taxonName + " (Validated against " +
                dataManagerService.getTaxonomicBackboneVersion() + ")";
    }

    // FR-V25
    public OccurrenceResource viewMetadataForDataset(String id) {
        dataManagerService.recordUsage();
        return dataManagerService.getOccurrenceResources().get(id);
    }

    // FR-V26
    public ChecklistResource viewMetadataForChecklist(String id) {
        dataManagerService.recordUsage();
        return dataManagerService.getChecklistResources().get(id);
    }

    // FR-V27
    public BibliographicResource viewDetailsForBibliographicRecord(String id) {
        dataManagerService.recordUsage();
        return dataManagerService.getBibliographicResources().get(id);
    }

    // FR-V28
    public InstitutionResource viewDetailsForInstitution(String id) {
        dataManagerService.recordUsage();
        return dataManagerService.getInstitutionResources().get(id);
    }

    // FR-V29
    public ExpertResource viewDetailsForExpert(String id) {
        dataManagerService.recordUsage();
        return dataManagerService.getExpertResources().get(id);
    }

    // FR-V30
    public MultimediaResource viewMetadataForMultimedia(String id) {
        dataManagerService.recordUsage();
        return dataManagerService.getMultimediaResources().get(id);
    }

    // FR-V31
    public byte[] downloadMultimediaFile(String id) {
        dataManagerService.recordUsage();
        MultimediaResource res = dataManagerService.getMultimediaResources().get(id);
        return res != null ? res.getData() : new byte[0];
    }

    // FR-V32
    public void navigateDistributionMap(double deltaLon, double deltaLat, double zoomFactor) {
        adminService.getMapConfig().getDefaultExtent().pan(deltaLon, deltaLat);
        adminService.getMapConfig().getDefaultExtent().zoom(zoomFactor);
    }

    // FR-V33
    public boolean toggleSpatialLayer(String layerId) {
        Optional<SpatialLayer> layer = adminService.getMapConfig().getLayer(layerId);
        if (layer.isPresent()) {
            layer.get().toggleVisibility();
            return true;
        }
        return false;
    }

    // FR-V34
    public User register(String username, String email, String password) {
        return adminService.createUserAccount("visitor-registration", username, email, password,
                Set.of(Role.REGISTERED_VISITOR));
    }

    // FR-V35
    public Optional<User> login(String username, String password) {
        User u = adminService.getUser(username);
        if (u != null && u.getPassword().equals(password)) {
            return Optional.of(u);
        }
        return Optional.empty();
    }

    // FR-V36
    public String requestPasswordByEmail(String email) {
        return "If the email " + email + " is associated with an account, your password has been sent to it.";
    }

    // FR-V37
    public String shareDistributionMapOnTwitter(List<OccurrenceRecord> records) {
        return "https://twitter.com/intent/tweet?text=" +
                "Check+out+these+" + records.size() + "+biodiversity+occurrence+points+on+the+portal!";
    }

    // FR-V38
    public String accessDataMetricsDashboard() {
        dataManagerService.recordUsage();
        if (!portalManagerService.getPortalConfig().isDataMetricsVisible()) {
            return "Metrics dashboard is currently hidden by the portal manager.";
        }
        long occurrences = dataManagerService.getOccurrenceResources().values().stream()
                .mapToLong(r -> r.getRecords().size()).sum();
        long datasets = dataManagerService.getOccurrenceResources().size();
        long checklists = dataManagerService.getChecklistResources().size();
        return String.format("=== Portal Data Metrics ===\nDatasets: %d | Occurrences: %d | Checklists: %d | Usage Hits: %d",
                datasets, occurrences, checklists, dataManagerService.monitorPortalUsage());
    }

    // FR-V39
    public String exportDataMetricArchives() {
        return "data-metrics-archive-" + System.currentTimeMillis() + ".csv";
    }

    // FR-V40
    public String viewNetworkSummaryInformation() {
        dataManagerService.recordUsage();
        return portalManagerService.getPortalConfig().getNetworkSummary();
    }

    // FR-V41
    public String viewToolsAndServicesInformation() {
        dataManagerService.recordUsage();
        return "Tools and Services: IPT Data Publisher, Darwin Core Validator, OGC WMS/WFS Map Services, REST API.";
    }

    // FR-V42
    public List<String> viewLatestRelayedGbifNews() {
        dataManagerService.recordUsage();
        return Collections.unmodifiableList(relayedGbifNews);
    }

    // FR-RV1
    public void saveCustomFilter(User user, OccurrenceFilter filter) {
        user.saveFilter(filter);
    }

    // FR-RV2
    public OccurrenceFilter loadCustomFilter(User user, String filterName) {
        return user.getSavedFilter(filterName);
    }

    // FR-RV3
    public OccurrenceFilter deleteCustomFilter(User user, String filterName) {
        return user.removeSavedFilter(filterName);
    }

    public List<String> getFeedbackMessages() {
        return Collections.unmodifiableList(feedbackMessages);
    }

    public List<String> getPublisherMessages() {
        return Collections.unmodifiableList(publisherMessages);
    }
}
