import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class OccurrenceFilter {
    private final String name;
    private final List<FilterCriterion> criteria = new ArrayList<>();

    public OccurrenceFilter(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void addCriterion(FilterCriterion criterion) {
        criteria.add(criterion);
    }

    public boolean removeCriterion(CriterionType type) {
        return criteria.removeIf(c -> c.getType() == type);
    }

    public List<FilterCriterion> getCriteria() {
        return Collections.unmodifiableList(criteria);
    }

    public boolean matches(OccurrenceRecord record) {
        for (FilterCriterion criterion : criteria) {
            if (!criterion.test(record)) {
                return false;
            }
        }
        return true;
    }
}
