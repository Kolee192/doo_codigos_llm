import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class AdministrationService {
    private final Set<String> installedModules = new HashSet<>();
    private final MapConfig mapConfig;
    private EmailConfig emailConfig;
    private final List<ErrorLogEntry> errorLogs = new ArrayList<>();
    private final List<AuditLogEntry> auditLogs = new ArrayList<>();
    private final Map<String, User> users = new HashMap<>();

    public AdministrationService() {
        this.mapConfig = new MapConfig("EPSG:4326", new MapExtent(-180.0, -90.0, 180.0, 90.0));
        this.emailConfig = new EmailConfig("smtp.portal.org", 587, "notifications@portal.org");
    }

    // FR-A1
    public void installModule(String moduleName) {
        installedModules.add(moduleName);
        logAudit("admin", "INSTALL_MODULE", "Installed module: " + moduleName);
    }

    // FR-A2
    public void uninstallModule(String moduleName) {
        installedModules.remove(moduleName);
        logAudit("admin", "UNINSTALL_MODULE", "Uninstalled module: " + moduleName);
    }

    public Set<String> getInstalledModules() {
        return Collections.unmodifiableSet(installedModules);
    }

    // FR-A3
    public void configureDistributionMapProjection(String projection) {
        mapConfig.setProjection(projection);
        logAudit("admin", "CONFIG_MAP_PROJECTION", "Projection set to: " + projection);
    }

    // FR-A4
    public void configureDistributionMapDefaultExtent(MapExtent extent) {
        mapConfig.setDefaultExtent(extent);
        logAudit("admin", "CONFIG_MAP_EXTENT", "Extent set to: " + extent);
    }

    public MapConfig getMapConfig() {
        return mapConfig;
    }

    // FR-A5
    public void editEmailServerConfiguration(String url, int port, String account) {
        this.emailConfig = new EmailConfig(url, port, account);
        logAudit("admin", "CONFIG_EMAIL_SERVER", "Email config updated: " + emailConfig);
    }

    public EmailConfig getEmailConfig() {
        return emailConfig;
    }

    // FR-A6
    public void addSpatialLayer(SpatialLayer layer) {
        mapConfig.addLayer(layer);
        logAudit("admin", "ADD_SPATIAL_LAYER", "Added layer: " + layer.getName());
    }

    // FR-A7
    public boolean removeSpatialLayer(String layerId) {
        boolean removed = mapConfig.removeLayer(layerId);
        if (removed) {
            logAudit("admin", "REMOVE_SPATIAL_LAYER", "Removed layer id: " + layerId);
        }
        return removed;
    }

    // FR-A8
    public boolean editSpatialLayerName(String layerId, String newName) {
        Optional<SpatialLayer> layer = mapConfig.getLayer(layerId);
        if (layer.isPresent()) {
            layer.get().setName(newName);
            logAudit("admin", "EDIT_SPATIAL_LAYER", "Renamed layer id " + layerId + " to: " + newName);
            return true;
        }
        return false;
    }

    // FR-A9
    public List<ErrorLogEntry> viewErrorLogs() {
        return Collections.unmodifiableList(errorLogs);
    }

    // FR-A10
    public String downloadErrorLogs() {
        StringBuilder sb = new StringBuilder();
        for (ErrorLogEntry e : errorLogs) {
            sb.append(e.toString()).append("\n");
        }
        return sb.toString();
    }

    public void logError(String module, String message, String stackTrace) {
        errorLogs.add(new ErrorLogEntry(module, message, stackTrace));
    }

    // FR-A11
    public User createUserAccount(String actor, String username, String email, String password, Set<Role> roles) {
        User user = new User(username, email, password, roles);
        users.put(username, user);
        logAudit(actor, "CREATE_USER", "Created user: " + username);
        return user;
    }

    // FR-A12
    public boolean deleteUserAccount(String actor, String username) {
        User removed = users.remove(username);
        if (removed != null) {
            logAudit(actor, "DELETE_USER", "Deleted user: " + username);
            return true;
        }
        return false;
    }

    // FR-A13
    public boolean assignRoleToUser(String actor, String username, Role role) {
        User u = users.get(username);
        if (u != null) {
            u.addRole(role);
            logAudit(actor, "ASSIGN_ROLE", "Assigned role " + role + " to user: " + username);
            return true;
        }
        return false;
    }

    // FR-A14
    public boolean removeRoleFromUser(String actor, String username, Role role) {
        User u = users.get(username);
        if (u != null) {
            u.removeRole(role);
            logAudit(actor, "REMOVE_ROLE", "Removed role " + role + " from user: " + username);
            return true;
        }
        return false;
    }

    // FR-A15
    public boolean editUserEmail(String actor, String username, String newEmail) {
        User u = users.get(username);
        if (u != null) {
            u.setEmail(newEmail);
            logAudit(actor, "EDIT_USER_EMAIL", "Updated email for user: " + username);
            return true;
        }
        return false;
    }

    // FR-A16
    public List<AuditLogEntry> viewAuditLogs() {
        return Collections.unmodifiableList(auditLogs);
    }

    // FR-A17
    public String downloadAuditLogEntriesForMonth(YearMonth yearMonth) {
        return auditLogs.stream()
                .filter(entry -> YearMonth.from(entry.getTimestamp()).equals(yearMonth))
                .map(AuditLogEntry::toString)
                .collect(Collectors.joining("\n"));
    }

    public void logAudit(String actor, String action, String details) {
        auditLogs.add(new AuditLogEntry(actor, action, details));
    }

    public User getUser(String username) {
        return users.get(username);
    }
}
