public class BiodiversityPortalSystem {
    private final AdministrationService adminService;
    private final DataManagerService dataManagerService;
    private final PortalManagerService portalManagerService;
    private final VisitorService visitorService;

    public BiodiversityPortalSystem() {
        this.adminService = new AdministrationService();
        this.dataManagerService = new DataManagerService();
        this.portalManagerService = new PortalManagerService();
        this.visitorService = new VisitorService(adminService, dataManagerService, portalManagerService);
    }

    public AdministrationService getAdminService() {
        return adminService;
    }

    public DataManagerService getDataManagerService() {
        return dataManagerService;
    }

    public PortalManagerService getPortalManagerService() {
        return portalManagerService;
    }

    public VisitorService getVisitorService() {
        return visitorService;
    }
}
