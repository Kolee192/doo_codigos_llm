import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class User {
    private final String username;
    private String email;
    private String password;
    private final Set<Role> roles = new HashSet<>();
    private final Map<String, OccurrenceFilter> savedFilters = new HashMap<>();

    public User(String username, String email, String password, Set<Role> initialRoles) {
        this.username = username;
        this.email = email;
        this.password = password;
        if (initialRoles != null) {
            this.roles.addAll(initialRoles);
        }
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Role> getRoles() {
        return Collections.unmodifiableSet(roles);
    }

    public void addRole(Role role) {
        roles.add(role);
    }

    public void removeRole(Role role) {
        roles.remove(role);
    }

    public boolean hasRole(Role role) {
        return roles.contains(role);
    }

    public void saveFilter(OccurrenceFilter filter) {
        savedFilters.put(filter.getName(), filter);
    }

    public OccurrenceFilter getSavedFilter(String filterName) {
        return savedFilters.get(filterName);
    }

    public OccurrenceFilter removeSavedFilter(String filterName) {
        return savedFilters.remove(filterName);
    }

    public Map<String, OccurrenceFilter> getSavedFilters() {
        return Collections.unmodifiableMap(savedFilters);
    }
}
