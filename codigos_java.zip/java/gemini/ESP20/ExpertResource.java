import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ExpertResource {
    private final String id;
    private String fullName;
    private String email;
    private String fieldOfExpertise;
    private final Map<String, String> metadata = new HashMap<>();

    public ExpertResource(String id, String fullName, String email, String fieldOfExpertise, Map<String, String> metadata) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.fieldOfExpertise = fieldOfExpertise;
        if (metadata != null) {
            this.metadata.putAll(metadata);
        }
    }

    public String getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFieldOfExpertise() {
        return fieldOfExpertise;
    }

    public void setFieldOfExpertise(String fieldOfExpertise) {
        this.fieldOfExpertise = fieldOfExpertise;
    }

    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(metadata);
    }

    public void updateMetadata(String key, String value) {
        metadata.put(key, value);
    }

    public boolean matchesKeyword(String keyword) {
        String lower = keyword.toLowerCase();
        if (id.toLowerCase().contains(lower) || fullName.toLowerCase().contains(lower) ||
                email.toLowerCase().contains(lower) || fieldOfExpertise.toLowerCase().contains(lower)) {
            return true;
        }
        for (Map.Entry<String, String> entry : metadata.entrySet()) {
            if (entry.getKey().toLowerCase().contains(lower) || entry.getValue().toLowerCase().contains(lower)) {
                return true;
            }
        }
        return false;
    }
}
