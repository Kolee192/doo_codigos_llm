import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class DataManagerService {
    private final Map<String, OccurrenceResource> occurrenceResources = new HashMap<>();
    private final Map<String, ChecklistResource> checklistResources = new HashMap<>();
    private final Map<String, MultimediaResource> multimediaResources = new HashMap<>();
    private final Map<String, BibliographicResource> bibliographicResources = new HashMap<>();
    private final Map<String, InstitutionResource> institutionResources = new HashMap<>();
    private final Map<String, ExpertResource> expertResources = new HashMap<>();

    private final Map<String, DataSource> registeredDataSources = new HashMap<>();
    private final Map<String, HarvestJob> harvestJobs = new HashMap<>();
    private final List<String> extensions = new ArrayList<>();
    private String taxonomicBackboneVersion = "GBIF Backbone Taxonomy 2023-01";
    private long portalAccessCount = 0;
    private String lastBackupTimestamp = LocalDateTime.now().toString();

    // FR-DM1
    public void importOccurrenceResource(OccurrenceResource resource) {
        occurrenceResources.put(resource.getId(), resource);
    }

    // FR-DM2
    public boolean deleteOccurrenceResource(String id) {
        return occurrenceResources.remove(id) != null;
    }

    // FR-DM3
    public boolean editOccurrenceResourceMetadata(String id, String key, String value) {
        OccurrenceResource res = occurrenceResources.get(id);
        if (res != null) {
            res.updateMetadata(key, value);
            return true;
        }
        return false;
    }

    // FR-DM4
    public List<OccurrenceResource> searchOccurrenceResources(String keyword) {
        return occurrenceResources.values().stream()
                .filter(r -> r.matchesKeyword(keyword))
                .collect(Collectors.toList());
    }

    // FR-DM5
    public void importChecklistResource(ChecklistResource resource) {
        checklistResources.put(resource.getId(), resource);
    }

    // FR-DM6
    public boolean deleteChecklistResource(String id) {
        return checklistResources.remove(id) != null;
    }

    // FR-DM7
    public boolean editChecklistResourceMetadata(String id, String key, String value) {
        ChecklistResource res = checklistResources.get(id);
        if (res != null) {
            res.updateMetadata(key, value);
            return true;
        }
        return false;
    }

    // FR-DM8
    public List<ChecklistResource> searchChecklistResources(String keyword) {
        return checklistResources.values().stream()
                .filter(r -> r.matchesKeyword(keyword))
                .collect(Collectors.toList());
    }

    // FR-DM9
    public void importMultimediaResource(MultimediaResource resource) {
        multimediaResources.put(resource.getId(), resource);
    }

    // FR-DM10
    public boolean deleteMultimediaResource(String id) {
        return multimediaResources.remove(id) != null;
    }

    // FR-DM11
    public boolean editMultimediaResourceMetadata(String id, String key, String value) {
        MultimediaResource res = multimediaResources.get(id);
        if (res != null) {
            res.updateMetadata(key, value);
            return true;
        }
        return false;
    }

    // FR-DM12
    public List<MultimediaResource> searchMultimediaResources(String keyword) {
        return multimediaResources.values().stream()
                .filter(r -> r.matchesKeyword(keyword))
                .collect(Collectors.toList());
    }

    // FR-DM13
    public void importBibliographicResource(BibliographicResource resource) {
        bibliographicResources.put(resource.getId(), resource);
    }

    // FR-DM14
    public boolean deleteBibliographicResource(String id) {
        return bibliographicResources.remove(id) != null;
    }

    // FR-DM15
    public boolean editBibliographicResourceMetadata(String id, String key, String value) {
        BibliographicResource res = bibliographicResources.get(id);
        if (res != null) {
            res.updateMetadata(key, value);
            return true;
        }
        return false;
    }

    // FR-DM16
    public List<BibliographicResource> searchBibliographicResources(String keyword) {
        return bibliographicResources.values().stream()
                .filter(r -> r.matchesKeyword(keyword))
                .collect(Collectors.toList());
    }

    // FR-DM17
    public void importInstitutionResource(InstitutionResource resource) {
        institutionResources.put(resource.getId(), resource);
    }

    // FR-DM18
    public boolean deleteInstitutionResource(String id) {
        return institutionResources.remove(id) != null;
    }

    // FR-DM19
    public boolean editInstitutionResourceMetadata(String id, String key, String value) {
        InstitutionResource res = institutionResources.get(id);
        if (res != null) {
            res.updateMetadata(key, value);
            return true;
        }
        return false;
    }

    // FR-DM20
    public List<InstitutionResource> searchInstitutionResources(String keyword) {
        return institutionResources.values().stream()
                .filter(r -> r.matchesKeyword(keyword))
                .collect(Collectors.toList());
    }

    // FR-DM21
    public void importExpertResource(ExpertResource resource) {
        expertResources.put(resource.getId(), resource);
    }

    // FR-DM22
    public boolean deleteExpertResource(String id) {
        return expertResources.remove(id) != null;
    }

    // FR-DM23
    public boolean editExpertResourceMetadata(String id, String key, String value) {
        ExpertResource res = expertResources.get(id);
        if (res != null) {
            res.updateMetadata(key, value);
            return true;
        }
        return false;
    }

    // FR-DM24
    public List<ExpertResource> searchExpertResources(String keyword) {
        return expertResources.values().stream()
                .filter(r -> r.matchesKeyword(keyword))
                .collect(Collectors.toList());
    }

    // FR-DM25
    public void registerGbifIndexDataSource(String id, String name, String url) {
        registeredDataSources.put(id, new DataSource(id, name, DataSource.Type.GBIF_INDEX, url));
    }

    // FR-DM26
    public void registerIptDataSource(String id, String name, String url) {
        registeredDataSources.put(id, new DataSource(id, name, DataSource.Type.IPT, url));
    }

    // FR-DM27
    public boolean unregisterIptDataSource(String id) {
        DataSource ds = registeredDataSources.get(id);
        if (ds != null && ds.getType() == DataSource.Type.IPT) {
            registeredDataSources.remove(id);
            return true;
        }
        return false;
    }

    // FR-DM28
    public boolean unregisterGbifIndexDataSource(String id) {
        DataSource ds = registeredDataSources.get(id);
        if (ds != null && ds.getType() == DataSource.Type.GBIF_INDEX) {
            registeredDataSources.remove(id);
            return true;
        }
        return false;
    }

    // FR-DM29
    public HarvestJob scheduleHarvestingJob(String jobId, String dataSourceId, LocalDateTime time) {
        HarvestJob job = new HarvestJob(jobId, dataSourceId, time);
        harvestJobs.put(jobId, job);
        return job;
    }

    // FR-DM30
    public boolean cancelHarvestingJob(String jobId) {
        HarvestJob job = harvestJobs.get(jobId);
        if (job != null && job.getStatus() == HarvestJobStatus.SCHEDULED) {
            job.setStatus(HarvestJobStatus.CANCELLED);
            job.setReport("Job cancelled by Data Manager");
            return true;
        }
        return false;
    }

    // FR-DM31
    public String viewHarvestReport(String jobId) {
        HarvestJob job = harvestJobs.get(jobId);
        return job != null ? job.getReport() : "Job not found";
    }

    // FR-DM32
    public boolean checkCoreResourcesConsistency() {
        return !registeredDataSources.isEmpty() || (!occurrenceResources.isEmpty() || !checklistResources.isEmpty());
    }

    // FR-DM33
    public boolean triggerHarvestingJob(String jobId) {
        HarvestJob job = harvestJobs.get(jobId);
        if (job != null) {
            job.setStatus(HarvestJobStatus.RUNNING);
            job.setStatus(HarvestJobStatus.COMPLETED);
            job.setReport("Harvesting completed successfully at " + LocalDateTime.now() + " for source: " + job.getDataSourceId());
            return true;
        }
        return false;
    }

    // FR-DM34
    public String requestRestorationOfLatestBackup() {
        return "Backup restoration requested successfully. Restored to snapshot: " + lastBackupTimestamp;
    }

    // FR-DM35
    public void updateTaxonomicBackbone(String version) {
        this.taxonomicBackboneVersion = version;
    }

    public String getTaxonomicBackboneVersion() {
        return taxonomicBackboneVersion;
    }

    // FR-DM36
    public void installExtension(String extensionName) {
        extensions.add(extensionName);
    }

    public List<String> getExtensions() {
        return Collections.unmodifiableList(extensions);
    }

    // FR-DM37
    public void recordUsage() {
        portalAccessCount++;
    }

    public long monitorPortalUsage() {
        return portalAccessCount;
    }

    public Map<String, OccurrenceResource> getOccurrenceResources() {
        return Collections.unmodifiableMap(occurrenceResources);
    }

    public Map<String, ChecklistResource> getChecklistResources() {
        return Collections.unmodifiableMap(checklistResources);
    }

    public Map<String, MultimediaResource> getMultimediaResources() {
        return Collections.unmodifiableMap(multimediaResources);
    }

    public Map<String, BibliographicResource> getBibliographicResources() {
        return Collections.unmodifiableMap(bibliographicResources);
    }

    public Map<String, InstitutionResource> getInstitutionResources() {
        return Collections.unmodifiableMap(institutionResources);
    }

    public Map<String, ExpertResource> getExpertResources() {
        return Collections.unmodifiableMap(expertResources);
    }

    public Map<String, DataSource> getRegisteredDataSources() {
        return Collections.unmodifiableMap(registeredDataSources);
    }
}
