import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OccurrenceResource {
    private final String id;
    private String title;
    private final Map<String, String> metadata = new HashMap<>();
    private final List<OccurrenceRecord> records = new ArrayList<>();

    public OccurrenceResource(String id, String title, Map<String, String> initialMetadata) {
        this.id = id;
        this.title = title;
        if (initialMetadata != null) {
            this.metadata.putAll(initialMetadata);
        }
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(metadata);
    }

    public void updateMetadata(String key, String value) {
        metadata.put(key, value);
    }

    public void addRecord(OccurrenceRecord record) {
        records.add(record);
    }

    public List<OccurrenceRecord> getRecords() {
        return Collections.unmodifiableList(records);
    }

    public boolean matchesKeyword(String keyword) {
        String lower = keyword.toLowerCase();
        if (id.toLowerCase().contains(lower) || title.toLowerCase().contains(lower)) return true;
        for (Map.Entry<String, String> entry : metadata.entrySet()) {
            if (entry.getKey().toLowerCase().contains(lower) || entry.getValue().toLowerCase().contains(lower)) {
                return true;
            }
        }
        return false;
    }
}
