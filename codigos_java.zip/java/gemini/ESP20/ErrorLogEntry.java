import java.time.LocalDateTime;

public class ErrorLogEntry {
    private final LocalDateTime timestamp;
    private final String module;
    private final String message;
    private final String stackTrace;

    public ErrorLogEntry(String module, String message, String stackTrace) {
        this.timestamp = LocalDateTime.now();
        this.module = module;
        this.message = message;
        this.stackTrace = stackTrace;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getModule() {
        return module;
    }

    public String getMessage() {
        return message;
    }

    public String getStackTrace() {
        return stackTrace;
    }

    @Override
    public String toString() {
        return String.format("[%s] Module: %s | Error: %s | Trace: %s",
                timestamp, module, message, stackTrace);
    }
}
