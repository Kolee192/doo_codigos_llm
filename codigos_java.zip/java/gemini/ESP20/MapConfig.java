import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class MapConfig {
    private String projection;
    private MapExtent defaultExtent;
    private final List<SpatialLayer> layers = new ArrayList<>();

    public MapConfig(String projection, MapExtent defaultExtent) {
        this.projection = projection;
        this.defaultExtent = defaultExtent;
    }

    public String getProjection() {
        return projection;
    }

    public void setProjection(String projection) {
        this.projection = projection;
    }

    public MapExtent getDefaultExtent() {
        return defaultExtent;
    }

    public void setDefaultExtent(MapExtent defaultExtent) {
        this.defaultExtent = defaultExtent;
    }

    public void addLayer(SpatialLayer layer) {
        layers.add(layer);
    }

    public boolean removeLayer(String layerId) {
        return layers.removeIf(l -> l.getId().equals(layerId));
    }

    public Optional<SpatialLayer> getLayer(String layerId) {
        return layers.stream().filter(l -> l.getId().equals(layerId)).findFirst();
    }

    public List<SpatialLayer> getLayers() {
        return Collections.unmodifiableList(layers);
    }
}
