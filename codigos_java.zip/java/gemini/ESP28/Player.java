import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Player implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String id;
    private String name;
    private String icon;
    private Wind seatWind;
    private final boolean isComputer;
    private COLevel coLevel;
    private COStyle coStyle;

    private final List<Tile> hand = new ArrayList<>();
    private final List<Meld> melds = new ArrayList<>();
    private int score;
    private boolean fishing;

    public Player(String id, String name, String icon, boolean isComputer) {
        this.id = id;
        this.name = name;
        this.icon = icon;
        this.isComputer = isComputer;
        this.score = 0;
        this.fishing = false;
        this.coLevel = COLevel.BEGINNER;
        this.coStyle = COStyle.BALANCED;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public Wind getSeatWind() {
        return seatWind;
    }

    public void setSeatWind(Wind seatWind) {
        this.seatWind = seatWind;
    }

    public boolean isComputer() {
        return isComputer;
    }

    public COLevel getCoLevel() {
        return coLevel;
    }

    public void setCoLevel(COLevel coLevel) {
        this.coLevel = coLevel;
    }

    public COStyle getCoStyle() {
        return coStyle;
    }

    public void setCoStyle(COStyle coStyle) {
        this.coStyle = coStyle;
    }

    public List<Tile> getHand() {
        return hand;
    }

    public List<Meld> getMelds() {
        return melds;
    }

    public int getScore() {
        return score;
    }

    public void addScore(int delta) {
        this.score += delta;
    }

    public boolean isFishing() {
        return fishing;
    }

    public void setFishing(boolean fishing) {
        this.fishing = fishing;
    }

    public void addTile(Tile tile) {
        hand.add(tile);
        Collections.sort(hand);
    }

    public boolean removeTile(Tile tile) {
        return hand.remove(tile);
    }

    public void addMeld(Meld meld) {
        melds.add(meld);
    }

    public void sortHand() {
        Collections.sort(hand);
    }

    @Override
    public String toString() {
        return name + " (" + seatWind + ")" + (isComputer ? " [CO:" + coLevel + "]" : " [Human]");
    }
}
