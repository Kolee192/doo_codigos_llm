import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class MultiMahjongServer {
    private final String ipAddress;
    private final List<HighScoreEntry> highScores = new CopyOnWriteArrayList<>();
    private final Map<Integer, GameSession> activeGames = new ConcurrentHashMap<>();
    private final List<ChatMessage> chatLog = new CopyOnWriteArrayList<>();
    private final List<String> serverLogs = new CopyOnWriteArrayList<>();
    private final AtomicInteger gameIdSequence = new AtomicInteger(100);

    private String serverName = "MultiMahjong Master Server";
    private int maxConcurrentGames = 50;

    public MultiMahjongServer(String ipAddress) {
        this.ipAddress = ipAddress;
        loadServerPreferences("server_prefs.dat");
        initialiseDefaultHighScores();
        log("MultiMahjongServer initialised on IP: " + ipAddress);
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public synchronized void log(String message) {
        String logEntry = "[SERVER " + System.currentTimeMillis() + "] " + message;
        serverLogs.add(logEntry);
        System.out.println(logEntry);
    }

    public List<String> getServerLogs() {
        return Collections.unmodifiableList(serverLogs);
    }

    private void initialiseDefaultHighScores() {
        highScores.add(new HighScoreEntry("DragonMaster", 1200));
        highScores.add(new HighScoreEntry("WindWalker", 950));
        highScores.add(new HighScoreEntry("TileWizard", 800));
        highScores.add(new HighScoreEntry("JadePhoenix", 650));
        Collections.sort(highScores);
    }

    public List<HighScoreEntry> getHighScores() {
        return Collections.unmodifiableList(highScores);
    }

    public synchronized void submitHighScore(String playerName, int score) {
        highScores.add(new HighScoreEntry(playerName, score));
        Collections.sort(highScores);
        log("New high score recorded: " + playerName + " -> " + score);
    }

    public synchronized GameSession createGame(String creatorName, String creatorIcon, int scoreLimit, int totalHumans, RuleVariation variation, COLevel coLevel) {
        int id = gameIdSequence.incrementAndGet();
        GameSession session = new GameSession(id, creatorName, creatorIcon, scoreLimit, totalHumans, variation, coLevel);
        Player creator = new Player(UUID.randomUUID().toString(), creatorName, creatorIcon, false);
        session.addPlayer(creator);
        activeGames.put(id, session);
        log("Game created [ID: " + id + "] by " + creatorName + ", RuleVariation: " + variation);
        return session;
    }

    public List<GameSession> getAvailableGames() {
        List<GameSession> available = new ArrayList<>();
        for (GameSession g : activeGames.values()) {
            if (!g.isActive() && !g.isFinished() && g.getRemainingPlayerSlots() > 0) {
                available.add(g);
            }
        }
        return available;
    }

    public synchronized boolean joinGame(int gameId, Player player) {
        GameSession game = activeGames.get(gameId);
        if (game != null && !game.isActive() && game.getRemainingPlayerSlots() > 0) {
            game.addPlayer(player);
            log("Player " + player.getName() + " joined game ID " + gameId);
            return true;
        }
        return false;
    }

    public synchronized void broadcastChat(ChatMessage msg) {
        chatLog.add(msg);
        log("Chat Relay: " + msg);
    }

    public List<ChatMessage> getChatHistory() {
        return Collections.unmodifiableList(chatLog);
    }

    public void updatePlayerProfile(int gameId, String playerId, String newName, String newIcon) {
        GameSession game = activeGames.get(gameId);
        if (game != null) {
            for (Player p : game.getPlayers()) {
                if (p.getId().equals(playerId)) {
                    p.setName(newName);
                    p.setIcon(newIcon);
                    log("Player " + playerId + " updated profile: Name=" + newName + ", Icon=" + newIcon);
                    break;
                }
            }
        }
    }

    public void saveServerPreferences(String filepath) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filepath))) {
            writer.println("ServerName=" + serverName);
            writer.println("MaxConcurrentGames=" + maxConcurrentGames);
            log("Server preferences saved to " + filepath);
        } catch (IOException e) {
            log("Error saving server preferences: " + e.getMessage());
        }
    }

    public void loadServerPreferences(String filepath) {
        File file = new File(filepath);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("=");
                if (parts.length == 2) {
                    if (parts[0].equals("ServerName")) serverName = parts[1];
                    if (parts[0].equals("MaxConcurrentGames")) maxConcurrentGames = Integer.parseInt(parts[1]);
                }
            }
            log("Server preferences loaded from " + filepath);
        } catch (Exception e) {
            log("Error reading preferences: " + e.getMessage());
        }
    }

    // Graphical Administrator Console interface
    public void openAdminConsole() {
        System.out.println("==================================================");
        System.out.println("  [SERVER ADMIN GUI CONSOLE] - " + serverName);
        System.out.println("  IP: " + ipAddress + " | Max Games: " + maxConcurrentGames);
        System.out.println("  Active Games: " + activeGames.size());
        System.out.println("  Recent Logs Count: " + serverLogs.size());
        System.out.println("==================================================");
    }
}
