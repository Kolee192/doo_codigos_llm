import java.io.*;
import java.util.*;

public class MultiMahjongClient {
    private final String clientId;
    private final MultiMahjongServer server; // In single-player, server call intercepted internally
    private final boolean isSinglePlayerMode;

    private Preferences preferences;
    private Player localPlayer;
    private GameSession currentGame;
    private final SoundManager soundManager;
    private final List<GameSnapshot> undoHistory = new ArrayList<>();

    public MultiMahjongClient(String clientId, MultiMahjongServer server, boolean singlePlayerMode) {
        this.clientId = clientId;
        this.server = server;
        this.isSinglePlayerMode = singlePlayerMode;
        this.preferences = PreferenceManager.loadPreferences("client_prefs_" + clientId + ".dat");
        this.soundManager = new SoundManager(preferences.isSoundEnabled());
        this.localPlayer = new Player(clientId, preferences.getPlayerName(), preferences.getIcon(), false);
    }

    public Player getLocalPlayer() {
        return localPlayer;
    }

    public GameSession getCurrentGame() {
        return currentGame;
    }

    public SoundManager getSoundManager() {
        return soundManager;
    }

    // Preference management
    public void updatePreferences(String name, String icon, boolean sound, COLevel level, RuleVariation variation) {
        preferences.setPlayerName(name);
        preferences.setIcon(icon);
        preferences.setSoundEnabled(sound);
        preferences.setDefaultCOLevel(level);
        preferences.setDefaultVariation(variation);
        soundManager.setEnabled(sound);
        localPlayer.setName(name);
        localPlayer.setIcon(icon);
        PreferenceManager.savePreferences(preferences, "client_prefs_" + clientId + ".dat");
        System.out.println("[Client " + clientId + "] Preferences updated and saved.");
    }

    // Custom Icon / Avatar upload
    public void uploadCustomImage(String imageFilePath) {
        if (imageFilePath.endsWith(".jpg") || imageFilePath.endsWith(".jpeg") || imageFilePath.endsWith(".gif")) {
            localPlayer.setIcon(imageFilePath);
            preferences.setIcon(imageFilePath);
            PreferenceManager.savePreferences(preferences, "client_prefs_" + clientId + ".dat");
            System.out.println("[Client " + clientId + "] Custom image uploaded successfully: " + imageFilePath);
            if (!isSinglePlayerMode && currentGame != null) {
                server.updatePlayerProfile(currentGame.getGameId(), clientId, localPlayer.getName(), imageFilePath);
            }
        } else {
            System.out.println("[Client " + clientId + "] Error: Only JPEG and GIF formats are allowed!");
        }
    }

    // Profile modification during gameplay
    public void modifyProfileDuringGame(String newName, String newIcon) {
        localPlayer.setName(newName);
        localPlayer.setIcon(newIcon);
        System.out.println("[Client " + clientId + "] Profile changed mid-game to: " + newName + " (" + newIcon + ")");
        if (!isSinglePlayerMode && currentGame != null) {
            server.updatePlayerProfile(currentGame.getGameId(), clientId, newName, newIcon);
        }
    }

    // Game creation: Multi-player
    public GameSession createMultiPlayerGame(int totalHumans, int scoreLimit, RuleVariation variation, COLevel coLevel) {
        if (totalHumans < 1 || totalHumans > 4) {
            throw new IllegalArgumentException("Total human players must be between 1 and 4.");
        }
        GameSession game = server.createGame(localPlayer.getName(), localPlayer.getIcon(), scoreLimit, totalHumans, variation, coLevel);
        this.currentGame = game;
        return game;
    }

    // Game creation: Single-player (server intercepted internally)
    public GameSession createSinglePlayerGame(int scoreLimit, RuleVariation variation, COLevel coLevel) {
        GameSession spGame = new GameSession(1, localPlayer.getName(), localPlayer.getIcon(), scoreLimit, 1, variation, coLevel);
        spGame.addPlayer(localPlayer);
        // Setup 3 COs directly
        for (int i = 1; i <= 3; i++) {
            Player co = new Player("CO_SP_" + i, "Bot_" + i, "Icon_CO.png", true);
            co.setCoLevel(coLevel);
            spGame.addPlayer(co);
        }
        this.currentGame = spGame;
        return spGame;
    }

    // Join Game
    public List<GameSession> fetchAvailableGames() {
        if (isSinglePlayerMode) {
            return Collections.emptyList();
        }
        return server.getAvailableGames();
    }

    public boolean joinMultiPlayerGame(int gameId) {
        boolean success = server.joinGame(gameId, localPlayer);
        if (success) {
            for (GameSession g : server.getAvailableGames()) {
                if (g.getGameId() == gameId) {
                    this.currentGame = g;
                    break;
                }
            }
        }
        return success;
    }

    // Start game
    public void startMahjongGame() {
        if (currentGame == null) return;
        currentGame.startGame();
        soundManager.playSound("game_start.wav");
        displayGameStatus();
    }

    // Display user interface screen status
    public void displayGameStatus() {
        System.out.println("\n----------------- GAME SCREEN [" + localPlayer.getName() + "] -----------------");
        System.out.println("Round Wind: " + currentGame.getCurrentRoundWind() + " | Wall Tiles Left: " + currentGame.getWall().size());
        System.out.println("Players:");
        for (Player p : currentGame.getPlayers()) {
            System.out.println("  " + p + " | Exposed Melds: " + p.getMelds() + (p.isFishing() ? " [FISHING!]" : ""));
        }
        System.out.println("Your Concealed Hand: " + localPlayer.getHand());
        System.out.println("Discard Pool: " + currentGame.getDiscards());
        Player turnPlayer = currentGame.getPlayers().get(currentGame.getCurrentTurnIndex());
        System.out.println(">> CURRENT TURN: " + turnPlayer.getName() + " (" + turnPlayer.getSeatWind() + ") <<");
        System.out.println("-----------------------------------------------------------------");
    }

    // Automated or manual tile pickup
    public Tile pickUpTileFromWall() {
        if (currentGame == null) return null;
        Player current = currentGame.getPlayers().get(currentGame.getCurrentTurnIndex());
        if (!current.getId().equals(localPlayer.getId())) {
            System.out.println("It is not your turn to pick up a tile!");
            return null;
        }

        // Save state for undo if in single player
        if (isSinglePlayerMode) {
            undoHistory.add(currentGame.createSnapshot(localPlayer));
        }

        Tile drawn = currentGame.drawTile(localPlayer);
        if (drawn != null) {
            soundManager.playSound("tile_draw.wav");
            System.out.println("[Action] You drew tile: " + drawn);
            localPlayer.sortHand();
        } else {
            System.out.println("[Notice] Wall is empty! Hand ended in a DRAW.");
            soundManager.playSound("draw_game.wav");
            currentGame.endRound(null);
        }
        return drawn;
    }

    // Discard tile
    public void discardTile(Tile tile) {
        if (currentGame == null) return;
        if (!localPlayer.getHand().contains(tile)) {
            System.out.println("Cannot discard a tile not present in your hand.");
            return;
        }

        // Save undo point in SP
        if (isSinglePlayerMode) {
            undoHistory.add(currentGame.createSnapshot(localPlayer));
        }

        currentGame.discardTile(localPlayer, tile);
        soundManager.playSound("tile_discard.wav");
        System.out.println("[Action] You discarded: " + tile);

        // Check if other players can claim
        evaluateOtherPlayersOnDiscard(tile);
    }

    // Respond to claims: Chow, Pung, Kong, Mahjong
    public void evaluatePlayerActionOptions(Tile lastDiscard) {
        if (lastDiscard == null) return;
        System.out.println("\nChecking claim options for " + localPlayer.getName() + " on " + lastDiscard + ":");

        boolean canChow = MahjongRuleValidator.canChow(localPlayer.getHand(), lastDiscard);
        boolean canPung = MahjongRuleValidator.canPung(localPlayer.getHand(), lastDiscard);
        boolean canKong = MahjongRuleValidator.canKong(localPlayer.getHand(), lastDiscard);
        boolean canMahjong = MahjongRuleValidator.checkMahjong(localPlayer.getHand(), localPlayer.getMelds(), lastDiscard, currentGame.getRuleVariation());

        if (canChow) System.out.println(" -> Option available: CHOW");
        if (canPung) System.out.println(" -> Option available: PUNG");
        if (canKong) System.out.println(" -> Option available: KONG");
        if (canMahjong) System.out.println(" -> Option available: MAHJONG (HU)!");

        if (!canChow && !canPung && !canKong && !canMahjong) {
            System.out.println(" -> No valid claims on this discard.");
        }
    }

    public void claimPung(Tile discard) {
        if (!MahjongRuleValidator.canPung(localPlayer.getHand(), discard)) {
            System.out.println("Invalid Pung claim.");
            return;
        }
        Meld meld = new Meld(MeldType.PUNG, List.of(discard, discard, discard), false);
        currentGame.performMeld(localPlayer, meld);
        soundManager.playSound("pung.wav");
        System.out.println("[Claim] You announced PUNG on " + discard + "!");
    }

    public void claimChow(Tile discard, Tile t1, Tile t2) {
        List<Tile> chowList = List.of(discard, t1, t2);
        Meld meld = new Meld(MeldType.CHOW, chowList, false);
        currentGame.performMeld(localPlayer, meld);
        soundManager.playSound("chow.wav");
        System.out.println("[Claim] You announced CHOW: " + meld);
    }

    public void claimKong(Tile discard) {
        if (!MahjongRuleValidator.canKong(localPlayer.getHand(), discard)) {
            System.out.println("Invalid Kong claim.");
            return;
        }
        Meld meld = new Meld(MeldType.KONG, List.of(discard, discard, discard, discard), false);
        currentGame.performMeld(localPlayer, meld);
        soundManager.playSound("kong.wav");
        System.out.println("[Claim] You announced KONG on " + discard + "!");
        // Pick extra tile from wall
        currentGame.drawTile(localPlayer);
    }

    public void declareMahjong(Tile winningTile) {
        if (MahjongRuleValidator.checkMahjong(localPlayer.getHand(), localPlayer.getMelds(), winningTile, currentGame.getRuleVariation())) {
            soundManager.playSound("mahjong_win.wav");
            System.out.println("\n************************************************");
            System.out.println("MAHJONG! " + localPlayer.getName() + " WINS THE HAND!");
            System.out.println("************************************************\n");
            currentGame.endRound(localPlayer);
            if (!isSinglePlayerMode) {
                server.submitHighScore(localPlayer.getName(), localPlayer.getScore());
            }
        } else {
            System.out.println("False Mahjong declaration!");
        }
    }

    private void evaluateOtherPlayersOnDiscard(Tile discard) {
        // Evaluate for AI players
        for (Player p : currentGame.getPlayers()) {
            if (p.isComputer() && !p.equals(localPlayer)) {
                if (MahjongRuleValidator.checkMahjong(p.getHand(), p.getMelds(), discard, currentGame.getRuleVariation())) {
                    System.out.println("[Notification] " + p.getName() + " went MAHJONG on " + discard + "!");
                    currentGame.endRound(p);
                    return;
                }
                if (MahjongRuleValidator.canPung(p.getHand(), discard) && ComputerOpponentAI.shouldClaimDiscard(p, discard, MeldType.PUNG)) {
                    Meld meld = new Meld(MeldType.PUNG, List.of(discard, discard, discard), false);
                    currentGame.performMeld(p, meld);
                    System.out.println("[CO Action] " + p.getName() + " claimed PUNG on " + discard);
                    // CO then discards
                    Tile coDiscard = ComputerOpponentAI.chooseDiscard(p, currentGame.getDiscards(), currentGame.getRuleVariation());
                    currentGame.discardTile(p, coDiscard);
                    System.out.println("[CO Action] " + p.getName() + " discarded " + coDiscard);
                    return;
                }
            }
        }
    }

    // Process turn for CO if current turn belongs to a Computer Opponent
    public void processNextCOTurn() {
        Player current = currentGame.getPlayers().get(currentGame.getCurrentTurnIndex());
        if (current.isComputer()) {
            Tile drawn = currentGame.drawTile(current);
            System.out.println("[CO Action] " + current.getName() + " picked up a tile from the wall.");
            // Check self-drawn win
            if (drawn != null && MahjongRuleValidator.checkMahjong(current.getHand(), current.getMelds(), null, currentGame.getRuleVariation())) {
                System.out.println("[CO Action] " + current.getName() + " goes MAHJONG with self-drawn tile!");
                currentGame.endRound(current);
                return;
            }
            Tile discard = ComputerOpponentAI.chooseDiscard(current, currentGame.getDiscards(), currentGame.getRuleVariation());
            currentGame.discardTile(current, discard);
            System.out.println("[CO Action] " + current.getName() + " discards " + discard);
            evaluatePlayerActionOptions(discard);
        }
    }

    // Single Player Undo & Save
    public void undoLastMove() {
        if (!isSinglePlayerMode) {
            System.out.println("Undo is only allowed in single player games!");
            return;
        }
        if (undoHistory.isEmpty()) {
            System.out.println("No move history to undo.");
            return;
        }
        GameSnapshot lastState = undoHistory.remove(undoHistory.size() - 1);
        currentGame.restoreSnapshot(localPlayer, lastState);
        System.out.println("[Undo] Reverted to previous move state successfully.");
    }

    public void saveSinglePlayerGame(String filename) {
        if (!isSinglePlayerMode) {
            System.out.println("Save is only allowed in single player games!");
            return;
        }
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(currentGame);
            System.out.println("[Save Game] Game successfully saved to " + filename);
        } catch (IOException e) {
            System.err.println("Failed to save game: " + e.getMessage());
        }
    }

    public void loadSinglePlayerGame(String filename) {
        if (!isSinglePlayerMode) return;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            this.currentGame = (GameSession) ois.readObject();
            System.out.println("[Load Game] Game restored from " + filename);
        } catch (Exception e) {
            System.err.println("Failed to load game: " + e.getMessage());
        }
    }

    // In-game Real-time Chat
    public void sendChatMessage(String text) {
        ChatMessage msg = new ChatMessage(localPlayer.getName(), text);
        if (!isSinglePlayerMode) {
            server.broadcastChat(msg);
        } else {
            System.out.println("[SP Chat] " + msg);
        }
    }

    public void printChatHistory() {
        if (!isSinglePlayerMode) {
            System.out.println("----- CHAT HISTORY -----");
            for (ChatMessage m : server.getChatHistory()) {
                System.out.println(m);
            }
            System.out.println("------------------------");
        }
    }

    // High Scores Viewer
    public void viewHighScores() {
        System.out.println("========== HIGH SCORES LIST ==========");
        List<HighScoreEntry> list = server.getHighScores();
        for (int i = 0; i < list.size(); i++) {
            System.out.println((i + 1) + ". " + list.get(i));
        }
        System.out.println("======================================");
    }

    // User Documentation
    public void openOnlineDocumentation() {
        System.out.println("\n[Online User Documentation]");
        System.out.println("Rulebook: 'How to Play Mah Jong' (Classical Chinese rules)");
        System.out.println("Objective: Complete 4 melds (Chow/Pung/Kong) and 1 pair (Eye) to achieve Mahjong (14 tiles).");
        System.out.println("Variations supported: Classical Chinese, Cleared Hand, Japanese Riichi.");
        System.out.println("CO Levels: Beginner (random discards), Intermediate (protects pairs/sequences), Advanced (look-ahead).");
        System.out.println("End Game: 4 winds rounds completed or player voluntary quit.\n");
    }

    // User premature leave replacement with CO
    public void leaveGamePrematurely() {
        if (currentGame != null && !isSinglePlayerMode) {
            System.out.println("[Client " + clientId + "] Player left game prematurely. Creating substitute CO...");
            currentGame.replacePlayerWithCO(localPlayer, preferences.getDefaultCOLevel());
            this.currentGame = null;
        }
    }

    // End current game
    public void endGame() {
        if (currentGame != null) {
            currentGame.terminateGame();
            System.out.println("[Client " + clientId + "] Game terminated. You can now quit or start/join a new game.");
        }
    }
}
