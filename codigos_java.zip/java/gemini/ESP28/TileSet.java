import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TileSet {
    public static List<Tile> createStandardTileSet() {
        List<Tile> tiles = new ArrayList<>(136);
        // Suited tiles: 4 sets of 1-9 for Bamboo, Characters, Dots
        for (int i = 0; i < 4; i++) {
            for (int rank = 1; rank <= 9; rank++) {
                tiles.add(new Tile(Suit.BAMBOO, rank));
                tiles.add(new Tile(Suit.CHARACTERS, rank));
                tiles.add(new Tile(Suit.DOTS, rank));
            }
            // Honor tiles: 4 copies of 4 Winds
            for (int w = 1; w <= 4; w++) {
                tiles.add(new Tile(Suit.WINDS, w));
            }
            // Honor tiles: 4 copies of 3 Dragons
            for (int d = 1; d <= 3; d++) {
                tiles.add(new Tile(Suit.DRAGONS, d));
            }
        }
        return tiles;
    }
}
