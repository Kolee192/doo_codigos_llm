public enum COStyle {
    DEFENSIVE,
    BALANCED,
    AGGRESSIVE
}
