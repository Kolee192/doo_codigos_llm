import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Meld implements Serializable {
    private static final long serialVersionUID = 1L;

    private final MeldType type;
    private final List<Tile> tiles;
    private final boolean concealed;

    public Meld(MeldType type, List<Tile> tiles, boolean concealed) {
        this.type = type;
        this.tiles = new ArrayList<>(tiles);
        Collections.sort(this.tiles);
        this.concealed = concealed;
    }

    public MeldType getType() {
        return type;
    }

    public List<Tile> getTiles() {
        return Collections.unmodifiableList(tiles);
    }

    public boolean isConcealed() {
        return concealed;
    }

    @Override
    public String toString() {
        return type + " " + tiles + (concealed ? " (Concealed)" : " (Exposed)");
    }
}
