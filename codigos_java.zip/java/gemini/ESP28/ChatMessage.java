import java.io.Serializable;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ChatMessage implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String sender;
    private final String message;
    private final String timestamp;

    public ChatMessage(String sender, String message) {
        this.sender = sender;
        this.message = message;
        this.timestamp = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }

    public String getSender() {
        return sender;
    }

    public String getMessage() {
        return message;
    }

    public String getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "[" + timestamp + "] " + sender + ": " + message;
    }
}
