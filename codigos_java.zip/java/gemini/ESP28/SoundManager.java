public class SoundManager {
    private boolean enabled;

    public SoundManager(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        System.out.println("[Audio System] Sound effects " + (enabled ? "ENABLED" : "DISABLED"));
    }

    public void playSound(String soundEffect) {
        if (!enabled) return;
        System.out.println("[Sound Effect] *Playing sound: " + soundEffect + "*");
    }
}
