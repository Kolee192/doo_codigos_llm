import java.io.Serializable;

public class Preferences implements Serializable {
    private static final long serialVersionUID = 1L;

    private String playerName;
    private String icon;
    private boolean soundEnabled;
    private COLevel defaultCOLevel;
    private RuleVariation defaultVariation;

    public Preferences() {
        this.playerName = "Player";
        this.icon = "Icon_Default.png";
        this.soundEnabled = true;
        this.defaultCOLevel = COLevel.BEGINNER;
        this.defaultVariation = RuleVariation.CLASSICAL_CHINESE;
    }

    public Preferences(String playerName, String icon, boolean soundEnabled, COLevel defaultCOLevel, RuleVariation defaultVariation) {
        this.playerName = playerName;
        this.icon = icon;
        this.soundEnabled = soundEnabled;
        this.defaultCOLevel = defaultCOLevel;
        this.defaultVariation = defaultVariation;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public boolean isSoundEnabled() {
        return soundEnabled;
    }

    public void setSoundEnabled(boolean soundEnabled) {
        this.soundEnabled = soundEnabled;
    }

    public COLevel getDefaultCOLevel() {
        return defaultCOLevel;
    }

    public void setDefaultCOLevel(COLevel defaultCOLevel) {
        this.defaultCOLevel = defaultCOLevel;
    }

    public RuleVariation getDefaultVariation() {
        return defaultVariation;
    }

    public void setDefaultVariation(RuleVariation defaultVariation) {
        this.defaultVariation = defaultVariation;
    }
}
