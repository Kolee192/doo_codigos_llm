import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("================================================================");
        System.out.println("          MultiMahjong System Specification Demo                ");
        System.out.println("================================================================\n");

        // 1. Initialise MultiMahjongServer on central IP node
        MultiMahjongServer server = new MultiMahjongServer("192.168.1.100");
        server.openAdminConsole();

        // 2. Initialise Clients
        MultiMahjongClient clientAlice = new MultiMahjongClient("client_01", server, false);
        clientAlice.updatePreferences("Alice", "Icon_Flower.png", true, COLevel.INTERMEDIATE, RuleVariation.CLASSICAL_CHINESE);
        clientAlice.uploadCustomImage("alice_avatar.jpg");

        MultiMahjongClient clientBob = new MultiMahjongClient("client_02", server, false);
        clientBob.updatePreferences("Bob", "Icon_Dragon.png", true, COLevel.ADVANCED, RuleVariation.CLASSICAL_CHINESE);

        // 3. Alice creates a 2-human multiplayer game (will support 2 COs)
        System.out.println("\n--- Step 1: Alice creates a multiplayer game ---");
        GameSession game = clientAlice.createMultiPlayerGame(2, 500, RuleVariation.CLASSICAL_CHINESE, COLevel.INTERMEDIATE);

        // Bob queries available games and joins
        System.out.println("\n--- Step 2: Bob lists available unstarted games & joins ---");
        List<GameSession> availableGames = clientBob.fetchAvailableGames();
        for (GameSession g : availableGames) {
            System.out.println("Found Game ID: " + g.getGameId() + " | Creator: " + g.getCreatorName() + " (" + g.getCreatorIcon() + ")"
                    + " | Needed Players: " + g.getRemainingPlayerSlots() + " | Score Limit: " + g.getScoreLimit());
        }
        clientBob.joinMultiPlayerGame(game.getGameId());

        // 4. In-Game Chat & Profile Change
        System.out.println("\n--- Step 3: Real-Time Chat & Profile Modification ---");
        clientAlice.sendChatMessage("Hello Bob, good luck in our Mahjong match!");
        clientBob.sendChatMessage("Thanks Alice! May the winds favor us.");
        clientAlice.printChatHistory();
        clientAlice.modifyProfileDuringGame("Alice_TheChampion", "Icon_MasterPhoenix.png");

        // 5. Start Game: Initialise Wall, Seatings, Tiles Deal
        System.out.println("\n--- Step 4: Game Initialisation & Starting Game ---");
        clientAlice.startMahjongGame();

        // 6. Demonstrate Turn Actions (Pick, Discard, Rule Checking)
        System.out.println("\n--- Step 5: Player Turns and Discard Action ---");
        Player currentTurnPlayer = game.getPlayers().get(game.getCurrentTurnIndex());
        System.out.println("Current turn belongs to: " + currentTurnPlayer.getName());

        if (currentTurnPlayer.getId().equals(clientAlice.getLocalPlayer().getId())) {
            Tile discardCandidate = clientAlice.getLocalPlayer().getHand().get(0);
            clientAlice.discardTile(discardCandidate);
        } else if (currentTurnPlayer.isComputer()) {
            clientAlice.processNextCOTurn();
        }

        // 7. Check Claim Evaluation (Chow, Pung, Kong, Mahjong)
        Tile sampleDiscard = new Tile(Suit.BAMBOO, 5);
        clientAlice.evaluatePlayerActionOptions(sampleDiscard);

        // 8. View High Scores & Online Documentation
        System.out.println("\n--- Step 6: Documentation and High Scores ---");
        clientAlice.openOnlineDocumentation();
        clientAlice.viewHighScores();

        // 9. Demonstrate Single Player Mode with Save & Undo
        System.out.println("\n--- Step 7: Single Player Mode (Save & Undo Capability) ---");
        MultiMahjongClient singlePlayerClient = new MultiMahjongClient("client_sp", server, true);
        singlePlayerClient.createSinglePlayerGame(300, RuleVariation.CLEARED_HAND, COLevel.BEGINNER);
        singlePlayerClient.startMahjongGame();

        System.out.println("Single player taking tile from wall...");
        Tile drawn = singlePlayerClient.pickUpTileFromWall();
        System.out.println("Performing single player Undo...");
        singlePlayerClient.undoLastMove();
        singlePlayerClient.saveSinglePlayerGame("sp_saved_game.dat");

        // 10. Demonstrate Premature Player Disconnect & CO Replacement
        System.out.println("\n--- Step 8: Bob leaves prematurely -> Replaced by Computer Opponent ---");
        clientBob.leaveGamePrematurely();
        System.out.println("Current players in Alice's game after Bob left:");
        for (Player p : game.getPlayers()) {
            System.out.println("  -> " + p);
        }

        // 11. End Game
        System.out.println("\n--- Step 9: Ending Game ---");
        clientAlice.endGame();

        System.out.println("\n================================================================");
        System.out.println("      MultiMahjong Specification Demo Executed Successfully     ");
        System.out.println("================================================================");
    }
}
