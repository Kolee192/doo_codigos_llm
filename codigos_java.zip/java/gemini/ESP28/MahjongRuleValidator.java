import java.util.*;

public class MahjongRuleValidator {

    public static boolean canPung(List<Tile> hand, Tile discard) {
        long count = hand.stream().filter(t -> t.equals(discard)).count();
        return count >= 2;
    }

    public static boolean canKong(List<Tile> hand, Tile discard) {
        long count = hand.stream().filter(t -> t.equals(discard)).count();
        return count >= 3;
    }

    public static boolean canChow(List<Tile> hand, Tile discard) {
        if (discard.isHonor()) {
            return false;
        }
        Suit s = discard.getSuit();
        int r = discard.getRank();

        boolean hasMinus2 = containsSuitRank(hand, s, r - 2);
        boolean hasMinus1 = containsSuitRank(hand, s, r - 1);
        boolean hasPlus1 = containsSuitRank(hand, s, r + 1);
        boolean hasPlus2 = containsSuitRank(hand, s, r + 2);

        // Pattern 1: [r-2, r-1, r]
        if (hasMinus2 && hasMinus1) return true;
        // Pattern 2: [r-1, r, r+1]
        if (hasMinus1 && hasPlus1) return true;
        // Pattern 3: [r, r+1, r+2]
        if (hasPlus1 && hasPlus2) return true;

        return false;
    }

    public static List<List<Tile>> getChowCombinations(List<Tile> hand, Tile discard) {
        List<List<Tile>> combos = new ArrayList<>();
        if (discard.isHonor()) return combos;

        Suit s = discard.getSuit();
        int r = discard.getRank();

        if (containsSuitRank(hand, s, r - 2) && containsSuitRank(hand, s, r - 1)) {
            combos.add(List.of(findTile(hand, s, r - 2), findTile(hand, s, r - 1), discard));
        }
        if (containsSuitRank(hand, s, r - 1) && containsSuitRank(hand, s, r + 1)) {
            combos.add(List.of(findTile(hand, s, r - 1), discard, findTile(hand, s, r + 1)));
        }
        if (containsSuitRank(hand, s, r + 1) && containsSuitRank(hand, s, r + 2)) {
            combos.add(List.of(discard, findTile(hand, s, r + 1), findTile(hand, s, r + 2)));
        }
        return combos;
    }

    private static boolean containsSuitRank(List<Tile> hand, Suit suit, int rank) {
        return hand.stream().anyMatch(t -> t.getSuit() == suit && t.getRank() == rank);
    }

    private static Tile findTile(List<Tile> hand, Suit suit, int rank) {
        return hand.stream().filter(t -> t.getSuit() == suit && t.getRank() == rank).findFirst().orElse(null);
    }

    public static boolean checkMahjong(List<Tile> handTiles, List<Meld> melds, Tile winningTile, RuleVariation variation) {
        List<Tile> fullHand = new ArrayList<>(handTiles);
        if (winningTile != null) {
            fullHand.add(winningTile);
        }
        Collections.sort(fullHand);

        // Mahjong requires 14 tiles equivalent: 4 melds + 1 pair
        // (melds count towards the 4 melds)
        int neededMelds = 4 - melds.size();
        if (fullHand.size() != neededMelds * 3 + 2) {
            return false;
        }

        if (variation == RuleVariation.CLEARED_HAND) {
            if (!isClearedHand(fullHand, melds)) {
                return false;
            }
        }

        return canFormMeldsAndPair(fullHand, neededMelds);
    }

    private static boolean isClearedHand(List<Tile> hand, List<Meld> melds) {
        // Cleared Hand (Flush/Half-flush or no honors): only 1 suit (+ optional honors)
        Suit primarySuit = null;
        for (Tile t : hand) {
            if (!t.isHonor()) {
                if (primarySuit == null) {
                    primarySuit = t.getSuit();
                } else if (primarySuit != t.getSuit()) {
                    return false;
                }
            }
        }
        for (Meld m : melds) {
            for (Tile t : m.getTiles()) {
                if (!t.isHonor()) {
                    if (primarySuit == null) {
                        primarySuit = t.getSuit();
                    } else if (primarySuit != t.getSuit()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private static boolean canFormMeldsAndPair(List<Tile> tiles, int neededMelds) {
        if (tiles.size() == 2) {
            return tiles.get(0).equals(tiles.get(1));
        }

        // Try every possible pair
        Set<Tile> checkedPairs = new HashSet<>();
        for (int i = 0; i < tiles.size() - 1; i++) {
            Tile t1 = tiles.get(i);
            Tile t2 = tiles.get(i + 1);
            if (t1.equals(t2) && !checkedPairs.contains(t1)) {
                checkedPairs.add(t1);
                List<Tile> remainder = new ArrayList<>(tiles);
                remainder.remove(t1);
                remainder.remove(t2);
                if (canFormMelds(remainder, neededMelds)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean canFormMelds(List<Tile> tiles, int meldsRemaining) {
        if (meldsRemaining == 0 && tiles.isEmpty()) {
            return true;
        }
        if (tiles.size() < 3) return false;

        Tile first = tiles.get(0);

        // Try Pung: 3 identical tiles
        long identicalCount = tiles.stream().filter(t -> t.equals(first)).count();
        if (identicalCount >= 3) {
            List<Tile> remainder = new ArrayList<>(tiles);
            remainder.remove(first);
            remainder.remove(first);
            remainder.remove(first);
            if (canFormMelds(remainder, meldsRemaining - 1)) {
                return true;
            }
        }

        // Try Chow: only for suited tiles
        if (!first.isHonor()) {
            Suit s = first.getSuit();
            int r = first.getRank();
            Tile second = findTile(tiles, s, r + 1);
            Tile third = findTile(tiles, s, r + 2);
            if (second != null && third != null) {
                List<Tile> remainder = new ArrayList<>(tiles);
                remainder.remove(first);
                remainder.remove(second);
                remainder.remove(third);
                if (canFormMelds(remainder, meldsRemaining - 1)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean isFishing(List<Tile> hand, List<Meld> melds, RuleVariation variation) {
        // Fishing (Ready hand / Tenpai): hand needs 1 tile to form Mahjong
        List<Tile> sampleTiles = TileSet.createStandardTileSet();
        Set<Tile> tested = new HashSet<>();
        for (Tile t : sampleTiles) {
            if (tested.add(t)) {
                if (checkMahjong(hand, melds, t, variation)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int calculateScore(List<Tile> hand, List<Meld> melds, Wind roundWind, Wind seatWind) {
        // Base Chinese score calculation
        int score = 20; // Base points for winning hand
        for (Meld m : melds) {
            if (m.getType() == MeldType.PUNG) {
                score += m.isConcealed() ? 8 : 4;
            } else if (m.getType() == MeldType.KONG) {
                score += m.isConcealed() ? 32 : 16;
            }
        }
        return Math.max(score, 20);
    }
}
