import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class GameSnapshot implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int gameId;
    private final int currentTurn;
    private final Wind roundWind;
    private final List<Tile> wall;
    private final List<Tile> userHand;
    private final List<Tile> discards;
    private final int scoreLimit;

    public GameSnapshot(int gameId, int currentTurn, Wind roundWind, List<Tile> wall, List<Tile> userHand, List<Tile> discards, int scoreLimit) {
        this.gameId = gameId;
        this.currentTurn = currentTurn;
        this.roundWind = roundWind;
        this.wall = new ArrayList<>(wall);
        this.userHand = new ArrayList<>(userHand);
        this.discards = new ArrayList<>(discards);
        this.scoreLimit = scoreLimit;
    }

    public int getGameId() {
        return gameId;
    }

    public int getCurrentTurn() {
        return currentTurn;
    }

    public Wind getRoundWind() {
        return roundWind;
    }

    public List<Tile> getWall() {
        return wall;
    }

    public List<Tile> getUserHand() {
        return userHand;
    }

    public List<Tile> getDiscards() {
        return discards;
    }

    public int getScoreLimit() {
        return scoreLimit;
    }
}
