public enum Suit {
    BAMBOO,
    CHARACTERS,
    DOTS,
    WINDS,
    DRAGONS
}
