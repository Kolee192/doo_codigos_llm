public enum COLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}
