public enum RuleVariation {
    CLASSICAL_CHINESE,
    CLEARED_HAND,
    JAPANESE_RIICHI
}
