import java.io.*;

public class PreferenceManager {
    public static void savePreferences(Preferences prefs, String filePath) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(prefs);
        } catch (IOException e) {
            System.err.println("Failed to save preferences: " + e.getMessage());
        }
    }

    public static Preferences loadPreferences(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            return new Preferences();
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (Preferences) ois.readObject();
        } catch (Exception e) {
            System.err.println("Failed to load preferences, using defaults: " + e.getMessage());
            return new Preferences();
        }
    }
}
