import java.io.Serializable;
import java.util.*;

public class GameSession implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int gameId;
    private final String creatorName;
    private final String creatorIcon;
    private final int scoreLimit;
    private final int totalHumanCapacity;
    private final RuleVariation ruleVariation;
    private COLevel defaultCOLevel;

    private final List<Player> players = new ArrayList<>();
    private final List<Tile> wall = new ArrayList<>();
    private final List<Tile> discards = new ArrayList<>();
    private int currentTurnIndex = 0;
    private Wind currentRoundWind = Wind.EAST;
    private int roundCount = 1;
    private boolean active = false;
    private boolean finished = false;
    private Tile lastDiscardedTile = null;
    private int lastDiscarderIndex = -1;

    public GameSession(int gameId, String creatorName, String creatorIcon, int scoreLimit, int totalHumans, RuleVariation variation, COLevel coLevel) {
        this.gameId = gameId;
        this.creatorName = creatorName;
        this.creatorIcon = creatorIcon;
        this.scoreLimit = scoreLimit;
        this.totalHumanCapacity = totalHumans;
        this.ruleVariation = variation;
        this.defaultCOLevel = coLevel;
    }

    public int getGameId() {
        return gameId;
    }

    public String getCreatorName() {
        return creatorName;
    }

    public String getCreatorIcon() {
        return creatorIcon;
    }

    public int getScoreLimit() {
        return scoreLimit;
    }

    public int getTotalHumanCapacity() {
        return totalHumanCapacity;
    }

    public RuleVariation getRuleVariation() {
        return ruleVariation;
    }

    public COLevel getDefaultCOLevel() {
        return defaultCOLevel;
    }

    public void setDefaultCOLevel(COLevel defaultCOLevel) {
        this.defaultCOLevel = defaultCOLevel;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public List<Tile> getWall() {
        return wall;
    }

    public List<Tile> getDiscards() {
        return discards;
    }

    public int getCurrentTurnIndex() {
        return currentTurnIndex;
    }

    public Wind getCurrentRoundWind() {
        return currentRoundWind;
    }

    public boolean isActive() {
        return active;
    }

    public boolean isFinished() {
        return finished;
    }

    public Tile getLastDiscardedTile() {
        return lastDiscardedTile;
    }

    public int getLastDiscarderIndex() {
        return lastDiscarderIndex;
    }

    public int getRemainingPlayerSlots() {
        long humanCount = players.stream().filter(p -> !p.isComputer()).count();
        return (int) Math.max(0, totalHumanCapacity - humanCount);
    }

    public synchronized boolean addPlayer(Player player) {
        if (players.size() >= 4) return false;
        players.add(player);
        return true;
    }

    public synchronized void startGame() {
        // Complete remaining spots with COs up to 4 players
        int coIndex = 1;
        while (players.size() < 4) {
            Player co = new Player("CO_" + coIndex, "Computer " + coIndex, "Icon_CO.png", true);
            co.setCoLevel(defaultCOLevel);
            players.add(co);
            coIndex++;
        }

        // Randomise seating position
        Collections.shuffle(players);
        Wind[] winds = Wind.values();
        for (int i = 0; i < 4; i++) {
            players.get(i).setSeatWind(winds[i]);
        }

        // Randomise tile order
        wall.clear();
        wall.addAll(TileSet.createStandardTileSet());
        Collections.shuffle(wall);

        // Deal tiles: 13 each, East (dealer) starts with 14
        for (Player p : players) {
            p.getHand().clear();
            p.getMelds().clear();
            for (int i = 0; i < 13; i++) {
                p.addTile(wall.remove(0));
            }
        }
        // East player picks up 1st tile (turn 0)
        currentTurnIndex = 0;
        players.get(0).addTile(wall.remove(0));

        active = true;
        finished = false;
    }

    public synchronized Tile drawTile(Player player) {
        if (wall.isEmpty()) {
            return null; // Wall depleted -> Draw
        }
        Tile drawn = wall.remove(0);
        player.addTile(drawn);
        return drawn;
    }

    public synchronized void discardTile(Player player, Tile tile) {
        player.removeTile(tile);
        discards.add(tile);
        lastDiscardedTile = tile;
        lastDiscarderIndex = players.indexOf(player);

        // Check if player is fishing
        boolean fishing = MahjongRuleValidator.isFishing(player.getHand(), player.getMelds(), ruleVariation);
        player.setFishing(fishing);

        // Advance turn clockwise
        currentTurnIndex = (currentTurnIndex + 1) % 4;
    }

    public synchronized void performMeld(Player claimant, Meld meld) {
        claimant.addMeld(meld);
        for (Tile t : meld.getTiles()) {
            claimant.removeTile(t);
        }
        currentTurnIndex = players.indexOf(claimant);
    }

    public synchronized void replacePlayerWithCO(Player humanPlayer, COLevel level) {
        int index = players.indexOf(humanPlayer);
        if (index >= 0) {
            Player co = new Player("CO_sub_" + System.currentTimeMillis(), "CO (sub for " + humanPlayer.getName() + ")", "Icon_CO.png", true);
            co.setSeatWind(humanPlayer.getSeatWind());
            co.setCoLevel(level);
            co.getHand().addAll(humanPlayer.getHand());
            co.getMelds().addAll(humanPlayer.getMelds());
            co.addScore(humanPlayer.getScore());
            co.setFishing(humanPlayer.isFishing());
            players.set(index, co);
        }
    }

    public synchronized void endRound(Player winner) {
        if (winner != null) {
            int score = MahjongRuleValidator.calculateScore(winner.getHand(), winner.getMelds(), currentRoundWind, winner.getSeatWind());
            winner.addScore(score);
        }
        roundCount++;
        if (roundCount > 4) {
            finished = true;
            active = false;
        } else {
            // Next round wind
            currentRoundWind = Wind.values()[(currentRoundWind.ordinal() + 1) % 4];
        }
    }

    public synchronized void terminateGame() {
        active = false;
        finished = true;
    }

    public GameSnapshot createSnapshot(Player userPlayer) {
        return new GameSnapshot(gameId, currentTurnIndex, currentRoundWind, wall, userPlayer.getHand(), discards, scoreLimit);
    }

    public void restoreSnapshot(Player userPlayer, GameSnapshot snapshot) {
        this.currentTurnIndex = snapshot.getCurrentTurnIndex();
        this.currentRoundWind = snapshot.getRoundWind();
        this.wall.clear();
        this.wall.addAll(snapshot.getWall());
        this.discards.clear();
        this.discards.addAll(snapshot.getDiscards());
        userPlayer.getHand().clear();
        userPlayer.getHand().addAll(snapshot.getUserHand());
        userPlayer.sortHand();
    }
}
