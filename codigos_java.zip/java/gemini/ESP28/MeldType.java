public enum MeldType {
    CHOW,
    PUNG,
    KONG
}
