import java.util.*;

public class ComputerOpponentAI {

    public static Tile chooseDiscard(Player co, List<Tile> discardedTiles, RuleVariation variation) {
        List<Tile> hand = co.getHand();
        if (hand.isEmpty()) return null;

        COLevel level = co.getCoLevel();
        COStyle style = co.getCoStyle();

        // Level 1: Beginner
        if (level == COLevel.BEGINNER) {
            // Discard isolated honor tiles first, then random
            for (Tile t : hand) {
                if (t.isHonor() && Collections.frequency(hand, t) == 1) {
                    return t;
                }
            }
            return hand.get(0);
        }

        // Level 2 & 3: Intermediate & Advanced with Look-ahead / Strategy
        // Rate tiles by utility to preserve pairs, partial sequences (Chows), etc.
        Map<Tile, Double> tileScores = new HashMap<>();

        for (Tile t : hand) {
            double score = 0.0;
            int count = Collections.frequency(hand, t);

            // Pair or triplet protection
            if (count >= 2) {
                score += count * 30.0;
            }

            // Chow potential
            if (!t.isHonor()) {
                Suit s = t.getSuit();
                int r = t.getRank();
                boolean neighbor1 = hand.stream().anyMatch(h -> h.getSuit() == s && Math.abs(h.getRank() - r) == 1);
                boolean neighbor2 = hand.stream().anyMatch(h -> h.getSuit() == s && Math.abs(h.getRank() - r) == 2);
                if (neighbor1) score += 20.0;
                if (neighbor2) score += 10.0;
            }

            // Advanced look-ahead: consider discarded tiles visibility
            if (level == COLevel.ADVANCED) {
                long seenInDiscards = discardedTiles.stream().filter(d -> d.equals(t)).count();
                // Fewer unseen tiles remaining makes forming sets harder
                score -= seenInDiscards * 5.0;

                // Adjust based on style
                if (style == COStyle.DEFENSIVE) {
                    // Favor keeping safe honor tiles if already discarded by others
                    if (seenInDiscards > 0) score += 15.0;
                } else if (style == COStyle.AGGRESSIVE) {
                    // Aggressive pushes for high suited sequences
                    if (!t.isHonor() && (t.getRank() >= 3 && t.getRank() <= 7)) {
                        score += 8.0;
                    }
                }
            }

            tileScores.put(t, score);
        }

        // Discard tile with lowest score
        Tile bestDiscard = hand.get(0);
        double minScore = Double.MAX_VALUE;
        for (Tile t : hand) {
            double s = tileScores.getOrDefault(t, 0.0);
            if (s < minScore) {
                minScore = s;
                bestDiscard = t;
            }
        }
        return bestDiscard;
    }

    public static boolean shouldClaimDiscard(Player co, Tile discard, MeldType claimType) {
        if (co.getCoLevel() == COLevel.BEGINNER) {
            return claimType == MeldType.PUNG || claimType == MeldType.KONG;
        }
        // Intermediate & Advanced prefer Pung/Kong or Chows if aggressive/balanced
        if (co.getCoStyle() == COStyle.DEFENSIVE && claimType == MeldType.CHOW) {
            return false; // Defensive prefers closed hand
        }
        return true;
    }
}
