import java.io.Serializable;
import java.util.Objects;

public class Tile implements Comparable<Tile>, Serializable {
    private static final long serialVersionUID = 1L;

    private final Suit suit;
    private final int rank; // 1-9 for bamboo/characters/dots; 1-4 for East/South/West/North; 1-3 for Red/Green/White
    private final String name;

    public Tile(Suit suit, int rank) {
        this.suit = suit;
        this.rank = rank;
        this.name = buildName(suit, rank);
    }

    private static String buildName(Suit suit, int rank) {
        return switch (suit) {
            case BAMBOO -> rank + " Bamboo";
            case CHARACTERS -> rank + " Character";
            case DOTS -> rank + " Dot";
            case WINDS -> switch (rank) {
                case 1 -> "East Wind";
                case 2 -> "South Wind";
                case 3 -> "West Wind";
                case 4 -> "North Wind";
                default -> "Unknown Wind";
            };
            case DRAGONS -> switch (rank) {
                case 1 -> "Red Dragon";
                case 2 -> "Green Dragon";
                case 3 -> "White Dragon";
                default -> "Unknown Dragon";
            };
        };
    }

    public Suit getSuit() {
        return suit;
    }

    public int getRank() {
        return rank;
    }

    public String getName() {
        return name;
    }

    public boolean isHonor() {
        return suit == Suit.WINDS || suit == Suit.DRAGONS;
    }

    @Override
    public int compareTo(Tile o) {
        if (this.suit != o.suit) {
            return this.suit.compareTo(o.suit);
        }
        return Integer.compare(this.rank, o.rank);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Tile tile)) return false;
        return rank == tile.rank && suit == tile.suit;
    }

    @Override
    public int hashCode() {
        return Objects.hash(suit, rank);
    }

    @Override
    public String toString() {
        return "[" + name + "]";
    }
}
