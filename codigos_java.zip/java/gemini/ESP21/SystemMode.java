public enum SystemMode {
    NORMAL_INTERACTIVE,
    ELECTION_MODE
}
