import java.util.ArrayList;
import java.util.List;

public class Candidate extends User {
    private final String candidateName;
    private final String party;
    private final String region;
    private boolean activated;
    private String cv;
    private final List<String> promises;
    private final List<CandidateQuestion> questions;

    public Candidate(String userId, String password, String candidateName, String party, String region) {
        super(userId, password, UserRole.CANDIDATE);
        this.candidateName = candidateName;
        this.party = party;
        this.region = region;
        this.activated = false;
        this.cv = "";
        this.promises = new ArrayList<>();
        this.questions = new ArrayList<>();
    }

    public String getCandidateName() {
        return candidateName;
    }

    public String getParty() {
        return party;
    }

    public String getRegion() {
        return region;
    }

    public boolean isActivated() {
        return activated;
    }

    public void setActivated(boolean activated) {
        this.activated = activated;
    }

    public String getCv() {
        return cv;
    }

    public void setCv(String cv) {
        this.cv = cv;
    }

    public List<String> getPromises() {
        return new ArrayList<>(promises);
    }

    public void addPromise(String promise) {
        if (promise != null && !promise.trim().isEmpty()) {
            this.promises.add(promise);
        }
    }

    public void editPromise(int index, String newPromise) {
        if (index >= 0 && index < promises.size()) {
            promises.set(index, newPromise);
        }
    }

    public List<CandidateQuestion> getQuestions() {
        return questions;
    }

    public void addQuestion(CandidateQuestion question) {
        this.questions.add(question);
    }
}
