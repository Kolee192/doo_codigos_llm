import java.util.HashMap;
import java.util.Map;

public class ElectionCenterStation {
    private final String stationId;
    private final String region;
    private boolean systemOpen;
    private final Map<String, String> activeVotingTokens; // Voter TCK -> One-time Hash Token
    private int offlineVotesMarkedCount;

    public ElectionCenterStation(String stationId, String region) {
        this.stationId = stationId;
        this.region = region;
        this.systemOpen = false;
        this.activeVotingTokens = new HashMap<>();
        this.offlineVotesMarkedCount = 0;
    }

    public String getStationId() {
        return stationId;
    }

    public String getRegion() {
        return region;
    }

    public boolean isSystemOpen() {
        return systemOpen;
    }

    public void setSystemOpen(boolean systemOpen) {
        this.systemOpen = systemOpen;
    }

    public void issueVotingPasswordToken(String tck, String token) {
        activeVotingTokens.put(tck, token);
    }

    public boolean consumeVotingToken(String tck, String token) {
        if (activeVotingTokens.containsKey(tck) && activeVotingTokens.get(tck).equals(token)) {
            activeVotingTokens.remove(tck);
            return true;
        }
        return false;
    }

    public void incrementOfflineCount() {
        offlineVotesMarkedCount++;
    }

    public int getOfflineVotesMarkedCount() {
        return offlineVotesMarkedCount;
    }
}
