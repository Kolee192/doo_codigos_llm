import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("   ONEV - Online National Election Voting System ");
        System.out.println("=================================================\n");

        OnevElectionSystem system = new OnevElectionSystem("2025");

        // Set up Election Center Station
        ElectionCenterStation station1 = new ElectionCenterStation("STATION-001", "Ankara");
        system.registerStation(station1);

        // Pre-create ECA and ESS users
        ECA eca = new ECA("eca_admin", "Admin123", "Supreme Election Council");
        ESS ess = new ESS("ess_01", "EssPass456", "11122233344", "STATION-001");
        system.registerUserDirectly(eca);
        system.registerUserDirectly(ess);

        // -----------------------------------------------------------------
        // PHASE 1: NORMAL INTERACTIVE MODE
        // -----------------------------------------------------------------
        System.out.println("--- PHASE 1: Normal Interactive Mode ---");

        // 1. Voter Registration Application
        OperationResult regRes = system.registerVoterApplication(
                "12345678901",
                "Ali Yilmaz",
                "Cankaya, Ankara",
                "Ankara",
                "photo_ref_ali.png"
        );
        System.out.println("Voter Application: " + regRes);
        String appId = (String) regRes.getPayload();

        // 2. ECA Log In & Approve Applicant
        system.login("eca_admin", "Admin123");
        OperationResult approveRes = system.approveVoterApplicant(appId, true, "STATION-001");
        System.out.println("ECA Approval: " + approveRes);
        Voter voterAli = (Voter) approveRes.getPayload();

        // 3. ECA creates Candidate Account
        OperationResult candRes = system.openCandidateAccount("Ayse Kaya", "Justice & Peace Party", "Ankara");
        System.out.println("Candidate Account Creation: " + candRes);
        Candidate candidateAyse = (Candidate) candRes.getPayload();
        candidateAyse.setPassword("CandPass789"); // Candidate custom password

        // ECA updates voters with official roster check
        system.addOfficialRosterRecord(new OfficialVoterRecord("12345678901", "Ali Yilmaz", "Cankaya, Ankara", "Ankara", true));
        OperationResult updateRosterRes = system.updateRegisteredVotersWithOfficialRoster();
        System.out.println("Roster Synchronization: " + updateRosterRes);

        system.logout();

        // 4. Candidate Logs In, edits CV and Promises
        system.login(candidateAyse.getUserId(), "CandPass789");
        system.activateCandidateProfile(candidateAyse.getUserId());
        system.editCV("Graduated in Political Science. 15 years in public administration.");
        system.addPromise("Modernize digital public transport and education infrastructure.");
        system.logout();

        // 5. Voter Ali logs in, views candidate, and asks a question
        system.login(voterAli.getUserId(), voterAli.getPassword());
        OperationResult viewRes = system.viewCandidateInformation(candidateAyse.getUserId());
        System.out.println("Voter Viewing Candidate: " + viewRes);
        OperationResult questionRes = system.askCandidateQuestion(candidateAyse.getUserId(), "What is your environmental policy for our region?");
        System.out.println("Voter Question: " + questionRes);
        system.logout();

        // 6. Candidate answers question
        system.login(candidateAyse.getUserId(), "CandPass789");
        CandidateQuestion q = candidateAyse.getQuestions().get(0);
        OperationResult answerRes = system.answerQuestion(q.getQuestionId(), "We will plant 100,000 trees and subsidize solar panels.");
        System.out.println("Candidate Answer: " + answerRes);
        system.logout();

        // -----------------------------------------------------------------
        // PHASE 2: ELECTION MODE (ELECTION DAY)
        // -----------------------------------------------------------------
        System.out.println("\n--- PHASE 2: Election Mode (Election Day) ---");

        // 1. ESS opens the system at Station-001
        OperationResult openRes = system.openSystemAtStation("11122233344", "ess_01", "EssPass456");
        System.out.println("Open Station System: " + openRes);

        // 2. ESS generates one-time voting token for Voter Ali (wants online vote)
        OperationResult tokenRes = system.markVotedAndGeneratePassword("STATION-001", "12345678901", true);
        System.out.println("ESS Generate Online Hash Token: " + tokenRes);
        String hashToken = (String) tokenRes.getPayload();

        // 3. Voter Ali casts vote online
        OperationResult voteRes = system.castVoteOnline(
                voterAli.getVin(),
                voterAli.getPassword(),
                hashToken,
                "STATION-001",
                candidateAyse.getUserId()
        );
        System.out.println("Online Vote Polling: " + voteRes);

        // Register a second voter who chooses to vote offline
        Voter voterMehmet = new Voter("VOTER-OFFLINE", "Pass123", "98765432100", "Mehmet Demir", "Kecioren, Ankara", "Ankara", "VIN-OFFLINE", "STATION-001");
        system.registerUserDirectly(voterMehmet);

        // 4. ESS marks Mehmet as Offline Voted
        OperationResult offlineMarkRes = system.markVotedAndGeneratePassword("STATION-001", "98765432100", false);
        System.out.println("ESS Offline Voting Mark: " + offlineMarkRes);

        // 5. ESS enters offline voting counts after polls close
        Map<String, Integer> offlineTallies = new HashMap<>();
        offlineTallies.put(candidateAyse.getUserId(), 1);

        OperationResult enterOfflineRes = system.enterOfflineVotes("ess_01", "EssPass456", offlineTallies);
        System.out.println("ESS Enter Offline Votes: " + enterOfflineRes);

        // 6. View Election Results
        System.out.println("\n--- Election Results ---");
        Map<String, Integer> finalResults = system.viewElectionResults("2025", "Ankara", "");
        finalResults.forEach((key, count) -> System.out.println(key + " -> " + count + " votes"));
    }
}
