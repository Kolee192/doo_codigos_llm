import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

public class BallotVote {
    private final String electionYear;
    private final String region;
    private final String candidateId;
    private final String partyName;
    private final boolean offline;
    private final String voteSecurityHash;

    public BallotVote(String electionYear, String region, String candidateId, String partyName, boolean offline, long timestamp) {
        this.electionYear = electionYear;
        this.region = region;
        this.candidateId = candidateId;
        this.partyName = partyName;
        this.offline = offline;
        this.voteSecurityHash = computeHash(electionYear + ":" + region + ":" + candidateId + ":" + partyName + ":" + timestamp);
    }

    private String computeHash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encoded = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : encoded) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            return String.valueOf(input.hashCode());
        }
    }

    public String getElectionYear() {
        return electionYear;
    }

    public String getRegion() {
        return region;
    }

    public String getCandidateId() {
        return candidateId;
    }

    public String getPartyName() {
        return partyName;
    }

    public boolean isOffline() {
        return offline;
    }

    public String getVoteSecurityHash() {
        return voteSecurityHash;
    }
}
