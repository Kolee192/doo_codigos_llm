public class OperationResult {
    private final boolean success;
    private final String message;
    private final Object payload;

    public OperationResult(boolean success, String message) {
        this(success, message, null);
    }

    public OperationResult(boolean success, String message, Object payload) {
        this.success = success;
        this.message = message;
        this.payload = payload;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public Object getPayload() {
        return payload;
    }

    @Override
    public String toString() {
        return "[" + (success ? "SUCCESS" : "ERROR") + "] " + message;
    }
}
