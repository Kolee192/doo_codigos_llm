public class SystemSession {
    private final String sessionId;
    private final User currentUser;
    private final long createdAt;

    public SystemSession(String sessionId, User currentUser) {
        this.sessionId = sessionId;
        this.currentUser = currentUser;
        this.createdAt = System.currentTimeMillis();
    }

    public String getSessionId() {
        return sessionId;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public long getCreatedAt() {
        return createdAt;
    }
}
