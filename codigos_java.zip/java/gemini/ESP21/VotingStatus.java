public enum VotingStatus {
    NOT_VOTED,
    ONLINE_VOTED,
    OFFLINE_VOTED
}
