public class CandidateQuestion {
    private final String questionId;
    private final String voterId;
    private final String questionText;
    private String answerText;
    private boolean answered;

    public CandidateQuestion(String questionId, String voterId, String questionText) {
        this.questionId = questionId;
        this.voterId = voterId;
        this.questionText = questionText;
        this.answerText = null;
        this.answered = false;
    }

    public String getQuestionId() {
        return questionId;
    }

    public String getVoterId() {
        return voterId;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getAnswerText() {
        return answerText;
    }

    public boolean isAnswered() {
        return answered;
    }

    public void answer(String answer) {
        this.answerText = answer;
        this.answered = true;
    }
}
