public class OfficialVoterRecord {
    private final String tck;
    private final String fullName;
    private final String officialAddress;
    private final String region;
    private final boolean eligible;

    public OfficialVoterRecord(String tck, String fullName, String officialAddress, String region, boolean eligible) {
        this.tck = tck;
        this.fullName = fullName;
        this.officialAddress = officialAddress;
        this.region = region;
        this.eligible = eligible;
    }

    public String getTck() {
        return tck;
    }

    public String getFullName() {
        return fullName;
    }

    public String getOfficialAddress() {
        return officialAddress;
    }

    public String getRegion() {
        return region;
    }

    public boolean isEligible() {
        return eligible;
    }
}
