public class ESS extends User {
    private final String tck;
    private final String stationId;

    public ESS(String userId, String password, String tck, String stationId) {
        super(userId, password, UserRole.ESS);
        this.tck = tck;
        this.stationId = stationId;
    }

    public String getTck() {
        return tck;
    }

    public String getStationId() {
        return stationId;
    }
}
