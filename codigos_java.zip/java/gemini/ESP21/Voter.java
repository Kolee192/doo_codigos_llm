public class Voter extends User {
    private final String tck;
    private String fullName;
    private String address;
    private String region;
    private final String vin; // Voter Identification Number / VIC
    private String stationId;
    private VotingStatus votingStatus;

    public Voter(String userId, String password, String tck, String fullName, String address, String region, String vin, String stationId) {
        super(userId, password, UserRole.VOTER);
        this.tck = tck;
        this.fullName = fullName;
        this.address = address;
        this.region = region;
        this.vin = vin;
        this.stationId = stationId;
        this.votingStatus = VotingStatus.NOT_VOTED;
    }

    public String getTck() {
        return tck;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getVin() {
        return vin;
    }

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }

    public VotingStatus getVotingStatus() {
        return votingStatus;
    }

    public void setVotingStatus(VotingStatus votingStatus) {
        this.votingStatus = votingStatus;
    }
}
