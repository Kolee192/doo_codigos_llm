public class VoterApplication {
    private final String applicationId;
    private final String tck;
    private final String fullName;
    private final String address;
    private final String region;
    private final String pictureRef;
    private boolean approved;

    public VoterApplication(String applicationId, String tck, String fullName, String address, String region, String pictureRef) {
        this.applicationId = applicationId;
        this.tck = tck;
        this.fullName = fullName;
        this.address = address;
        this.region = region;
        this.pictureRef = pictureRef;
        this.approved = false;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getTck() {
        return tck;
    }

    public String getFullName() {
        return fullName;
    }

    public String getAddress() {
        return address;
    }

    public String getRegion() {
        return region;
    }

    public String getPictureRef() {
        return pictureRef;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }
}
