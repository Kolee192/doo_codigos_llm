public class ECA extends User {
    private final String authorityName;

    public ECA(String userId, String password, String authorityName) {
        super(userId, password, UserRole.ECA);
        this.authorityName = authorityName;
    }

    public String getAuthorityName() {
        return authorityName;
    }
}
