public enum UserRole {
    VOTER,
    CANDIDATE,
    ECA,
    ESS
}
