import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class RepositoryService {
    private final Map<String, User> users = new HashMap<>();
    private final Map<String, RepositoryItem> items = new HashMap<>();
    private final Map<String, RepositoryCollection> collections = new HashMap<>();
    private final List<ReleaseCalendarEvent> releaseCalendar = new ArrayList<>();
    private final Set<String> controlledSubjects = new TreeSet<>();
    private final NotificationService notificationService = new NotificationService();
    private final ExternalSystemSyncService syncService = new ExternalSystemSyncService();
    private final InstitutionalSuccessionPlan successionPlan;
    private final List<String> techSupportTickets = new ArrayList<>();
    private final List<String> workflowReminders = new ArrayList<>();

    public RepositoryService() {
        this.successionPlan = new InstitutionalSuccessionPlan("CORNELL-PLAN-001", "Cornell University", "HathiTrust Digital Library");
        initStandardSubjects();
    }

    private void initStandardSubjects() {
        controlledSubjects.add("Agricultural and Life Sciences");
        controlledSubjects.add("Law and Legal Scholarship");
        controlledSubjects.add("Applied Economics and Management");
        controlledSubjects.add("Computer and Information Science");
        controlledSubjects.add("Engineering and Applied Physics");
        controlledSubjects.add("Rural and Community Sociology");
    }

    // Security & Auth
    public void registerUser(User user) { users.put(user.getUserId(), user); }
    public User getUser(String userId) { return users.get(userId); }
    public User login(String username, String password) {
        return users.values().stream()
                .filter(u -> u.getUsername().equalsIgnoreCase(username) && u.getPassword().equals(password) && u.isActive())
                .findFirst().orElse(null);
    }
    public User loginViaShibboleth(String eppn) {
        return users.values().stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(eppn) && u.isCornellAffiliated())
                .findFirst().orElse(null);
    }

    // Collection Management
    public RepositoryCollection createCollection(String id, String name, String description, String ownerId) {
        RepositoryCollection c = new RepositoryCollection(id, name, description, ownerId);
        collections.put(id, c);
        return c;
    }
    public RepositoryCollection getCollection(String id) { return collections.get(id); }
    public void renameCollection(String id, String newName) {
        RepositoryCollection c = collections.get(id);
        if (c != null) c.setName(newName);
    }
    public void moveCollection(String id, String newParentCollectionId) {
        RepositoryCollection c = collections.get(id);
        if (c != null) c.setParentCollectionId(newParentCollectionId);
    }

    // Item Management
    public RepositoryItem depositItem(RepositoryItem item, String targetCollectionId, User depositor) {
        items.put(item.getItemId(), item);
        if (targetCollectionId != null && collections.containsKey(targetCollectionId)) {
            collections.get(targetCollectionId).addItem(item.getItemId());
            item.assignCollection(targetCollectionId);
        }
        item.addRevision("Initial Deposit", "Item deposited into repository by " + depositor.getFullName(), depositor);
        syncService.syncWithSymplecticElements(item);
        syncService.syncWithActivityInsight(item);

        if (item.isSubscribable()) {
            notificationService.notifySubscribers(item.getItemId(), item.getPrimaryTitle(), "New content deposited: " + item.getPrimaryTitle());
            if (targetCollectionId != null) {
                notificationService.notifySubscribers(targetCollectionId, item.getPrimaryTitle(), "New content added to collection " + targetCollectionId);
            }
        }
        return item;
    }

    public void mapItemToCollection(String itemId, String targetCollectionId) {
        RepositoryItem it = items.get(itemId);
        RepositoryCollection col = collections.get(targetCollectionId);
        if (it != null && col != null) {
            col.addItem(itemId);
            it.assignCollection(targetCollectionId);
        }
    }

    public void markItemErrorHidden(String itemId, String reason, User admin) {
        RepositoryItem item = items.get(itemId);
        if (item != null) {
            item.setStatus(ItemStatus.FLAGGED_ERROR_HIDDEN);
            item.setSubscribable(false);
            item.addRevision("Marked Error / Hidden", reason, admin);
        }
    }

    public void unpublishItemByAgency(String itemId, String reason, User admin) {
        RepositoryItem item = items.get(itemId);
        if (item != null) {
            item.setStatus(ItemStatus.UNPUBLISHED_BY_AGENCY);
            item.addRevision("Unpublished per agency request", reason, admin);
        }
    }

    // Access control evaluation
    public boolean canUserAccessItem(User user, RepositoryItem item) {
        if (item.getStatus() == ItemStatus.FLAGGED_ERROR_HIDDEN || item.getStatus() == ItemStatus.UNPUBLISHED_BY_AGENCY) {
            return user != null && (user.hasRole(UserRole.DB_IR_ADMINISTRATOR) || user.hasRole(UserRole.LIBRARY_STAFF));
        }
        if (item.isEmbargoActive()) {
            return user != null && (user.hasRole(UserRole.DB_IR_ADMINISTRATOR) || user.hasRole(UserRole.LIBRARY_STAFF) || item.getAuthors().contains(user.getFullName()));
        }
        if (item.getAccessLevel() == AccessLevel.PUBLIC) return true;
        if (item.getAccessLevel() == AccessLevel.CAMPUS_ONLY) {
            return user != null && user.isCornellAffiliated();
        }
        if (item.getAccessLevel() == AccessLevel.INTERNAL_GROUP) {
            return user != null;
        }
        return false;
    }

    // View & Download Actions
    public RepositoryItem viewItem(String itemId, User user) {
        RepositoryItem it = items.get(itemId);
        if (it != null && canUserAccessItem(user, it)) {
            it.recordView();
            return it;
        }
        return null;
    }

    public FileAsset downloadFile(String itemId, String fileId, User user) {
        RepositoryItem it = viewItem(itemId, user);
        if (it != null) {
            for (ItemVersion ver : it.getVersions()) {
                for (FileAsset fa : ver.getFiles()) {
                    if (fa.getFileId().equals(fileId)) {
                        it.recordDownload();
                        // Notify author if faculty
                        for (User u : users.values()) {
                            if (it.getAuthors().contains(u.getFullName()) && u.hasRole(UserRole.FACULTY)) {
                                notificationService.notifyAuthorDownload(u.getEmail(), it.getPrimaryTitle(), (user != null ? user.getFullName() : "Anonymous patron"));
                            }
                        }
                        return fa;
                    }
                }
            }
        }
        return null;
    }

    // Search and Browsing
    public List<RepositoryItem> searchKeyword(String query, String collectionFilter, String subjectFilter) {
        String q = query == null ? "" : query.toLowerCase();
        return items.values().stream()
                .filter(it -> it.getStatus() == ItemStatus.PUBLISHED || it.getStatus() == ItemStatus.HISTORICAL_ARCHIVED)
                .filter(it -> collectionFilter == null || it.getCollectionIds().contains(collectionFilter))
                .filter(it -> subjectFilter == null || subjectFilter.equalsIgnoreCase(it.getSubjectArea()))
                .filter(it -> it.getPrimaryTitle().toLowerCase().contains(q)
                        || (it.getDescription() != null && it.getDescription().toLowerCase().contains(q))
                        || it.getKeywords().stream().anyMatch(k -> k.toLowerCase().contains(q))
                        || it.getHistoricalNames().stream().anyMatch(hn -> hn.toLowerCase().contains(q))
                        || it.getAuthors().stream().anyMatch(a -> a.toLowerCase().contains(q)))
                .collect(Collectors.toList());
    }

    public List<RepositoryItem> searchByAuthorName(String authorQuery) {
        String aq = authorQuery.toLowerCase();
        return items.values().stream()
                .filter(it -> it.getAuthors().stream().anyMatch(a -> a.toLowerCase().contains(aq)))
                .sorted(Comparator.comparing(RepositoryItem::getDateCreated))
                .collect(Collectors.toList());
    }

    public List<RepositoryItem> searchDissertationsByCommitteeMember(String facultyName) {
        String fn = facultyName.toLowerCase();
        return items.values().stream()
                .filter(it -> it.getDocumentType() == DocumentType.DISSERTATION_THESIS)
                .filter(it -> it.getThesisCommitteeMembers().stream().anyMatch(m -> m.toLowerCase().contains(fn)))
                .collect(Collectors.toList());
    }

    public List<RepositoryItem> getItemsInCollectionSorted(String collectionId) {
        RepositoryCollection c = collections.get(collectionId);
        if (c == null) return Collections.emptyList();
        List<RepositoryItem> list = c.getItemIds().stream().map(items::get).filter(Objects::nonNull).collect(Collectors.toList());
        switch (c.getSortOrder()) {
            case TITLE_ASC -> list.sort(Comparator.comparing(RepositoryItem::getPrimaryTitle));
            case DATE_ASC -> list.sort(Comparator.comparing(RepositoryItem::getDateCreated));
            case DATE_DESC -> list.sort(Comparator.comparing(RepositoryItem::getDateCreated).reversed());
            case AUTHOR_ASC -> list.sort(Comparator.comparing(i -> i.getAuthors().isEmpty() ? "" : i.getAuthors().get(0)));
            case CUSTOM_ORDER -> list.sort(Comparator.comparingInt(i -> c.getCustomRank(i.getItemId())));
        }
        return list;
    }

    // OAI-PMH Harvest Simulation
    public String exportOaiPmhMetadataXml(String sinceDateIso) {
        StringBuilder sb = new StringBuilder();
        sb.append("<OAI-PMH xmlns=\"http://www.openarchives.org/OAI/2.0/\">\n");
        sb.append("  <responseDate>").append(LocalDate.now()).append("</responseDate>\n");
        sb.append("  <ListRecords>\n");
        for (RepositoryItem it : items.values()) {
            sb.append("    <record>\n");
            sb.append("      <header><identifier>oai:cornell.edu:").append(it.getItemId()).append("</identifier></header>\n");
            sb.append("      <metadata>\n");
            sb.append("        <dc:title>").append(it.getPrimaryTitle()).append("</dc:title>\n");
            sb.append("        <dc:creator>").append(String.join("; ", it.getAuthors())).append("</dc:creator>\n");
            sb.append("        <dc:subject>").append(it.getSubjectArea()).append("</dc:subject>\n");
            sb.append("        <dc:rights>").append(it.getLicenseType().getDisplayName()).append("</dc:rights>\n");
            sb.append("        <dc:identifier>").append(it.getPersistentHandleUrl()).append("</dc:identifier>\n");
            sb.append("      </metadata>\n");
            sb.append("    </record>\n");
        }
        sb.append("  </ListRecords>\n");
        sb.append("</OAI-PMH>");
        return sb.toString();
    }

    // Google Discovery Metadata Generator
    public String generateGoogleScholarMetaTags(String itemId) {
        RepositoryItem it = items.get(itemId);
        if (it == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append("<meta name=\"citation_title\" content=\"").append(it.getPrimaryTitle()).append("\">\n");
        for (String a : it.getAuthors()) {
            sb.append("<meta name=\"citation_author\" content=\"").append(a).append("\">\n");
        }
        sb.append("<meta name=\"citation_publication_date\" content=\"").append(it.getDateCreated().toLocalDate()).append("\">\n");
        sb.append("<meta name=\"citation_pdf_url\" content=\"").append(it.getPersistentHandleUrl()).append("/download.pdf\">\n");
        return sb.toString();
    }

    // Release Calendar
    public void addCalendarEvent(ReleaseCalendarEvent evt) { releaseCalendar.add(evt); }
    public List<ReleaseCalendarEvent> getReleaseCalendar() { return Collections.unmodifiableList(releaseCalendar); }
    public String exportCalendarIcs() {
        StringBuilder sb = new StringBuilder("BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Cornell IR//Calendar//EN\n");
        for (ReleaseCalendarEvent e : releaseCalendar) {
            sb.append(e.toIcsFormat());
        }
        sb.append("END:VCALENDAR\n");
        return sb.toString();
    }

    // Tech Support & Reminders
    public void submitTechSupportTicket(String patronEmail, String issueDescription) {
        String ticket = "TICKET [" + UUID.randomUUID() + "] From: " + patronEmail + " | Issue: " + issueDescription;
        techSupportTickets.add(ticket);
    }
    public void addWorkflowReminder(String reminder) { workflowReminders.add(reminder); }
    public List<String> getWorkflowReminders() { return workflowReminders; }

    // Controlled Vocabularies
    public void addSubjectClassification(String subject) { controlledSubjects.add(subject); }
    public Set<String> getControlledSubjects() { return Collections.unmodifiableSet(controlledSubjects); }

    // Succession / Asset Management
    public InstitutionalSuccessionPlan getSuccessionPlan() { return successionPlan; }
    public NotificationService getNotificationService() { return notificationService; }
    public ExternalSystemSyncService getSyncService() { return syncService; }
    public Map<String, RepositoryItem> getAllItems() { return Collections.unmodifiableMap(items); }
    public Map<String, User> getAllUsers() { return Collections.unmodifiableMap(users); }
}
