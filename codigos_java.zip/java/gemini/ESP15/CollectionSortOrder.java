public enum CollectionSortOrder {
    TITLE_ASC,
    DATE_DESC,
    DATE_ASC,
    AUTHOR_ASC,
    CUSTOM_ORDER
}
