import java.util.*;

public class NotificationService {
    // Subscriber Email -> Subscribed Item / Collection / Author IDs
    private final Map<String, Set<String>> patronSubscriptions = new HashMap<>();
    private final List<String> sentEmailLog = new ArrayList<>();

    public void subscribe(String email, String subscriptionTargetId) {
        patronSubscriptions.computeIfAbsent(email, k -> new HashSet<>()).add(subscriptionTargetId);
    }

    public void unsubscribe(String email, String subscriptionTargetId) {
        if (patronSubscriptions.containsKey(email)) {
            patronSubscriptions.get(email).remove(subscriptionTargetId);
        }
    }

    public Set<String> getSubscriptionsForEmail(String email) {
        return patronSubscriptions.getOrDefault(email, Collections.emptySet());
    }

    public List<String> getSubscribersForTarget(String targetId) {
        List<String> subscribers = new ArrayList<>();
        for (Map.Entry<String, Set<String>> entry : patronSubscriptions.entrySet()) {
            if (entry.getValue().contains(targetId)) {
                subscribers.add(entry.getKey());
            }
        }
        return subscribers;
    }

    public void notifySubscribers(String targetId, String itemTitle, String message) {
        List<String> subscribers = getSubscribersForTarget(targetId);
        for (String email : subscribers) {
            String record = "EMAIL TO [" + email + "] Regarding [" + itemTitle + "]: " + message;
            sentEmailLog.add(record);
        }
    }

    public void notifyAuthorDownload(String authorEmail, String itemTitle, String downloaderInfo) {
        String notice = "DOWNLOAD NOTICE TO [" + authorEmail + "]: Your item '" + itemTitle + "' was downloaded by " + downloaderInfo;
        sentEmailLog.add(notice);
    }

    public List<String> getSentEmailLog() {
        return Collections.unmodifiableList(sentEmailLog);
    }
}
