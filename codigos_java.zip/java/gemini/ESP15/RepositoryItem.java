import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class RepositoryItem {
    private final String itemId;
    private final String persistentHandleUrl;
    private String primaryTitle;
    private final List<String> historicalNames = new ArrayList<>();
    private String description;
    private final List<String> authors = new ArrayList<>();
    private final List<String> authorOrcids = new ArrayList<>();
    private final List<String> thesisCommitteeMembers = new ArrayList<>();
    private DocumentType documentType;
    private ItemStatus status;
    private AccessLevel accessLevel;
    private LicenseType licenseType;
    private String associatedPublicationDoi;
    private String primaryDoi;
    private boolean subscribable = true;
    private String subjectArea;
    private String releaseFrequency;
    private final Set<String> keywords = new HashSet<>();
    private final Set<String> tags = new HashSet<>();
    private final Map<String, String> customMetadata = new HashMap<>();
    private final List<ItemVersion> versions = new ArrayList<>();
    private final List<RevisionRecord> auditTrail = new ArrayList<>();
    private final Set<String> collectionIds = new HashSet<>();
    private final Set<String> seeAlsoItemIds = new HashSet<>();
    private LocalDate embargoUntilDate = null;
    private LocalDate retentionScheduleEndDate = null;
    private final LocalDateTime dateCreated;
    private LocalDateTime dateUpdated;
    private String geographicRegion;
    private double geographicLatitude;
    private double geographicLongitude;
    private int intellectualValueRating = 3; // Scale 1-5 for collection assessment

    // Analytics
    private int viewCount = 0;
    private int downloadCount = 0;
    private int altmetricScore = 0;

    public RepositoryItem(String itemId, String primaryTitle, DocumentType documentType, String primaryAuthor, String authorOrcid) {
        this.itemId = itemId;
        this.persistentHandleUrl = "https://hdl.handle.net/1813/" + itemId;
        this.primaryTitle = primaryTitle;
        this.historicalNames.add(primaryTitle);
        this.documentType = documentType;
        this.authors.add(primaryAuthor);
        if (authorOrcid != null) this.authorOrcids.add(authorOrcid);
        this.status = ItemStatus.PUBLISHED;
        this.accessLevel = AccessLevel.PUBLIC;
        this.licenseType = LicenseType.CC_BY;
        this.dateCreated = LocalDateTime.now();
        this.dateUpdated = LocalDateTime.now();
    }

    public void changeTitle(String newTitle, String reason, User modifier) {
        this.historicalNames.add(this.primaryTitle);
        this.primaryTitle = newTitle;
        this.dateUpdated = LocalDateTime.now();
        addRevision("Title change", "Renamed to: " + newTitle + ". Reason: " + reason, modifier);
    }

    public void addRevision(String reason, String summary, User modifier) {
        int vNum = versions.size() + 1;
        RevisionRecord rec = new RevisionRecord(UUID.randomUUID().toString(), vNum, modifier.getUserId(), modifier.getFullName(), reason, summary);
        this.auditTrail.add(rec);
    }

    public void addVersion(ItemVersion v, User modifier, String reason) {
        this.versions.add(v);
        this.dateUpdated = LocalDateTime.now();
        addRevision(reason, "Uploaded version " + v.getVersionNumber(), modifier);
    }

    public String generateCitation() {
        String authorList = String.join(", ", authors);
        int year = dateCreated.getYear();
        return String.format("%s (%d). \"%s\". Cornell University Institutional Repository. DOI/Handle: %s. License: %s.",
                authorList, year, primaryTitle, (primaryDoi != null ? primaryDoi : persistentHandleUrl), licenseType.getDisplayName());
    }

    public boolean isEmbargoActive() {
        return embargoUntilDate != null && LocalDate.now().isBefore(embargoUntilDate);
    }

    public void applyEmbargo(LocalDate untilDate, User user) {
        this.embargoUntilDate = untilDate;
        this.status = ItemStatus.EMBARGOED;
        addRevision("Embargo applied", "Access embargo set until: " + untilDate, user);
    }

    public void liftEmbargo(User user) {
        this.embargoUntilDate = null;
        this.status = ItemStatus.PUBLISHED;
        addRevision("Embargo lifted", "Access embargo removed", user);
    }

    public void recordView() { this.viewCount++; this.altmetricScore += 1; }
    public void recordDownload() { this.downloadCount++; this.altmetricScore += 3; }

    // Getters and Setters
    public String getItemId() { return itemId; }
    public String getPersistentHandleUrl() { return persistentHandleUrl; }
    public String getPrimaryTitle() { return primaryTitle; }
    public void setPrimaryTitle(String primaryTitle) { this.primaryTitle = primaryTitle; }
    public List<String> getHistoricalNames() { return Collections.unmodifiableList(historicalNames); }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<String> getAuthors() { return authors; }
    public void addAuthor(String author) { this.authors.add(author); }
    public List<String> getAuthorOrcids() { return authorOrcids; }
    public void addAuthorOrcid(String orcid) { this.authorOrcids.add(orcid); }
    public List<String> getThesisCommitteeMembers() { return thesisCommitteeMembers; }
    public void addThesisCommitteeMember(String memberName) { this.thesisCommitteeMembers.add(memberName); }
    public DocumentType getDocumentType() { return documentType; }
    public void setDocumentType(DocumentType documentType) { this.documentType = documentType; }
    public ItemStatus getStatus() { return status; }
    public void setStatus(ItemStatus status) { this.status = status; }
    public AccessLevel getAccessLevel() { return accessLevel; }
    public void setAccessLevel(AccessLevel accessLevel) { this.accessLevel = accessLevel; }
    public LicenseType getLicenseType() { return licenseType; }
    public void setLicenseType(LicenseType licenseType) { this.licenseType = licenseType; }
    public String getAssociatedPublicationDoi() { return associatedPublicationDoi; }
    public void setAssociatedPublicationDoi(String associatedPublicationDoi) { this.associatedPublicationDoi = associatedPublicationDoi; }
    public String getPrimaryDoi() { return primaryDoi; }
    public void setPrimaryDoi(String primaryDoi) { this.primaryDoi = primaryDoi; }
    public boolean isSubscribable() { return subscribable; }
    public void setSubscribable(boolean subscribable) { this.subscribable = subscribable; }
    public String getSubjectArea() { return subjectArea; }
    public void setSubjectArea(String subjectArea) { this.subjectArea = subjectArea; }
    public String getReleaseFrequency() { return releaseFrequency; }
    public void setReleaseFrequency(String releaseFrequency) { this.releaseFrequency = releaseFrequency; }
    public Set<String> getKeywords() { return keywords; }
    public Set<String> getTags() { return tags; }
    public Map<String, String> getCustomMetadata() { return customMetadata; }
    public List<ItemVersion> getVersions() { return Collections.unmodifiableList(versions); }
    public List<RevisionRecord> getAuditTrail() { return Collections.unmodifiableList(auditTrail); }
    public Set<String> getCollectionIds() { return collectionIds; }
    public void assignCollection(String colId) { this.collectionIds.add(colId); }
    public void removeCollection(String colId) { this.collectionIds.remove(colId); }
    public Set<String> getSeeAlsoItemIds() { return seeAlsoItemIds; }
    public void addSeeAlsoItem(String id) { this.seeAlsoItemIds.add(id); }
    public LocalDate getEmbargoUntilDate() { return embargoUntilDate; }
    public LocalDate getRetentionScheduleEndDate() { return retentionScheduleEndDate; }
    public void setRetentionScheduleEndDate(LocalDate retentionScheduleEndDate) { this.retentionScheduleEndDate = retentionScheduleEndDate; }
    public LocalDateTime getDateCreated() { return dateCreated; }
    public LocalDateTime getDateUpdated() { return dateUpdated; }
    public String getGeographicRegion() { return geographicRegion; }
    public void setGeographicRegion(String geographicRegion) { this.geographicRegion = geographicRegion; }
    public double getGeographicLatitude() { return geographicLatitude; }
    public void setGeographicCoordinates(double lat, double lon) { this.geographicLatitude = lat; this.geographicLongitude = lon; }
    public double getGeographicLongitude() { return geographicLongitude; }
    public int getIntellectualValueRating() { return intellectualValueRating; }
    public void setIntellectualValueRating(int val) { this.intellectualValueRating = val; }
    public int getViewCount() { return viewCount; }
    public int getDownloadCount() { return downloadCount; }
    public int getAltmetricScore() { return altmetricScore; }
}
