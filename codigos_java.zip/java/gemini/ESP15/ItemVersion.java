import java.time.LocalDateTime;
import java.util.*;

public class ItemVersion {
    private final int versionNumber;
    private final LocalDateTime createdDate;
    private final String title;
    private final String description;
    private final List<FileAsset> files = new ArrayList<>();
    private final Map<String, String> metadata = new HashMap<>();

    public ItemVersion(int versionNumber, String title, String description) {
        this.versionNumber = versionNumber;
        this.createdDate = LocalDateTime.now();
        this.title = title;
        this.description = description;
    }

    public int getVersionNumber() { return versionNumber; }
    public LocalDateTime getCreatedDate() { return createdDate; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public List<FileAsset> getFiles() { return Collections.unmodifiableList(files); }
    public void addFile(FileAsset asset) { files.add(asset); }
    public Map<String, String> getMetadata() { return metadata; }
}
