import java.time.LocalDate;
import java.util.*;

public class InstitutionalSuccessionPlan {
    private final String planId;
    private final String governingInstitution;
    private String designatedSuccessor;
    private LocalDate lastReviewDate;
    private final List<String> contractClauses = new ArrayList<>();
    private boolean activeEndowmentFundingCommitted = true;

    public InstitutionalSuccessionPlan(String planId, String governingInstitution, String designatedSuccessor) {
        this.planId = planId;
        this.governingInstitution = governingInstitution;
        this.designatedSuccessor = designatedSuccessor;
        this.lastReviewDate = LocalDate.now();
        this.contractClauses.add("Perpetual access guarantee through Ivy Plus / HathiTrust partnership.");
        this.contractClauses.add("Automatic repository transfer clause upon cessation of Cornell IR operations.");
    }

    public String getPlanId() { return planId; }
    public String getGoverningInstitution() { return governingInstitution; }
    public String getDesignatedSuccessor() { return designatedSuccessor; }
    public void setDesignatedSuccessor(String successor) { this.designatedSuccessor = successor; }
    public LocalDate getLastReviewDate() { return lastReviewDate; }
    public void refreshReview() { this.lastReviewDate = LocalDate.now(); }
    public List<String> getContractClauses() { return contractClauses; }
    public void addClause(String clause) { this.contractClauses.add(clause); }
    public boolean isActiveEndowmentFundingCommitted() { return activeEndowmentFundingCommitted; }
    public void setActiveEndowmentFundingCommitted(boolean committed) { this.activeEndowmentFundingCommitted = committed; }
}
