import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        RepositoryService repo = new RepositoryService();

        // 1. Create Users with multiple roles
        User fac1 = new User("usr_fac_01", "cfaculty", "faculty@cornell.edu", "pass123", "Prof. Jane Cornell", "Dept of Agriculture", "0000-0002-1825-0097", true);
        fac1.addRole(UserRole.FACULTY);
        repo.registerUser(fac1);

        User libStaff = new User("usr_lib_01", "mlibrarian", "librarian@cornell.edu", "libPass!", "Marcus Librarian", "Mann Library", null, true);
        libStaff.addRole(UserRole.LIBRARY_STAFF);
        repo.registerUser(libStaff);

        User admin = new User("usr_adm_01", "admin1", "admin@cornell.edu", "adminSecret", "Alice Administrator", "IR Administration", null, true);
        admin.addRole(UserRole.DB_IR_ADMINISTRATOR);
        repo.registerUser(admin);

        User patron = new User("usr_pat_01", "jpatron", "researcher@nonprofit.org", "patron123", "David Patron", "Rural Policy Institute", null, false);
        patron.addRole(UserRole.PATRON);
        repo.registerUser(patron);

        User student = new User("usr_stu_01", "astudent", "student@cornell.edu", "gradPass", "Sarah Student", "Law School", null, true);
        student.addRole(UserRole.STUDENT);
        repo.registerUser(student);

        // 2. Remote Shibboleth login demonstration
        User shibSession = repo.loginViaShibboleth("faculty@cornell.edu");
        System.out.println("Shibboleth SSO Auth Success: " + (shibSession != null && shibSession.isCornellAffiliated()));

        // 3. Create Branded Collections
        RepositoryCollection cceCol = repo.createCollection("col_cce", "Cornell Cooperative Extension Publications", "Extension resources for NYS educators and communities", fac1.getUserId());
        cceCol.setBranding("CCE - Knowledge for Real Life Impact", "https://cornell.edu/branding/cce.png");
        cceCol.addCustomFieldDefinition("NYS_Target_County");

        RepositoryCollection lawCol = repo.createCollection("col_law", "Cornell Law School Legal Archives", "Scholarship and historic judicial theses", libStaff.getUserId());
        lawCol.setRareOrArchival(true);

        // 4. Deposit Items with DOIs, multi-format attachments (including historic Lotus Works format)
        RepositoryItem dataItem = new RepositoryItem("item_dat_001", "NYS Soil Organic Matter Survey 2010-2023", DocumentType.SINGLE_TOPIC_DATASET, fac1.getFullName(), fac1.getOrcid());
        dataItem.setSubjectArea("Agricultural and Life Sciences");
        dataItem.setLicenseType(LicenseType.CC_BY);
        dataItem.setPrimaryDoi("10.5061/dryad.cornell01");
        dataItem.setAssociatedPublicationDoi("10.1016/j.agee.2023.108543");
        dataItem.getKeywords().addAll(Arrays.asList("soil", "carbon", "NYS", "agriculture"));
        dataItem.setGeographicCoordinates(42.4440, -76.5019);
        dataItem.setGeographicRegion("Tompkins County, NY");

        ItemVersion v1 = new ItemVersion(1, "NYS Soil Survey v1", "Initial baseline survey");
        byte[] lotusFileContent = "LOTUS_WORKS_V2.0_DATA_TABLE_DUMP".getBytes(StandardCharsets.UTF_8);
        FileAsset lotusAsset = new FileAsset("f_001", "soildata_historic.123", "application/vnd.lotus-1-2-3", lotusFileContent.length, lotusFileContent, false, "10.5061/dryad.cornell01/file1");
        v1.addFile(lotusAsset);
        dataItem.addVersion(v1, fac1, "Initial survey dataset deposit");

        repo.depositItem(dataItem, cceCol.getCollectionId(), fac1);

        // 5. Versioning demonstration & Dataset Name Change Tracking
        dataItem.changeTitle("NYS Soil Organic & Nitrogen Survey 2010-2024", "Expanded survey scope to include nitrogen", admin);
        ItemVersion v2 = new ItemVersion(2, "NYS Soil Survey v2", "Updated dataset with 2024 additions");
        byte[] csvData = "location,lat,lon,organic_matter,nitrogen\nIthaca,42.44,-76.50,4.2,0.18".getBytes(StandardCharsets.UTF_8);
        v2.addFile(new FileAsset("f_002", "soil_nitrogen_2024.csv", "text/csv", csvData.length, csvData, false, "10.5061/dryad.cornell01/file2"));
        dataItem.addVersion(v2, fac1, "Added 2024 data");

        // 6. Historic Dissertations and Committee Member Discovery
        RepositoryItem thesisItem = new RepositoryItem("item_th_001", "Constitutional Limits on Executive Emergency Powers", DocumentType.DISSERTATION_THESIS, "Hon. Marcus LegalThinker", "0000-0001-9988-7711");
        thesisItem.setSubjectArea("Law and Legal Scholarship");
        thesisItem.addThesisCommitteeMember("Prof. Jane Cornell");
        thesisItem.applyEmbargo(LocalDate.now().plusMonths(6), libStaff);
        repo.depositItem(thesisItem, lawCol.getCollectionId(), libStaff);

        // 7. Subscriptions & Email notifications for releases
        repo.getNotificationService().subscribe(patron.getEmail(), dataItem.getItemId());
        repo.getNotificationService().subscribe(patron.getEmail(), cceCol.getCollectionId());

        // 8. DB/IR Admin Release Calendar & ICS export
        repo.addCalendarEvent(new ReleaseCalendarEvent("cal_01", "USDA NYS Crop & Soil Outlook", "Agricultural and Life Sciences", LocalDate.now().plusDays(14), "Quarterly", "USDA-ERS"));
        String icsFeed = repo.exportCalendarIcs();

        // 9. Searching by historical titles & keyword
        List<RepositoryItem> searchByHistoricTitle = repo.searchKeyword("Soil Organic Matter Survey", null, null);
        List<RepositoryItem> committeeTheses = repo.searchDissertationsByCommitteeMember("Prof. Jane Cornell");

        // 10. Digital Preservation Integrity Check & Self-Healing Replica Simulation
        lotusAsset.simulateCorruptionOnNode("Replica-Lockss-Preservation");
        boolean preservedOk = lotusAsset.verifyIntegrityAndFix();

        // 11. Custom Ordering within Collection
        cceCol.setSortOrder(CollectionSortOrder.CUSTOM_ORDER);
        cceCol.setCustomRank(dataItem.getItemId(), 1);
        List<RepositoryItem> sortedItems = repo.getItemsInCollectionSorted(cceCol.getCollectionId());

        // 12. Direct student link & Citation Generation
        String directHandleLink = dataItem.getPersistentHandleUrl();
        String formattedCitation = dataItem.generateCitation();

        // 13. File Download & Author Notification
        FileAsset downloaded = repo.downloadFile(dataItem.getItemId(), "f_002", patron);

        // 14. OAI-PMH Harvesting Output
        String oaiHarvestXml = repo.exportOaiPmhMetadataXml(LocalDate.now().minusDays(1).toString());

        // 15. Google Scholar Indexing Tags
        String googleMetaTags = repo.generateGoogleScholarMetaTags(dataItem.getItemId());

        // 16. Technical Support Ticket Submission
        repo.submitTechSupportTicket(patron.getEmail(), "Inquiry about bulk downloading large GIS layers");

        // Print Demo Summary
        System.out.println("\n=== CORNELL UNIVERSITY DIGITAL REPOSITORY DEMO ===");
        System.out.println("Persistent Handle URL: " + directHandleLink);
        System.out.println("Formatted Cut-and-Paste Citation:\n  " + formattedCitation);
        System.out.println("\nHistorical Name Search Matches: " + searchByHistoricTitle.size() + " (" + searchByHistoricTitle.get(0).getPrimaryTitle() + ")");
        System.out.println("Dissertations Directed by Prof. Cornell: " + committeeTheses.size() + " (" + committeeTheses.get(0).getPrimaryTitle() + " - Embargoed: " + committeeTheses.get(0).isEmbargoActive() + ")");
        System.out.println("Bit-Level Preservation Self-Healing Check: " + (!preservedOk ? "CORRUPTION DETECTED & AUTOMATICALLY RESTORED FROM GOLDEN COPY" : "ALL REPLICAS IN SYNC"));
        System.out.println("Symplectic Sync Count: " + repo.getSyncService().getSyncedElementsRecords().size());
        System.out.println("Activity Insight Sync Count: " + repo.getSyncService().getSyncedActivityInsightRecords().size());
        System.out.println("Sent Notification Emails: " + repo.getNotificationService().getSentEmailLog().size());
        for (String log : repo.getNotificationService().getSentEmailLog()) {
            System.out.println("  " + log);
        }
        System.out.println("\nSuccession Plan Destination: " + repo.getSuccessionPlan().getDesignatedSuccessor());
        System.out.println("Demo completed successfully.");
    }
}
