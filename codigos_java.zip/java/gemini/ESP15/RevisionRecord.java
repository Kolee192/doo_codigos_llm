import java.time.LocalDateTime;

public class RevisionRecord {
    private final String revisionId;
    private final int version;
    private final String modifiedByUserId;
    private final String modifiedByUserName;
    private final LocalDateTime timestamp;
    private final String reason;
    private final String summaryOfChanges;

    public RevisionRecord(String revisionId, int version, String modifiedByUserId, String modifiedByUserName, String reason, String summaryOfChanges) {
        this.revisionId = revisionId;
        this.version = version;
        this.modifiedByUserId = modifiedByUserId;
        this.modifiedByUserName = modifiedByUserName;
        this.timestamp = LocalDateTime.now();
        this.reason = reason;
        this.summaryOfChanges = summaryOfChanges;
    }

    public String getRevisionId() { return revisionId; }
    public int getVersion() { return version; }
    public String getModifiedByUserId() { return modifiedByUserId; }
    public String getModifiedByUserName() { return modifiedByUserName; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getReason() { return reason; }
    public String getSummaryOfChanges() { return summaryOfChanges; }

    @Override
    public String toString() {
        return String.format("[Rev v%d on %s by %s] Reason: %s | Changes: %s",
                version, timestamp, modifiedByUserName, reason, summaryOfChanges);
    }
}
