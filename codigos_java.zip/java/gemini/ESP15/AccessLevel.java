public enum AccessLevel {
    PUBLIC,
    CAMPUS_ONLY,
    INTERNAL_GROUP,
    PRIVATE
}
