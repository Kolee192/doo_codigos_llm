import java.util.*;

public class User {
    private final String userId;
    private String username;
    private String email;
    private String password;
    private String fullName;
    private String department;
    private String orcid;
    private final Set<UserRole> roles = new HashSet<>();
    private boolean cornellAffiliated;
    private boolean active = true;

    public User(String userId, String username, String email, String password, String fullName, String department, String orcid, boolean cornellAffiliated) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.department = department;
        this.orcid = orcid;
        this.cornellAffiliated = cornellAffiliated;
    }

    public String getUserId() { return userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getOrcid() { return orcid; }
    public void setOrcid(String orcid) { this.orcid = orcid; }
    public Set<UserRole> getRoles() { return Collections.unmodifiableSet(roles); }
    public void addRole(UserRole role) { this.roles.add(role); }
    public void removeRole(UserRole role) { this.roles.remove(role); }
    public boolean hasRole(UserRole role) { return this.roles.contains(role); }
    public boolean isCornellAffiliated() { return cornellAffiliated; }
    public void setCornellAffiliated(boolean cornellAffiliated) { this.cornellAffiliated = cornellAffiliated; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    @Override
    public String toString() {
        return fullName + " <" + email + "> [" + roles + "]";
    }
}
