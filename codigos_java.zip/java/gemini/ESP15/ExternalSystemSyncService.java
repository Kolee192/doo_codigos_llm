import java.util.*;

public class ExternalSystemSyncService {
    private final List<String> syncedElementsRecords = new ArrayList<>();
    private final List<String> syncedActivityInsightRecords = new ArrayList<>();

    public void syncWithSymplecticElements(RepositoryItem item) {
        String record = "SYMPLECTIC_SYNC: Item=" + item.getItemId() + ", Authors=" + item.getAuthors() + ", Title=" + item.getPrimaryTitle();
        syncedElementsRecords.add(record);
    }

    public void syncWithActivityInsight(RepositoryItem item) {
        String record = "ACTIVITY_INSIGHT_SYNC: Item=" + item.getItemId() + ", Authors=" + item.getAuthors() + ", Title=" + item.getPrimaryTitle();
        syncedActivityInsightRecords.add(record);
    }

    public List<String> getSyncedElementsRecords() { return syncedElementsRecords; }
    public List<String> getSyncedActivityInsightRecords() { return syncedActivityInsightRecords; }
}
