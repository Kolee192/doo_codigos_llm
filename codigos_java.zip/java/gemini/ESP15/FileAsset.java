import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

public class FileAsset {
    private final String fileId;
    private final String filename;
    private final String mimeType;
    private final long sizeBytes;
    private final boolean streamingMedia;
    private final String doi;
    private final Map<String, byte[]> storageReplicas = new HashMap<>(); // Node -> Content
    private String verifiedChecksum;
    private final Map<String, String> technicalMetadata = new HashMap<>();

    public FileAsset(String fileId, String filename, String mimeType, long sizeBytes, byte[] content, boolean streamingMedia, String doi) {
        this.fileId = fileId;
        this.filename = filename;
        this.mimeType = mimeType;
        this.sizeBytes = sizeBytes;
        this.streamingMedia = streamingMedia;
        this.doi = doi;
        this.verifiedChecksum = calculateChecksum(content);
        // Redundant replication across distinct storage locations
        storageReplicas.put("Primary-Cornell-IR", Arrays.copyOf(content, content.length));
        storageReplicas.put("Replica-Lockss-Preservation", Arrays.copyOf(content, content.length));
        storageReplicas.put("Replica-Geographic-Secondary", Arrays.copyOf(content, content.length));
    }

    private String calculateChecksum(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(data);
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    public boolean verifyIntegrityAndFix() {
        boolean allGood = true;
        byte[] goldenMaster = null;
        for (Map.Entry<String, byte[]> entry : storageReplicas.entrySet()) {
            String check = calculateChecksum(entry.getValue());
            if (check.equals(verifiedChecksum)) {
                goldenMaster = entry.getValue();
            } else {
                allGood = false;
            }
        }
        if (!allGood && goldenMaster != null) {
            // Restore corrupted replicas from golden master
            for (String key : new ArrayList<>(storageReplicas.keySet())) {
                storageReplicas.put(key, Arrays.copyOf(goldenMaster, goldenMaster.length));
            }
            return false; // had corruption, but restored
        }
        return allGood;
    }

    public void simulateCorruptionOnNode(String nodeName) {
        if (storageReplicas.containsKey(nodeName)) {
            byte[] corrupted = new byte[] {0, 1, 2, 3};
            storageReplicas.put(nodeName, corrupted);
        }
    }

    public byte[] retrieveContent() {
        return storageReplicas.get("Primary-Cornell-IR");
    }

    public String getFileId() { return fileId; }
    public String getFilename() { return filename; }
    public String getMimeType() { return mimeType; }
    public long getSizeBytes() { return sizeBytes; }
    public boolean isStreamingMedia() { return streamingMedia; }
    public String getDoi() { return doi; }
    public String getVerifiedChecksum() { return verifiedChecksum; }
    public Map<String, String> getTechnicalMetadata() { return technicalMetadata; }
    public void addTechnicalMetadata(String key, String value) { technicalMetadata.put(key, value); }
}
