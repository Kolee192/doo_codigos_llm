import java.time.LocalDate;

public class ReleaseCalendarEvent {
    private final String eventId;
    private final String reportTitle;
    private final String subjectArea;
    private final LocalDate scheduledReleaseDate;
    private final String frequency;
    private final String responsibleAgency;

    public ReleaseCalendarEvent(String eventId, String reportTitle, String subjectArea, LocalDate scheduledReleaseDate, String frequency, String responsibleAgency) {
        this.eventId = eventId;
        this.reportTitle = reportTitle;
        this.subjectArea = subjectArea;
        this.scheduledReleaseDate = scheduledReleaseDate;
        this.frequency = frequency;
        this.responsibleAgency = responsibleAgency;
    }

    public String getEventId() { return eventId; }
    public String getReportTitle() { return reportTitle; }
    public String getSubjectArea() { return subjectArea; }
    public LocalDate getScheduledReleaseDate() { return scheduledReleaseDate; }
    public String getFrequency() { return frequency; }
    public String getResponsibleAgency() { return responsibleAgency; }

    public String toIcsFormat() {
        return "BEGIN:VEVENT\n" +
                "UID:" + eventId + "@cornell.edu\n" +
                "SUMMARY:Release: " + reportTitle + "\n" +
                "DESCRIPTION:Subject: " + subjectArea + " | Agency: " + responsibleAgency + "\n" +
                "DTSTART;VALUE=DATE:" + scheduledReleaseDate.toString().replace("-", "") + "\n" +
                "END:VEVENT\n";
    }

    @Override
    public String toString() {
        return String.format("[%s] %s (Subject: %s, Agency: %s, Freq: %s)",
                scheduledReleaseDate, reportTitle, subjectArea, responsibleAgency, frequency);
    }
}
