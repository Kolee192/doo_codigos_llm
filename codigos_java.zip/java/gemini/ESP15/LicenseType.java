public enum LicenseType {
    ALL_RIGHTS_RESERVED("All Rights Reserved", "No reuse without explicit permission."),
    CC_BY("Creative Commons Attribution (CC-BY 4.0)", "Allows distribution, remixing, tweaking, and building upon work, even commercially, as long as credited."),
    CC0("Creative Commons Zero (CC0 1.0)", "Public Domain Dedication - no rights reserved worldwide."),
    OPEN_GOVERNMENT("Open Government License", "Reuse public sector information freely."),
    CUSTOM("Custom Institutional License", "Institutional reuse governed by specific agreement.");

    private final String displayName;
    private final String description;

    LicenseType(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }
}
