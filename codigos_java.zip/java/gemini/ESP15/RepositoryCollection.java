import java.util.*;

public class RepositoryCollection {
    private final String collectionId;
    private String name;
    private String description;
    private String brandingHeader;
    private String logoUrl;
    private String parentCollectionId;
    private boolean rareOrArchival;
    private CollectionSortOrder sortOrder = CollectionSortOrder.DATE_DESC;
    private final Set<String> itemIds = new LinkedHashSet<>();
    private final Map<String, Integer> customOrderRanks = new HashMap<>();
    private final Set<String> customFieldDefinitions = new HashSet<>();
    private String ownerUserId;

    public RepositoryCollection(String collectionId, String name, String description, String ownerUserId) {
        this.collectionId = collectionId;
        this.name = name;
        this.description = description;
        this.ownerUserId = ownerUserId;
    }

    public void addItem(String itemId) {
        itemIds.add(itemId);
    }

    public void removeItem(String itemId) {
        itemIds.remove(itemId);
        customOrderRanks.remove(itemId);
    }

    public void setCustomRank(String itemId, int rank) {
        customOrderRanks.put(itemId, rank);
    }

    public Integer getCustomRank(String itemId) {
        return customOrderRanks.getOrDefault(itemId, 9999);
    }

    public String getCollectionId() { return collectionId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getBrandingHeader() { return brandingHeader; }
    public void setBranding(String header, String logo) { this.brandingHeader = header; this.logoUrl = logo; }
    public String getLogoUrl() { return logoUrl; }
    public String getParentCollectionId() { return parentCollectionId; }
    public void setParentCollectionId(String parentCollectionId) { this.parentCollectionId = parentCollectionId; }
    public boolean isRareOrArchival() { return rareOrArchival; }
    public void setRareOrArchival(boolean rareOrArchival) { this.rareOrArchival = rareOrArchival; }
    public CollectionSortOrder getSortOrder() { return sortOrder; }
    public void setSortOrder(CollectionSortOrder sortOrder) { this.sortOrder = sortOrder; }
    public Set<String> getItemIds() { return Collections.unmodifiableSet(itemIds); }
    public Set<String> getCustomFieldDefinitions() { return customFieldDefinitions; }
    public void addCustomFieldDefinition(String fieldName) { this.customFieldDefinitions.add(fieldName); }
    public String getOwnerUserId() { return ownerUserId; }
    public void setOwnerUserId(String ownerUserId) { this.ownerUserId = ownerUserId; }
}
