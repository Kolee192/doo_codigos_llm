public enum OwnerVerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED
}
