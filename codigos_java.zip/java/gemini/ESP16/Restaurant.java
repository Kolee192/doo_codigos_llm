import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Restaurant {
    private String id;
    private String name;
    private String address;
    private String email;
    private String phone;
    private String mobilePhone;
    private double averagePrice;
    private String description;
    private String restaurantType;
    private String pictureUrl;
    private String websiteUrl;
    private double latitude;
    private double longitude;
    private final List<Dish> menu = new ArrayList<>();

    public Restaurant(String id, String name, String address, String email, String phone, double averagePrice) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.email = email;
        this.phone = phone;
        this.averagePrice = averagePrice;
        this.description = "";
        this.restaurantType = "General";
        this.pictureUrl = "default_picture.png";
        this.websiteUrl = "https://example.com/" + id;
        this.latitude = 0.0;
        this.longitude = 0.0;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public double getAveragePrice() {
        return averagePrice;
    }

    public void setAveragePrice(double averagePrice) {
        this.averagePrice = averagePrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRestaurantType() {
        return restaurantType;
    }

    public void setRestaurantType(String restaurantType) {
        this.restaurantType = restaurantType;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public List<Dish> getMenu() {
        return Collections.unmodifiableList(menu);
    }

    public void addDish(Dish dish) {
        menu.add(dish);
    }

    public void removeDish(Dish dish) {
        menu.remove(dish);
    }

    public void clearMenu() {
        menu.clear();
    }
}
