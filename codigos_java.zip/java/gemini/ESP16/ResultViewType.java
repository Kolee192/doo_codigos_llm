public enum ResultViewType {
    MAP,
    LIST
}
