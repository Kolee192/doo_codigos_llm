public class SearchCriteria {
    private Integer minPrice;
    private Integer maxPrice;
    private Integer minDistanceKm;
    private Integer maxDistanceKm;
    private String restaurantType;
    private String specificDish;
    private String freeText;
    private boolean searchByPriceExplicit;

    public SearchCriteria() {
        this.minDistanceKm = 0;
        this.maxDistanceKm = 10;
        this.searchByPriceExplicit = false;
    }

    public Integer getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(Integer minPrice) {
        this.minPrice = minPrice;
        if (minPrice != null) {
            this.searchByPriceExplicit = true;
        }
    }

    public Integer getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(Integer maxPrice) {
        this.maxPrice = maxPrice;
        if (maxPrice != null) {
            this.searchByPriceExplicit = true;
        }
    }

    public Integer getMinDistanceKm() {
        return minDistanceKm;
    }

    public void setMinDistanceKm(Integer minDistanceKm) {
        this.minDistanceKm = minDistanceKm;
    }

    public Integer getMaxDistanceKm() {
        return maxDistanceKm;
    }

    public void setMaxDistanceKm(Integer maxDistanceKm) {
        this.maxDistanceKm = maxDistanceKm;
    }

    public String getRestaurantType() {
        return restaurantType;
    }

    public void setRestaurantType(String restaurantType) {
        this.restaurantType = restaurantType;
    }

    public String getSpecificDish() {
        return specificDish;
    }

    public void setSpecificDish(String specificDish) {
        this.specificDish = specificDish;
    }

    public String getFreeText() {
        return freeText;
    }

    public void setFreeText(String freeText) {
        this.freeText = freeText;
    }

    public boolean isSearchByPriceExplicit() {
        return searchByPriceExplicit;
    }

    public void setSearchByPriceExplicit(boolean searchByPriceExplicit) {
        this.searchByPriceExplicit = searchByPriceExplicit;
    }
}
