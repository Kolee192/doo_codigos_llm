import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SearchResultView {
    private ResultViewType viewType;
    private final List<RestaurantSearchResult> baseResults;
    private List<RestaurantSearchResult> filteredResults;
    private final int defaultZoomLevel = 12;
    private SortOption currentSortOption;
    private SortOrder currentSortOrder;

    public SearchResultView(ResultViewType viewType, List<RestaurantSearchResult> initialResults, boolean searchByPriceDefault) {
        this.viewType = viewType;
        this.baseResults = new ArrayList<>(initialResults.stream().limit(100).toList());
        this.filteredResults = new ArrayList<>(this.baseResults);
        this.currentSortOrder = SortOrder.ASCENDING;
        if (searchByPriceDefault) {
            applyPriceSearchDefaultSorting();
        } else {
            applyOtherSearchDefaultSorting();
        }
    }

    public ResultViewType getViewType() {
        return viewType;
    }

    public void setViewType(ResultViewType viewType) {
        this.viewType = viewType;
    }

    public int getDefaultZoomLevel() {
        return defaultZoomLevel;
    }

    public List<RestaurantSearchResult> getDisplayedResults() {
        return filteredResults;
    }

    public int getResultCount() {
        return filteredResults.size();
    }

    public void applyFilter(FilterCriteria filter) {
        filteredResults = new ArrayList<>(baseResults.stream()
                .filter(res -> filter.getMaxDistanceKm() == null || res.getDistanceKm() <= filter.getMaxDistanceKm())
                .filter(res -> filter.getMaxPrice() == null || res.getRestaurant().getAveragePrice() <= filter.getMaxPrice())
                .filter(res -> filter.getRestaurantType() == null || filter.getRestaurantType().isBlank() ||
                        res.getRestaurant().getRestaurantType().equalsIgnoreCase(filter.getRestaurantType()))
                .filter(res -> filter.getSpecificDish() == null || filter.getSpecificDish().isBlank() ||
                        res.getRestaurant().getMenu().stream().anyMatch(d -> d.getName().equalsIgnoreCase(filter.getSpecificDish())))
                .limit(100)
                .toList());

        if (currentSortOption != null) {
            applySorting(currentSortOption, currentSortOrder);
        }
    }

    public void applyPriceSearchDefaultSorting() {
        currentSortOption = SortOption.PRICE;
        currentSortOrder = SortOrder.ASCENDING;
        filteredResults.sort(
                Comparator.comparingDouble((RestaurantSearchResult r) -> r.getRestaurant().getAveragePrice())
                        .thenComparingDouble(RestaurantSearchResult::getDistanceKm)
                        .thenComparing(r -> r.getRestaurant().getRestaurantType(), String.CASE_INSENSITIVE_ORDER)
                        .thenComparing(RestaurantSearchResult::getMatchedDishName, String.CASE_INSENSITIVE_ORDER)
        );
    }

    public void applyOtherSearchDefaultSorting() {
        currentSortOption = SortOption.DISTANCE;
        currentSortOrder = SortOrder.ASCENDING;
        filteredResults.sort(
                Comparator.comparingDouble(RestaurantSearchResult::getDistanceKm)
                        .thenComparingDouble((RestaurantSearchResult r) -> r.getRestaurant().getAveragePrice())
                        .thenComparing(r -> r.getRestaurant().getRestaurantType(), String.CASE_INSENSITIVE_ORDER)
                        .thenComparing(RestaurantSearchResult::getMatchedDishName, String.CASE_INSENSITIVE_ORDER)
        );
    }

    public void toggleSort(SortOption option) {
        if (currentSortOption == option) {
            currentSortOrder = (currentSortOrder == SortOrder.ASCENDING) ? SortOrder.DESCENDING : SortOrder.ASCENDING;
        } else {
            currentSortOption = option;
            currentSortOrder = SortOrder.ASCENDING;
        }
        applySorting(currentSortOption, currentSortOrder);
    }

    private void applySorting(SortOption option, SortOrder order) {
        Comparator<RestaurantSearchResult> comparator = switch (option) {
            case PRICE -> Comparator.comparingDouble(r -> r.getRestaurant().getAveragePrice());
            case DISTANCE -> Comparator.comparingDouble(RestaurantSearchResult::getDistanceKm);
            case RESTAURANT_TYPE -> Comparator.comparing(r -> r.getRestaurant().getRestaurantType(), String.CASE_INSENSITIVE_ORDER);
            case SPECIFIC_DISH -> Comparator.comparing(RestaurantSearchResult::getMatchedDishName, String.CASE_INSENSITIVE_ORDER);
            case RESTAURANT_NAME -> Comparator.comparing(r -> r.getRestaurant().getName(), String.CASE_INSENSITIVE_ORDER);
        };

        if (order == SortOrder.DESCENDING) {
            comparator = comparator.reversed();
        }
        filteredResults.sort(comparator);
    }

    public String renderFilteringMenu() {
        return "=== FILTERING MENU ===\n" +
                "1. Increase/Decrease Max Distance\n" +
                "2. Increase/Decrease Max Price\n" +
                "3. Choose Restaurant Type\n" +
                "4. Choose Specific Dish\n" +
                "======================";
    }

    public String renderSortingHeader() {
        return "=== SORT OPTIONS === [PRICE] [DISTANCE] [RESTAURANT_TYPE] [SPECIFIC_DISH] [RESTAURANT_NAME] (Current: "
                + currentSortOption + " " + currentSortOrder + ")";
    }

    public String render() {
        StringBuilder sb = new StringBuilder();
        if (viewType == ResultViewType.MAP) {
            sb.append("=== MAP VIEW (Zoom: ").append(defaultZoomLevel).append("x) ===\n");
            sb.append("[Filter Button: Filter Results]\n");
            sb.append("Showing closest & relevant restaurants (Max 100):\n");
            for (RestaurantSearchResult r : filteredResults) {
                sb.append(r.toMapPinView()).append("\n");
            }
        } else {
            sb.append("=== LIST VIEW ===\n");
            sb.append(renderSortingHeader()).append("\n");
            sb.append("[Filter Button: Filter Results]\n");
            sb.append("Showing restaurants (Max 100):\n");
            for (RestaurantSearchResult r : filteredResults) {
                sb.append(r.toListElementView()).append("\n");
            }
        }
        return sb.toString();
    }
}
