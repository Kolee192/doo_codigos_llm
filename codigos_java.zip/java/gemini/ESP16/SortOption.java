public enum SortOption {
    PRICE,
    DISTANCE,
    RESTAURANT_TYPE,
    SPECIFIC_DISH,
    RESTAURANT_NAME
}
