public class GpsNavigationService {
    private boolean navigating = false;
    private String currentDestination;

    public void startNavigation(String destinationAddress) {
        this.currentDestination = destinationAddress;
        this.navigating = true;
    }

    public boolean isNavigating() {
        return navigating;
    }

    public String getCurrentDestination() {
        return currentDestination;
    }

    public void reachDestination() {
        this.navigating = false;
    }
}
