import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class SystemDatabase {
    private final Map<String, User> users = new HashMap<>();
    private final Map<String, RestaurantOwner> owners = new HashMap<>();
    private final Map<String, Administrator> admins = new HashMap<>();
    private final Map<String, Restaurant> restaurants = new HashMap<>();
    private final Map<String, String> ownerRestaurantMap = new HashMap<>(); // ownerUsername -> restaurantId
    private final List<String> restaurantTypes = new ArrayList<>();
    private final List<Dish> dishCatalog = new ArrayList<>();

    public SystemDatabase() {
        // Default restaurant types
        restaurantTypes.add("Italian");
        restaurantTypes.add("Japanese");
        restaurantTypes.add("Swedish");
        restaurantTypes.add("Mexican");
        restaurantTypes.add("Fast Food");

        // Default admin
        admins.put("admin", new Administrator("admin", "admin123"));
    }

    public Map<String, User> getUsers() {
        return users;
    }

    public Map<String, RestaurantOwner> getOwners() {
        return owners;
    }

    public Map<String, Administrator> getAdmins() {
        return admins;
    }

    public Map<String, Restaurant> getRestaurants() {
        return restaurants;
    }

    public List<String> getRestaurantTypes() {
        return restaurantTypes;
    }

    public List<Dish> getDishCatalog() {
        return dishCatalog;
    }

    public void registerRestaurant(String ownerUsername, Restaurant restaurant) {
        restaurants.put(restaurant.getId(), restaurant);
        if (ownerUsername != null) {
            ownerRestaurantMap.put(ownerUsername, restaurant.getId());
        }
    }

    public Restaurant getRestaurantByOwner(String ownerUsername) {
        String restaurantId = ownerRestaurantMap.get(ownerUsername);
        if (restaurantId != null) {
            return restaurants.get(restaurantId);
        }
        return null;
    }

    public void deleteRestaurantByOwner(String ownerUsername) {
        String restaurantId = ownerRestaurantMap.remove(ownerUsername);
        if (restaurantId != null) {
            restaurants.remove(restaurantId);
        }
    }

    public Optional<User> findUserByUsername(String username) {
        return Optional.ofNullable(users.get(username));
    }

    public Optional<User> findUserByEmail(String email) {
        return users.values().stream()
                .filter(u -> u.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }

    public Optional<RestaurantOwner> findOwnerByUsername(String username) {
        return Optional.ofNullable(owners.get(username));
    }

    public Optional<RestaurantOwner> findOwnerByEmail(String email) {
        return owners.values().stream()
                .filter(o -> o.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }

    public double calculateDistance(double userLat, double userLon, double restLat, double restLon) {
        // Approximate planar distance in km
        double dLat = (restLat - userLat) * 111.0;
        double dLon = (restLon - userLon) * 111.0 * Math.cos(Math.toRadians(userLat));
        return Math.sqrt(dLat * dLat + dLon * dLon);
    }
}
