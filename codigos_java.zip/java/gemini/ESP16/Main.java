public class Main {
    public static void main(String[] args) {
        // Initialize infrastructure
        AppStore appStore = new AppStore("1.1.0");
        SystemDatabase db = new SystemDatabase();
        EmailService emailService = new EmailService();

        System.out.println("=== SYSTEM INITIALIZATION ===");

        // FR1 & FR2: Download mobile application & check updates
        MobileApplication mobileApp = MobileApplication.downloadFromAppStore(appStore, db, emailService);
        System.out.println("FR1 & FR2: App installed version: " + mobileApp.getInstalledVersion());
        System.out.println("Update check: " + mobileApp.checkForNewReleases());

        // FR26 & FR28: Admin setup
        WebPortal webPortal = new WebPortal(db, emailService);
        webPortal.loginAdmin("admin", "admin123");
        webPortal.addRestaurantType("French");
        webPortal.addDishToCatalog("Köttbullar", "Swedish meatballs with lingonberries", 135.0);
        System.out.println("FR28: Admin added restaurant types: " + db.getRestaurantTypes());

        // FR22: Restaurant Owner Registration
        String regMsg = webPortal.registerOwner("mario", "pasta123", "Stortorget 1", "mario@example.com", "08123456", "0701122334");
        System.out.println("FR22: Owner Registration: " + regMsg);

        // FR27: Admin Verifies Owner
        String verifyMsg = webPortal.verifyRestaurantOwner("mario");
        System.out.println("FR27: Admin Verification: " + verifyMsg);
        System.out.println("Sent Email: " + emailService.getLatestEmailFor("mario@example.com").getSubject());

        // FR23 & FR24: Owner logs in and adds restaurant information
        webPortal.loginOwner("mario", "pasta123");
        webPortal.addOrUpdateRestaurantInfo(
                "Trattoria Mario",
                "Stortorget 1",
                "mario@example.com",
                "08123456",
                180.0,
                "Authentic Italian restaurant in the heart of the city.",
                "Italian",
                "mario.jpg",
                "0701122334"
        );
        webPortal.addDishToMenu("Lasagna Bolognese", "Classic rich beef lasagna", 160.0);
        webPortal.addDishToMenu("Pizza Margherita", "Fresh mozzarella and basil", 140.0);

        // Set restaurant location to Stockholm coordinates
        Restaurant marioRest = db.getRestaurantByOwner("mario");
        marioRest.setLatitude(59.3250);
        marioRest.setLongitude(18.0700);

        // Add a second restaurant via Admin (FR30)
        webPortal.adminAddRestaurant("rest_sushi", "Sakura Sushi", "Kungsgatan 12", "sakura@example.com", "08998877", 220.0);
        Restaurant sushiRest = db.getRestaurants().get("rest_sushi");
        sushiRest.setRestaurantType("Japanese");
        sushiRest.setDescription("Finest sushi and sashimi in town.");
        sushiRest.addDish(new Dish("Salmon Nigiri Set", "8 pieces fresh salmon", 180.0));
        sushiRest.setLatitude(59.3350);
        sushiRest.setLongitude(18.0650);

        System.out.println("FR24 & FR30: Added restaurants: " + db.getRestaurants().keySet());

        // FR3: Mobile User Registration
        String userReg = mobileApp.registerUser("alice", "passAlice", "alice@example.com", "0723456789");
        System.out.println("FR3: User Registration: " + userReg);

        // FR4: Mobile User Log-in & Auto login test
        String userLogin = mobileApp.login("alice", "passAlice");
        System.out.println("FR4: Mobile Log-in: " + userLogin);
        System.out.println("Is on Search Page: " + mobileApp.isOnSearchPage());

        // FR5: Retrieve Password
        String passRetrieval = mobileApp.retrievePassword("alice@example.com");
        System.out.println("FR5: Retrieve Password: " + passRetrieval);
        System.out.println("Password Email Body: " + emailService.getLatestEmailFor("alice@example.com").getBody());

        // FR14: Input validation demo
        StringBuilder err = new StringBuilder();
        boolean valid = mobileApp.validateIntegerInput("abc", "Price", err);
        System.out.println("FR14 Input Validation Check (valid: " + valid + "): " + err);

        // FR12: Search by Price (Default list view)
        SearchCriteria priceSearch = new SearchCriteria();
        priceSearch.setMinPrice(100);
        priceSearch.setMaxPrice(200);
        mobileApp.search(priceSearch);
        System.out.println("FR12: Search by Price View Type: " + mobileApp.getCurrentResultView().getViewType());
        System.out.println(mobileApp.getCurrentResultView().render());

        // FR13 & FR17: Search by Destination & Free-Text (Default map view)
        SearchCriteria generalSearch = new SearchCriteria();
        generalSearch.setFreeText("Italian");
        generalSearch.setMinDistanceKm(0);
        generalSearch.setMaxDistanceKm(5);
        mobileApp.search(generalSearch);
        System.out.println("FR13 & FR17: Search by Text/Destination View Type: " + mobileApp.getCurrentResultView().getViewType());
        System.out.println(mobileApp.getCurrentResultView().render());

        // FR10: Switch Result View
        mobileApp.switchResultView();
        System.out.println("FR10: Switched to View Type: " + mobileApp.getCurrentResultView().getViewType());

        // FR19: Sorting Results
        System.out.println("FR19: Sorting by PRICE...");
        mobileApp.sortResults(SortOption.PRICE);
        System.out.println(mobileApp.getCurrentResultView().render());

        // FR20: Filtering Results
        System.out.println("FR20: Filtering results (max distance 1 km)...");
        FilterCriteria filter = new FilterCriteria();
        filter.setMaxDistanceKm(1);
        mobileApp.filterResults(filter);
        System.out.println(mobileApp.getCurrentResultView().render());

        // FR11: Select Information Link
        RestaurantSearchResult selectedResult = mobileApp.getCurrentResultView().getDisplayedResults().get(0);
        String infoPage = mobileApp.selectInformationLink(selectedResult.getRestaurant());
        System.out.println("FR11 Information Link Selected:\n" + infoPage);

        // FR9: Navigation to Restaurant
        System.out.println(mobileApp.selectAndNavigateToRestaurant(selectedResult));
        System.out.println(mobileApp.reachDestinationAndReturnToSearch());
        System.out.println("Is on Search Page after navigation: " + mobileApp.isOnSearchPage());

        // FR18: No match found scenario
        SearchCriteria noMatchCriteria = new SearchCriteria();
        noMatchCriteria.setFreeText("NonExistentTacos");
        String noMatchResult = mobileApp.search(noMatchCriteria);
        System.out.println("FR18 No Match: " + noMatchResult);
        System.out.println("Remains on Search Page: " + mobileApp.isOnSearchPage());

        // FR21: Profile page update (Language, details)
        String profileUpdate = mobileApp.updateProfile("newPassAlice", "alice_new@example.com", "0799999999", Language.SWEDISH);
        System.out.println("FR21 Profile update: " + profileUpdate);

        // FR25 & FR33: Language changes on web portal
        System.out.println("FR25 Owner Language: " + webPortal.setOwnerPreferredLanguage(Language.SPANISH));
        System.out.println("FR33 Admin Language: " + webPortal.setAdminPreferredLanguage(Language.FRENCH));

        // FR31 & FR32: Admin user & owner management
        System.out.println("FR31 Admin user update: " + webPortal.adminEditUser("alice", "adminSetPass", "alice_admin@example.com", "0700000000"));
        System.out.println("FR32 Admin delete owner: " + webPortal.adminDeleteRestaurantOwner("mario"));
        System.out.println("Restaurants remaining after owner deleted: " + db.getRestaurants().keySet());

        System.out.println("\n=== ALL REQUIREMENTS DEMONSTRATED SUCCESSFULLY ===");
    }
}
