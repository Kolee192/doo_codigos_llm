import java.util.Optional;

public class WebPortal {
    private final SystemDatabase database;
    private final EmailService emailService;
    private RestaurantOwner loggedInOwner;
    private Administrator loggedInAdmin;

    public WebPortal(SystemDatabase database, EmailService emailService) {
        this.database = database;
        this.emailService = emailService;
    }

    // FR22: Restaurant owner registration
    public String registerOwner(String username, String password, String address, String email, String phone, String mobileNumber) {
        if (username == null || username.isBlank() || password == null || password.isBlank() ||
                address == null || address.isBlank() || email == null || email.isBlank() || phone == null || phone.isBlank()) {
            return "Registration failed: username, password, address, email, and phone are mandatory.";
        }
        if (database.findOwnerByUsername(username).isPresent()) {
            return "Registration failed: username already in use.";
        }
        RestaurantOwner owner = new RestaurantOwner(username, password, address, email, phone, mobileNumber);
        database.getOwners().put(username, owner);
        return "Registration submitted. Applied for verification.";
    }

    // FR23: Restaurant owner log-in
    public String loginOwner(String username, String password) {
        Optional<RestaurantOwner> ownerOpt = database.findOwnerByUsername(username);
        if (ownerOpt.isEmpty()) {
            return "Log-in failed: Invalid credentials.";
        }
        RestaurantOwner owner = ownerOpt.get();
        if (owner.getVerificationStatus() != OwnerVerificationStatus.VERIFIED) {
            return "Log-in failed: Account is not verified yet.";
        }
        if (!owner.getPassword().equals(password)) {
            return "Log-in failed: Invalid credentials.";
        }
        this.loggedInOwner = owner;
        return "Logged in successfully as restaurant owner.";
    }

    public void logoutOwner() {
        this.loggedInOwner = null;
    }

    public String retrieveOwnerPassword(String email) {
        Optional<RestaurantOwner> ownerOpt = database.findOwnerByEmail(email);
        if (ownerOpt.isPresent()) {
            RestaurantOwner owner = ownerOpt.get();
            emailService.sendEmail(email, "Web-Portal Password Retrieval", "Your password is: " + owner.getPassword());
            return "Password recovery email sent.";
        }
        return "Email address not found.";
    }

    // FR24: Manage restaurant information by restaurant owner
    public String addOrUpdateRestaurantInfo(String name, String address, String email, String phone,
                                            Double averagePrice, String description, String restaurantType,
                                            String pictureUrl, String mobilePhone) {
        if (loggedInOwner == null) {
            return "Must be logged in to manage information.";
        }
        if (name == null || name.isBlank() || address == null || address.isBlank() ||
                email == null || email.isBlank() || phone == null || phone.isBlank() || averagePrice == null) {
            return "Failed: Mandatory fields (restaurant name, address, email, phone, average price) must be filled.";
        }

        Restaurant restaurant = database.getRestaurantByOwner(loggedInOwner.getUsername());
        if (restaurant == null) {
            restaurant = new Restaurant("rest_" + loggedInOwner.getUsername(), name, address, email, phone, averagePrice);
            database.registerRestaurant(loggedInOwner.getUsername(), restaurant);
        } else {
            restaurant.setName(name);
            restaurant.setAddress(address);
            restaurant.setEmail(email);
            restaurant.setPhone(phone);
            restaurant.setAveragePrice(averagePrice);
        }

        if (description != null) restaurant.setDescription(description);
        if (restaurantType != null) restaurant.setRestaurantType(restaurantType);
        if (pictureUrl != null) restaurant.setPictureUrl(pictureUrl);
        if (mobilePhone != null) restaurant.setMobilePhone(mobilePhone);

        return "Restaurant information saved successfully.";
    }

    public String addDishToMenu(String dishName, String dishDescription, double dishPrice) {
        if (loggedInOwner == null) {
            return "Must be logged in to manage menu.";
        }
        Restaurant restaurant = database.getRestaurantByOwner(loggedInOwner.getUsername());
        if (restaurant == null) {
            return "Please create restaurant information before adding dishes.";
        }
        restaurant.addDish(new Dish(dishName, dishDescription, dishPrice));
        return "Dish added to restaurant menu.";
    }

    public String deleteRestaurantInfo() {
        if (loggedInOwner == null) {
            return "Must be logged in to delete information.";
        }
        database.deleteRestaurantByOwner(loggedInOwner.getUsername());
        return "Restaurant information deleted.";
    }

    // FR25: Owner preferred language
    public String setOwnerPreferredLanguage(Language language) {
        if (loggedInOwner == null) {
            return "Must be logged in to set language.";
        }
        loggedInOwner.setLanguage(language);
        return "Web-portal language set to " + language;
    }

    // FR26: Administrator log in
    public String loginAdmin(String username, String password) {
        Administrator admin = database.getAdmins().get(username);
        if (admin != null && admin.getPassword().equals(password)) {
            this.loggedInAdmin = admin;
            return "Logged in successfully as administrator.";
        }
        return "Administrator log-in failed.";
    }

    public void logoutAdmin() {
        this.loggedInAdmin = null;
    }

    // FR27: Verify or reject restaurant owner
    public String verifyRestaurantOwner(String ownerUsername) {
        if (loggedInAdmin == null) return "Administrator access required.";
        Optional<RestaurantOwner> ownerOpt = database.findOwnerByUsername(ownerUsername);
        if (ownerOpt.isEmpty()) return "Restaurant owner not found.";

        RestaurantOwner owner = ownerOpt.get();
        owner.setVerificationStatus(OwnerVerificationStatus.VERIFIED);
        emailService.sendEmail(owner.getEmail(), "Account Verified", "Your account has been verified. You can now log in.");
        return "Restaurant owner verified and notified by confirmation email.";
    }

    public String rejectRestaurantOwner(String ownerUsername) {
        if (loggedInAdmin == null) return "Administrator access required.";
        Optional<RestaurantOwner> ownerOpt = database.findOwnerByUsername(ownerUsername);
        if (ownerOpt.isEmpty()) return "Restaurant owner not found.";

        RestaurantOwner owner = ownerOpt.get();
        owner.setVerificationStatus(OwnerVerificationStatus.REJECTED);
        emailService.sendEmail(owner.getEmail(), "Account Rejected", "Your registration has been rejected.");
        return "Restaurant owner rejected and notified by rejection email.";
    }

    // FR28: Manage restaurant types
    public String addRestaurantType(String type) {
        if (loggedInAdmin == null) return "Administrator access required.";
        if (!database.getRestaurantTypes().contains(type)) {
            database.getRestaurantTypes().add(type);
            return "Restaurant type '" + type + "' added.";
        }
        return "Restaurant type already exists.";
    }

    public String editRestaurantType(String oldType, String newType) {
        if (loggedInAdmin == null) return "Administrator access required.";
        int index = database.getRestaurantTypes().indexOf(oldType);
        if (index >= 0) {
            database.getRestaurantTypes().set(index, newType);
            return "Restaurant type updated to '" + newType + "'.";
        }
        return "Restaurant type not found.";
    }

    public String deleteRestaurantType(String type) {
        if (loggedInAdmin == null) return "Administrator access required.";
        if (database.getRestaurantTypes().remove(type)) {
            return "Restaurant type '" + type + "' removed.";
        }
        return "Restaurant type not found.";
    }

    // FR29: Manage restaurant dishes in global catalog
    public String addDishToCatalog(String name, String description, double price) {
        if (loggedInAdmin == null) return "Administrator access required.";
        database.getDishCatalog().add(new Dish(name, description, price));
        return "Dish added to catalog.";
    }

    public String editDishInCatalog(String oldName, String newName, String newDescription, double newPrice) {
        if (loggedInAdmin == null) return "Administrator access required.";
        for (Dish d : database.getDishCatalog()) {
            if (d.getName().equalsIgnoreCase(oldName)) {
                d.setName(newName);
                d.setDescription(newDescription);
                d.setPrice(newPrice);
                return "Dish updated in catalog.";
            }
        }
        return "Dish not found in catalog.";
    }

    public String deleteDishFromCatalog(String name) {
        if (loggedInAdmin == null) return "Administrator access required.";
        boolean removed = database.getDishCatalog().removeIf(d -> d.getName().equalsIgnoreCase(name));
        return removed ? "Dish removed from catalog." : "Dish not found in catalog.";
    }

    // FR30: Manage restaurant information by admin
    public String adminAddRestaurant(String restaurantId, String name, String address, String email, String phone, double avgPrice) {
        if (loggedInAdmin == null) return "Administrator access required.";
        Restaurant restaurant = new Restaurant(restaurantId, name, address, email, phone, avgPrice);
        database.getRestaurants().put(restaurantId, restaurant);
        return "Restaurant information added by admin.";
    }

    public String adminEditRestaurant(String restaurantId, String name, String address, String email, String phone, double avgPrice) {
        if (loggedInAdmin == null) return "Administrator access required.";
        Restaurant restaurant = database.getRestaurants().get(restaurantId);
        if (restaurant == null) return "Restaurant not found.";
        restaurant.setName(name);
        restaurant.setAddress(address);
        restaurant.setEmail(email);
        restaurant.setPhone(phone);
        restaurant.setAveragePrice(avgPrice);
        return "Restaurant information updated by admin.";
    }

    public String adminDeleteRestaurant(String restaurantId) {
        if (loggedInAdmin == null) return "Administrator access required.";
        Restaurant removed = database.getRestaurants().remove(restaurantId);
        return removed != null ? "Restaurant information deleted." : "Restaurant not found.";
    }

    // FR31: Manage users by admin
    public String adminEditUser(String username, String newPassword, String newEmail, String newPhone) {
        if (loggedInAdmin == null) return "Administrator access required.";
        Optional<User> userOpt = database.findUserByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (newPassword != null) user.setPassword(newPassword);
            if (newEmail != null) user.setEmail(newEmail);
            if (newPhone != null) user.setPhone(newPhone);
            return "User updated by admin.";
        }
        return "User not found.";
    }

    public String adminDeleteOrInactivateUser(String username, boolean deletePermanently) {
        if (loggedInAdmin == null) return "Administrator access required.";
        if (deletePermanently) {
            User removed = database.getUsers().remove(username);
            return removed != null ? "User deleted." : "User not found.";
        } else {
            Optional<User> userOpt = database.findUserByUsername(username);
            if (userOpt.isPresent()) {
                userOpt.get().setActive(false);
                return "User inactivated.";
            }
            return "User not found.";
        }
    }

    // FR32: Manage restaurant owners by admin
    public String adminAddRestaurantOwner(String username, String password, String address, String email, String phone, String mobile) {
        if (loggedInAdmin == null) return "Administrator access required.";
        if (database.findOwnerByUsername(username).isPresent()) {
            return "Owner already exists.";
        }
        RestaurantOwner owner = new RestaurantOwner(username, password, address, email, phone, mobile);
        owner.setVerificationStatus(OwnerVerificationStatus.VERIFIED);
        database.getOwners().put(username, owner);
        return "Restaurant owner added by admin.";
    }

    public String adminEditRestaurantOwner(String username, String newAddress, String newEmail, String newPhone) {
        if (loggedInAdmin == null) return "Administrator access required.";
        Optional<RestaurantOwner> ownerOpt = database.findOwnerByUsername(username);
        if (ownerOpt.isPresent()) {
            RestaurantOwner owner = ownerOpt.get();
            if (newAddress != null) owner.setAddress(newAddress);
            if (newEmail != null) owner.setEmail(newEmail);
            if (newPhone != null) owner.setPhone(newPhone);
            return "Restaurant owner updated by admin.";
        }
        return "Restaurant owner not found.";
    }

    public String adminDeleteRestaurantOwner(String username) {
        if (loggedInAdmin == null) return "Administrator access required.";
        RestaurantOwner removed = database.getOwners().remove(username);
        if (removed != null) {
            database.deleteRestaurantByOwner(username);
            return "Restaurant owner and associated restaurant information deleted.";
        }
        return "Restaurant owner not found.";
    }

    // FR33: Admin preferred language
    public String setAdminPreferredLanguage(Language language) {
        if (loggedInAdmin == null) return "Must be logged in to set language.";
        loggedInAdmin.setLanguage(language);
        return "Web-portal language set to " + language;
    }

    public RestaurantOwner getLoggedInOwner() {
        return loggedInOwner;
    }

    public Administrator getLoggedInAdmin() {
        return loggedInAdmin;
    }
}
