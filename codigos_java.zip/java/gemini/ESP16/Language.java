public enum Language {
    SWEDISH,
    ENGLISH,
    SPANISH,
    FRENCH
}
