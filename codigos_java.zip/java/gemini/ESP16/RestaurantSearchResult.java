import java.util.Objects;

public class RestaurantSearchResult {
    private final Restaurant restaurant;
    private final double distanceKm;
    private final String matchedDishName;

    public RestaurantSearchResult(Restaurant restaurant, double distanceKm, String matchedDishName) {
        this.restaurant = restaurant;
        this.distanceKm = distanceKm;
        this.matchedDishName = matchedDishName;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    public String getMatchedDishName() {
        return matchedDishName != null ? matchedDishName : "";
    }

    public String toListElementView() {
        String shortDesc = restaurant.getDescription();
        if (shortDesc.length() > 60) {
            shortDesc = shortDesc.substring(0, 57) + "...";
        }
        String twoLineDesc = shortDesc + "\nFreshly prepared daily.";

        return "--------------------------------------------------\n" +
                "Name: " + restaurant.getName() + "\n" +
                "Telephone: " + restaurant.getPhone() + "\n" +
                "Food Type: " + restaurant.getRestaurantType() + "\n" +
                "Distance: " + String.format("%.2f", distanceKm) + " km\n" +
                "Average Price: " + restaurant.getAveragePrice() + " SEK\n" +
                "Description:\n" + twoLineDesc + "\n" +
                "Website: " + restaurant.getWebsiteUrl() + "\n" +
                "Info Link: [Select Information Link]\n" +
                "--------------------------------------------------";
    }

    public String toMapPinView() {
        return "Pin at (" + String.format("%.4f", restaurant.getLatitude()) + ", " +
                String.format("%.4f", restaurant.getLongitude()) + ") -> " +
                restaurant.getName() + " [Info Link: Select Pin]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RestaurantSearchResult that)) return false;
        return Objects.equals(restaurant.getId(), that.restaurant.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(restaurant.getId());
    }
}
