import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmailService {
    private final List<Email> sentEmails = new ArrayList<>();

    public void sendEmail(String recipient, String subject, String body) {
        Email email = new Email(recipient, subject, body);
        sentEmails.add(email);
    }

    public List<Email> getSentEmails() {
        return Collections.unmodifiableList(sentEmails);
    }

    public Email getLatestEmailFor(String recipient) {
        for (int i = sentEmails.size() - 1; i >= 0; i--) {
            if (sentEmails.get(i).getRecipient().equalsIgnoreCase(recipient)) {
                return sentEmails.get(i);
            }
        }
        return null;
    }
}
