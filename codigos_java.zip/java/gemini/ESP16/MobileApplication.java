import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MobileApplication {
    private String installedVersion;
    private final AppStore appStore;
    private final SystemDatabase database;
    private final EmailService emailService;
    private final GpsNavigationService navigationService;

    private User currentUser;
    private String savedUsername;
    private String savedPassword;
    private boolean onSearchPage = false;
    private double userLatitude = 59.3293;  // Default user location (e.g., Stockholm)
    private double userLongitude = 18.0686;
    private SearchResultView currentResultView;

    public MobileApplication(AppStore appStore, SystemDatabase database, EmailService emailService) {
        this.installedVersion = "1.0.0";
        this.appStore = appStore;
        this.database = database;
        this.emailService = emailService;
        this.navigationService = new GpsNavigationService();
    }

    // FR1: Download mobile application
    public static MobileApplication downloadFromAppStore(AppStore store, SystemDatabase db, EmailService emailService) {
        store.downloadApplication();
        MobileApplication app = new MobileApplication(store, db, emailService);
        app.installedVersion = store.getLatestVersion();
        return app;
    }

    // FR2: Download and notify users of new releases (manual check)
    public String checkForNewReleases() {
        if (appStore.isNewReleaseAvailable(installedVersion)) {
            return "A new release (" + appStore.getLatestVersion() + ") is available! You can download it now.";
        }
        return "You are using the latest version (" + installedVersion + ").";
    }

    public String downloadUpdate() {
        if (appStore.isNewReleaseAvailable(installedVersion)) {
            String msg = appStore.downloadNewRelease(installedVersion);
            this.installedVersion = appStore.getLatestVersion();
            return msg;
        }
        return "No new release to download.";
    }

    // FR3: User registration
    public String registerUser(String username, String password, String email, String phone) {
        if (username == null || username.isBlank() || password == null || password.isBlank() || email == null || email.isBlank()) {
            return "Registration failed: user-name, password, and email address are required.";
        }
        if (database.findUserByUsername(username).isPresent()) {
            return "Registration failed: user-name already exists.";
        }
        User user = new User(username, password, email, phone);
        database.getUsers().put(username, user);
        return "Registration successful.";
    }

    // FR4: User log-in & automatic login
    public String login(String username, String password) {
        Optional<User> userOpt = database.findUserByUsername(username);
        if (userOpt.isPresent() && userOpt.get().isActive() && userOpt.get().getPassword().equals(password)) {
            this.currentUser = userOpt.get();
            this.savedUsername = username;
            this.savedPassword = password;
            this.onSearchPage = true; // FR6: first page shown is the search page
            return "Log-in successful. Welcome to the search page!";
        }
        return "Log-in failed: Invalid credentials or inactive account.";
    }

    public String autoLogin() {
        if (savedUsername != null && savedPassword != null) {
            return login(savedUsername, savedPassword);
        }
        return "No stored credentials for automatic log-in.";
    }

    public void logout() {
        this.currentUser = null;
        this.onSearchPage = false;
        this.currentResultView = null;
    }

    // FR5: Retrieve password
    public String retrievePassword(String email) {
        Optional<User> userOpt = database.findUserByEmail(email);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            emailService.sendEmail(email, "Password Retrieval", "Your password is: " + user.getPassword());
            return "Password has been sent to your e-mail address.";
        }
        return "E-mail address not found.";
    }

    // Input validation for Price and Destination (FR14)
    public boolean validateIntegerInput(String input, String fieldName, StringBuilder errorMessage) {
        try {
            int val = Integer.parseInt(input.trim());
            if (val < 0) {
                errorMessage.append("Invalid input for ").append(fieldName).append(": must be non-negative integer. Please insert an accepted input.");
                return false;
            }
            return true;
        } catch (NumberFormatException e) {
            errorMessage.append("Invalid input for ").append(fieldName).append(": '").append(input).append("' is not an integer. Please insert an accepted input.");
            return false;
        }
    }

    // FR6, FR7, FR8, FR12, FR13, FR15, FR16, FR17, FR18: Search
    public String search(SearchCriteria criteria) {
        if (currentUser == null) {
            return "Please log in to search.";
        }

        List<RestaurantSearchResult> matchingResults = new ArrayList<>();

        for (Restaurant r : database.getRestaurants().values()) {
            double distance = database.calculateDistance(userLatitude, userLongitude, r.getLatitude(), r.getLongitude());

            // Destination distance check (FR13, default min 0, max 10)
            if (criteria.getMinDistanceKm() != null && distance < criteria.getMinDistanceKm()) {
                continue;
            }
            if (criteria.getMaxDistanceKm() != null && distance > criteria.getMaxDistanceKm()) {
                continue;
            }

            // Price range check (FR12)
            if (criteria.getMinPrice() != null && r.getAveragePrice() < criteria.getMinPrice()) {
                continue;
            }
            if (criteria.getMaxPrice() != null && r.getAveragePrice() > criteria.getMaxPrice()) {
                continue;
            }

            // Restaurant type check (FR15)
            if (criteria.getRestaurantType() != null && !criteria.getRestaurantType().isBlank()) {
                if (!r.getRestaurantType().equalsIgnoreCase(criteria.getRestaurantType())) {
                    continue;
                }
            }

            // Specific dish check (FR16)
            String matchedDish = null;
            if (criteria.getSpecificDish() != null && !criteria.getSpecificDish().isBlank()) {
                Optional<Dish> dishOpt = r.getMenu().stream()
                        .filter(d -> d.getName().equalsIgnoreCase(criteria.getSpecificDish()))
                        .findFirst();
                if (dishOpt.isEmpty()) {
                    continue;
                } else {
                    matchedDish = dishOpt.get().getName();
                }
            }

            // Free-text search check (FR17)
            if (criteria.getFreeText() != null && !criteria.getFreeText().isBlank()) {
                String term = criteria.getFreeText().toLowerCase();
                boolean matchesName = r.getName().toLowerCase().contains(term);
                boolean matchesDesc = r.getDescription().toLowerCase().contains(term);
                boolean matchesAddress = r.getAddress().toLowerCase().contains(term);
                boolean matchesType = r.getRestaurantType().toLowerCase().contains(term);
                boolean matchesMenu = r.getMenu().stream()
                        .anyMatch(d -> d.getName().toLowerCase().contains(term) || d.getDescription().toLowerCase().contains(term));

                if (!matchesName && !matchesDesc && !matchesAddress && !matchesType && !matchesMenu) {
                    continue;
                }
            }

            matchingResults.add(new RestaurantSearchResult(r, distance, matchedDish));
        }

        // FR18: No match found - keep user on search page
        if (matchingResults.isEmpty()) {
            this.onSearchPage = true;
            this.currentResultView = null;
            return "No match found. You remain on the search page to conduct a new search.";
        }

        // Default view: FR12 says search by price defaults to list view. Other searches default to map view.
        ResultViewType defaultViewType;
        if (criteria.isSearchByPriceExplicit()) {
            defaultViewType = ResultViewType.LIST;
        } else {
            defaultViewType = ResultViewType.MAP;
        }

        this.currentResultView = new SearchResultView(defaultViewType, matchingResults, criteria.isSearchByPriceExplicit());
        this.onSearchPage = false;
        return "Search completed. Found " + currentResultView.getResultCount() + " results.";
    }

    // FR10: Switch result view
    public void switchResultView() {
        if (currentResultView != null) {
            if (currentResultView.getViewType() == ResultViewType.MAP) {
                currentResultView.setViewType(ResultViewType.LIST);
            } else {
                currentResultView.setViewType(ResultViewType.MAP);
            }
        }
    }

    // FR19: Sorting results
    public void sortResults(SortOption option) {
        if (currentResultView != null) {
            currentResultView.toggleSort(option);
        }
    }

    // FR20: Filtering results
    public void filterResults(FilterCriteria filter) {
        if (currentResultView != null) {
            currentResultView.applyFilter(filter);
        }
    }

    // FR9: Navigation to restaurant
    public String selectAndNavigateToRestaurant(RestaurantSearchResult result) {
        navigationService.startNavigation(result.getRestaurant().getAddress());
        return "Navigating to: " + result.getRestaurant().getName() + " at " + result.getRestaurant().getAddress();
    }

    public String reachDestinationAndReturnToSearch() {
        navigationService.reachDestination();
        this.onSearchPage = true;
        return "Destination reached. Returned to search page.";
    }

    // FR11: Select information link
    public String selectInformationLink(Restaurant restaurant) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== RESTAURANT INFORMATION PAGE ===\n");
        sb.append("Picture: [").append(restaurant.getPictureUrl()).append("]\n");
        sb.append("Name: ").append(restaurant.getName()).append("\n");
        sb.append("Address: ").append(restaurant.getAddress()).append("\n");
        sb.append("Phone: ").append(restaurant.getPhone()).append("\n");
        sb.append("E-mail: ").append(restaurant.getEmail()).append("\n");
        sb.append("Type of food: ").append(restaurant.getRestaurantType()).append("\n");
        sb.append("Average price: ").append(restaurant.getAveragePrice()).append(" SEK\n");
        sb.append("Description: ").append(restaurant.getDescription()).append("\n");
        sb.append("--- MENU ---\n");
        if (restaurant.getMenu().isEmpty()) {
            sb.append("No dishes listed.\n");
        } else {
            for (Dish dish : restaurant.getMenu()) {
                sb.append("Dish: ").append(dish.getName())
                        .append(" | Description: ").append(dish.getDescription())
                        .append(" | Price: ").append(dish.getPrice()).append(" SEK\n");
            }
        }
        sb.append("===================================");
        return sb.toString();
    }

    // FR21: Profile page
    public String updateProfile(String newPassword, String newEmail, String newPhone, Language newLanguage) {
        if (currentUser == null) {
            return "Please log in to edit profile.";
        }
        if (newPassword != null && !newPassword.isBlank()) {
            currentUser.setPassword(newPassword);
            this.savedPassword = newPassword;
        }
        if (newEmail != null && !newEmail.isBlank()) {
            currentUser.setEmail(newEmail);
        }
        if (newPhone != null) {
            currentUser.setPhone(newPhone);
        }
        if (newLanguage != null) {
            currentUser.setLanguage(newLanguage);
        }
        return "Profile updated successfully. App language set to " + currentUser.getLanguage() + ".";
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public SearchResultView getCurrentResultView() {
        return currentResultView;
    }

    public boolean isOnSearchPage() {
        return onSearchPage;
    }

    public void setUserLocation(double lat, double lon) {
        this.userLatitude = lat;
        this.userLongitude = lon;
    }

    public String getInstalledVersion() {
        return installedVersion;
    }
}
