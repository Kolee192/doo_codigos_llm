public class Administrator {
    private String username;
    private String password;
    private Language language;

    public Administrator(String username, String password) {
        this.username = username;
        this.password = password;
        this.language = Language.ENGLISH;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }
}
