import java.util.ArrayList;
import java.util.List;

public class AppStore {
    private final String latestVersion;
    private final List<String> changeLogs = new ArrayList<>();

    public AppStore(String latestVersion) {
        this.latestVersion = latestVersion;
        this.changeLogs.add("v1.0.0: Initial public release");
        this.changeLogs.add("v1.1.0: Added smart filters and updated UI");
    }

    public String downloadApplication() {
        // Free to download
        return "Mobile Application downloaded successfully for free (Version: " + latestVersion + ").";
    }

    public boolean isNewReleaseAvailable(String currentVersion) {
        return !latestVersion.equalsIgnoreCase(currentVersion);
    }

    public String getLatestVersion() {
        return latestVersion;
    }

    public String downloadNewRelease(String currentVersion) {
        if (isNewReleaseAvailable(currentVersion)) {
            return "Downloaded new release: " + latestVersion;
        }
        return "Already running the latest version: " + currentVersion;
    }
}
