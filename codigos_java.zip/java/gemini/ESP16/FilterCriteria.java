public class FilterCriteria {
    private Integer maxDistanceKm;
    private Integer maxPrice;
    private String restaurantType;
    private String specificDish;

    public FilterCriteria() {
    }

    public Integer getMaxDistanceKm() {
        return maxDistanceKm;
    }

    public void setMaxDistanceKm(Integer maxDistanceKm) {
        this.maxDistanceKm = maxDistanceKm;
    }

    public Integer getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(Integer maxPrice) {
        this.maxPrice = maxPrice;
    }

    public String getRestaurantType() {
        return restaurantType;
    }

    public void setRestaurantType(String restaurantType) {
        this.restaurantType = restaurantType;
    }

    public String getSpecificDish() {
        return specificDish;
    }

    public void setSpecificDish(String specificDish) {
        this.specificDish = specificDish;
    }
}
