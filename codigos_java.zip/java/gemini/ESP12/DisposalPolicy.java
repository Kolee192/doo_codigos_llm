import java.time.LocalDate;

public class DisposalPolicy {
    private final int retentionYears;
    private final LocalDate scheduledDisposalDate;
    private final String justification;
    private boolean approvedByAdministrator;

    public DisposalPolicy(int retentionYears, LocalDate scheduledDisposalDate, String justification) {
        this.retentionYears = retentionYears;
        this.scheduledDisposalDate = scheduledDisposalDate;
        this.justification = justification;
        this.approvedByAdministrator = false;
    }

    public int getRetentionYears() {
        return retentionYears;
    }

    public LocalDate getScheduledDisposalDate() {
        return scheduledDisposalDate;
    }

    public String getJustification() {
        return justification;
    }

    public boolean isApprovedByAdministrator() {
        return approvedByAdministrator;
    }

    public void approveDisposal() {
        this.approvedByAdministrator = true;
    }
}
