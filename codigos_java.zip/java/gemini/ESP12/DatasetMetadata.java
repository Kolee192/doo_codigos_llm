import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatasetMetadata {
    private String title;
    private final List<String> authors = new ArrayList<>();
    private String description;
    private String subjectDiscipline;
    private final List<String> keywords = new ArrayList<>();
    private String opusPublicationId;
    private String dmpId;
    private String crisProjectId;
    private String funderName;
    private String grantNumber;
    private String externalRepositoryUrl;
    private final Map<String, String> customDomainMetadata = new HashMap<>();

    public DatasetMetadata(String title, String description, String subjectDiscipline) {
        this.title = title;
        this.description = description;
        this.subjectDiscipline = subjectDiscipline;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getAuthors() {
        return authors;
    }

    public void addAuthor(String author) {
        this.authors.add(author);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSubjectDiscipline() {
        return subjectDiscipline;
    }

    public void setSubjectDiscipline(String subjectDiscipline) {
        this.subjectDiscipline = subjectDiscipline;
    }

    public List<String> getKeywords() {
        return keywords;
    }

    public void addKeyword(String keyword) {
        this.keywords.add(keyword);
    }

    public String getOpusPublicationId() {
        return opusPublicationId;
    }

    public void setOpusPublicationId(String opusPublicationId) {
        this.opusPublicationId = opusPublicationId;
    }

    public String getDmpId() {
        return dmpId;
    }

    public void setDmpId(String dmpId) {
        this.dmpId = dmpId;
    }

    public String getCrisProjectId() {
        return crisProjectId;
    }

    public void setCrisProjectId(String crisProjectId) {
        this.crisProjectId = crisProjectId;
    }

    public String getFunderName() {
        return funderName;
    }

    public void setFunderName(String funderName) {
        this.funderName = funderName;
    }

    public String getGrantNumber() {
        return grantNumber;
    }

    public void setGrantNumber(String grantNumber) {
        this.grantNumber = grantNumber;
    }

    public String getExternalRepositoryUrl() {
        return externalRepositoryUrl;
    }

    public void setExternalRepositoryUrl(String externalRepositoryUrl) {
        this.externalRepositoryUrl = externalRepositoryUrl;
    }

    public Map<String, String> getCustomDomainMetadata() {
        return customDomainMetadata;
    }

    public void addCustomField(String key, String value) {
        this.customDomainMetadata.put(key, value);
    }
}
