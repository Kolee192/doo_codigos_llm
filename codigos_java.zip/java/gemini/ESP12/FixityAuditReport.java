import java.time.LocalDateTime;

public class FixityAuditReport {
    private final String fileId;
    private final String fileName;
    private final boolean passed;
    private final String expectedSha256;
    private final LocalDateTime checkTimestamp;

    public FixityAuditReport(String fileId, String fileName, boolean passed, String expectedSha256) {
        this.fileId = fileId;
        this.fileName = fileName;
        this.passed = passed;
        this.expectedSha256 = expectedSha256;
        this.checkTimestamp = LocalDateTime.now();
    }

    public String getFileId() {
        return fileId;
    }

    public String getFileName() {
        return fileName;
    }

    public boolean isPassed() {
        return passed;
    }

    public String getExpectedSha256() {
        return expectedSha256;
    }

    public LocalDateTime getCheckTimestamp() {
        return checkTimestamp;
    }
}
