public class StoredFile {
    private final String fileId;
    private final String fileName;
    private final String contentType;
    private final long sizeBytes;
    private final String sha256Checksum;
    private final boolean liveWorkingData;
    private final byte[] content;

    public StoredFile(String fileId, String fileName, String contentType, long sizeBytes, String sha256Checksum, boolean liveWorkingData, byte[] content) {
        this.fileId = fileId;
        this.fileName = fileName;
        this.contentType = contentType;
        this.sizeBytes = sizeBytes;
        this.sha256Checksum = sha256Checksum;
        this.liveWorkingData = liveWorkingData;
        this.content = content != null ? content : new byte[0];
    }

    public String getFileId() {
        return fileId;
    }

    public String getFileName() {
        return fileName;
    }

    public String getContentType() {
        return contentType;
    }

    public long getSizeBytes() {
        return sizeBytes;
    }

    public String getSha256Checksum() {
        return sha256Checksum;
    }

    public boolean isLiveWorkingData() {
        return liveWorkingData;
    }

    public byte[] getContent() {
        return content.clone();
    }
}
