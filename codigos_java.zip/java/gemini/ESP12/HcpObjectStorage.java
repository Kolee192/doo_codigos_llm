import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class HcpObjectStorage implements StorageBackend {
    private final Map<String, byte[]> objectStore = new HashMap<>();

    @Override
    public void store(String fileId, byte[] data) {
        objectStore.put(fileId, data.clone());
    }

    @Override
    public byte[] retrieve(String fileId) {
        byte[] data = objectStore.get(fileId);
        return data == null ? null : data.clone();
    }

    @Override
    public boolean verifyIntegrity(String fileId, String expectedSha256) {
        byte[] data = objectStore.get(fileId);
        if (data == null) {
            return false;
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data);
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString().equalsIgnoreCase(expectedSha256);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    @Override
    public long getCapacityAvailable() {
        return Long.MAX_VALUE;
    }
}
