public class SwordDepositRequest {
    private final String depositorId;
    private final String onBehalfOf;
    private final String title;
    private final String abstractText;
    private final String discipline;
    private final String licenseIdentifier;
    private final String fileName;
    private final byte[] fileBytes;

    public SwordDepositRequest(String depositorId, String onBehalfOf, String title, String abstractText,
                               String discipline, String licenseIdentifier, String fileName, byte[] fileBytes) {
        this.depositorId = depositorId;
        this.onBehalfOf = onBehalfOf;
        this.title = title;
        this.abstractText = abstractText;
        this.discipline = discipline;
        this.licenseIdentifier = licenseIdentifier;
        this.fileName = fileName;
        this.fileBytes = fileBytes != null ? fileBytes : new byte[0];
    }

    public String getDepositorId() {
        return depositorId;
    }

    public String getOnBehalfOf() {
        return onBehalfOf;
    }

    public String getTitle() {
        return title;
    }

    public String getAbstractText() {
        return abstractText;
    }

    public String getDiscipline() {
        return discipline;
    }

    public String getLicenseIdentifier() {
        return licenseIdentifier;
    }

    public String getFileName() {
        return fileName;
    }

    public byte[] getFileBytes() {
        return fileBytes.clone();
    }
}
