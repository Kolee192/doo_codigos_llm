public enum AccessLevel {
    OPEN,
    EMBARGOED,
    RESTRICTED,
    CLOSED
}
