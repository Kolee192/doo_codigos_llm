import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CrisIntegrationService {
    public static class CrisProject {
        private final String projectId;
        private final String projectTitle;
        private final String funderName;
        private final String grantRef;
        private final List<String> outputDatasetIds = new ArrayList<>();

        public CrisProject(String projectId, String projectTitle, String funderName, String grantRef) {
            this.projectId = projectId;
            this.projectTitle = projectTitle;
            this.funderName = funderName;
            this.grantRef = grantRef;
        }

        public String getProjectId() {
            return projectId;
        }

        public String getProjectTitle() {
            return projectTitle;
        }

        public String getFunderName() {
            return funderName;
        }

        public String getGrantRef() {
            return grantRef;
        }

        public List<String> getOutputDatasetIds() {
            return outputDatasetIds;
        }

        public void linkDataset(String datasetId) {
            outputDatasetIds.add(datasetId);
        }
    }

    private final Map<String, CrisProject> projects = new HashMap<>();

    public void registerProject(CrisProject project) {
        projects.put(project.getProjectId(), project);
    }

    public CrisProject getProject(String projectId) {
        return projects.get(projectId);
    }

    public void linkDatasetToCris(String projectId, String datasetId) {
        CrisProject project = projects.get(projectId);
        if (project != null) {
            project.linkDataset(datasetId);
        }
    }
}
