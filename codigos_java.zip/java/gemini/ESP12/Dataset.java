import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Dataset {
    private final String datasetId;
    private final String depositorId;
    private final List<DatasetVersion> versions = new ArrayList<>();
    private DatasetStatus status;
    private final boolean externalRepositoryLink;

    public Dataset(String datasetId, String depositorId, boolean externalRepositoryLink) {
        this.datasetId = datasetId;
        this.depositorId = depositorId;
        this.status = DatasetStatus.DRAFT;
        this.externalRepositoryLink = externalRepositoryLink;
    }

    public String getDatasetId() {
        return datasetId;
    }

    public String getDepositorId() {
        return depositorId;
    }

    public DatasetStatus getStatus() {
        return status;
    }

    public void setStatus(DatasetStatus status) {
        this.status = status;
    }

    public boolean isExternalRepositoryLink() {
        return externalRepositoryLink;
    }

    public List<DatasetVersion> getVersions() {
        return Collections.unmodifiableList(versions);
    }

    public DatasetVersion getLatestVersion() {
        if (versions.isEmpty()) {
            return null;
        }
        return versions.get(versions.size() - 1);
    }

    public void addVersion(DatasetVersion version) {
        this.versions.add(version);
    }

    public DatasetVersion getVersion(int versionNumber) {
        for (DatasetVersion v : versions) {
            if (v.getVersionNumber() == versionNumber) {
                return v;
            }
        }
        return null;
    }
}
