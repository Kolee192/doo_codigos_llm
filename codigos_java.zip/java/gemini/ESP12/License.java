public class License {
    private final String identifier;
    private final String name;
    private final String url;
    private final boolean openAccess;

    public License(String identifier, String name, String url, boolean openAccess) {
        this.identifier = identifier;
        this.name = name;
        this.url = url;
        this.openAccess = openAccess;
    }

    public String getIdentifier() {
        return identifier;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public boolean isOpenAccess() {
        return openAccess;
    }

    public static final License CC_BY_4_0 = new License("CC-BY-4.0", "Creative Commons Attribution 4.0 International", "https://creativecommons.org/licenses/by/4.0/", true);
    public static final License CC0_1_0 = new License("CC0-1.0", "Creative Commons Zero Universal", "https://creativecommons.org/publicdomain/zero/1.0/", true);
    public static final License RESTRICTED_COLLABORATION = new License("BATH-RESTRICTED", "University of Bath Collaborative Research IP License", "https://www.bath.ac.uk/ip/terms", false);
}
