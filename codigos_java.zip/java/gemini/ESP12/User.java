import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class User {
    private final String userId;
    private final String fullName;
    private final String email;
    private final String department;
    private final Role role;
    private String preferredLanguage;
    private final Set<String> delegatedDepositorIds;

    public User(String userId, String fullName, String email, String department, Role role, String preferredLanguage) {
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.department = department;
        this.role = role;
        this.preferredLanguage = preferredLanguage == null ? "en" : preferredLanguage;
        this.delegatedDepositorIds = new HashSet<>();
    }

    public String getUserId() {
        return userId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartment() {
        return department;
    }

    public Role getRole() {
        return role;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }

    public Set<String> getDelegatedDepositorIds() {
        return Collections.unmodifiableSet(delegatedDepositorIds);
    }

    public void addDelegatedDepositor(String depositorId) {
        this.delegatedDepositorIds.add(depositorId);
    }

    public boolean canDepositOnBehalfOf(String depositorId) {
        return this.userId.equals(depositorId) || this.delegatedDepositorIds.contains(depositorId);
    }
}
