import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AnalyticsService {
    private final List<UsageMetricRecord> metrics = new ArrayList<>();
    private final Map<String, Integer> citationCounts = new HashMap<>();

    public void logMetric(String datasetId, int versionNumber, UsageMetricRecord.Action action, String country, String sector) {
        metrics.add(new UsageMetricRecord(datasetId, versionNumber, action, country, sector));
    }

    public void recordCitation(String datasetId) {
        citationCounts.put(datasetId, citationCounts.getOrDefault(datasetId, 0) + 1);
        metrics.add(new UsageMetricRecord(datasetId, 1, UsageMetricRecord.Action.CITATION, "GLOBAL", "ACADEMIC"));
    }

    public int getCitationCount(String datasetId) {
        return citationCounts.getOrDefault(datasetId, 0);
    }

    public long getTotalDownloads(String datasetId) {
        return metrics.stream()
                .filter(m -> m.getDatasetId().equals(datasetId) && m.action() == UsageMetricRecord.Action.DOWNLOAD)
                .count();
    }

    public long getTotalViews(String datasetId) {
        return metrics.stream()
                .filter(m -> m.getDatasetId().equals(datasetId) && m.action() == UsageMetricRecord.Action.VIEW)
                .count();
    }

    public Map<String, Long> getDownloadsByCountry(String datasetId) {
        return metrics.stream()
                .filter(m -> m.getDatasetId().equals(datasetId) && m.action() == UsageMetricRecord.Action.DOWNLOAD)
                .collect(Collectors.groupingBy(UsageMetricRecord::getCountry, Collectors.counting()));
    }

    public Map<String, Long> getDownloadsBySector(String datasetId) {
        return metrics.stream()
                .filter(m -> m.getDatasetId().equals(datasetId) && m.action() == UsageMetricRecord.Action.DOWNLOAD)
                .collect(Collectors.groupingBy(UsageMetricRecord::getSector, Collectors.counting()));
    }
}
