import java.time.LocalDateTime;

public class UsageMetricRecord {
    public enum Action {
        VIEW,
        DOWNLOAD,
        CITATION
    }

    private final String datasetId;
    private final int versionNumber;
    private final Action action;
    private final String country;
    private final String sector;
    private final LocalDateTime timestamp;

    public UsageMetricRecord(String datasetId, int versionNumber, Action action, String country, String sector) {
        this.datasetId = datasetId;
        this.versionNumber = versionNumber;
        this.action = action;
        this.country = country;
        this.sector = sector;
        this.timestamp = LocalDateTime.now();
    }

    public String getDatasetId() {
        return datasetId;
    }

    public int getVersionNumber() {
        return versionNumber;
    }

    public Action action() {
        return action;
    }

    public String getCountry() {
        return country;
    }

    public String getSector() {
        return sector;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}
