import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DatasetVersion {
    private final int versionNumber;
    private final LocalDateTime createdTimestamp;
    private final String changeSummary;
    private final DatasetMetadata metadata;
    private final License license;
    private final DisposalPolicy disposalPolicy;
    private final AccessLevel accessLevel;
    private final LocalDate embargoEndDate;
    private final Set<String> privilegedCollaborators;
    private final List<StoredFile> files;
    private String doi;
    private String persistentUrl;

    public DatasetVersion(int versionNumber, String changeSummary, DatasetMetadata metadata, License license,
                          DisposalPolicy disposalPolicy, AccessLevel accessLevel, LocalDate embargoEndDate) {
        this.versionNumber = versionNumber;
        this.createdTimestamp = LocalDateTime.now();
        this.changeSummary = changeSummary;
        this.metadata = metadata;
        this.license = license;
        this.disposalPolicy = disposalPolicy;
        this.accessLevel = accessLevel;
        this.embargoEndDate = embargoEndDate;
        this.privilegedCollaborators = new HashSet<>();
        this.files = new ArrayList<>();
    }

    public int getVersionNumber() {
        return versionNumber;
    }

    public LocalDateTime getCreatedTimestamp() {
        return createdTimestamp;
    }

    public String getChangeSummary() {
        return changeSummary;
    }

    public DatasetMetadata getMetadata() {
        return metadata;
    }

    public License getLicense() {
        return license;
    }

    public DisposalPolicy getDisposalPolicy() {
        return disposalPolicy;
    }

    public AccessLevel getAccessLevel() {
        return accessLevel;
    }

    public LocalDate getEmbargoEndDate() {
        return embargoEndDate;
    }

    public Set<String> getPrivilegedCollaborators() {
        return Collections.unmodifiableSet(privilegedCollaborators);
    }

    public void addPrivilegedCollaborator(String collaboratorId) {
        this.privilegedCollaborators.add(collaboratorId);
    }

    public List<StoredFile> getFiles() {
        return Collections.unmodifiableList(files);
    }

    public void addFile(StoredFile file) {
        this.files.add(file);
    }

    public String getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public String getPersistentUrl() {
        return persistentUrl;
    }

    public void setPersistentUrl(String persistentUrl) {
        this.persistentUrl = persistentUrl;
    }

    public boolean isEmbargoActive(LocalDate currentDate) {
        if (accessLevel == AccessLevel.EMBARGOED && embargoEndDate != null) {
            return currentDate.isBefore(embargoEndDate);
        }
        return false;
    }
}
