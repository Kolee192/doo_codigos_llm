import java.util.HashMap;
import java.util.Map;

public class LocalizationService {
    private final Map<String, Map<String, String>> translations = new HashMap<>();

    public LocalizationService() {
        Map<String, String> en = new HashMap<>();
        en.put("ui.welcome", "Welcome to University of Bath Data Archive");
        en.put("ui.deposit", "Deposit New Dataset");
        en.put("ui.search", "Search Archive");
        en.put("ui.cite", "Cite this Dataset");
        translations.put("en", en);

        Map<String, String> fr = new HashMap<>();
        fr.put("ui.welcome", "Bienvenue aux archives de données de l'Université de Bath");
        fr.put("ui.deposit", "Déposer un nouveau jeu de données");
        fr.put("ui.search", "Rechercher dans l'archive");
        fr.put("ui.cite", "Citer ce jeu de données");
        translations.put("fr", fr);

        Map<String, String> es = new HashMap<>();
        es.put("ui.welcome", "Bienvenido al Archivo de Datos de la Universidad de Bath");
        es.put("ui.deposit", "Depositar nuevo conjunto de datos");
        es.put("ui.search", "Buscar en el archivo");
        es.put("ui.cite", "Citar este conjunto de datos");
        translations.put("es", es);
    }

    public String getMessage(String key, String lang) {
        String effectiveLang = translations.containsKey(lang) ? lang : "en";
        return translations.get(effectiveLang).getOrDefault(key, key);
    }
}
