import java.util.ArrayList;
import java.util.List;

public class MetadataValidator {
    public static class ValidationResult {
        private final boolean valid;
        private final List<String> errors;

        public ValidationResult(boolean valid, List<String> errors) {
            this.valid = valid;
            this.errors = errors;
        }

        public boolean isValid() {
            return valid;
        }

        public List<String> getErrors() {
            return errors;
        }
    }

    public ValidationResult validate(DatasetVersion version) {
        List<String> errors = new ArrayList<>();
        DatasetMetadata meta = version.getMetadata();

        if (meta == null) {
            errors.add("Metadata object is missing.");
            return new ValidationResult(false, errors);
        }

        if (meta.getTitle() == null || meta.getTitle().trim().isEmpty()) {
            errors.add("Mandatory field missing: Title is required.");
        }
        if (meta.getAuthors() == null || meta.getAuthors().isEmpty()) {
            errors.add("Mandatory field missing: At least one Author/Creator is required.");
        }
        if (meta.getDescription() == null || meta.getDescription().trim().length() < 10) {
            errors.add("Mandatory field missing: Description must be at least 10 characters.");
        }
        if (meta.getSubjectDiscipline() == null || meta.getSubjectDiscipline().trim().isEmpty()) {
            errors.add("Mandatory field missing: Subject discipline is required.");
        }
        if (version.getLicense() == null) {
            errors.add("Mandatory field missing: Valid license selection is required.");
        }

        return new ValidationResult(errors.isEmpty(), errors);
    }
}
