public class DoiService {
    private final String prefix = "10.15125/BATH-";

    public String mintDoi(String datasetId, int versionNumber) {
        return prefix + datasetId.toUpperCase() + ".V" + versionNumber;
    }

    public String generatePersistentUrl(String doi) {
        return "https://doi.org/" + doi;
    }

    public String formatApaCitation(Dataset dataset, DatasetVersion version) {
        String authors = String.join(", ", version.getMetadata().getAuthors());
        int year = version.getCreatedTimestamp().getYear();
        String title = version.getMetadata().getTitle();
        String doi = version.getDoi();
        return String.format("%s (%d). %s [Data set]. University of Bath Data Archive. %s",
                authors.isEmpty() ? "University of Bath" : authors,
                year,
                title,
                doi != null ? "https://doi.org/" + doi : version.getPersistentUrl());
    }

    public String formatBibtexCitation(Dataset dataset, DatasetVersion version) {
        String key = "bath_" + dataset.getDatasetId() + "_v" + version.getVersionNumber();
        String authors = String.join(" and ", version.getMetadata().getAuthors());
        return String.format("""
                @misc{%s,
                  author = {%s},
                  title = {{%s}},
                  year = {%d},
                  publisher = {University of Bath Research Data Archive},
                  doi = {%s},
                  url = {%s}
                }""",
                key,
                authors,
                version.getMetadata().getTitle(),
                version.getCreatedTimestamp().getYear(),
                version.getDoi(),
                version.getPersistentUrl());
    }
}
