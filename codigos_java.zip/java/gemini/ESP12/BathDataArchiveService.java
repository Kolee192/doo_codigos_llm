import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

public class BathDataArchiveService {
    private final LdapDirectoryService ldapService;
    private final StorageBackend storageBackend;
    private final DoiService doiService;
    private final MetadataValidator metadataValidator;
    private final AnalyticsService analyticsService;
    private final CrisIntegrationService crisService;
    private final LocalizationService localizationService;
    private final MetadataHarvestingService harvestingService;

    private final Map<String, Dataset> datasets = new HashMap<>();
    private final Map<String, DatasetMetadata> rememberedDepositorMetadata = new HashMap<>();

    public BathDataArchiveService(LdapDirectoryService ldapService, StorageBackend storageBackend) {
        this.ldapService = ldapService;
        this.storageBackend = storageBackend;
        this.doiService = new DoiService();
        this.metadataValidator = new MetadataValidator();
        this.analyticsService = new AnalyticsService();
        this.crisService = new CrisIntegrationService();
        this.localizationService = new LocalizationService();
        this.harvestingService = new MetadataHarvestingService();
    }

    public Dataset createDatasetDraft(String actingUserId, String onBehalfOfUserId, boolean externalRepoLink) {
        User actor = ldapService.authenticate(actingUserId)
                .orElseThrow(() -> new IllegalArgumentException("User not found in University LDAP: " + actingUserId));

        String targetDepositorId = actingUserId;
        if (onBehalfOfUserId != null && !onBehalfOfUserId.equals(actingUserId)) {
            if (!actor.canDepositOnBehalfOf(onBehalfOfUserId) && actor.getRole() != Role.FACILITY_MANAGER && actor.getRole() != Role.ADMINISTRATOR) {
                throw new SecurityException("User " + actingUserId + " is not authorized to deposit on behalf of " + onBehalfOfUserId);
            }
            targetDepositorId = onBehalfOfUserId;
        }

        String datasetId = "bath-data-" + UUID.randomUUID().toString().substring(0, 8);
        Dataset dataset = new Dataset(datasetId, targetDepositorId, externalRepoLink);
        datasets.put(datasetId, dataset);
        return dataset;
    }

    public DatasetMetadata prepareMetadataWithDefaults(String depositorId, String title, String description, String discipline) {
        DatasetMetadata meta = new DatasetMetadata(title, description, discipline);
        Map<String, String> ldapDefaults = ldapService.fetchUserProfileMetadata(depositorId);
        if (ldapDefaults.containsKey("creator.name")) {
            meta.addAuthor(ldapDefaults.get("creator.name") + " (" + ldapDefaults.get("creator.department") + ")");
        }
        DatasetMetadata previous = rememberedDepositorMetadata.get(depositorId);
        if (previous != null) {
            meta.setCrisProjectId(previous.getCrisProjectId());
            meta.setDmpId(previous.getDmpId());
            meta.setFunderName(previous.getFunderName());
            meta.setGrantNumber(previous.getGrantNumber());
        }
        return meta;
    }

    public StoredFile uploadFile(String datasetId, String fileName, String contentType, byte[] data, boolean isLive) {
        String fileId = "file-" + UUID.randomUUID().toString();
        String checksum = calculateSha256(data);
        storageBackend.store(fileId, data);
        return new StoredFile(fileId, fileName, contentType, data.length, checksum, isLive, data);
    }

    public DatasetVersion addVersionToDataset(String datasetId, String actingUserId, DatasetMetadata metadata,
                                              License license, DisposalPolicy disposalPolicy,
                                              AccessLevel accessLevel, LocalDate embargoEndDate,
                                              List<StoredFile> files, String changeSummary) {
        Dataset dataset = datasets.get(datasetId);
        if (dataset == null) {
            throw new IllegalArgumentException("Dataset not found: " + datasetId);
        }

        int nextVersionNumber = dataset.getVersions().size() + 1;
        DatasetVersion version = new DatasetVersion(nextVersionNumber, changeSummary, metadata, license, disposalPolicy, accessLevel, embargoEndDate);
        for (StoredFile file : files) {
            version.addFile(file);
        }

        dataset.addVersion(version);
        rememberedDepositorMetadata.put(dataset.getDepositorId(), metadata);
        if (metadata.getCrisProjectId() != null) {
            crisService.linkDatasetToCris(metadata.getCrisProjectId(), datasetId);
        }
        return version;
    }

    public void submitForReview(String datasetId) {
        Dataset dataset = datasets.get(datasetId);
        if (dataset == null) {
            throw new IllegalArgumentException("Dataset not found");
        }
        dataset.setStatus(DatasetStatus.SUBMITTED_FOR_REVIEW);
    }

    public boolean adminApproveAndPublish(String adminUserId, String datasetId) {
        User admin = ldapService.authenticate(adminUserId)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found"));
        if (admin.getRole() != Role.ADMINISTRATOR) {
            throw new SecurityException("Only University of Bath Archive Administrators can approve datasets.");
        }

        Dataset dataset = datasets.get(datasetId);
        if (dataset == null) {
            throw new IllegalArgumentException("Dataset not found");
        }

        DatasetVersion latest = dataset.getLatestVersion();
        if (latest == null) {
            return false;
        }

        MetadataValidator.ValidationResult validation = metadataValidator.validate(latest);
        if (!validation.isValid()) {
            throw new IllegalStateException("Metadata validation failed: " + String.join(", ", validation.getErrors()));
        }

        String doi = doiService.mintDoi(dataset.getDatasetId(), latest.getVersionNumber());
        String purl = doiService.generatePersistentUrl(doi);
        latest.setDoi(doi);
        latest.setPersistentUrl(purl);

        dataset.setStatus(DatasetStatus.PUBLISHED);
        return true;
    }

    public FixityAuditReport auditFileIntegrity(String fileId, String expectedSha256, String fileName) {
        boolean match = storageBackend.verifyIntegrity(fileId, expectedSha256);
        return new FixityAuditReport(fileId, fileName, match, expectedSha256);
    }

    public boolean canAccessData(Dataset dataset, DatasetVersion version, User user, LocalDate currentDate, boolean onCampus) {
        if (user != null && (user.getRole() == Role.ADMINISTRATOR || user.getUserId().equals(dataset.getDepositorId()))) {
            return true;
        }

        if (version.getPrivilegedCollaborators().contains(user != null ? user.getUserId() : "")) {
            return true;
        }

        if (version.isEmbargoActive(currentDate)) {
            return false;
        }

        if (version.getAccessLevel() == AccessLevel.OPEN) {
            return true;
        }

        if (version.getAccessLevel() == AccessLevel.RESTRICTED) {
            return onCampus && user != null;
        }

        return false;
    }

    public List<Dataset> searchCatalog(String query, String subjectFilter) {
        String q = query == null ? "" : query.toLowerCase();
        String subj = subjectFilter == null ? "" : subjectFilter.toLowerCase();

        return datasets.values().stream()
                .filter(d -> d.getStatus() == DatasetStatus.PUBLISHED)
                .filter(d -> {
                    DatasetVersion v = d.getLatestVersion();
                    if (v == null) return false;
                    boolean matchesQuery = q.isEmpty() ||
                            v.getMetadata().getTitle().toLowerCase().contains(q) ||
                            v.getMetadata().getDescription().toLowerCase().contains(q) ||
                            v.getMetadata().getKeywords().stream().anyMatch(k -> k.toLowerCase().contains(q));
                    boolean matchesSubject = subj.isEmpty() ||
                            v.getMetadata().getSubjectDiscipline().toLowerCase().contains(subj);
                    return matchesQuery && matchesSubject;
                })
                .collect(Collectors.toList());
    }

    public List<Dataset> primoSearchEndpoint(String genericSearchTerm) {
        return searchCatalog(genericSearchTerm, null);
    }

    public Dataset swordDeposit(SwordDepositRequest request) {
        User actor = ldapService.authenticate(request.getDepositorId())
                .orElseThrow(() -> new IllegalArgumentException("Unknown SWORD user"));
        Dataset dataset = createDatasetDraft(actor.getUserId(), request.getOnBehalfOf(), false);

        DatasetMetadata meta = new DatasetMetadata(request.getTitle(), request.getAbstractText(), request.getDiscipline());
        meta.addAuthor(actor.getFullName());

        List<StoredFile> files = new ArrayList<>();
        if (request.getFileBytes() != null && request.getFileBytes().length > 0) {
            StoredFile file = uploadFile(dataset.getDatasetId(), request.getFileName(), "application/octet-stream", request.getFileBytes(), false);
            files.add(file);
        }

        License lic = "CC-BY-4.0".equalsIgnoreCase(request.getLicenseIdentifier()) ? License.CC_BY_4_0 : License.RESTRICTED_COLLABORATION;
        DisposalPolicy policy = new DisposalPolicy(10, LocalDate.now().plusYears(10), "Standard 10-year research funder retention");

        addVersionToDataset(dataset.getDatasetId(), actor.getUserId(), meta, lic, policy, AccessLevel.OPEN, null, files, "Deposited via SWORDv2 API");
        submitForReview(dataset.getDatasetId());
        return dataset;
    }

    public void approveDisposal(String adminUserId, String datasetId) {
        User admin = ldapService.authenticate(adminUserId).orElseThrow();
        if (admin.getRole() != Role.ADMINISTRATOR) {
            throw new SecurityException("Only admin can approve disposal");
        }
        Dataset dataset = datasets.get(datasetId);
        if (dataset != null && dataset.getLatestVersion() != null) {
            dataset.getLatestVersion().getDisposalPolicy().approveDisposal();
            dataset.setStatus(DatasetStatus.DISPOSED);
        }
    }

    public byte[] wholesaleExportArchive() {
        StringBuilder sb = new StringBuilder();
        sb.append("BATH-ARCHIVE-WHOLESALE-EXPORT-V1\n");
        for (Dataset d : datasets.values()) {
            DatasetVersion v = d.getLatestVersion();
            if (v != null) {
                sb.append("DATASET:").append(d.getDatasetId())
                  .append("|STATUS:").append(d.getStatus())
                  .append("|TITLE:").append(v.getMetadata().getTitle())
                  .append("|DOI:").append(v.getDoi())
                  .append("|FILES_COUNT:").append(v.getFiles().size())
                  .append("\n");
            }
        }
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    public int wholesaleImportExternalData(List<Dataset> externalDatasets) {
        int imported = 0;
        for (Dataset d : externalDatasets) {
            datasets.put(d.getDatasetId(), d);
            imported++;
        }
        return imported;
    }

    public List<Dataset> queryEntireArchive(DatasetStatus statusFilter, String funderFilter) {
        return datasets.values().stream()
                .filter(d -> statusFilter == null || d.getStatus() == statusFilter)
                .filter(d -> {
                    if (funderFilter == null) return true;
                    DatasetVersion v = d.getLatestVersion();
                    return v != null && funderFilter.equalsIgnoreCase(v.getMetadata().getFunderName());
                })
                .collect(Collectors.toList());
    }

    private String calculateSha256(byte[] data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data);
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) sb.append('0');
                sb.append(hex);
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public DoiService getDoiService() {
        return doiService;
    }

    public AnalyticsService getAnalyticsService() {
        return analyticsService;
    }

    public CrisIntegrationService getCrisService() {
        return crisService;
    }

    public LocalizationService getLocalizationService() {
        return localizationService;
    }

    public MetadataHarvestingService getHarvestingService() {
        return harvestingService;
    }

    public Map<String, Dataset> getAllDatasets() {
        return Collections.unmodifiableMap(datasets);
    }
}
