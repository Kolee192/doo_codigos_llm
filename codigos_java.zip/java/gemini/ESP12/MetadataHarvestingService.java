import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MetadataHarvestingService {
    public static class OaiRecord {
        private final String identifier;
        private final String title;
        private final List<String> creators;
        private final String subject;
        private final String description;
        private final String publisher;
        private final String date;
        private final String license;
        private final String doi;
        private final String funder;
        private final String grantRef;

        public OaiRecord(String identifier, String title, List<String> creators, String subject,
                         String description, String publisher, String date, String license,
                         String doi, String funder, String grantRef) {
            this.identifier = identifier;
            this.title = title;
            this.creators = creators;
            this.subject = subject;
            this.description = description;
            this.publisher = publisher;
            this.date = date;
            this.license = license;
            this.doi = doi;
            this.funder = funder;
            this.grantRef = grantRef;
        }

        public String toDublinCoreXml() {
            return String.format("""
                    <oai_dc:dc xmlns:oai_dc="http://www.openarchives.org/OAI/2.0/oai_dc/" xmlns:dc="http://purl.org/dc/elements/1.1/">
                      <dc:identifier>%s</dc:identifier>
                      <dc:title>%s</dc:title>
                      %s
                      <dc:subject>%s</dc:subject>
                      <dc:description>%s</dc:description>
                      <dc:publisher>%s</dc:publisher>
                      <dc:date>%s</dc:date>
                      <dc:rights>%s</dc:rights>
                      <dc:relation>%s</dc:relation>
                    </oai_dc:dc>""",
                    identifier,
                    title,
                    creators.stream().map(c -> "<dc:creator>" + c + "</dc:creator>").collect(Collectors.joining("\n  ")),
                    subject,
                    description,
                    publisher,
                    date,
                    license,
                    doi != null ? "info:doi/" + doi : "");
        }

        public String getFunder() {
            return funder;
        }

        public String getGrantRef() {
            return grantRef;
        }

        public String getIdentifier() {
            return identifier;
        }
    }

    public List<OaiRecord> harvestByFunder(List<Dataset> datasets, String funderName) {
        List<OaiRecord> harvested = new ArrayList<>();
        for (Dataset d : datasets) {
            if (d.getStatus() == DatasetStatus.PUBLISHED) {
                DatasetVersion v = d.getLatestVersion();
                if (v != null && funderName.equalsIgnoreCase(v.getMetadata().getFunderName())) {
                    harvested.add(new OaiRecord(
                            d.getDatasetId(),
                            v.getMetadata().getTitle(),
                            v.getMetadata().getAuthors(),
                            v.getMetadata().getSubjectDiscipline(),
                            v.getMetadata().getDescription(),
                            "University of Bath",
                            v.getCreatedTimestamp().toLocalDate().toString(),
                            v.getLicense().getName(),
                            v.getDoi(),
                            v.getMetadata().getFunderName(),
                            v.getMetadata().getGrantNumber()
                    ));
                }
            }
        }
        return harvested;
    }
}
