import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== University of Bath Research Data Archive System Demo ===\n");

        // 1. Initialize LDAP and Storage (HCP Object Storage)
        LdapDirectoryService ldap = new LdapDirectoryService();
        User profSmith = new User("smith_a", "Prof. Alice Smith", "a.smith@bath.ac.uk", "Dept of Chemistry", Role.DEPOSITOR, "en");
        User drDupont = new User("dupont_j", "Dr. Jean Dupont", "j.dupont@bath.ac.uk", "Dept of Physics", Role.DEPOSITOR, "fr");
        User facManager = new User("facility_mgr", "Dr. Bob Facility", "b.facility@bath.ac.uk", "MC2 Microscopy Facility", Role.FACILITY_MANAGER, "en");
        User adminUser = new User("bath_admin", "Bath Archive Administrator", "data-archive-admin@bath.ac.uk", "Library & Archive Services", Role.ADMINISTRATOR, "en");
        User extCollaborator = new User("ext_collab_carol", "Dr. Carol Offsite", "carol@collaborator-inst.org", "External Institute", Role.COLLABORATOR, "es");
        User crisManager = new User("cris_mgr", "Research Information Manager", "rim@bath.ac.uk", "Research & Innovation Services", Role.RESEARCH_INFORMATION_MANAGER, "en");

        // Set delegation: Prof Smith allows facility manager to deposit on her behalf
        profSmith.addDelegatedDepositor("facility_mgr");

        ldap.registerUser(profSmith);
        ldap.registerUser(drDupont);
        ldap.registerUser(facManager);
        ldap.registerUser(adminUser);
        ldap.registerUser(extCollaborator);
        ldap.registerUser(crisManager);

        StorageBackend hcpStorage = new HcpObjectStorage();
        BathDataArchiveService archive = new BathDataArchiveService(ldap, hcpStorage);

        // 2. CRIS Integration Setup
        CrisIntegrationService.CrisProject projectEpsrc = new CrisIntegrationService.CrisProject(
                "CRIS-PROJ-7788", "NextGen Photocatalysis Systems", "EPSRC", "EP/K012345/1");
        archive.getCrisService().registerProject(projectEpsrc);

        // 3. User Story: Familiar Web/Auto-filled Metadata & Opus Publication / DMP Linking
        System.out.println("--- 1. Deposit with Autofill & DMP / Opus Linking ---");
        Dataset dataset1 = archive.createDatasetDraft("smith_a", null, false);
        DatasetMetadata meta1 = archive.prepareMetadataWithDefaults("smith_a",
                "Solar Photocatalysis Reaction Time-Series Data",
                "Kinetic rate experiments of novel metal-organic frameworks under artificial sunlight.",
                "Chemistry");
        meta1.addKeyword("photocatalysis");
        meta1.addKeyword("chemistry");
        meta1.setDmpId("DMP-BATH-CHEM-2023-A");
        meta1.setOpusPublicationId("opus/publications/98765");
        meta1.setCrisProjectId("CRIS-PROJ-7788");
        meta1.setFunderName("EPSRC");
        meta1.setGrantNumber("EP/K012345/1");

        // Arbitrarily large file deposit & Integrity check
        byte[] largeData = "Large RAW spectrometer time-series observations 2023-2024 ... [GB/TB data payload]".getBytes(StandardCharsets.UTF_8);
        StoredFile file1 = archive.uploadFile(dataset1.getDatasetId(), "photocat_kinetics_v1.csv", "text/csv", largeData, false);

        // Version 1 with Embargo and Privileged Off-Campus Collaborator Access
        LocalDate embargoDate = LocalDate.now().plusMonths(6);
        DisposalPolicy policy1 = new DisposalPolicy(10, LocalDate.now().plusYears(10), "Retain for 10 years in line with EPSRC data mandate.");

        DatasetVersion v1 = archive.addVersionToDataset(
                dataset1.getDatasetId(), "smith_a", meta1, License.CC_BY_4_0, policy1, AccessLevel.EMBARGOED, embargoDate,
                List.of(file1), "Initial dataset deposit associated with Opus paper 98765"
        );
        v1.addPrivilegedCollaborator("ext_collab_carol");

        // Submit for Review
        archive.submitForReview(dataset1.getDatasetId());
        System.out.println("Dataset created: ID=" + dataset1.getDatasetId() + ", Status=" + dataset1.getStatus());
        System.out.println("Auto-filled authors: " + v1.getMetadata().getAuthors());
        System.out.println("Linked Opus Publication ID: " + v1.getMetadata().getOpusPublicationId());
        System.out.println("Linked DMP: " + v1.getMetadata().getDmpId());

        // 4. Archive Administrator Review and DOI minting
        System.out.println("\n--- 2. Administrator Quality Check & DOI Minting ---");
        boolean published = archive.adminApproveAndPublish("bath_admin", dataset1.getDatasetId());
        System.out.println("Dataset approved and published? " + published);
        System.out.println("Minted DOI: " + v1.getDoi());
        System.out.println("Persistent URL: " + v1.getPersistentUrl());

        // 5. Versioning (v2 update with transparent changes)
        System.out.println("\n--- 3. Dataset Versioning ---");
        byte[] v2Data = "Updated reaction dataset including calibration factors".getBytes(StandardCharsets.UTF_8);
        StoredFile file2 = archive.uploadFile(dataset1.getDatasetId(), "photocat_kinetics_v2.csv", "text/csv", v2Data, false);
        DatasetVersion v2 = archive.addVersionToDataset(
                dataset1.getDatasetId(), "smith_a", meta1, License.CC_BY_4_0, policy1, AccessLevel.EMBARGOED, embargoDate,
                List.of(file1, file2), "Version 2: Added calibration measurements"
        );
        archive.adminApproveAndPublish("bath_admin", dataset1.getDatasetId());
        System.out.println("Dataset now has versions: " + dataset1.getVersions().size());
        System.out.println("V1 DOI: " + dataset1.getVersion(1).getDoi());
        System.out.println("V2 DOI: " + dataset1.getVersion(2).getDoi());

        // 6. Access Control & Embargo Checks (Privileged Collaborator vs General Reuser)
        System.out.println("\n--- 4. Embargo & Privileged Off-Campus Access ---");
        boolean canReuserAccess = archive.canAccessData(dataset1, v2, null, LocalDate.now(), false);
        boolean canCarolAccess = archive.canAccessData(dataset1, v2, extCollaborator, LocalDate.now(), false);
        System.out.println("Public Reuser access during embargo: " + canReuserAccess + " (Blocked by active embargo)");
        System.out.println("External Collaborator (Carol) access during embargo off-campus: " + canCarolAccess + " (Allowed via privileged list)");

        // 7. Facility Manager depositing on behalf of researcher
        System.out.println("\n--- 5. Facility Manager Delegation Deposit ---");
        Dataset facilityDataset = archive.createDatasetDraft("facility_mgr", "smith_a", false);
        DatasetMetadata facMeta = new DatasetMetadata("MC2 Electron Microscopy Scans", "High-res SEM micrographs", "Materials Science");
        facMeta.addAuthor("Prof. Alice Smith");
        byte[] semImage = "TIFF-RAW-IMAGE-BYTE-STREAM".getBytes(StandardCharsets.UTF_8);
        StoredFile semFile = archive.uploadFile(facilityDataset.getDatasetId(), "micrograph_01.tif", "image/tiff", semImage, false);
        archive.addVersionToDataset(facilityDataset.getDatasetId(), "facility_mgr", facMeta, License.CC0_1_0,
                new DisposalPolicy(5, LocalDate.now().plusYears(5), "5-year facility storage"),
                AccessLevel.OPEN, null, List.of(semFile), "Direct upload from MC2 facility");
        archive.submitForReview(facilityDataset.getDatasetId());
        archive.adminApproveAndPublish("bath_admin", facilityDataset.getDatasetId());
        System.out.println("Facility deposit successful. Owner: " + facilityDataset.getDepositorId() + ", Status: " + facilityDataset.getStatus());

        // 8. SWORD2 API Deposit (VRE / Pure programmatic deposit)
        System.out.println("\n--- 6. SWORD2 / API Ingestion Standard ---");
        SwordDepositRequest swordReq = new SwordDepositRequest(
                "dupont_j", null, "VRE Simulation Run: Quantum Spin States",
                "Automated output from VRE cluster computing environment.",
                "Physics", "CC-BY-4.0", "spin_results.json", "{\"state\": [1, 0, -1]}".getBytes(StandardCharsets.UTF_8)
        );
        Dataset swordDataset = archive.swordDeposit(swordReq);
        archive.adminApproveAndPublish("bath_admin", swordDataset.getDatasetId());
        System.out.println("SWORD API Dataset published. ID: " + swordDataset.getDatasetId() + ", Title: " + swordDataset.getLatestVersion().getMetadata().getTitle());

        // 9. Linking External Repositories (e.g. Zenodo/Dryad registration)
        System.out.println("\n--- 7. Linking Externally Hosted Repositories ---");
        Dataset externalDataset = archive.createDatasetDraft("smith_a", null, true);
        DatasetMetadata extMeta = new DatasetMetadata("Global Climate Models 2024", "External climate simulations hosted at CEDA", "Meteorology");
        extMeta.addAuthor("Prof. Alice Smith");
        extMeta.setExternalRepositoryUrl("https://archive.ceda.ac.uk/record/12345");
        archive.addVersionToDataset(externalDataset.getDatasetId(), "smith_a", extMeta, License.CC_BY_4_0,
                new DisposalPolicy(10, LocalDate.now().plusYears(10), "Maintained externally"),
                AccessLevel.OPEN, null, List.of(), "External link registration");
        archive.submitForReview(externalDataset.getDatasetId());
        archive.adminApproveAndPublish("bath_admin", externalDataset.getDatasetId());
        System.out.println("Registered external dataset. External URL: " + externalDataset.getLatestVersion().getMetadata().getExternalRepositoryUrl());

        // 10. Data Integrity and Fixity Check
        System.out.println("\n--- 8. Data Fixity & Integrity Auditing ---");
        FixityAuditReport audit = archive.auditFileIntegrity(file1.getFileId(), file1.getSha256Checksum(), file1.getFileName());
        System.out.println("Fixity audit for " + audit.getFileName() + " passed: " + audit.isPassed() + " [SHA-256: " + audit.getExpectedSha256() + "]");

        // 11. Discovery & Search (Web, Primo Gateway, Multilingual UI)
        System.out.println("\n--- 9. Discovery, Primo Search, and Multilingual Interface ---");
        List<Dataset> primoResults = archive.primoSearchEndpoint("photocatalysis");
        System.out.println("Primo discovery hits for 'photocatalysis': " + primoResults.size());
        for (Dataset d : primoResults) {
            System.out.println(" - Found in Primo: " + d.getLatestVersion().getMetadata().getTitle());
        }

        System.out.println("UI Localization [EN]: " + archive.getLocalizationService().getMessage("ui.welcome", "en"));
        System.out.println("UI Localization [FR]: " + archive.getLocalizationService().getMessage("ui.welcome", "fr"));
        System.out.println("UI Localization [ES]: " + archive.getLocalizationService().getMessage("ui.welcome", "es"));

        // 12. Citation Generation (APA & BibTeX)
        System.out.println("\n--- 10. Citation Examples ---");
        System.out.println("APA Citation:\n" + archive.getDoiService().formatApaCitation(dataset1, dataset1.getLatestVersion()));
        System.out.println("BibTeX Citation:\n" + archive.getDoiService().formatBibtexCitation(dataset1, dataset1.getLatestVersion()));

        // 13. Metrics Tracking & CRIS Reporting (Downloads segmented by Country and Sector, Citations)
        System.out.println("\n--- 11. Impact Analytics & CRIS Tracking ---");
        archive.getAnalyticsService().logMetric(dataset1.getDatasetId(), 2, UsageMetricRecord.Action.DOWNLOAD, "UK", "ACADEMIC");
        archive.getAnalyticsService().logMetric(dataset1.getDatasetId(), 2, UsageMetricRecord.Action.DOWNLOAD, "UK", "COMMERCIAL");
        archive.getAnalyticsService().logMetric(dataset1.getDatasetId(), 2, UsageMetricRecord.Action.DOWNLOAD, "DE", "ACADEMIC");
        archive.getAnalyticsService().logMetric(dataset1.getDatasetId(), 2, UsageMetricRecord.Action.VIEW, "FR", "PUBLIC");
        archive.getAnalyticsService().recordCitation(dataset1.getDatasetId());
        archive.getAnalyticsService().recordCitation(dataset1.getDatasetId());

        System.out.println("Total views: " + archive.getAnalyticsService().getTotalViews(dataset1.getDatasetId()));
        System.out.println("Total downloads: " + archive.getAnalyticsService().getTotalDownloads(dataset1.getDatasetId()));
        System.out.println("Citation count: " + archive.getAnalyticsService().getCitationCount(dataset1.getDatasetId()));
        System.out.println("Downloads by country: " + archive.getAnalyticsService().getDownloadsByCountry(dataset1.getDatasetId()));
        System.out.println("Downloads by sector: " + archive.getAnalyticsService().getDownloadsBySector(dataset1.getDatasetId()));

        // 14. Funder Harvesting (OAI-PMH / Dublin Core)
        System.out.println("\n--- 12. Funder Harvesting (OAI-PMH Dublin Core) ---");
        List<MetadataHarvestingService.OaiRecord> epsrcHarvest = archive.getHarvestingService()
                .harvestByFunder(new ArrayList<>(archive.getAllDatasets().values()), "EPSRC");
        System.out.println("Harvested records for EPSRC: " + epsrcHarvest.size());
        if (!epsrcHarvest.isEmpty()) {
            System.out.println(epsrcHarvest.get(0).toDublinCoreXml());
        }

        // 15. Admin Wholesale Export and Disposal Approval
        System.out.println("\n--- 13. System Portability & Disposal Policy Enforcement ---");
        byte[] wholesaleBackup = archive.wholesaleExportArchive();
        System.out.println("Exported wholesale archive package size: " + wholesaleBackup.length + " bytes");

        // Disposal review and approval
        archive.approveDisposal("bath_admin", facilityDataset.getDatasetId());
        System.out.println("Facility Dataset status after approved disposal: " + facilityDataset.getStatus());

        System.out.println("\n=== All specification user stories successfully demonstrated ===");
    }
}
