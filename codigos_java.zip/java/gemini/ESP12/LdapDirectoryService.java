import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class LdapDirectoryService {
    private final Map<String, User> directory = new HashMap<>();

    public void registerUser(User user) {
        directory.put(user.getUserId(), user);
    }

    public Optional<User> authenticate(String userId) {
        return Optional.ofNullable(directory.get(userId));
    }

    public Map<String, String> fetchUserProfileMetadata(String userId) {
        Map<String, String> meta = new HashMap<>();
        User user = directory.get(userId);
        if (user != null) {
            meta.put("creator.name", user.getFullName());
            meta.put("creator.email", user.getEmail());
            meta.put("creator.department", user.getDepartment());
            meta.put("creator.institution", "University of Bath");
        }
        return meta;
    }
}
