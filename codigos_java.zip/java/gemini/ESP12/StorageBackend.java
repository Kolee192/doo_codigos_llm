import java.io.InputStream;

public interface StorageBackend {
    void store(String fileId, byte[] data);
    byte[] retrieve(String fileId);
    boolean verifyIntegrity(String fileId, String expectedSha256);
    long getCapacityAvailable();
}
