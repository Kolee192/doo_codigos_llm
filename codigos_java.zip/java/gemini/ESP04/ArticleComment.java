import java.time.LocalDateTime;

public class ArticleComment {
    private final String authorName;
    private final String commentText;
    private final LocalDateTime postedTime;

    public ArticleComment(String authorName, String commentText) {
        this.authorName = authorName;
        this.commentText = commentText;
        this.postedTime = LocalDateTime.now();
    }

    public String getAuthorName() { return authorName; }
    public String getCommentText() { return commentText; }
    public LocalDateTime getPostedTime() { return postedTime; }
}
