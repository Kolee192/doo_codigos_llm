public enum CertificationType {
    CSM,
    CSPO,
    CSP,
    CST
}
