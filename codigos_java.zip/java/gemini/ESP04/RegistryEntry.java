import java.time.LocalDate;

public class RegistryEntry {
    private final String fullName;
    private final String email;
    private final CertificationType certificationType;
    private final String courseId;
    private final LocalDate certificationDate;

    public RegistryEntry(String fullName, String email, CertificationType certificationType, String courseId, LocalDate certificationDate) {
        this.fullName = fullName;
        this.email = email;
        this.certificationType = certificationType;
        this.courseId = courseId;
        this.certificationDate = certificationDate;
    }

    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public CertificationType getCertificationType() { return certificationType; }
    public String getCourseId() { return courseId; }
    public LocalDate getCertificationDate() { return certificationDate; }
}
