import java.time.LocalDate;

public class JobAd {
    private final String id;
    private String recruiterId;
    private String title;
    private String company;
    private String description;
    private boolean approved;
    private LocalDate postedDate;
    private LocalDate expirationDate;

    public JobAd(String id, String recruiterId, String title, String company, String description, LocalDate postedDate) {
        this.id = id;
        this.recruiterId = recruiterId;
        this.title = title;
        this.company = company;
        this.description = description;
        this.postedDate = postedDate;
        this.expirationDate = postedDate.plusDays(30);
        this.approved = false;
    }

    public String getId() { return id; }
    public String getRecruiterId() { return recruiterId; }
    public void setRecruiterId(String recruiterId) { this.recruiterId = recruiterId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public boolean isApproved() { return approved; }
    public void setApproved(boolean approved) { this.approved = approved; }
    public LocalDate getPostedDate() { return postedDate; }
    public void setPostedDate(LocalDate postedDate) { this.postedDate = postedDate; }
    public LocalDate getExpirationDate() { return expirationDate; }
    public void setExpirationDate(LocalDate expirationDate) { this.expirationDate = expirationDate; }

    public void extend30Days() {
        this.expirationDate = this.expirationDate.plusDays(30);
    }

    public boolean isActive(LocalDate currentDate) {
        return approved && !currentDate.isAfter(expirationDate);
    }
}
