import java.time.LocalDate;
import java.util.*;

public class Article {
    private final String id;
    private String title;
    private String authorUserId;
    private String teaser;
    private String body;
    private boolean membersOnly;
    private boolean featuredOnHome;
    private LocalDate startPublishingDate;
    private LocalDate oldArticleDate;
    private LocalDate stopPublishingDate;
    private int viewCount = 0;
    private final List<ArticleComment> comments = new ArrayList<>();

    public Article(String id, String title, String authorUserId, String teaser, String body, boolean membersOnly) {
        this.id = id;
        this.title = title;
        this.authorUserId = authorUserId;
        this.teaser = teaser;
        this.body = body;
        this.membersOnly = membersOnly;
        this.startPublishingDate = LocalDate.now();
        this.oldArticleDate = LocalDate.now().plusMonths(3);
        this.stopPublishingDate = LocalDate.now().plusYears(1);
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getAuthorUserId() { return authorUserId; }
    public String getTeaser() { return teaser; }
    public void setTeaser(String teaser) { this.teaser = teaser; }
    public String getBody() { return body; }
    public void setBody(String body) { this.body = body; }
    public boolean isMembersOnly() { return membersOnly; }
    public void setMembersOnly(boolean membersOnly) { this.membersOnly = membersOnly; }
    public boolean isFeaturedOnHome() { return featuredOnHome; }
    public void setFeaturedOnHome(boolean featuredOnHome) { this.featuredOnHome = featuredOnHome; }
    public LocalDate getStartPublishingDate() { return startPublishingDate; }
    public void setStartPublishingDate(LocalDate startPublishingDate) { this.startPublishingDate = startPublishingDate; }
    public LocalDate getOldArticleDate() { return oldArticleDate; }
    public void setOldArticleDate(LocalDate oldArticleDate) { this.oldArticleDate = oldArticleDate; }
    public LocalDate getStopPublishingDate() { return stopPublishingDate; }
    public void setStopPublishingDate(LocalDate stopPublishingDate) { this.stopPublishingDate = stopPublishingDate; }
    public int getViewCount() { return viewCount; }
    public void incrementViewCount() { this.viewCount++; }
    public List<ArticleComment> getComments() { return Collections.unmodifiableList(comments); }
    public void addComment(ArticleComment comment) { comments.add(comment); }

    public boolean isPublishable(LocalDate today) {
        return (today.isEqual(startPublishingDate) || today.isAfter(startPublishingDate)) &&
               today.isBefore(stopPublishingDate);
    }
}
