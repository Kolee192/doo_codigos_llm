import java.time.LocalDate;

public class NewsItem {
    private final String id;
    private String title;
    private String content;
    private int priority; // higher means more prominent
    private LocalDate startPublishingDate;
    private LocalDate oldNewsDate;
    private LocalDate stopPublishingDate;

    public NewsItem(String id, String title, String content, int priority, 
                    LocalDate startPublishingDate, LocalDate oldNewsDate, LocalDate stopPublishingDate) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.priority = priority;
        this.startPublishingDate = startPublishingDate;
        this.oldNewsDate = oldNewsDate;
        this.stopPublishingDate = stopPublishingDate;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public LocalDate getStartPublishingDate() { return startPublishingDate; }
    public void setStartPublishingDate(LocalDate startPublishingDate) { this.startPublishingDate = startPublishingDate; }
    public LocalDate getOldNewsDate() { return oldNewsDate; }
    public void setOldNewsDate(LocalDate oldNewsDate) { this.oldNewsDate = oldNewsDate; }
    public LocalDate getStopPublishingDate() { return stopPublishingDate; }
    public void setStopPublishingDate(LocalDate stopPublishingDate) { this.stopPublishingDate = stopPublishingDate; }

    public boolean isCurrent(LocalDate today) {
        return (today.isEqual(startPublishingDate) || today.isAfter(startPublishingDate)) &&
               today.isBefore(oldNewsDate) &&
               today.isBefore(stopPublishingDate);
    }

    public boolean isOld(LocalDate today) {
        return (today.isEqual(oldNewsDate) || today.isAfter(oldNewsDate)) &&
               today.isBefore(stopPublishingDate);
    }
}
