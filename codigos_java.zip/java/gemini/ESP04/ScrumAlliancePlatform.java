import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class ScrumAlliancePlatform {
    private final EmailService emailService = new EmailService();

    // In-memory repositories
    private final Map<String, User> users = new HashMap<>();
    private final Map<String, CertificationApplication> applications = new HashMap<>();
    private final Map<String, NewsItem> news = new HashMap<>();
    private final Map<String, CourseEvent> coursesEvents = new HashMap<>();
    private final Map<String, JobAd> jobAds = new HashMap<>();
    private final Map<String, Article> articles = new HashMap<>();
    private final Map<String, FAQItem> faqs = new HashMap<>();
    private final List<DownloadResource> downloads = new ArrayList<>();
    private final List<SurveyResponse> surveys = new ArrayList<>();
    private final Map<String, CorporateSponsor> sponsors = new HashMap<>();
    private final List<RegistryEntry> registry = new ArrayList<>();
    private final Map<String, List<PendingClassAttendee>> pendingClassRosters = new HashMap<>();
    private final List<String> trainerOnlyNotices = new ArrayList<>();

    // Configurable system settings
    private double otherListingFee = 50.0;
    private double memberAnnualFee = 100.0;
    private double practitionerAnnualFee = 150.0;
    private double trainerAnnualFee = 500.0;
    private String specialAnnouncement = "Welcome to Scrum Alliance!";
    private String whatIsScrumContent = "Scrum is an agile framework for developing, delivering, and sustaining products.";
    private String whatIsCsmContent = "CSM (Certified ScrumMaster) helps you master agile fundamentals and lead agile teams.";
    private String newCertEmailTemplate = "Hello %s, welcome to Scrum Alliance as a newly certified %s! Please visit our site to activate your membership.";

    public ScrumAlliancePlatform() {
        initDefaults();
    }

    private void initDefaults() {
        // Site Admin & Editor default
        User admin = new User("usr-admin", "admin", "admin123", "admin@scrumalliance.org", "Alice Administrator", Role.ADMIN);
        User editor = new User("usr-editor", "editor", "editor123", "editor@scrumalliance.org", "Edward Editor", Role.EDITOR);
        users.put(admin.getId(), admin);
        users.put(editor.getId(), editor);

        // Downloadables
        downloads.add(new DownloadResource("dl-1", "Scrum Guide 2020", "scrum_guide_2020.pdf", false));
        downloads.add(new DownloadResource("dl-2", "CSM Training Material Slides", "csm_slides.pdf", true));
    }

    public EmailService getEmailService() { return emailService; }

    // --- User & Profile Management ---
    public void registerUser(User user) {
        users.put(user.getId(), user);
    }

    public User getUser(String userId) {
        return users.get(userId);
    }

    public User getUserByUsername(String username) {
        return users.values().stream()
                .filter(u -> u.getUsername().equalsIgnoreCase(username))
                .findFirst().orElse(null);
    }

    public void updateMemberProfile(String userId, String bio, String location, String company, boolean profilePrivate, boolean emailPrivate) {
        User u = users.get(userId);
        if (u != null) {
            u.setBio(bio);
            u.setLocation(location);
            u.setCompany(company);
            u.setProfilePrivate(profilePrivate);
            u.setEmailPrivate(emailPrivate);
        }
    }

    public void adminEditProfile(String adminUserId, String targetUserId, String newName, String newEmail, String newBio) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) {
            throw new SecurityException("Only administrators can edit other profiles");
        }
        User target = users.get(targetUserId);
        if (target != null) {
            target.setFullName(newName);
            target.setEmail(newEmail);
            target.setBio(newBio);
        }
    }

    public String viewProfile(String targetUserId, String viewerUserId) {
        User target = users.get(targetUserId);
        if (target == null) return "User not found";
        
        if (target.isProfilePrivate()) {
            return String.format("Profile: [Private] Name: %s", target.getFullName());
        }

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Profile of: %s %s\n", target.getFullName(), target.getCertificationBadge()));
        if (!target.isEmailPrivate()) {
            sb.append(String.format("Email: %s\n", target.getEmail()));
        } else {
            sb.append("Email: [Private]\n");
        }
        sb.append(String.format("Bio: %s\nLocation: %s\nCompany: %s\n", target.getBio(), target.getLocation(), target.getCompany()));
        if (target.getRole() == Role.PRACTITIONER || target.getCertifications().contains(CertificationType.CSP)) {
            sb.append(String.format("Practitioner Experience: %s\n", target.getExperienceDetails()));
        }
        if (target.getRole() == Role.TRAINER || target.getCertifications().contains(CertificationType.CST)) {
            sb.append(String.format("Trainer Philosophy: %s\n", target.getTrainerPhilosophy()));
            sb.append(String.format("Trainer Rating: %.2f / 5.0\n", getTrainerAverageRating(target.getId())));
            sb.append("Upcoming Classes:\n");
            for (CourseEvent ce : getUpcomingTrainerCourses(target.getId())) {
                sb.append(String.format(" - %s at %s (Starts: %s) [Link: /course/%s]\n", ce.getTitle(), ce.getLocation(), ce.getStartDate(), ce.getId()));
            }
        }
        return sb.toString();
    }

    public List<User> searchProfiles(String nameKeyword, String locationKeyword) {
        return users.values().stream()
                .filter(u -> !u.isProfilePrivate())
                .filter(u -> nameKeyword == null || u.getFullName().toLowerCase().contains(nameKeyword.toLowerCase()))
                .filter(u -> locationKeyword == null || (u.getLocation() != null && u.getLocation().toLowerCase().contains(locationKeyword.toLowerCase())))
                .collect(Collectors.toList());
    }

    public void sendEmailViaForm(String senderEmail, String targetUserId, String subject, String message) {
        User target = users.get(targetUserId);
        if (target == null) {
            throw new IllegalArgumentException("Recipient not found");
        }
        // Send email even if target's email address is private, because form masks the direct email
        emailService.sendEmail(senderEmail, target.getEmail(), subject, message);
    }

    public void requestPasswordReminder(String email) {
        User user = users.values().stream().filter(u -> u.getEmail().equalsIgnoreCase(email)).findFirst().orElse(null);
        if (user != null) {
            emailService.sendEmail("support@scrumalliance.org", user.getEmail(), "Password Reminder", "Your password is: " + user.getPassword());
        }
    }

    // --- Certification Applications ---
    public CertificationApplication applyForCertification(String userId, CertificationType certType, String summary) {
        String appId = "app-" + UUID.randomUUID().toString().substring(0, 8);
        CertificationApplication app = new CertificationApplication(appId, userId, certType, summary);
        applications.put(appId, app);
        return app;
    }

    public List<CertificationApplication> getPendingApplications(String adminUserId) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");
        return applications.values().stream().filter(a -> a.getStatus() == ApplicationStatus.PENDING).collect(Collectors.toList());
    }

    public void evaluateApplication(String adminUserId, String applicationId, boolean approve) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");
        CertificationApplication app = applications.get(applicationId);
        if (app != null) {
            app.setStatus(approve ? ApplicationStatus.APPROVED : ApplicationStatus.REJECTED);
            if (approve) {
                User applicant = users.get(app.getApplicantUserId());
                if (applicant != null) {
                    applicant.addCertification(app.getDesiredCert());
                    if (app.getDesiredCert() == CertificationType.CSP) {
                        applicant.setRole(Role.PRACTITIONER);
                        // Practitioner activation fee notice
                        emailService.sendEmail("billing@scrumalliance.org", applicant.getEmail(), "Practitioner Approval", 
                            "Congratulations! Please pay the activation fee of $" + practitionerAnnualFee + " to activate your CSP status.");
                    } else if (app.getDesiredCert() == CertificationType.CST) {
                        applicant.setRole(Role.TRAINER);
                        emailService.sendEmail("billing@scrumalliance.org", applicant.getEmail(), "CST Approval", 
                            "Congratulations! Your CST status is approved. Annual fee is $" + trainerAnnualFee);
                    }
                }
            }
        }
    }

    // --- News Management ---
    public void addNewsItem(String editorUserId, NewsItem item) {
        User editor = users.get(editorUserId);
        if (editor == null || (editor.getRole() != Role.EDITOR && editor.getRole() != Role.ADMIN)) {
            throw new SecurityException("Editor or Admin required");
        }
        news.put(item.getId(), item);
    }

    public void submitNewsTipToEditor(String submitterEmail, String title, String body) {
        emailService.sendEmail(submitterEmail, "editor@scrumalliance.org", "News Submission: " + title, body);
    }

    public List<NewsItem> getCurrentNews(LocalDate date) {
        return news.values().stream()
                .filter(n -> n.isCurrent(date))
                .sorted(Comparator.comparingInt(NewsItem::getPriority).reversed())
                .collect(Collectors.toList());
    }

    public List<NewsItem> getOldNews(LocalDate date) {
        return news.values().stream()
                .filter(n -> n.isOld(date))
                .sorted(Comparator.comparing(NewsItem::getOldNewsDate).reversed())
                .collect(Collectors.toList());
    }

    public String getNewsRssFeed(LocalDate date) {
        StringBuilder rss = new StringBuilder("<rss><channel><title>Scrum Alliance News</title>");
        for (NewsItem n : getCurrentNews(date)) {
            rss.append(String.format("<item><title>%s</title><description>%s</description></item>", n.getTitle(), n.getContent()));
        }
        rss.append("</channel></rss>");
        return rss.toString();
    }

    // --- Courses and Events ---
    public void setOtherListingFee(String adminUserId, double fee) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");
        this.otherListingFee = fee;
    }

    public double getOtherListingFee() { return otherListingFee; }

    public CourseEvent createCourseOrEvent(String creatorUserId, CourseEvent item) {
        User creator = users.get(creatorUserId);
        if (creator == null) throw new IllegalArgumentException("User not found");

        if (creator.getRole() == Role.TRAINER) {
            // Charging listing fee for Other Course or Event
            if (item.getType() == ItemType.OTHER_COURSE || item.getType() == ItemType.EVENT) {
                item.setFeeCharged(this.otherListingFee);
            }
        } else if (creator.getRole() == Role.ADMIN) {
            // Admin creates for free (e.g. Scrum Gatherings)
            item.setFeeCharged(0.0);
        } else {
            throw new SecurityException("Only trainers or admins can create courses/events");
        }

        coursesEvents.put(item.getId(), item);
        return item;
    }

    public void updateCourseOrEvent(String userId, String itemId, String newTitle, String newDesc, LocalDate start, LocalDate end) {
        User u = users.get(userId);
        CourseEvent ce = coursesEvents.get(itemId);
        if (ce == null) return;
        if (u.getRole() == Role.ADMIN || u.getRole() == Role.EDITOR || ce.getTrainerId().equals(userId)) {
            ce.setTitle(newTitle);
            ce.setDescription(newDesc);
            ce.setStartDate(start);
            ce.setEndDate(end);
        } else {
            throw new SecurityException("Not authorized to update this course/event");
        }
    }

    public void deleteCourseOrEvent(String userId, String itemId) {
        User u = users.get(userId);
        CourseEvent ce = coursesEvents.get(itemId);
        if (ce == null) return;
        if (u.getRole() == Role.ADMIN || ce.getTrainerId().equals(userId)) {
            coursesEvents.remove(itemId);
        } else {
            throw new SecurityException("Not authorized to delete this course/event");
        }
    }

    public CourseEvent copyCourseOrEvent(String trainerUserId, String itemId, String newItemId) {
        CourseEvent existing = coursesEvents.get(itemId);
        if (existing == null) throw new IllegalArgumentException("Item not found");
        if (!existing.getTrainerId().equals(trainerUserId)) throw new SecurityException("Can only copy own items");
        CourseEvent copy = existing.copy(newItemId);
        coursesEvents.put(newItemId, copy);
        return copy;
    }

    public void changeCourseEventType(String userId, String itemId, ItemType newType) {
        User u = users.get(userId);
        CourseEvent ce = coursesEvents.get(itemId);
        if (ce == null) return;
        if (u.getRole() == Role.ADMIN || ce.getTrainerId().equals(userId)) {
            ce.setType(newType);
        } else {
            throw new SecurityException("Not authorized to switch type");
        }
    }

    public List<CourseEvent> getUpcomingTrainerCourses(String trainerId) {
        LocalDate now = LocalDate.now();
        return coursesEvents.values().stream()
                .filter(c -> c.getTrainerId().equals(trainerId))
                .filter(c -> !c.getStartDate().isBefore(now))
                .sorted(Comparator.comparing(CourseEvent::getStartDate))
                .collect(Collectors.toList());
    }

    public List<CourseEvent> pageUpcomingCertificationCourses(int page, int pageSize) {
        LocalDate now = LocalDate.now();
        return coursesEvents.values().stream()
                .filter(c -> c.getType() == ItemType.CERTIFICATION_COURSE)
                .filter(c -> !c.getStartDate().isBefore(now))
                .sorted(Comparator.comparing(CourseEvent::getStartDate))
                .skip((long) page * pageSize)
                .limit(pageSize)
                .collect(Collectors.toList());
    }

    public List<CourseEvent> pageUpcomingOtherCourses(int page, int pageSize) {
        LocalDate now = LocalDate.now();
        return coursesEvents.values().stream()
                .filter(c -> c.getType() == ItemType.OTHER_COURSE)
                .filter(c -> !c.getStartDate().isBefore(now))
                .sorted(Comparator.comparing(CourseEvent::getStartDate))
                .skip((long) page * pageSize)
                .limit(pageSize)
                .collect(Collectors.toList());
    }

    public List<CourseEvent> getUpcomingEvents() {
        LocalDate now = LocalDate.now();
        return coursesEvents.values().stream()
                .filter(c -> c.getType() == ItemType.EVENT)
                .filter(c -> !c.getStartDate().isBefore(now))
                .sorted(Comparator.comparing(CourseEvent::getStartDate))
                .collect(Collectors.toList());
    }

    public List<CourseEvent> advancedSearchCoursesEvents(ItemType type, String keyword, String location, LocalDate fromDate) {
        return coursesEvents.values().stream()
                .filter(c -> type == null || c.getType() == type)
                .filter(c -> keyword == null || c.getTitle().toLowerCase().contains(keyword.toLowerCase()) || c.getDescription().toLowerCase().contains(keyword.toLowerCase()))
                .filter(c -> location == null || c.getLocation().toLowerCase().contains(location.toLowerCase()))
                .filter(c -> fromDate == null || !c.getStartDate().isBefore(fromDate))
                .collect(Collectors.toList());
    }

    public String getCoursesAndEventsRssFeed() {
        StringBuilder rss = new StringBuilder("<rss><channel><title>Scrum Alliance Courses and Events</title>");
        coursesEvents.values().stream()
                .filter(c -> !c.getStartDate().isBefore(LocalDate.now()))
                .sorted(Comparator.comparing(CourseEvent::getStartDate))
                .forEach(c -> rss.append(String.format("<item><title>%s</title><link>/course/%s</link><desc>%s at %s</desc></item>", 
                        c.getTitle(), c.getId(), c.getType(), c.getLocation())));
        rss.append("</channel></rss>");
        return rss.toString();
    }

    // --- FAQs ---
    public void addOrUpdateFAQ(String editorUserId, FAQItem item) {
        User editor = users.get(editorUserId);
        if (editor == null || (editor.getRole() != Role.EDITOR && editor.getRole() != Role.ADMIN)) {
            throw new SecurityException("Editor or Admin required");
        }
        faqs.put(item.getId(), item);
    }

    public List<FAQItem> getAllFAQs() {
        return new ArrayList<>(faqs.values());
    }

    public List<FAQItem> searchFAQs(String query) {
        String q = query.toLowerCase();
        return faqs.values().stream()
                .filter(f -> f.getQuestion().toLowerCase().contains(q) || f.getAnswer().toLowerCase().contains(q))
                .collect(Collectors.toList());
    }

    // --- Downloads ---
    public void addDownloadResource(DownloadResource resource) {
        downloads.add(resource);
    }

    public List<DownloadResource> getDownloadableResources(Role viewerRole) {
        boolean isMemberOrAbove = viewerRole != Role.VISITOR;
        return downloads.stream()
                .filter(d -> !d.isMembersOnly() || isMemberOrAbove)
                .collect(Collectors.toList());
    }

    // --- Jobs / Help Wanted ---
    public JobAd postJobAd(String recruiterId, String title, String company, String description) {
        JobAd job = new JobAd("job-" + UUID.randomUUID().toString().substring(0, 8), recruiterId, title, company, description, LocalDate.now());
        jobAds.put(job.getId(), job);
        // Email site admin
        emailService.sendEmail("recruiting@scrumalliance.org", "admin@scrumalliance.org", 
            "New Job Submitted: " + title, "A job has been posted by recruiter: " + recruiterId);
        return job;
    }

    public void approveJobAd(String adminUserId, String jobId, boolean approve) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");
        JobAd job = jobAds.get(jobId);
        if (job != null) job.setApproved(approve);
    }

    public void editOrDeleteJobAd(String adminUserId, String jobId, String newTitle, String newDesc, boolean delete) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");
        if (delete) {
            jobAds.remove(jobId);
        } else {
            JobAd job = jobAds.get(jobId);
            if (job != null) {
                job.setTitle(newTitle);
                job.setDescription(newDesc);
            }
        }
    }

    public void extendJobAd(String recruiterUserId, String jobId) {
        JobAd job = jobAds.get(jobId);
        if (job != null && job.getRecruiterId().equals(recruiterUserId)) {
            job.extend30Days();
        }
    }

    public void sendJobExpirationReminders(LocalDate currentDate) {
        for (JobAd job : jobAds.values()) {
            if (job.isApproved() && job.getExpirationDate().minusDays(7).isEqual(currentDate)) {
                User rec = users.get(job.getRecruiterId());
                String email = rec != null ? rec.getEmail() : "recruiter@domain.com";
                emailService.sendEmail("jobs@scrumalliance.org", email, 
                    "Job Posting Expiring Soon", "Your job posting '" + job.getTitle() + "' will expire in 7 days. Log in to extend.");
            }
        }
    }

    public List<JobAd> getActiveJobs(LocalDate currentDate) {
        return jobAds.values().stream()
                .filter(j -> j.isActive(currentDate))
                .collect(Collectors.toList());
    }

    public String getJobRssFeed(LocalDate currentDate) {
        StringBuilder rss = new StringBuilder("<rss><channel><title>Scrum Alliance Jobs</title>");
        for (JobAd j : getActiveJobs(currentDate)) {
            rss.append(String.format("<item><title>%s at %s</title><desc>%s</desc></item>", j.getTitle(), j.getCompany(), j.getDescription()));
        }
        rss.append("</channel></rss>");
        return rss.toString();
    }

    // --- Articles ---
    public void addArticle(String editorUserId, Article article) {
        User editor = users.get(editorUserId);
        if (editor == null || (editor.getRole() != Role.EDITOR && editor.getRole() != Role.ADMIN)) {
            throw new SecurityException("Editor or Admin required");
        }
        articles.put(article.getId(), article);
    }

    public void practitionerSubmitArticle(String practitionerUserId, Article article) {
        User user = users.get(practitionerUserId);
        if (user == null || (user.getRole() != Role.PRACTITIONER && user.getRole() != Role.TRAINER)) {
            throw new SecurityException("Must be a certified practitioner or trainer to author articles");
        }
        articles.put(article.getId(), article);
    }

    public Article getArticleForReading(String articleId, Role viewerRole) {
        Article art = articles.get(articleId);
        if (art == null) return null;
        if (art.isMembersOnly() && viewerRole == Role.VISITOR) {
            throw new SecurityException("Members-only article. Please sign in or join!");
        }
        art.incrementViewCount();
        return art;
    }

    public List<Article> getFrontPageArticles(LocalDate date) {
        return articles.values().stream()
                .filter(a -> a.isPublishable(date) && a.isFeaturedOnHome())
                .collect(Collectors.toList());
    }

    public List<Article> searchArticles(String query) {
        String q = query.toLowerCase();
        return articles.values().stream()
                .filter(a -> a.getTitle().toLowerCase().contains(q) ||
                             a.getBody().toLowerCase().contains(q) ||
                             (users.containsKey(a.getAuthorUserId()) && users.get(a.getAuthorUserId()).getFullName().toLowerCase().contains(q)))
                .collect(Collectors.toList());
    }

    public String getArticleRssFeed(LocalDate date) {
        StringBuilder rss = new StringBuilder("<rss><channel><title>Scrum Alliance Articles</title>");
        for (Article art : articles.values()) {
            if (art.isPublishable(date) && !art.isMembersOnly()) {
                rss.append(String.format("<item><title>%s</title><teaser>%s</teaser></item>", art.getTitle(), art.getTeaser()));
            }
        }
        rss.append("</channel></rss>");
        return rss.toString();
    }

    public void postArticleComment(String articleId, String authorName, String commentText) {
        Article art = articles.get(articleId);
        if (art != null) {
            art.addComment(new ArticleComment(authorName, commentText));
        }
    }

    public List<Article> getMostPopularArticles(int limit) {
        return articles.values().stream()
                .sorted(Comparator.comparingInt(Article::getViewCount).reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }

    // --- Survey and Trainer Ratings ---
    public boolean submitCourseSurvey(SurveyResponse survey) {
        // Prevent duplicate answers by same participant for same class
        boolean alreadySubmitted = surveys.stream()
                .anyMatch(s -> s.getCourseId().equals(survey.getCourseId()) &&
                               s.getParticipantEmail().equalsIgnoreCase(survey.getParticipantEmail()));
        if (alreadySubmitted) {
            return false;
        }
        surveys.add(survey);
        
        CourseEvent course = coursesEvents.get(survey.getCourseId());
        if (course != null) {
            User trainer = users.get(course.getTrainerId());
            if (trainer != null) {
                emailService.sendEmail("surveys@scrumalliance.org", trainer.getEmail(), 
                    "New Survey Result for " + course.getTitle(), 
                    String.format("Participant rated %d/5: %s", survey.getRating(), survey.getFeedback()));
            }
        }
        return true;
    }

    public double getCourseAverageRating(String courseId) {
        return surveys.stream()
                .filter(s -> s.getCourseId().equals(courseId))
                .mapToInt(SurveyResponse::getRating)
                .average().orElse(0.0);
    }

    public double getTrainerAverageRating(String trainerUserId) {
        List<String> trainerCourseIds = coursesEvents.values().stream()
                .filter(c -> c.getTrainerId().equals(trainerUserId))
                .map(CourseEvent::getId)
                .toList();

        return surveys.stream()
                .filter(s -> trainerCourseIds.contains(s.getCourseId()))
                .mapToInt(SurveyResponse::getRating)
                .average().orElse(0.0);
    }

    public Map<String, Double> adminGetTrainerRatingAverages(String adminUserId) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");

        Map<String, Double> map = new HashMap<>();
        for (User u : users.values()) {
            if (u.getRole() == Role.TRAINER) {
                map.put(u.getFullName(), getTrainerAverageRating(u.getId()));
            }
        }
        return map;
    }

    // --- Roster, Pending Classes & Registry ---
    public void trainerUploadCourseRoster(String trainerUserId, String courseId, List<PendingClassAttendee> attendees) {
        CourseEvent ce = coursesEvents.get(courseId);
        if (ce == null || !ce.getTrainerId().equals(trainerUserId)) {
            throw new SecurityException("Can only upload roster for your own courses");
        }
        ce.setPending(true);
        pendingClassRosters.put(courseId, new ArrayList<>(attendees));
    }

    public List<CourseEvent> getPendingClasses(String adminUserId) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");
        return coursesEvents.values().stream().filter(CourseEvent::isPending).collect(Collectors.toList());
    }

    public void adminApproveClassPaymentAndMoveToRegistry(String adminUserId, String courseId) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");

        CourseEvent ce = coursesEvents.get(courseId);
        if (ce != null && ce.isPending()) {
            List<PendingClassAttendee> attendees = pendingClassRosters.getOrDefault(courseId, Collections.emptyList());
            for (PendingClassAttendee a : attendees) {
                registry.add(new RegistryEntry(a.getFullName(), a.getEmail(), a.getCertificationType(), courseId, LocalDate.now()));
                // Send automated welcoming email
                String emailBody = String.format(newCertEmailTemplate, a.getFullName(), a.getCertificationType());
                emailService.sendEmail("registry@scrumalliance.org", a.getEmail(), "Welcome to Scrum Alliance!", emailBody);
            }
            ce.setPending(false);
            pendingClassRosters.remove(courseId);
        }
    }

    public void editNewCertEmailTemplate(String editorUserId, String template) {
        User editor = users.get(editorUserId);
        if (editor == null || (editor.getRole() != Role.EDITOR && editor.getRole() != Role.ADMIN)) {
            throw new SecurityException("Editor or Admin required");
        }
        this.newCertEmailTemplate = template;
    }

    public List<RegistryEntry> getRegistryByCertification(CertificationType certType) {
        return registry.stream()
                .filter(r -> r.getCertificationType() == certType)
                .collect(Collectors.toList());
    }

    // --- Corporate Sponsorship ---
    public void registerCorporateSponsor(CorporateSponsor sponsor, double paymentAmount) {
        if (paymentAmount >= 1000.0) {
            sponsor.setPaidFee(true);
            sponsors.put(sponsor.getId(), sponsor);
        }
    }

    public List<CorporateSponsor> getCorporateSponsors() {
        return sponsors.values().stream().filter(CorporateSponsor::isPaidFee).collect(Collectors.toList());
    }

    public CorporateSponsor getRandomSponsorForHome() {
        List<CorporateSponsor> active = getCorporateSponsors();
        if (active.isEmpty()) return null;
        int idx = new Random().nextInt(active.size());
        return active.get(idx);
    }

    // --- Membership Renewals & Fees ---
    public void setAnnualFees(String adminUserId, double memberFee, double practitionerFee, double trainerFee) {
        User admin = users.get(adminUserId);
        if (admin == null || admin.getRole() != Role.ADMIN) throw new SecurityException("Admin required");
        this.memberAnnualFee = memberFee;
        this.practitionerAnnualFee = practitionerFee;
        this.trainerAnnualFee = trainerFee;
    }

    public void sendRenewalReminders(LocalDate today) {
        for (User u : users.values()) {
            if (u.getMembershipRenewalDate() != null && u.getMembershipRenewalDate().minusDays(30).isEqual(today)) {
                emailService.sendEmail("membership@scrumalliance.org", u.getEmail(), 
                    "Membership Renewal Reminder", 
                    "Your membership will expire in 30 days. Renew here: https://scrumalliance.org/renew?id=" + u.getId());
            }
        }
    }

    public void payTrainerAnnualFee(String trainerUserId, double amount) {
        if (amount >= trainerAnnualFee) {
            User u = users.get(trainerUserId);
            if (u != null && u.getRole() == Role.TRAINER) {
                u.setMembershipRenewalDate(LocalDate.now().plusYears(1));
                u.setActiveMembership(true);
            }
        }
    }

    // --- Trainers-Only Section ---
    public void postTrainersNotice(String editorUserId, String notice) {
        User ed = users.get(editorUserId);
        if (ed == null || (ed.getRole() != Role.EDITOR && ed.getRole() != Role.ADMIN)) {
            throw new SecurityException("Editor or Admin required");
        }
        trainerOnlyNotices.add(notice);
    }

    public List<String> getTrainersSection(String userId) {
        User u = users.get(userId);
        if (u == null || (u.getRole() != Role.TRAINER && u.getRole() != Role.ADMIN)) {
            throw new SecurityException("Access denied: Trainers only");
        }
        return Collections.unmodifiableList(trainerOnlyNotices);
    }

    // --- Home Page Content & Navigation ---
    public String getSpecialAnnouncement() { return specialAnnouncement; }
    public void setSpecialAnnouncement(String editorUserId, String text) {
        User ed = users.get(editorUserId);
        if (ed == null || (ed.getRole() != Role.EDITOR && ed.getRole() != Role.ADMIN)) {
            throw new SecurityException("Editor or Admin required");
        }
        this.specialAnnouncement = text;
    }

    public String getWhatIsScrumContent() { return whatIsScrumContent; }
    public void setWhatIsScrumContent(String editorUserId, String content) {
        User ed = users.get(editorUserId);
        if (ed == null || (ed.getRole() != Role.EDITOR && ed.getRole() != Role.ADMIN)) {
            throw new SecurityException("Editor or Admin required");
        }
        this.whatIsScrumContent = content;
    }

    public String getWhatIsCsmContent() { return whatIsCsmContent; }
    public void setWhatIsCsmContent(String editorUserId, String content) {
        User ed = users.get(editorUserId);
        if (ed == null || (ed.getRole() != Role.EDITOR && ed.getRole() != Role.ADMIN)) {
            throw new SecurityException("Editor or Admin required");
        }
        this.whatIsCsmContent = content;
    }

    public String renderHomePage(LocalDate today) {
        StringBuilder sb = new StringBuilder();
        sb.append("=================== SCRUM ALLIANCE HOME ===================\n");
        sb.append("PROMINENT ANNOUNCEMENT: ").append(specialAnnouncement).append("\n\n");
        sb.append("--- WHAT IS SCRUM & WHY ALLIANCE? ---\n").append(whatIsScrumContent).append("\n\n");
        sb.append("--- WHAT IS A CSM & WHY BE ONE? ---\n").append(whatIsCsmContent).append("\n\n");

        CorporateSponsor randSponsor = getRandomSponsorForHome();
        if (randSponsor != null) {
            sb.append(String.format("FEATURED CORPORATE SPONSOR: %s [Logo: %s]\n\n", randSponsor.getCompanyName(), randSponsor.getLogoUrl()));
        }

        sb.append("--- TOP NEWS ---\n");
        for (NewsItem n : getCurrentNews(today)) {
            sb.append(String.format(" * [P%d] %s: %s\n", n.getPriority(), n.getTitle(), n.getContent()));
        }

        sb.append("\n--- FEATURED ARTICLES ---\n");
        for (Article a : getFrontPageArticles(today)) {
            sb.append(String.format(" * %s (Teaser: %s) -> Read at /article/%s\n", a.getTitle(), a.getTeaser(), a.getId()));
        }

        sb.append("\n--- UPCOMING HIGHLIGHTS ---\n");
        List<CourseEvent> courses = pageUpcomingCertificationCourses(0, 3);
        for (CourseEvent c : courses) {
            User trainer = users.get(c.getTrainerId());
            String tName = trainer != null ? trainer.getFullName() : "Staff";
            sb.append(String.format(" * Course: %s by %s (Trainer Profile: /user/%s)\n", c.getTitle(), tName, c.getTrainerId()));
        }
        sb.append("===========================================================\n");
        return sb.toString();
    }
}
