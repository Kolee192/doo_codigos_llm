import java.time.LocalDate;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("Starting Scrum Alliance Platform Demo...\n");
        ScrumAlliancePlatform platform = new ScrumAlliancePlatform();
        LocalDate today = LocalDate.of(2025, 3, 1);

        // 1. Members, Practitioners, Trainers registration & semi-structured profiles
        User member = new User("u-101", "john_dev", "pass1", "john@example.com", "John Doe", Role.MEMBER);
        platform.registerUser(member);
        platform.updateMemberProfile(member.getId(), "Passionate agile developer", "Chicago, IL", "Acme Tech", false, true);

        User trainer = new User("u-201", "sarah_cst", "pass2", "sarah@agilesolutions.com", "Sarah CST", Role.TRAINER);
        trainer.addCertification(CertificationType.CST);
        trainer.setTrainerPhilosophy("Interactive, hands-on learning with real-world scenarios.");
        platform.registerUser(trainer);

        System.out.println("--- User Profile Viewing (Email Private Test) ---");
        System.out.println(platform.viewProfile(member.getId(), "visitor"));

        // 2. Private member profile
        User privateUser = new User("u-102", "bob_stealth", "pass", "bob@secret.org", "Bob Hidden", Role.MEMBER);
        platform.registerUser(privateUser);
        platform.updateMemberProfile(privateUser.getId(), "Super secret", "Unknown", "Incognito", true, true);
        System.out.println("--- Private Profile (Only name visible) ---");
        System.out.println(platform.viewProfile(privateUser.getId(), "visitor"));

        // 3. Email via form
        platform.sendEmailViaForm("john@example.com", member.getId(), "Hello John", "Wanted to connect on Scrum topic.");
        System.out.println("Form Email Sent: " + platform.getEmailService().getLastSentEmail());

        // 4. Application to become CSP and CST
        CertificationApplication appCsp = platform.applyForCertification(member.getId(), CertificationType.CSP, "5 years working as ScrumMaster");
        System.out.println("\nApplication submitted: " + appCsp.getApplicationId() + " Status: " + appCsp.getStatus());
        platform.evaluateApplication("usr-admin", appCsp.getApplicationId(), true);
        System.out.println("Application approved: " + appCsp.getStatus() + ", User Role: " + member.getRole());
        System.out.println("CSP Badge: " + member.getCertificationBadge());

        // 5. Practitioner writes article with certification graphic badge
        Article art = new Article("art-1", "Adopting Scrum in Enterprise", member.getId(), 
            "A short teaser on agile scaling...", "Full text about agile transformation and Scrum rituals.", false);
        art.setFeaturedOnHome(true);
        platform.practitionerSubmitArticle(member.getId(), art);
        System.out.println("\nArticle Published by " + member.getFullName() + " " + member.getCertificationBadge());

        // Comment on article & view count increment
        platform.postArticleComment(art.getId(), "Alice", "Excellent practical insights!");
        platform.getArticleForReading(art.getId(), Role.VISITOR);
        System.out.println("Article view count: " + art.getViewCount() + ", Comments: " + art.getComments().size());

        // 6. Trainer courses & events, fee charging for Other Course/Event
        CourseEvent csmCourse = new CourseEvent("crs-301", "Certified ScrumMaster (CSM)", ItemType.CERTIFICATION_COURSE, 
                trainer.getId(), "New York / Virtual", today.plusDays(10), today.plusDays(12), "Complete CSM course");
        platform.createCourseOrEvent(trainer.getId(), csmCourse);

        CourseEvent agileWorkshop = new CourseEvent("crs-302", "Agile Coaching Workshop", ItemType.OTHER_COURSE, 
                trainer.getId(), "Chicago", today.plusDays(20), today.plusDays(21), "Deep dive coaching");
        platform.createCourseOrEvent(trainer.getId(), agileWorkshop);
        System.out.println(String.format("\nListing fee charged to trainer for Other Course '%s': $%.2f", agileWorkshop.getTitle(), agileWorkshop.getFeeCharged()));

        // Admin creates Gathering event without listing fee
        CourseEvent gathering = new CourseEvent("evt-401", "Global Scrum Gathering", ItemType.EVENT, 
                "usr-admin", "Orlando, FL", today.plusDays(40), today.plusDays(43), "Scrum Alliance Global Conference");
        platform.createCourseOrEvent("usr-admin", gathering);
        System.out.println(String.format("Listing fee charged to admin for Event '%s': $%.2f", gathering.getTitle(), gathering.getFeeCharged()));

        // 7. Survey submission and rating protection
        SurveyResponse s1 = new SurveyResponse(csmCourse.getId(), "student1@test.com", 5, "Amazing instructor!");
        SurveyResponse s2 = new SurveyResponse(csmCourse.getId(), "student1@test.com", 1, "Duplicate skew attempt");
        boolean res1 = platform.submitCourseSurvey(s1);
        boolean res2 = platform.submitCourseSurvey(s2);
        System.out.println("\nSurvey submission 1 accepted: " + res1 + " | Duplicate submission blocked: " + (!res2));
        System.out.println(String.format("Trainer %s average rating: %.2f", trainer.getFullName(), platform.getTrainerAverageRating(trainer.getId())));

        // 8. Roster upload and moving attendees from pending to official registry
        List<PendingClassAttendee> roster = List.of(
            new PendingClassAttendee("Charlie Brown", "charlie@peanuts.com", CertificationType.CSM),
            new PendingClassAttendee("Lucy van Pelt", "lucy@peanuts.com", CertificationType.CSM)
        );
        platform.trainerUploadCourseRoster(trainer.getId(), csmCourse.getId(), roster);
        System.out.println("\nPending classes needing admin verification: " + platform.getPendingClasses("usr-admin").size());
        
        // Admin confirms trainer payment and approves class
        platform.adminApproveClassPaymentAndMoveToRegistry("usr-admin", csmCourse.getId());
        List<RegistryEntry> csmRegistry = platform.getRegistryByCertification(CertificationType.CSM);
        System.out.println("CSM Registry size now: " + csmRegistry.size());
        System.out.println("Automated welcome email to newly certified CSM: " + platform.getEmailService().getLastSentEmail());

        // 9. Job postings and Recruiter extensions
        User recruiter = new User("rec-501", "recruiter_dave", "pass", "dave@hiring.com", "Dave Recruiter", Role.RECRUITER);
        platform.registerUser(recruiter);
        JobAd job = platform.postJobAd(recruiter.getId(), "Senior Scrum Master", "FinTech Corp", "Seeking enterprise Scrum Master.");
        platform.approveJobAd("usr-admin", job.getId(), true);
        System.out.println("\nActive approved jobs: " + platform.getActiveJobs(today).size());
        job.setExpirationDate(today.plusDays(7));
        platform.sendJobExpirationReminders(today);
        System.out.println("Expiration reminder sent: " + platform.getEmailService().getLastSentEmail());

        // 10. News and RSS feeds
        NewsItem news1 = new NewsItem("news-1", "Agile 2025 Trends Report Released", 
                "Key findings reveal growth in Product Owner skills demand.", 10, today.minusDays(1), today.plusDays(30), today.plusDays(60));
        platform.addNewsItem("usr-editor", news1);
        System.out.println("\nNews RSS Feed sample:\n" + platform.getNewsRssFeed(today));

        // 11. Corporate Sponsor
        CorporateSponsor sponsor = new CorporateSponsor("sp-1", "AgileWorks Inc.", "https://agileworks.example/logo.png");
        platform.registerCorporateSponsor(sponsor, 1000.0);

        // 12. Render Home Page
        System.out.println(platform.renderHomePage(today));
        System.out.println("Demo completed successfully.");
    }
}
