import java.time.LocalDate;
import java.util.*;

public class User {
    private final String id;
    private String username;
    private String password;
    private String email;
    private String fullName;
    private Role role;
    private boolean profilePrivate;
    private boolean emailPrivate;
    
    // Semi-structured profile fields
    private String bio;
    private String location;
    private String company;
    
    // Practitioner/Trainer specific
    private String experienceDetails;
    private String trainerPhilosophy;
    private final Set<CertificationType> certifications = new HashSet<>();
    
    private LocalDate membershipRenewalDate;
    private boolean activeMembership;

    public User(String id, String username, String password, String email, String fullName, Role role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
        this.profilePrivate = false;
        this.emailPrivate = false;
        this.membershipRenewalDate = LocalDate.now().plusYears(1);
        this.activeMembership = true;
    }

    public String getId() { return id; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
    public boolean isProfilePrivate() { return profilePrivate; }
    public void setProfilePrivate(boolean profilePrivate) { this.profilePrivate = profilePrivate; }
    public boolean isEmailPrivate() { return emailPrivate; }
    public void setEmailPrivate(boolean emailPrivate) { this.emailPrivate = emailPrivate; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
    public String getExperienceDetails() { return experienceDetails; }
    public void setExperienceDetails(String experienceDetails) { this.experienceDetails = experienceDetails; }
    public String getTrainerPhilosophy() { return trainerPhilosophy; }
    public void setTrainerPhilosophy(String trainerPhilosophy) { this.trainerPhilosophy = trainerPhilosophy; }
    public Set<CertificationType> getCertifications() { return certifications; }
    public void addCertification(CertificationType cert) { certifications.add(cert); }
    public LocalDate getMembershipRenewalDate() { return membershipRenewalDate; }
    public void setMembershipRenewalDate(LocalDate membershipRenewalDate) { this.membershipRenewalDate = membershipRenewalDate; }
    public boolean isActiveMembership() { return activeMembership; }
    public void setActiveMembership(boolean activeMembership) { this.activeMembership = activeMembership; }

    public String getCertificationBadge() {
        if (certifications.contains(CertificationType.CST)) return "[Badge: CST]";
        if (certifications.contains(CertificationType.CSP)) return "[Badge: CSP]";
        if (certifications.contains(CertificationType.CSPO)) return "[Badge: CSPO]";
        if (certifications.contains(CertificationType.CSM)) return "[Badge: CSM]";
        return "[No Certification]";
    }
}
