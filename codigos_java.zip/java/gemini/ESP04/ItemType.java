public enum ItemType {
    CERTIFICATION_COURSE,
    OTHER_COURSE,
    EVENT
}
