public class CorporateSponsor {
    private final String id;
    private final String companyName;
    private final String logoUrl;
    private boolean paidFee;

    public CorporateSponsor(String id, String companyName, String logoUrl) {
        this.id = id;
        this.companyName = companyName;
        this.logoUrl = logoUrl;
        this.paidFee = false;
    }

    public String getId() { return id; }
    public String getCompanyName() { return companyName; }
    public String getLogoUrl() { return logoUrl; }
    public boolean isPaidFee() { return paidFee; }
    public void setPaidFee(boolean paidFee) { this.paidFee = paidFee; }
}
