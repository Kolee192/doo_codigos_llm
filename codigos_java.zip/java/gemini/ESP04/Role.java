public enum Role {
    VISITOR,
    MEMBER,
    PRACTITIONER,
    TRAINER,
    RECRUITER,
    EDITOR,
    ADMIN
}
