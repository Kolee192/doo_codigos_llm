import java.time.LocalDate;

public class CertificationApplication {
    private final String applicationId;
    private final String applicantUserId;
    private final CertificationType desiredCert;
    private final String experienceSummary;
    private ApplicationStatus status;
    private final LocalDate appliedDate;

    public CertificationApplication(String applicationId, String applicantUserId, CertificationType desiredCert, String experienceSummary) {
        this.applicationId = applicationId;
        this.applicantUserId = applicantUserId;
        this.desiredCert = desiredCert;
        this.experienceSummary = experienceSummary;
        this.status = ApplicationStatus.PENDING;
        this.appliedDate = LocalDate.now();
    }

    public String getApplicationId() { return applicationId; }
    public String getApplicantUserId() { return applicantUserId; }
    public CertificationType getDesiredCert() { return desiredCert; }
    public String getExperienceSummary() { return experienceSummary; }
    public ApplicationStatus getStatus() { return status; }
    public void setStatus(ApplicationStatus status) { this.status = status; }
    public LocalDate getAppliedDate() { return appliedDate; }
}
