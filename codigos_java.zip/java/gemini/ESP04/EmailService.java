import java.util.*;

public class EmailService {
    private final List<String> sentEmails = new ArrayList<>();

    public void sendEmail(String from, String to, String subject, String body) {
        String logEntry = String.format("From: %s | To: %s | Subject: %s | Content: %s", from, to, subject, body);
        sentEmails.add(logEntry);
    }

    public List<String> getSentEmails() {
        return Collections.unmodifiableList(sentEmails);
    }

    public String getLastSentEmail() {
        if (sentEmails.isEmpty()) return null;
        return sentEmails.get(sentEmails.size() - 1);
    }
}
