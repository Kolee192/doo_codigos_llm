public class DownloadResource {
    private final String id;
    private final String title;
    private final String filename;
    private final boolean membersOnly;

    public DownloadResource(String id, String title, String filename, boolean membersOnly) {
        this.id = id;
        this.title = title;
        this.filename = filename;
        this.membersOnly = membersOnly;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getFilename() { return filename; }
    public boolean isMembersOnly() { return membersOnly; }
}
