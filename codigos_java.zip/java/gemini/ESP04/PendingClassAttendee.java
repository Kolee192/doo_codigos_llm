public class PendingClassAttendee {
    private final String fullName;
    private final String email;
    private final CertificationType certificationType;

    public PendingClassAttendee(String fullName, String email, CertificationType certificationType) {
        this.fullName = fullName;
        this.email = email;
        this.certificationType = certificationType;
    }

    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public CertificationType getCertificationType() { return certificationType; }
}
