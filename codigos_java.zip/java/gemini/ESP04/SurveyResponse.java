public class SurveyResponse {
    private final String courseId;
    private final String participantEmail;
    private final int rating; // 1 to 5
    private final String feedback;

    public SurveyResponse(String courseId, String participantEmail, int rating, String feedback) {
        this.courseId = courseId;
        this.participantEmail = participantEmail;
        this.rating = rating;
        this.feedback = feedback;
    }

    public String getCourseId() { return courseId; }
    public String getParticipantEmail() { return participantEmail; }
    public int getRating() { return rating; }
    public String getFeedback() { return feedback; }
}
