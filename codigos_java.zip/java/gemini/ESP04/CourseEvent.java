import java.time.LocalDate;

public class CourseEvent {
    private String id;
    private String title;
    private ItemType type;
    private String trainerId;
    private String location;
    private LocalDate startDate;
    private LocalDate endDate;
    private String description;
    private double feeCharged;
    private boolean isPending;

    public CourseEvent(String id, String title, ItemType type, String trainerId, String location, LocalDate startDate, LocalDate endDate, String description) {
        this.id = id;
        this.title = title;
        this.type = type;
        this.trainerId = trainerId;
        this.location = location;
        this.startDate = startDate;
        this.endDate = endDate;
        this.description = description;
        this.feeCharged = 0.0;
        this.isPending = false;
    }

    public CourseEvent copy(String newId) {
        CourseEvent cloned = new CourseEvent(newId, this.title, this.type, this.trainerId, this.location, this.startDate, this.endDate, this.description);
        cloned.setFeeCharged(this.feeCharged);
        cloned.setPending(this.isPending);
        return cloned;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public ItemType getType() { return type; }
    public void setType(ItemType type) { this.type = type; }
    public String getTrainerId() { return trainerId; }
    public void setTrainerId(String trainerId) { this.trainerId = trainerId; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public double getFeeCharged() { return feeCharged; }
    public void setFeeCharged(double feeCharged) { this.feeCharged = feeCharged; }
    public boolean isPending() { return isPending; }
    public void setPending(boolean pending) { isPending = pending; }
}
