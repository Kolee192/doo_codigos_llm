public enum CarStatus {
    AVAILABLE,
    RENTED,
    IN_SERVICE,
    DAMAGED
}
