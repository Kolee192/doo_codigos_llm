import java.time.LocalDate;
import java.util.Objects;

public class Connection {
    private Person person1;
    private Person person2;
    private LocalDate startDate;
    private LocalDate endDate;
    private ConnectionType connectionType;

    public Connection(Person person1, Person person2, LocalDate startDate, LocalDate endDate, ConnectionType connectionType) {
        this.person1 = person1;
        this.person2 = person2;
        this.startDate = startDate;
        this.endDate = endDate;
        this.connectionType = connectionType;
        if (person1 != null) {
            person1.addConnection(this);
        }
        if (person2 != null) {
            person2.addConnection(this);
        }
    }

    public Person getPerson1() {
        return person1;
    }

    public void setPerson1(Person person1) {
        this.person1 = person1;
    }

    public Person getPerson2() {
        return person2;
    }

    public void setPerson2(Person person2) {
        this.person2 = person2;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public ConnectionType getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(ConnectionType connectionType) {
        this.connectionType = connectionType;
    }

    @Override
    public String toString() {
        return "Connection [" + connectionType + "] between " + person1.getName() + " and " + person2.getName();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Connection that)) return false;
        return Objects.equals(person1, that.person1) &&
                Objects.equals(person2, that.person2) &&
                Objects.equals(startDate, that.startDate) &&
                Objects.equals(endDate, that.endDate) &&
                Objects.equals(connectionType, that.connectionType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(person1, person2, startDate, endDate, connectionType);
    }
}
