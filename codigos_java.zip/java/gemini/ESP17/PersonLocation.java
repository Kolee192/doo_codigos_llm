import java.time.LocalDate;
import java.util.Objects;

public class PersonLocation {
    private LocalDate startDate;
    private LocalDate endDate;
    private PersonLocationType type;
    private Location location;

    public PersonLocation(LocalDate startDate, LocalDate endDate, PersonLocationType type, Location location) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.type = type;
        this.location = location;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public PersonLocationType getType() {
        return type;
    }

    public void setType(PersonLocationType type) {
        this.type = type;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Location [" + type + "]: " + location + " (" + startDate + " to " + endDate + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PersonLocation that)) return false;
        return Objects.equals(startDate, that.startDate) &&
                Objects.equals(endDate, that.endDate) &&
                Objects.equals(type, that.type) &&
                Objects.equals(location, that.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(startDate, endDate, type, location);
    }
}
