import java.util.Objects;

public class Temperature {
    private final double value;
    private final TemperatureScale scale;

    public Temperature(double value, TemperatureScale scale) {
        this.value = value;
        this.scale = Objects.requireNonNull(scale, "Temperature scale cannot be null");
    }

    public double getValue() {
        return value;
    }

    public TemperatureScale getScale() {
        return scale;
    }

    public Temperature toFahrenheit() {
        if (scale == TemperatureScale.FAHRENHEIT) {
            return this;
        }
        double fVal = (value * 9.0 / 5.0) + 32.0;
        return new Temperature(fVal, TemperatureScale.FAHRENHEIT);
    }

    public Temperature toCelsius() {
        if (scale == TemperatureScale.CELSIUS) {
            return this;
        }
        double cVal = (value - 32.0) * 5.0 / 9.0;
        return new Temperature(cVal, TemperatureScale.CELSIUS);
    }

    @Override
    public String toString() {
        return String.format("%.1f °%s", value, scale == TemperatureScale.FAHRENHEIT ? "F" : "C");
    }
}
