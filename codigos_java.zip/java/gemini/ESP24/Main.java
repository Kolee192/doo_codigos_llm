import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Initializing DigitalHome (DH) System ===");

        // 1. Initialize DH System with hybrid HVAC (Gas + Solar) and security light alarm subsystem
        DigitalHomeSystem dh = new DigitalHomeSystem(
                Set.of(HVACType.GAS, HVACType.SOLAR),
                List.of("FrontPorchLight", "BackyardSpotlight", "LivingRoomFlashingLight")
        );

        DHGatewayDevice gateway = dh.getGateway();
        DHWebServer webServer = dh.getWebServer();
        DHDatabase database = dh.getDatabase();
        DHPlanner planner = dh.getPlanner();

        // 2. Add Thermostats (up to 8, one per room)
        Thermostat t1 = new Thermostat("T01", "Living Room");
        Thermostat t2 = new Thermostat("T02", "Master Bedroom");
        gateway.addThermostat(t1);
        gateway.addThermostat(t2);

        // 3. Add Humidistats (up to 8, one per room)
        Humidistat h1 = new Humidistat("H01", "Living Room");
        Humidistat h2 = new Humidistat("H02", "Master Bedroom");
        gateway.addHumidistat(h1);
        gateway.addHumidistat(h2);

        // 4. Add Contact Sensors (up to 50)
        ContactSensor s1 = new ContactSensor("CS01", "Front Door", "Foyer");
        ContactSensor s2 = new ContactSensor("CS02", "Balcony Window", "Master Bedroom");
        gateway.getSecuritySystem().addContactSensor(s1);
        gateway.getSecuritySystem().addContactSensor(s2);

        // 5. Add Appliance Power Switches (115V, 10A, up to 100)
        PowerSwitch ps1 = new PowerSwitch("SW01", "Coffee Maker", "Kitchen");
        PowerSwitch ps2 = new PowerSwitch("SW02", "Living Room Floor Lamp", "Living Room");
        gateway.addPowerSwitch(ps1);
        gateway.addPowerSwitch(ps2);

        System.out.println("Gateway configured with:");
        System.out.println("  Thermostats: " + gateway.getThermostats().size());
        System.out.println("  Humidistats: " + gateway.getHumidistats().size());
        System.out.println("  Contact Sensors: " + gateway.getSecuritySystem().getContactSensors().size());
        System.out.println("  Power Switches: " + gateway.getPowerSwitches().size());
        System.out.println("  HVAC System: " + dh.getHvacSystem());

        // 6. Demonstrate Thermostat readings and Fahrenheit/Celsius support
        System.out.println("\n--- Thermostat Monitoring & Control ---");
        gateway.recordThermostatReading("T01", new Temperature(72.0, TemperatureScale.FAHRENHEIT), LocalDateTime.now());
        Temperature t1TempF = webServer.readThermostatTemperature("T01", TemperatureScale.FAHRENHEIT);
        Temperature t1TempC = webServer.readThermostatTemperature("T01", TemperatureScale.CELSIUS);
        System.out.println("Thermostat T01 Reading (Fahrenheit): " + t1TempF);
        System.out.println("Thermostat T01 Reading (Celsius): " + t1TempC);

        // Setting target individually and collectively (range 60°F - 80°F)
        webServer.setThermostatTemperature("T01", 68);
        System.out.println("Thermostat T01 target set to: " + t1.getTargetTemperatureFahrenheit() + " °F");
        webServer.setAllThermostatsTemperature(71);
        System.out.println("All thermostats target set collectively to 71 °F. T01="
                + t1.getTargetTemperatureFahrenheit() + " °F, T02="
                + t2.getTargetTemperatureFahrenheit() + " °F");

        // 7. Demonstrate Humidistat Monitoring & Control (range 30% - 60%)
        System.out.println("\n--- Humidistat Monitoring & Control ---");
        gateway.recordHumidistatReading("H01", 48.0, LocalDateTime.now());
        System.out.println("Humidistat H01 Reading: " + webServer.readHumidistatHumidity("H01") + "%");
        webServer.setHumidistatLevel("H01", 42);
        System.out.println("Humidistat H01 target set to: " + h1.getTargetHumidityPercent() + "%");

        // 8. Demonstrate Appliance Management (Power switches ON/OFF)
        System.out.println("\n--- Appliance Switch Control ---");
        System.out.println("Coffee Maker initial state: " + webServer.readPowerSwitchState("SW01"));
        webServer.setPowerSwitchState("SW01", SwitchState.ON);
        System.out.println("Coffee Maker state after turning ON: " + webServer.readPowerSwitchState("SW01"));

        // 9. Demonstrate Monthly Planning (up to 4 daily periods)
        System.out.println("\n--- Monthly Planning ---");
        LocalDateTime now = LocalDateTime.now();
        MonthPlan augustPlan = new MonthPlan(now.getYear(), now.getMonthValue());

        for (int day = 1; day <= YearMonth.from(now).lengthOfMonth(); day++) {
            DailyPlan dailyPlan = new DailyPlan(day);
            // Period 1: Morning (06:00 - 09:00)
            dailyPlan.addPeriodSetting(new TimePeriodSetting("Morning", LocalTime.of(6, 0), LocalTime.of(9, 0),
                    70, 45, false, Map.of("SW01", SwitchState.ON, "SW02", SwitchState.ON)));
            // Period 2: Day (09:00 - 17:00)
            dailyPlan.addPeriodSetting(new TimePeriodSetting("Day", LocalTime.of(9, 0), LocalTime.of(17, 0),
                    74, 40, true, Map.of("SW01", SwitchState.OFF, "SW02", SwitchState.OFF)));
            // Period 3: Evening (17:00 - 22:00)
            dailyPlan.addPeriodSetting(new TimePeriodSetting("Evening", LocalTime.of(17, 0), LocalTime.of(22, 0),
                    71, 45, false, Map.of("SW01", SwitchState.OFF, "SW02", SwitchState.ON)));
            // Period 4: Night (22:00 - 06:00 next day)
            dailyPlan.addPeriodSetting(new TimePeriodSetting("Night", LocalTime.of(22, 0), LocalTime.of(23, 59),
                    68, 50, true, Map.of("SW01", SwitchState.OFF, "SW02", SwitchState.OFF)));
            augustPlan.setDailyPlan(dailyPlan);
        }
        planner.saveMonthPlan(augustPlan);
        System.out.println("Created and saved month plan for " + augustPlan.getMonth() + "/" + augustPlan.getYear()
                + " with 4 daily periods per day.");

        // 10. Demonstrate Manual Override and Reset
        System.out.println("\n--- Manual Override Feature ---");
        LocalDateTime currentVirtualTime = LocalDateTime.of(now.getYear(), now.getMonthValue(), 10, 10, 0);
        webServer.applyPlanAtTime(currentVirtualTime);
        System.out.println("Plan applied at 10:00 (Day Period):");
        System.out.println("  T01 Target: " + t1.getTargetTemperatureFahrenheit() + " °F");
        System.out.println("  Coffee Maker: " + ps1.getState());
        System.out.println("  Security Armed: " + webServer.isSecurityArmed());

        // User manually overrides temperature and power switch until 12:00
        LocalDateTime overrideUntil = LocalDateTime.of(now.getYear(), now.getMonthValue(), 10, 12, 0);
        webServer.manualOverrideThermostat("T01", 64, overrideUntil);
        webServer.manualOverridePowerSwitch("SW01", SwitchState.ON, overrideUntil);
        System.out.println("\nManual override activated until " + overrideUntil + ":");
        System.out.println("  T01 Target (Overridden): " + t1.getTargetTemperatureFahrenheit() + " °F (Override Active=" + t1.isManualOverrideActive() + ")");
        System.out.println("  Coffee Maker (Overridden): " + ps1.getState() + " (Override Active=" + ps1.isManualOverrideActive() + ")");

        // Time advances beyond override expiration
        LocalDateTime afterOverrideTime = LocalDateTime.of(now.getYear(), now.getMonthValue(), 10, 12, 30);
        webServer.applyPlanAtTime(afterOverrideTime);
        System.out.println("\nPlan re-evaluated after override expiration (12:30):");
        System.out.println("  T01 Target: " + t1.getTargetTemperatureFahrenheit() + " °F (Override Active=" + t1.isManualOverrideActive() + ")");
        System.out.println("  Coffee Maker: " + ps1.getState() + " (Override Active=" + ps1.isManualOverrideActive() + ")");

        // 11. Security Breach Simulation: Contact Sensor set to OPEN
        System.out.println("\n--- Security Alarm Simulation ---");
        webServer.setSecurityArmed(true);
        LocalDateTime breachTime = LocalDateTime.of(now.getYear(), now.getMonthValue(), 15, 2, 35);
        System.out.println("Security Armed: " + webServer.isSecurityArmed());
        System.out.println("Simulating security breach: Front Door (CS01) opened at " + breachTime);
        gateway.onContactSensorChange("CS01", ContactState.OPEN, breachTime);

        System.out.println("Alarm Status: " + (webServer.isSecurityAlarmActive() ? "ACTIVE" : "INACTIVE"));
        System.out.println("  Sound Alarm Siren: " + dh.getSecuritySystem().getSoundAlarm().isSounding());
        System.out.println("  Light Alarm Flashing: " + dh.getSecuritySystem().getLightAlarmSubsystem().isFlashing());
        System.out.println("  Flashing Lights: " + dh.getSecuritySystem().getLightAlarmSubsystem().getLights());

        // Disarm system
        webServer.setSecurityArmed(false);
        System.out.println("Alarm disarmed. Alarm Status: " + (webServer.isSecurityAlarmActive() ? "ACTIVE" : "INACTIVE"));

        // 12. Simulate Month Readings & System Downtime for Reporting
        System.out.println("\n--- Generating Monthly Report ---");
        // Add sensor readings for day 15 and 16
        database.recordReading(new SensorReading(LocalDateTime.of(now.getYear(), now.getMonthValue(), 15, 6, 0), "T01", SensorReading.DeviceType.THERMOSTAT, 66.0));
        database.recordReading(new SensorReading(LocalDateTime.of(now.getYear(), now.getMonthValue(), 15, 14, 0), "T01", SensorReading.DeviceType.THERMOSTAT, 76.0));
        database.recordReading(new SensorReading(LocalDateTime.of(now.getYear(), now.getMonthValue(), 15, 20, 0), "T01", SensorReading.DeviceType.THERMOSTAT, 71.0));

        database.recordReading(new SensorReading(LocalDateTime.of(now.getYear(), now.getMonthValue(), 15, 8, 0), "H01", SensorReading.DeviceType.HUMIDISTAT, 35.0));
        database.recordReading(new SensorReading(LocalDateTime.of(now.getYear(), now.getMonthValue(), 15, 18, 0), "H01", SensorReading.DeviceType.HUMIDISTAT, 55.0));

        // Add a downtime period (DH system outage)
        database.recordDowntime(new SystemDowntimePeriod(
                LocalDateTime.of(now.getYear(), now.getMonthValue(), 18, 3, 0),
                LocalDateTime.of(now.getYear(), now.getMonthValue(), 18, 4, 30),
                "Gateway firmware update & broadband fiber maintenance"
        ));

        // Request and print monthly report
        String report = webServer.requestMonthlyReport(now.getYear(), now.getMonthValue());
        System.out.println(report);

        System.out.println("DigitalHome System demo successfully completed.");
    }
}
