import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DHGatewayDevice {
    public static final int MAX_THERMOSTATS = 8;
    public static final int MAX_HUMIDISTATS = 8;
    public static final int MAX_POWER_SWITCHES = 100;

    private boolean broadbandConnected;
    private final List<Thermostat> thermostats;
    private final List<Humidistat> humidistats;
    private final List<PowerSwitch> powerSwitches;
    private final SecuritySystem securitySystem;
    private final DHDatabase database;

    public DHGatewayDevice(SecuritySystem securitySystem, DHDatabase database) {
        this.broadbandConnected = true;
        this.thermostats = new ArrayList<>();
        this.humidistats = new ArrayList<>();
        this.powerSwitches = new ArrayList<>();
        this.securitySystem = securitySystem;
        this.database = database;
    }

    public boolean isBroadbandConnected() {
        return broadbandConnected;
    }

    public void setBroadbandConnected(boolean broadbandConnected) {
        this.broadbandConnected = broadbandConnected;
    }

    public void addThermostat(Thermostat thermostat) {
        if (thermostats.size() >= MAX_THERMOSTATS) {
            throw new IllegalStateException("Maximum of " + MAX_THERMOSTATS + " thermostats reached.");
        }
        thermostats.add(thermostat);
    }

    public void addHumidistat(Humidistat humidistat) {
        if (humidistats.size() >= MAX_HUMIDISTATS) {
            throw new IllegalStateException("Maximum of " + MAX_HUMIDISTATS + " humidistats reached.");
        }
        humidistats.add(humidistat);
    }

    public void addPowerSwitch(PowerSwitch powerSwitch) {
        if (powerSwitches.size() >= MAX_POWER_SWITCHES) {
            throw new IllegalStateException("Maximum of " + MAX_POWER_SWITCHES + " power switches reached.");
        }
        powerSwitches.add(powerSwitch);
    }

    public List<Thermostat> getThermostats() {
        return Collections.unmodifiableList(thermostats);
    }

    public List<Humidistat> getHumidistats() {
        return Collections.unmodifiableList(humidistats);
    }

    public List<PowerSwitch> getPowerSwitches() {
        return Collections.unmodifiableList(powerSwitches);
    }

    public SecuritySystem getSecuritySystem() {
        return securitySystem;
    }

    public DHDatabase getDatabase() {
        return database;
    }

    // Wireless communication methods
    public void recordThermostatReading(String thermostatId, Temperature temp, LocalDateTime time) {
        for (Thermostat t : thermostats) {
            if (t.getId().equals(thermostatId)) {
                t.setCurrentTemperature(temp);
                database.recordReading(new SensorReading(
                        time, thermostatId, SensorReading.DeviceType.THERMOSTAT, temp.toFahrenheit().getValue()));
                break;
            }
        }
    }

    public void recordHumidistatReading(String humidistatId, double humidity, LocalDateTime time) {
        for (Humidistat h : humidistats) {
            if (h.getId().equals(humidistatId)) {
                h.setCurrentHumidity(humidity);
                database.recordReading(new SensorReading(
                        time, humidistatId, SensorReading.DeviceType.HUMIDISTAT, humidity));
                break;
            }
        }
    }

    public void setIndividualThermostatTarget(String thermostatId, int tempF) {
        for (Thermostat t : thermostats) {
            if (t.getId().equals(thermostatId)) {
                t.setTargetTemperatureFahrenheit(tempF);
                return;
            }
        }
        throw new IllegalArgumentException("Thermostat not found: " + thermostatId);
    }

    public void setCollectiveThermostatsTarget(int tempF) {
        for (Thermostat t : thermostats) {
            t.setTargetTemperatureFahrenheit(tempF);
        }
    }

    public void setHumidistatTarget(String humidistatId, int humidityPercent) {
        for (Humidistat h : humidistats) {
            if (h.getId().equals(humidistatId)) {
                h.setTargetHumidityPercent(humidityPercent);
                return;
            }
        }
        throw new IllegalArgumentException("Humidistat not found: " + humidistatId);
    }

    public void setPowerSwitchState(String switchId, SwitchState state) {
        for (PowerSwitch ps : powerSwitches) {
            if (ps.getId().equals(switchId)) {
                ps.setState(state);
                return;
            }
        }
        throw new IllegalArgumentException("Power switch not found: " + switchId);
    }

    public void onContactSensorChange(String sensorId, ContactState state, LocalDateTime time) {
        SecurityBreachEvent event = securitySystem.checkSensorAndTriggerAlarm(sensorId, state, time);
        if (event != null) {
            database.recordBreach(event);
        }
    }
}
