import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LightAlarmSubsystem {
    private final List<String> lights;
    private boolean flashing;

    public LightAlarmSubsystem(List<String> lights) {
        this.lights = new ArrayList<>(lights);
        this.flashing = false;
    }

    public void activate() {
        this.flashing = true;
    }

    public void deactivate() {
        this.flashing = false;
    }

    public boolean isFlashing() {
        return flashing;
    }

    public List<String> getLights() {
        return Collections.unmodifiableList(lights);
    }

    @Override
    public String toString() {
        return "LightAlarmSubsystem[flashing=" + flashing + ", lightsCount=" + lights.size() + "]";
    }
}
