import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class DHDatabase {
    private final List<SensorReading> sensorReadings = new ArrayList<>();
    private final List<SecurityBreachEvent> breachEvents = new ArrayList<>();
    private final List<SystemDowntimePeriod> downtimePeriods = new ArrayList<>();

    public synchronized void recordReading(SensorReading reading) {
        sensorReadings.add(reading);
    }

    public synchronized void recordBreach(SecurityBreachEvent event) {
        breachEvents.add(event);
    }

    public synchronized void recordDowntime(SystemDowntimePeriod downtime) {
        downtimePeriods.add(downtime);
    }

    public synchronized List<SensorReading> getReadingsBetween(LocalDateTime start, LocalDateTime end) {
        return sensorReadings.stream()
                .filter(r -> !r.getTimestamp().isBefore(start) && !r.getTimestamp().isAfter(end))
                .collect(Collectors.toList());
    }

    public synchronized List<SecurityBreachEvent> getBreachesBetween(LocalDateTime start, LocalDateTime end) {
        return breachEvents.stream()
                .filter(b -> !b.getTimestamp().isBefore(start) && !b.getTimestamp().isAfter(end))
                .collect(Collectors.toList());
    }

    public synchronized List<SystemDowntimePeriod> getDowntimesBetween(LocalDateTime start, LocalDateTime end) {
        return downtimePeriods.stream()
                .filter(d -> !d.getStartTime().isAfter(end) && !d.getEndTime().isBefore(start))
                .collect(Collectors.toList());
    }
}
