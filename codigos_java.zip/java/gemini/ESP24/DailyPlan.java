import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DailyPlan {
    public static final int MAX_PERIODS = 4;
    private final int dayOfMonth;
    private final List<TimePeriodSetting> periodSettings;

    public DailyPlan(int dayOfMonth) {
        this.dayOfMonth = dayOfMonth;
        this.periodSettings = new ArrayList<>();
    }

    public int getDayOfMonth() {
        return dayOfMonth;
    }

    public void addPeriodSetting(TimePeriodSetting setting) {
        if (periodSettings.size() >= MAX_PERIODS) {
            throw new IllegalStateException("A daily plan can have up to " + MAX_PERIODS + " periods.");
        }
        periodSettings.add(setting);
    }

    public List<TimePeriodSetting> getPeriodSettings() {
        return Collections.unmodifiableList(periodSettings);
    }

    public TimePeriodSetting findSettingForTime(LocalTime time) {
        for (TimePeriodSetting setting : periodSettings) {
            if ((time.equals(setting.getStartTime()) || time.isAfter(setting.getStartTime()))
                    && time.isBefore(setting.getEndTime())) {
                return setting;
            }
        }
        return periodSettings.isEmpty() ? null : periodSettings.get(0);
    }
}
