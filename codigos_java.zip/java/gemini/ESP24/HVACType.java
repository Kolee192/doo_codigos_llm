public enum HVACType {
    GAS,
    OIL,
    ELECTRICITY,
    SOLAR
}
