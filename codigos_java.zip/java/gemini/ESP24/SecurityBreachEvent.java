import java.time.LocalDateTime;

public class SecurityBreachEvent {
    private final LocalDateTime timestamp;
    private final String sensorId;
    private final String sensorName;
    private final String location;

    public SecurityBreachEvent(LocalDateTime timestamp, String sensorId, String sensorName, String location) {
        this.timestamp = timestamp;
        this.sensorId = sensorId;
        this.sensorName = sensorName;
        this.location = location;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getSensorId() {
        return sensorId;
    }

    public String getSensorName() {
        return sensorName;
    }

    public String getLocation() {
        return location;
    }

    @Override
    public String toString() {
        return String.format("SecurityBreachEvent[%s: Sensor %s (%s at %s) tripped]",
                timestamp, sensorId, sensorName, location);
    }
}
