import java.util.List;
import java.util.Set;

public class DigitalHomeSystem {
    private final DHDatabase database;
    private final SecuritySystem securitySystem;
    private final DHGatewayDevice gateway;
    private final DHPlanner planner;
    private final HVACSystem hvacSystem;
    private final DHWebServer webServer;

    public DigitalHomeSystem(Set<HVACType> hvacSources, List<String> alarmLights) {
        this.database = new DHDatabase();
        SoundAlarm soundAlarm = new SoundAlarm();
        LightAlarmSubsystem lightAlarmSubsystem = new LightAlarmSubsystem(alarmLights);
        this.securitySystem = new SecuritySystem(soundAlarm, lightAlarmSubsystem);
        this.gateway = new DHGatewayDevice(securitySystem, database);
        this.planner = new DHPlanner();
        this.hvacSystem = new HVACSystem(hvacSources);
        this.webServer = new DHWebServer(gateway, planner, hvacSystem);
    }

    public DHDatabase getDatabase() {
        return database;
    }

    public SecuritySystem getSecuritySystem() {
        return securitySystem;
    }

    public DHGatewayDevice getGateway() {
        return gateway;
    }

    public DHPlanner getPlanner() {
        return planner;
    }

    public HVACSystem getHvacSystem() {
        return hvacSystem;
    }

    public DHWebServer getWebServer() {
        return webServer;
    }
}
