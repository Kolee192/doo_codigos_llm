public class SoundAlarm {
    private boolean sounding;

    public SoundAlarm() {
        this.sounding = false;
    }

    public void activate() {
        this.sounding = true;
    }

    public void deactivate() {
        this.sounding = false;
    }

    public boolean isSounding() {
        return sounding;
    }

    @Override
    public String toString() {
        return "SoundAlarm[sounding=" + sounding + "]";
    }
}
