import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SecuritySystem {
    public static final int MAX_CONTACT_SENSORS = 50;

    private final List<ContactSensor> contactSensors;
    private final SoundAlarm soundAlarm;
    private final LightAlarmSubsystem lightAlarmSubsystem;
    private boolean armed;

    public SecuritySystem(SoundAlarm soundAlarm, LightAlarmSubsystem lightAlarmSubsystem) {
        this.contactSensors = new ArrayList<>();
        this.soundAlarm = soundAlarm;
        this.lightAlarmSubsystem = lightAlarmSubsystem;
        this.armed = true;
    }

    public void addContactSensor(ContactSensor sensor) {
        if (contactSensors.size() >= MAX_CONTACT_SENSORS) {
            throw new IllegalStateException("Maximum of " + MAX_CONTACT_SENSORS + " contact sensors reached.");
        }
        contactSensors.add(sensor);
    }

    public List<ContactSensor> getContactSensors() {
        return Collections.unmodifiableList(contactSensors);
    }

    public SoundAlarm getSoundAlarm() {
        return soundAlarm;
    }

    public LightAlarmSubsystem getLightAlarmSubsystem() {
        return lightAlarmSubsystem;
    }

    public boolean isArmed() {
        return armed;
    }

    public void setArmed(boolean armed) {
        this.armed = armed;
        if (!armed) {
            soundAlarm.deactivate();
            lightAlarmSubsystem.deactivate();
        }
    }

    public SecurityBreachEvent checkSensorAndTriggerAlarm(String sensorId, ContactState newState, LocalDateTime time) {
        ContactSensor target = contactSensors.stream()
                .filter(s -> s.getId().equals(sensorId))
                .findFirst()
                .orElse(null);

        if (target == null) {
            return null;
        }

        target.setState(newState);

        if (armed && newState == ContactState.OPEN) {
            soundAlarm.activate();
            lightAlarmSubsystem.activate();
            return new SecurityBreachEvent(time, target.getId(), target.getName(), target.getLocation());
        }
        return null;
    }

    public boolean isAlarmActive() {
        return soundAlarm.isSounding() || lightAlarmSubsystem.isFlashing();
    }
}
