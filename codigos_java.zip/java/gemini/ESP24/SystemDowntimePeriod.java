import java.time.LocalDateTime;

public class SystemDowntimePeriod {
    private final LocalDateTime startTime;
    private final LocalDateTime endTime;
    private final String reason;

    public SystemDowntimePeriod(LocalDateTime startTime, LocalDateTime endTime, String reason) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.reason = reason;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public String getReason() {
        return reason;
    }

    @Override
    public String toString() {
        return String.format("Downtime: %s to %s (Reason: %s)", startTime, endTime, reason);
    }
}
