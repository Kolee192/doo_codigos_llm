import java.time.LocalDateTime;
import java.util.List;

public class DHWebServer {
    private final DHGatewayDevice gateway;
    private final DHPlanner planner;
    private final HVACSystem hvacSystem;

    public DHWebServer(DHGatewayDevice gateway, DHPlanner planner, HVACSystem hvacSystem) {
        this.gateway = gateway;
        this.planner = planner;
        this.hvacSystem = hvacSystem;
    }

    public DHGatewayDevice getGateway() {
        return gateway;
    }

    public DHPlanner getPlanner() {
        return planner;
    }

    public HVACSystem getHvacSystem() {
        return hvacSystem;
    }

    // Thermostat controls
    public Temperature readThermostatTemperature(String thermostatId, TemperatureScale scale) {
        for (Thermostat t : gateway.getThermostats()) {
            if (t.getId().equals(thermostatId)) {
                return scale == TemperatureScale.FAHRENHEIT
                        ? t.getCurrentTemperature().toFahrenheit()
                        : t.getCurrentTemperature().toCelsius();
            }
        }
        throw new IllegalArgumentException("Thermostat not found: " + thermostatId);
    }

    public void setThermostatTemperature(String thermostatId, int tempF) {
        gateway.setIndividualThermostatTarget(thermostatId, tempF);
    }

    public void setAllThermostatsTemperature(int tempF) {
        gateway.setCollectiveThermostatsTarget(tempF);
    }

    public void manualOverrideThermostat(String thermostatId, int tempF, LocalDateTime until) {
        for (Thermostat t : gateway.getThermostats()) {
            if (t.getId().equals(thermostatId)) {
                t.setManualTarget(tempF, until);
                return;
            }
        }
        throw new IllegalArgumentException("Thermostat not found: " + thermostatId);
    }

    // Humidistat controls
    public double readHumidistatHumidity(String humidistatId) {
        for (Humidistat h : gateway.getHumidistats()) {
            if (h.getId().equals(humidistatId)) {
                return h.getCurrentHumidity();
            }
        }
        throw new IllegalArgumentException("Humidistat not found: " + humidistatId);
    }

    public void setHumidistatLevel(String humidistatId, int humidityPercent) {
        gateway.setHumidistatTarget(humidistatId, humidityPercent);
    }

    public void manualOverrideHumidistat(String humidistatId, int humidityPercent, LocalDateTime until) {
        for (Humidistat h : gateway.getHumidistats()) {
            if (h.getId().equals(humidistatId)) {
                h.setManualTarget(humidityPercent, until);
                return;
            }
        }
        throw new IllegalArgumentException("Humidistat not found: " + humidistatId);
    }

    // Power switches
    public SwitchState readPowerSwitchState(String switchId) {
        for (PowerSwitch ps : gateway.getPowerSwitches()) {
            if (ps.getId().equals(switchId)) {
                return ps.getState();
            }
        }
        throw new IllegalArgumentException("Power switch not found: " + switchId);
    }

    public void setPowerSwitchState(String switchId, SwitchState state) {
        gateway.setPowerSwitchState(switchId, state);
    }

    public void togglePowerSwitch(String switchId) {
        for (PowerSwitch ps : gateway.getPowerSwitches()) {
            if (ps.getId().equals(switchId)) {
                ps.setState(ps.getState() == SwitchState.ON ? SwitchState.OFF : SwitchState.ON);
                return;
            }
        }
        throw new IllegalArgumentException("Power switch not found: " + switchId);
    }

    public void manualOverridePowerSwitch(String switchId, SwitchState state, LocalDateTime until) {
        for (PowerSwitch ps : gateway.getPowerSwitches()) {
            if (ps.getId().equals(switchId)) {
                ps.setManualState(state, until);
                return;
            }
        }
        throw new IllegalArgumentException("Power switch not found: " + switchId);
    }

    // Security controls
    public void setSecurityArmed(boolean armed) {
        gateway.getSecuritySystem().setArmed(armed);
    }

    public boolean isSecurityArmed() {
        return gateway.getSecuritySystem().isArmed();
    }

    public boolean isSecurityAlarmActive() {
        return gateway.getSecuritySystem().isAlarmActive();
    }

    public List<ContactSensor> getContactSensors() {
        return gateway.getSecuritySystem().getContactSensors();
    }

    // Apply planning
    public void applyPlanAtTime(LocalDateTime currentTime) {
        TimePeriodSetting setting = planner.getActivePlanSetting(currentTime);
        if (setting == null) {
            return;
        }

        // Apply temperature to thermostats not manually overridden
        for (Thermostat t : gateway.getThermostats()) {
            t.clearOverrideIfExpired ? (void) null : null;
            if (t.isManualOverrideActive()) {
                if (t.getOverrideUntil() != null && currentTime.isAfter(t.getOverrideUntil())) {
                    t.setTargetTemperatureFahrenheit(setting.getTargetTemperatureF());
                }
            } else {
                t.setTargetTemperatureFahrenheit(setting.getTargetTemperatureF());
            }
        }

        // Apply humidity
        for (Humidistat h : gateway.getHumidistats()) {
            if (h.isManualOverrideActive()) {
                if (h.getOverrideUntil() != null && currentTime.isAfter(h.getOverrideUntil())) {
                    h.setTargetHumidityPercent(setting.getTargetHumidityPercent());
                }
            } else {
                h.setTargetHumidityPercent(setting.getTargetHumidityPercent());
            }
        }

        // Apply switch states
        for (Map.Entry<String, SwitchState> entry : setting.getSwitchStates().entrySet()) {
            for (PowerSwitch ps : gateway.getPowerSwitches()) {
                if (ps.getId().equals(entry.getKey())) {
                    ps.clearOverrideIfExpired(currentTime);
                    if (!ps.isManualOverrideActive()) {
                        ps.setState(entry.getValue());
                    }
                }
            }
        }

        // Apply security armed state
        gateway.getSecuritySystem().setArmed(setting.isSecurityArmed());
    }

    // Reporting
    public String requestMonthlyReport(int year, int month) {
        MonthlyReport report = new MonthlyReport(year, month, gateway.getDatabase(),
                gateway.getThermostats(), gateway.getHumidistats());
        return report.generateReport();
    }
}
