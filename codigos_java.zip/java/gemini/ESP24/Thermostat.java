import java.time.DayOfWeek;
import java.time.LocalDateTime;

public class Thermostat {
    public static final int MIN_TEMP_FAHRENHEIT = 60;
    public static final int MAX_TEMP_FAHRENHEIT = 80;

    private final String id;
    private final String room;
    private Temperature currentTemperature;
    private int targetTemperatureFahrenheit;
    private boolean manualOverrideActive;
    private LocalDateTime overrideUntil;

    // 7 days a week, 24 hourly settings per day (temperatures in °F)
    private final int[][] weeklySchedule;

    public Thermostat(String id, String room) {
        this.id = id;
        this.room = room;
        this.currentTemperature = new Temperature(70.0, TemperatureScale.FAHRENHEIT);
        this.targetTemperatureFahrenheit = 70;
        this.manualOverrideActive = false;
        this.overrideUntil = null;
        this.weeklySchedule = new int[7][24];
        for (int d = 0; d < 7; d++) {
            for (int h = 0; h < 24; h++) {
                weeklySchedule[d][h] = 70;
            }
        }
    }

    public String getId() {
        return id;
    }

    public String getRoom() {
        return room;
    }

    public Temperature getCurrentTemperature() {
        return currentTemperature;
    }

    public void setCurrentTemperature(Temperature currentTemperature) {
        this.currentTemperature = currentTemperature;
    }

    public int getTargetTemperatureFahrenheit() {
        return targetTemperatureFahrenheit;
    }

    public Temperature getTargetTemperature(TemperatureScale scale) {
        Temperature tempF = new Temperature(targetTemperatureFahrenheit, TemperatureScale.FAHRENHEIT);
        return scale == TemperatureScale.FAHRENHEIT ? tempF : tempF.toCelsius();
    }

    public void setTargetTemperatureFahrenheit(int targetTempF) {
        if (targetTempF < MIN_TEMP_FAHRENHEIT || targetTempF > MAX_TEMP_FAHRENHEIT) {
            throw new IllegalArgumentException(String.format(
                    "Thermostat temperature must be between %d °F and %d °F inclusive.",
                    MIN_TEMP_FAHRENHEIT, MAX_TEMP_FAHRENHEIT));
        }
        this.targetTemperatureFahrenheit = targetTempF;
    }

    public void setTargetTemperature(Temperature temperature) {
        Temperature fahrenheit = temperature.toFahrenheit();
        int roundedF = (int) Math.round(fahrenheit.getValue());
        setTargetTemperatureFahrenheit(roundedF);
    }

    public void setManualTarget(int targetTempF, LocalDateTime until) {
        setTargetTemperatureFahrenheit(targetTempF);
        this.manualOverrideActive = true;
        this.overrideUntil = until;
    }

    public void scheduleHour(DayOfWeek day, int hour, int targetTempF) {
        if (hour < 0 || hour >= 24) {
            throw new IllegalArgumentException("Hour must be between 0 and 23.");
        }
        if (targetTempF < MIN_TEMP_FAHRENHEIT || targetTempF > MAX_TEMP_FAHRENHEIT) {
            throw new IllegalArgumentException("Schedule temp must be between 60°F and 80°F.");
        }
        int dayIndex = day.getValue() - 1; // Monday=0, Sunday=6
        weeklySchedule[dayIndex][hour] = targetTempF;
    }

    public int getScheduledTemp(DayOfWeek day, int hour) {
        int dayIndex = day.getValue() - 1;
        return weeklySchedule[dayIndex][hour];
    }

    public void applyScheduleForTime(LocalDateTime dateTime) {
        if (manualOverrideActive) {
            if (overrideUntil != null && dateTime.isAfter(overrideUntil)) {
                manualOverrideActive = false;
                overrideUntil = null;
            } else {
                return; // Override still in effect
            }
        }
        int scheduled = getScheduledTemp(dateTime.getDayOfWeek(), dateTime.getHour());
        setTargetTemperatureFahrenheit(scheduled);
    }

    public boolean isManualOverrideActive() {
        return manualOverrideActive;
    }

    public LocalDateTime getOverrideUntil() {
        return overrideUntil;
    }

    @Override
    public String toString() {
        return String.format("Thermostat[%s in %s: Current=%s, Target=%d °F, Override=%b]",
                id, room, currentTemperature, targetTemperatureFahrenheit, manualOverrideActive);
    }
}
