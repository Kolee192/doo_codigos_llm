public enum SwitchState {
    OFF,
    ON
}
