import java.time.LocalDateTime;

public class PowerSwitch {
    private final String id;
    private final String applianceName;
    private final String roomLocation;
    private final int voltage;
    private final int amperage;
    private SwitchState state;
    private boolean manualOverrideActive;
    private LocalDateTime overrideUntil;

    public PowerSwitch(String id, String applianceName, String roomLocation) {
        this.id = id;
        this.applianceName = applianceName;
        this.roomLocation = roomLocation;
        this.voltage = 115;
        this.amperage = 10;
        this.state = SwitchState.OFF;
        this.manualOverrideActive = false;
        this.overrideUntil = null;
    }

    public String getId() {
        return id;
    }

    public String getApplianceName() {
        return applianceName;
    }

    public String getRoomLocation() {
        return roomLocation;
    }

    public int getVoltage() {
        return voltage;
    }

    public int getAmperage() {
        return amperage;
    }

    public SwitchState getState() {
        return state;
    }

    public void setState(SwitchState state) {
        this.state = state;
    }

    public void setManualState(SwitchState newState, LocalDateTime until) {
        this.state = newState;
        this.manualOverrideActive = true;
        this.overrideUntil = until;
    }

    public void clearOverrideIfExpired(LocalDateTime currentTime) {
        if (manualOverrideActive && overrideUntil != null && currentTime.isAfter(overrideUntil)) {
            manualOverrideActive = false;
            overrideUntil = null;
        }
    }

    public boolean isManualOverrideActive() {
        return manualOverrideActive;
    }

    public LocalDateTime getOverrideUntil() {
        return overrideUntil;
    }

    @Override
    public String toString() {
        return String.format("PowerSwitch[%s: %s at %s (%dV, %dA) - State: %s (Override: %b)]",
                id, applianceName, roomLocation, voltage, amperage, state, manualOverrideActive);
    }
}
