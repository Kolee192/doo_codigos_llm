import java.time.DayOfWeek;
import java.time.LocalDateTime;

public class Humidistat {
    public static final int MIN_HUMIDITY = 30;
    public static final int MAX_HUMIDITY = 60;

    private final String id;
    private final String room;
    private double currentHumidity;
    private int targetHumidityPercent;
    private boolean manualOverrideActive;
    private LocalDateTime overrideUntil;

    // 7 days a week, 24 hourly settings per day (humidity in %)
    private final int[][] weeklySchedule;

    public Humidistat(String id, String room) {
        this.id = id;
        this.room = room;
        this.currentHumidity = 45.0;
        this.targetHumidityPercent = 45;
        this.manualOverrideActive = false;
        this.overrideUntil = null;
        this.weeklySchedule = new int[7][24];
        for (int d = 0; d < 7; d++) {
            for (int h = 0; h < 24; h++) {
                weeklySchedule[d][h] = 45;
            }
        }
    }

    public String getId() {
        return id;
    }

    public String getRoom() {
        return room;
    }

    public double getCurrentHumidity() {
        return currentHumidity;
    }

    public void setCurrentHumidity(double currentHumidity) {
        this.currentHumidity = currentHumidity;
    }

    public int getTargetHumidityPercent() {
        return targetHumidityPercent;
    }

    public void setTargetHumidityPercent(int targetHumidityPercent) {
        if (targetHumidityPercent < MIN_HUMIDITY || targetHumidityPercent > MAX_HUMIDITY) {
            throw new IllegalArgumentException(String.format(
                    "Humidistat target humidity must be between %d%% and %d%% inclusive.",
                    MIN_HUMIDITY, MAX_HUMIDITY));
        }
        this.targetHumidityPercent = targetHumidityPercent;
    }

    public void setManualTarget(int targetHumidityPercent, LocalDateTime until) {
        setTargetHumidityPercent(targetHumidityPercent);
        this.manualOverrideActive = true;
        this.overrideUntil = until;
    }

    public void scheduleHour(DayOfWeek day, int hour, int targetHumidityPercent) {
        if (hour < 0 || hour >= 24) {
            throw new IllegalArgumentException("Hour must be between 0 and 23.");
        }
        if (targetHumidityPercent < MIN_HUMIDITY || targetHumidityPercent > MAX_HUMIDITY) {
            throw new IllegalArgumentException("Schedule humidity must be between 30% and 60%.");
        }
        int dayIndex = day.getValue() - 1;
        weeklySchedule[dayIndex][hour] = targetHumidityPercent;
    }

    public int getScheduledHumidity(DayOfWeek day, int hour) {
        int dayIndex = day.getValue() - 1;
        return weeklySchedule[dayIndex][hour];
    }

    public void applyScheduleForTime(LocalDateTime dateTime) {
        if (manualOverrideActive) {
            if (overrideUntil != null && dateTime.isAfter(overrideUntil)) {
                manualOverrideActive = false;
                overrideUntil = null;
            } else {
                return;
            }
        }
        int scheduled = getScheduledHumidity(dateTime.getDayOfWeek(), dateTime.getHour());
        setTargetHumidityPercent(scheduled);
    }

    public boolean isManualOverrideActive() {
        return manualOverrideActive;
    }

    public LocalDateTime getOverrideUntil() {
        return overrideUntil;
    }

    @Override
    public String toString() {
        return String.format("Humidistat[%s in %s: Current=%.1f%%, Target=%d%%, Override=%b]",
                id, room, currentHumidity, targetHumidityPercent, manualOverrideActive);
    }
}
