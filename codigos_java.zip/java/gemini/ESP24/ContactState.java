public enum ContactState {
    CLOSED,
    OPEN
}
