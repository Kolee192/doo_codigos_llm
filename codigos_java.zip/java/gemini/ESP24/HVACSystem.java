import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

public class HVACSystem {
    private final Set<HVACType> energySources;
    private boolean operational;

    public HVACSystem(Set<HVACType> sources) {
        if (sources == null || sources.isEmpty()) {
            throw new IllegalArgumentException("HVAC must have at least one energy source.");
        }
        this.energySources = Collections.unmodifiableSet(EnumSet.copyOf(sources));
        this.operational = true;
    }

    public Set<HVACType> getEnergySources() {
        return energySources;
    }

    public boolean isOperational() {
        return operational;
    }

    public void setOperational(boolean operational) {
        this.operational = operational;
    }

    @Override
    public String toString() {
        return "HVACSystem [sources=" + energySources + ", operational=" + operational + "]";
    }
}
