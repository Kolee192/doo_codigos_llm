import java.util.HashMap;
import java.util.Map;

public class MonthPlan {
    private final int year;
    private final int month; // 1 - 12
    private final Map<Integer, DailyPlan> dailyPlans;

    public MonthPlan(int year, int month) {
        this.year = year;
        this.month = month;
        this.dailyPlans = new HashMap<>();
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public void setDailyPlan(DailyPlan plan) {
        dailyPlans.put(plan.getDayOfMonth(), plan);
    }

    public DailyPlan getDailyPlan(int dayOfMonth) {
        return dailyPlans.get(dayOfMonth);
    }

    public Map<Integer, DailyPlan> getDailyPlans() {
        return dailyPlans;
    }
}
