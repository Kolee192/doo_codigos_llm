public class ContactSensor {
    private final String id;
    private final String name;
    private final String location;
    private ContactState state;

    public ContactSensor(String id, String name, String location) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.state = ContactState.CLOSED;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public ContactState getState() {
        return state;
    }

    public void setState(ContactState state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return String.format("ContactSensor[%s, %s, %s, %s]", id, name, location, state);
    }
}
