import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class DHPlanner {
    private final Map<String, MonthPlan> monthPlans = new HashMap<>();

    private String key(int year, int month) {
        return year + "-" + String.format("%02d", month);
    }

    public void saveMonthPlan(MonthPlan plan) {
        monthPlans.put(key(plan.getYear(), plan.getMonth()), plan);
    }

    public MonthPlan getMonthPlan(int year, int month) {
        return monthPlans.get(key(year, month));
    }

    public TimePeriodSetting getActivePlanSetting(LocalDateTime dateTime) {
        MonthPlan mp = getMonthPlan(dateTime.getYear(), dateTime.getMonthValue());
        if (mp == null) {
            return null;
        }
        DailyPlan dp = mp.getDailyPlan(dateTime.getDayOfMonth());
        if (dp == null) {
            return null;
        }
        return dp.findSettingForTime(dateTime.toLocalTime());
    }
}
