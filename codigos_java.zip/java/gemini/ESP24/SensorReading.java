import java.time.LocalDateTime;

public class SensorReading {
    public enum DeviceType { THERMOSTAT, HUMIDISTAT }

    private final LocalDateTime timestamp;
    private final String deviceId;
    private final DeviceType deviceType;
    private final double value; // Temperature in °F or Humidity in %

    public SensorReading(LocalDateTime timestamp, String deviceId, DeviceType deviceType, double value) {
        this.timestamp = timestamp;
        this.deviceId = deviceId;
        this.deviceType = deviceType;
        this.value = value;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public double getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.format("SensorReading[%s, %s, %s, %.2f]", timestamp, deviceId, deviceType, value);
    }
}
