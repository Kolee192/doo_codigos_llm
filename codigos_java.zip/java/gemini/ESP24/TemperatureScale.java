public enum TemperatureScale {
    FAHRENHEIT,
    CELSIUS
}
