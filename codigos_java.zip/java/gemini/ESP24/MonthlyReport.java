import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

public class MonthlyReport {
    private final int year;
    private final int month;
    private final DHDatabase database;
    private final List<Thermostat> thermostats;
    private final List<Humidistat> humidistats;

    public MonthlyReport(int year, int month, DHDatabase database,
                         List<Thermostat> thermostats, List<Humidistat> humidistats) {
        this.year = year;
        this.month = month;
        this.database = database;
        this.thermostats = thermostats;
        this.humidistats = humidistats;
    }

    public static class DaySensorStats {
        public double average;
        public double min = Double.MAX_VALUE;
        public LocalDateTime minTime;
        public double max = -Double.MAX_VALUE;
        public LocalDateTime maxTime;
        public int count = 0;
    }

    public String generateReport() {
        LocalDateTime now = LocalDateTime.now();
        YearMonth requestedYm = YearMonth.of(year, month);
        YearMonth currentYm = YearMonth.from(now);

        long monthsDiff = (currentYm.getYear() - requestedYm.getYear()) * 12L + (currentYm.getMonthValue() - requestedYm.getMonthValue());
        if (monthsDiff < 0 || monthsDiff > 24) {
            throw new IllegalArgumentException("Report can only be provided for months in the past two years.");
        }

        LocalDateTime startOfMonth = requestedYm.atDay(1).atStartOfDay();
        LocalDateTime endOfMonth = requestedYm.atEndOfMonth().atTime(23, 59, 59);

        List<SensorReading> readings = database.getReadingsBetween(startOfMonth, endOfMonth);
        List<SecurityBreachEvent> breaches = database.getBreachesBetween(startOfMonth, endOfMonth);
        List<SystemDowntimePeriod> downtimes = database.getDowntimesBetween(startOfMonth, endOfMonth);

        StringBuilder sb = new StringBuilder();
        sb.append("=================================================================\n");
        sb.append(String.format("         DIGITAL HOME MONTHLY REPORT - %02d/%d\n", month, year));
        sb.append("=================================================================\n\n");

        sb.append("1. TEMPERATURE METRICS (Per Thermostat)\n");
        sb.append("-----------------------------------------------------------------\n");
        for (Thermostat t : thermostats) {
            sb.append(String.format("Thermostat %s (%s):\n", t.getId(), t.getRoom()));
            Map<Integer, DaySensorStats> dailyStats = computeDailyStats(readings, t.getId(), SensorReading.DeviceType.THERMOSTAT);
            if (dailyStats.isEmpty()) {
                sb.append("  No readings available for this month.\n");
            } else {
                dailyStats.keySet().stream().sorted().forEach(day -> {
                    DaySensorStats s = dailyStats.get(day);
                    sb.append(String.format("  Day %02d: Avg=%.1f°F | Min=%.1f°F (%s) | Max=%.1f°F (%s)\n",
                            day, s.average, s.min, s.minTime.toLocalTime(), s.max, s.maxTime.toLocalTime()));
                });
            }
            sb.append("\n");
        }

        sb.append("2. HUMIDITY METRICS (Per Humidistat)\n");
        sb.append("-----------------------------------------------------------------\n");
        for (Humidistat h : humidistats) {
            sb.append(String.format("Humidistat %s (%s):\n", h.getId(), h.getRoom()));
            Map<Integer, DaySensorStats> dailyStats = computeDailyStats(readings, h.getId(), SensorReading.DeviceType.HUMIDISTAT);
            if (dailyStats.isEmpty()) {
                sb.append("  No readings available for this month.\n");
            } else {
                dailyStats.keySet().stream().sorted().forEach(day -> {
                    DaySensorStats s = dailyStats.get(day);
                    sb.append(String.format("  Day %02d: Avg=%.1f%% | Min=%.1f%% (%s) | Max=%.1f%% (%s)\n",
                            day, s.average, s.min, s.minTime.toLocalTime(), s.max, s.maxTime.toLocalTime()));
                });
            }
            sb.append("\n");
        }

        sb.append("3. SECURITY BREACHES\n");
        sb.append("-----------------------------------------------------------------\n");
        if (breaches.isEmpty()) {
            sb.append("  No security breaches recorded.\n");
        } else {
            for (SecurityBreachEvent b : breaches) {
                sb.append(String.format("  [BREACH] Date/Time: %s | Sensor: %s (%s at %s)\n",
                        b.getTimestamp(), b.getSensorId(), b.getSensorName(), b.getLocation()));
            }
        }
        sb.append("\n");

        sb.append("4. SYSTEM OUTAGES / NON-OPERATION PERIODS\n");
        sb.append("-----------------------------------------------------------------\n");
        if (downtimes.isEmpty()) {
            sb.append("  DH System was operational continuously throughout this month.\n");
        } else {
            for (SystemDowntimePeriod dt : downtimes) {
                sb.append(String.format("  [OUTAGE] From: %s to %s | Reason: %s\n",
                        dt.getStartTime(), dt.getEndTime(), dt.getReason()));
            }
        }
        sb.append("=================================================================\n");
        return sb.toString();
    }

    private Map<Integer, DaySensorStats> computeDailyStats(List<SensorReading> readings, String deviceId, SensorReading.DeviceType type) {
        Map<Integer, List<SensorReading>> grouped = readings.stream()
                .filter(r -> r.getDeviceId().equals(deviceId) && r.getDeviceType() == type)
                .collect(Collectors.groupingBy(r -> r.getTimestamp().getDayOfMonth()));

        Map<Integer, DaySensorStats> result = new HashMap<>();
        for (Map.Entry<Integer, List<SensorReading>> entry : grouped.entrySet()) {
            DaySensorStats stats = new DaySensorStats();
            double sum = 0;
            for (SensorReading r : entry.getValue()) {
                sum += r.getValue();
                stats.count++;
                if (r.getValue() < stats.min) {
                    stats.min = r.getValue();
                    stats.minTime = r.getTimestamp();
                }
                if (r.getValue() > stats.max) {
                    stats.max = r.getValue();
                    stats.maxTime = r.getTimestamp();
                }
            }
            stats.average = sum / stats.count;
            result.put(entry.getKey(), stats);
        }
        return result;
    }
}
