import java.time.LocalTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class TimePeriodSetting {
    private final String periodName;
    private final LocalTime startTime;
    private final LocalTime endTime;
    private final int targetTemperatureF;
    private final int targetHumidityPercent;
    private final boolean securityArmed;
    private final Map<String, SwitchState> switchStates;

    public TimePeriodSetting(String periodName, LocalTime startTime, LocalTime endTime,
                             int targetTemperatureF, int targetHumidityPercent,
                             boolean securityArmed, Map<String, SwitchState> switchStates) {
        this.periodName = periodName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.targetTemperatureF = targetTemperatureF;
        this.targetHumidityPercent = targetHumidityPercent;
        this.securityArmed = securityArmed;
        this.switchStates = switchStates != null ? new HashMap<>(switchStates) : new HashMap<>();
    }

    public String getPeriodName() {
        return periodName;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public int getTargetTemperatureF() {
        return targetTemperatureF;
    }

    public int getTargetHumidityPercent() {
        return targetHumidityPercent;
    }

    public boolean isSecurityArmed() {
        return securityArmed;
    }

    public Map<String, SwitchState> getSwitchStates() {
        return Collections.unmodifiableMap(switchStates);
    }
}
