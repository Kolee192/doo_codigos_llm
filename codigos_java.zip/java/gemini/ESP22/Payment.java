import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Payment {
    private final String id;
    private final PaymentType paymentType;
    private final int tableId;
    private final Integer customerId; // null if for whole table
    private final List<OrderItem> assignedMeals;
    private final List<Double> assignedTips;
    private boolean processed;
    private boolean refunded;

    public Payment(String id, PaymentType paymentType, int tableId, Integer customerId) {
        this.id = id;
        this.paymentType = paymentType;
        this.tableId = tableId;
        this.customerId = customerId;
        this.assignedMeals = new ArrayList<>();
        this.assignedTips = new ArrayList<>();
        this.processed = false;
        this.refunded = false;
    }

    public String getId() {
        return id;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public int getTableId() {
        return tableId;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public List<OrderItem> getAssignedMeals() {
        return Collections.unmodifiableList(assignedMeals);
    }

    public List<Double> getAssignedTips() {
        return Collections.unmodifiableList(assignedTips);
    }

    public boolean addMeal(OrderItem item) {
        if (!processed && !assignedMeals.contains(item)) {
            return assignedMeals.add(item);
        }
        return false;
    }

    public boolean removeMeal(OrderItem item) {
        if (!processed) {
            return assignedMeals.remove(item);
        }
        return false;
    }

    public boolean addTip(double tipAmount) {
        if (!processed) {
            return assignedTips.add(tipAmount);
        }
        return false;
    }

    public boolean removeTip(double tipAmount) {
        if (!processed) {
            return assignedTips.remove(Double.valueOf(tipAmount));
        }
        return false;
    }

    public double getMealsTotal() {
        double total = 0.0;
        for (OrderItem item : assignedMeals) {
            total += item.getPrice();
        }
        return total;
    }

    public double getTipsTotal() {
        double total = 0.0;
        for (Double tip : assignedTips) {
            total += tip;
        }
        return total;
    }

    public double getTotalAmount() {
        return getMealsTotal() + getTipsTotal();
    }

    public boolean isProcessed() {
        return processed;
    }

    public void setProcessed(boolean processed) {
        this.processed = processed;
    }

    public boolean isRefunded() {
        return refunded;
    }

    public void setRefunded(boolean refunded) {
        this.refunded = refunded;
    }
}
