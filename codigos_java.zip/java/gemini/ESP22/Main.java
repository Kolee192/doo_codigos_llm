public class Main {
    public static void main(String[] args) {
        System.out.println("=== RMOS System Initialization ===");
        Register register = new Register();
        RMOSServer server = new RMOSServer(register);

        // Staff members
        StaffMember waiter = new StaffMember("W1", "Alice Waiter", "alice", "pass123", Role.WAITER);
        StaffMember chef = new StaffMember("C1", "Bob Chef", "bob", "chef123", Role.CHEF);
        StaffMember supervisor = new StaffMember("S1", "Carol Supervisor", "carol", "super123", Role.SUPERVISOR);

        server.registerStaff(waiter);
        server.registerStaff(chef);
        server.registerStaff(supervisor);

        // Menu items
        MenuItem steak = new MenuItem("M1", "Ribeye Steak", 32.50, "Prime beef cut");
        MenuItem salad = new MenuItem("M2", "Garden Salad", 12.00, "Fresh organic vegetables");
        MenuItem wine = new MenuItem("M3", "Red Wine Glass", 9.50, "Cabernet Sauvignon");

        server.addMenuItem(steak);
        server.addMenuItem(salad);
        server.addMenuItem(wine);

        // Hardware terminals
        Tablet waiterTablet = new Tablet(server);
        KitchenDisplay kitchenDisplay = new KitchenDisplay(server);
        SurfaceComputer tableSurface = new SurfaceComputer(5, 2, server);

        // W01: Waiter login
        boolean waiterLoggedIn = waiterTablet.login("alice", "pass123");
        System.out.println("W01: Alice logged into tablet: " + waiterLoggedIn);

        // W03, W05: Activate surface computer & open table account, waiter assigned
        TableAccount account = waiterTablet.activateSurfaceComputer(tableSurface);
        System.out.println("W03 & W05: Table 5 activated. Account opened: " + account.getId() +
                ", Assigned Waiter: " + server.getAssignedWaiterId(5));

        // C01: Engage menu by double tapping activated surface computer
        tableSurface.doubleTapSurface();
        System.out.println("C01: Customer double-tapped surface. Menu engaged: " + tableSurface.isMenuEngaged());

        // C03: Create empty pending order
        Order order = tableSurface.createPendingOrder();
        System.out.println("C03: Empty pending order created: " + order.getId());

        // C05 & C06: Navigate and drag items onto pending order
        System.out.println("C05: Available menu items: " + tableSurface.getAvailableMenuItems().size());
        OrderItem meal1 = tableSurface.dragItemToOrder(steak, 1);
        OrderItem meal2 = tableSurface.dragItemToOrder(salad, 2);
        OrderItem meal3 = tableSurface.dragItemToOrder(wine, 1);
        System.out.println("C06: Added items: " + meal1.getMenuItem().getName() + ", " +
                meal2.getMenuItem().getName() + ", " + meal3.getMenuItem().getName());

        // C04: Customer cannot dismiss engaged menu while there is a non-empty pending order
        boolean dismissedAttempt = tableSurface.doubleTapDismiss();
        System.out.println("C04: Attempted dismiss with non-empty pending order: " + dismissedAttempt +
                " (Menu still engaged: " + tableSurface.isMenuEngaged() + ")");

        // C07: Drag item off order
        boolean itemRemoved = tableSurface.dragItemOffOrder(meal3);
        System.out.println("C07: Dragged wine off order: " + itemRemoved);

        // C08 & C09: Add dietary requirements (standard and wildcard)
        DietaryRequirement glutenFree = DietaryRequirement.standard("Gluten Free");
        tableSurface.dragDietaryRequirementToOrder(glutenFree);
        DietaryRequirement wildcardReq = tableSurface.addWildcardDietaryRequirement("No garlic or onion in sauce");
        System.out.println("C08: Added dietary req: " + glutenFree);
        System.out.println("C09: Added wildcard dietary req: " + wildcardReq);

        // C10: Place order
        boolean placed = tableSurface.placeOrder();
        System.out.println("C10: Order placed: " + placed);

        // W06: Alert received on waiter tablet for order placed
        System.out.println("W06: Waiter alerts: " + waiterTablet.getReceivedAlerts());
        waiterTablet.clearAlerts();

        // W07: Waiter accepts placed order
        boolean acceptedByWaiter = waiterTablet.acceptOrder(order.getId());
        System.out.println("W07: Waiter accepted order: " + acceptedByWaiter);

        // K01, K02, K03: Kitchen chef actions
        kitchenDisplay.login("bob", "chef123");
        kitchenDisplay.acceptOrderItem(meal1.getId());
        kitchenDisplay.markItemReady(meal1.getId(), 5);
        System.out.println("K01 & K03: Chef accepted and marked steak ready.");

        kitchenDisplay.rejectOrderItem(meal2.getId(), 5);
        System.out.println("K02: Chef rejected salad.");

        // W06: Verify alerts received on waiter tablet for item ready & item rejected
        System.out.println("W06: Waiter received kitchen alerts: " + waiterTablet.getReceivedAlerts());
        waiterTablet.clearAlerts();

        // C12: Customer calls for waiter assistance
        tableSurface.callWaiterAssistance();
        System.out.println("C12 & W06: Waiter assistance requested alert: " + waiterTablet.getReceivedAlerts());
        waiterTablet.clearAlerts();

        // W09: Waiter delivers steak to customer
        boolean delivered = waiterTablet.indicateDelivery(meal1.getId());
        System.out.println("W09: Waiter indicated delivery of steak: " + delivered);

        // C13: Customer engages bill mode
        tableSurface.engageBillMode();
        System.out.println("C13: Billing mode engaged: " + tableSurface.isBillModeEngaged());

        // C15 & C16: Representations of Cash for table & Bankcard for each customer
        Payment cashRep = tableSurface.getCashPaymentRepresentation();
        Payment cardRepCust1 = tableSurface.getBankcardPaymentRepresentation(1);
        System.out.println("C15: Cash payment representation: " + cashRep.getId());
        System.out.println("C16: Bankcard payment representation for Customer 1: " + cardRepCust1.getId());

        // C17 & C18: Ordered meals and tip denominations
        System.out.println("C17: Delivered meals ready for billing: " + tableSurface.getMealsOrderedForBilling());
        System.out.println("C18: Tip denominations available: " + tableSurface.getTipDenominations());

        // C19 & C21: Drag meal and tip into Customer 1 bankcard payment
        tableSurface.dragMealToPayment(meal1, cardRepCust1);
        tableSurface.dragTipToPayment(TipDenomination.FIVE, cardRepCust1);
        System.out.println("C19 & C21: Meal and $5 tip added to Customer 1 card payment. Total: $" +
                String.format("%.2f", cardRepCust1.getTotalAmount()));

        // C20 & C22: Test dragging out and re-adding
        tableSurface.dragTipOutOfPayment(TipDenomination.FIVE, cardRepCust1);
        System.out.println("C22: Tip removed. New total: $" + String.format("%.2f", cardRepCust1.getTotalAmount()));
        tableSurface.dragTipToPayment(TipDenomination.TEN, cardRepCust1);
        System.out.println("C21: $10 tip added. New total: $" + String.format("%.2f", cardRepCust1.getTotalAmount()));

        // G06 & W11: Tablet interfaces with register to process bankcard payment
        boolean paid = waiterTablet.processPaymentBankcard(cardRepCust1, "4111 2222 3333 4444");
        System.out.println("G06 & W11: Tablet processed bankcard payment: " + paid);

        // W04: Deactivate surface computer and close account
        tableSurface.disengageBillMode();
        waiterTablet.deactivateSurfaceComputer(tableSurface);
        System.out.println("W04: Surface computer deactivated. Account closed.");

        // S01-S05: Supervisor capabilities demonstration
        System.out.println("\n=== Supervisor Privileges Demo ===");
        Tablet supervisorTablet = new Tablet(server);
        supervisorTablet.login("carol", "super123");

        // Open Table 2 for supervisor demo
        SurfaceComputer table2 = new SurfaceComputer(2, 2, server);
        supervisorTablet.activateSurfaceComputer(table2);
        table2.doubleTapSurface();
        table2.createPendingOrder();
        OrderItem supMeal = table2.dragItemToOrder(steak, 1);
        table2.placeOrder();
        supervisorTablet.acceptOrder(table2.getPendingOrder() != null ? "" : server.getActiveAccount(2).getOrders().get(0).getId());

        // S02: Supervisor performs chef operation
        supervisorTablet.chefMarkItemReady(supMeal.getId(), 2, kitchenDisplay);
        supervisorTablet.indicateDelivery(supMeal.getId());

        // S03: Supervisor aborts/purges meal from active system with no expectation of payment
        boolean mealPurged = supervisorTablet.abortMeal(supMeal.getId());
        System.out.println("S03: Supervisor purged meal: " + mealPurged + " (Status=" + supMeal.getStatus() + ")");

        // S04: Supervisor aborts/purges entire table account
        boolean accountPurged = supervisorTablet.abortTableAccount(2, table2);
        System.out.println("S04: Supervisor purged table 2 account: " + accountPurged);

        // S05: Supervisor issues refund for customer 1's previous payment
        boolean refundSuccess = supervisorTablet.issueRefund(cardRepCust1, Collections.singletonList(meal1));
        System.out.println("S05: Supervisor issued refund for steak: " + refundSuccess);

        System.out.println("\nRegister Transaction Audit Logs:");
        for (String log : register.getTransactionLogs()) {
            System.out.println(" - " + log);
        }

        System.out.println("\n=== RMOS Demo Completed Successfully ===");
    }
}
