import java.util.ArrayList;
import java.util.List;

public class OrderItem {
    private final String id;
    private final MenuItem menuItem;
    private final int customerId;
    private final List<DietaryRequirement> dietaryRequirements;
    private OrderItemStatus status;

    public OrderItem(String id, MenuItem menuItem, int customerId) {
        this.id = id;
        this.menuItem = menuItem;
        this.customerId = customerId;
        this.dietaryRequirements = new ArrayList<>();
        this.status = OrderItemStatus.ORDERED;
    }

    public String getId() {
        return id;
    }

    public MenuItem getMenuItem() {
        return menuItem;
    }

    public int getCustomerId() {
        return customerId;
    }

    public List<DietaryRequirement> getDietaryRequirements() {
        return dietaryRequirements;
    }

    public void addDietaryRequirement(DietaryRequirement requirement) {
        this.dietaryRequirements.add(requirement);
    }

    public OrderItemStatus getStatus() {
        return status;
    }

    public void setStatus(OrderItemStatus status) {
        this.status = status;
    }

    public double getPrice() {
        return menuItem.getPrice();
    }

    @Override
    public String toString() {
        return id + ": " + menuItem.getName() + " for Customer " + customerId + " [" + status + "]";
    }
}
