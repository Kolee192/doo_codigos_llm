import java.util.ArrayList;
import java.util.List;

public class Register {
    private final List<String> transactionLogs;

    public Register() {
        this.transactionLogs = new ArrayList<>();
    }

    public boolean processCashPayment(Payment payment, double tenderedAmount) {
        double total = payment.getTotalAmount();
        if (tenderedAmount >= total) {
            payment.setProcessed(true);
            double change = tenderedAmount - total;
            String log = "CASH PAYMENT ACCEPTED. PaymentId=" + payment.getId() +
                    ", Total=$" + String.format("%.2f", total) +
                    ", Tendered=$" + String.format("%.2f", tenderedAmount) +
                    ", Change=$" + String.format("%.2f", change);
            transactionLogs.add(log);
            return true;
        }
        return false;
    }

    public boolean processBankcardPayment(Payment payment, String cardNumber) {
        if (cardNumber != null && cardNumber.replaceAll("\\s+", "").length() >= 12) {
            payment.setProcessed(true);
            String masked = "**** **** **** " + cardNumber.substring(cardNumber.length() - 4);
            String log = "BANKCARD PAYMENT APPROVED. PaymentId=" + payment.getId() +
                    ", Card=" + masked +
                    ", Total=$" + String.format("%.2f", payment.getTotalAmount());
            transactionLogs.add(log);
            return true;
        }
        return false;
    }

    public boolean processRefund(Payment payment, double refundAmount) {
        payment.setRefunded(true);
        String log = "REFUND PROCESSED. PaymentId=" + payment.getId() +
                ", Amount=$" + String.format("%.2f", refundAmount);
        transactionLogs.add(log);
        return true;
    }

    public List<String> getTransactionLogs() {
        return new ArrayList<>(transactionLogs);
    }
}
