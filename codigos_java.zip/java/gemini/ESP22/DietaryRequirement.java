public class DietaryRequirement {
    private final String description;
    private final boolean wildcard;

    public DietaryRequirement(String description, boolean wildcard) {
        this.description = description;
        this.wildcard = wildcard;
    }

    public static DietaryRequirement standard(String description) {
        return new DietaryRequirement(description, false);
    }

    public static DietaryRequirement wildcard(String customRequirement) {
        return new DietaryRequirement(customRequirement, true);
    }

    public String getDescription() {
        return description;
    }

    public boolean isWildcard() {
        return wildcard;
    }

    @Override
    public String toString() {
        return wildcard ? "[Wildcard] " + description : description;
    }
}
