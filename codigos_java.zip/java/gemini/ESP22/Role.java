public enum Role {
    WAITER,
    CHEF,
    SUPERVISOR
}
