import java.util.*;

public class Tablet implements AlertListener {
    private final RMOSServer server;
    private StaffMember currentUser;
    private final List<Alert> receivedAlerts;

    public Tablet(RMOSServer server) {
        this.server = server;
        this.receivedAlerts = new ArrayList<>();
    }

    // W01: Waiter / supervisor logs into tablet
    public boolean login(String username, String password) {
        StaffMember staff = server.authenticateStaff(username, password);
        if (staff != null && (staff.getRole() == Role.WAITER || staff.getRole() == Role.SUPERVISOR)) {
            this.currentUser = staff;
            server.registerAlertListener(staff.getId(), this);
            return true;
        }
        return false;
    }

    // W02: Waiter logs out of tablet
    public void logout() {
        if (currentUser != null) {
            server.unregisterAlertListener(currentUser.getId());
            this.currentUser = null;
        }
    }

    public StaffMember getCurrentUser() {
        return currentUser;
    }

    // W03 & W05: Activate surface computer and open its account, assigned to table
    public TableAccount activateSurfaceComputer(SurfaceComputer surfaceComputer) {
        if (currentUser == null) throw new IllegalStateException("Staff must be logged in");
        TableAccount account = server.openAccount(surfaceComputer.getTableId(), currentUser.getId());
        surfaceComputer.setActivated(true);
        return account;
    }

    // W04: Deactivate surface computer and close its account
    public TableAccount deactivateSurfaceComputer(SurfaceComputer surfaceComputer) {
        if (currentUser == null) throw new IllegalStateException("Staff must be logged in");
        surfaceComputer.setActivated(false);
        return server.closeAccount(surfaceComputer.getTableId());
    }

    // W06: Alerted via wireless tablet
    @Override
    public void onAlert(Alert alert) {
        receivedAlerts.add(alert);
    }

    public List<Alert> getReceivedAlerts() {
        return Collections.unmodifiableList(receivedAlerts);
    }

    public void clearAlerts() {
        receivedAlerts.clear();
    }

    // W07: Accept order placed by customer
    public boolean acceptOrder(String orderId) {
        if (currentUser == null) throw new IllegalStateException("Staff must be logged in");
        Order order = server.getOrder(orderId);
        if (order != null && order.getStatus() == OrderStatus.PLACED) {
            order.setStatus(OrderStatus.ACCEPTED_BY_WAITER);
            return true;
        }
        return false;
    }

    // W08: Reject order placed by customer
    public boolean rejectOrder(String orderId) {
        if (currentUser == null) throw new IllegalStateException("Staff must be logged in");
        Order order = server.getOrder(orderId);
        if (order != null && order.getStatus() == OrderStatus.PLACED) {
            order.setStatus(OrderStatus.REJECTED_BY_WAITER);
            return true;
        }
        return false;
    }

    // W09: Indicate delivery of an item to customer
    public boolean indicateDelivery(String orderItemId) {
        if (currentUser == null) throw new IllegalStateException("Staff must be logged in");
        OrderItem item = server.getOrderItem(orderItemId);
        if (item != null && item.getStatus() == OrderItemStatus.READY_TO_SERVE) {
            item.setStatus(OrderItemStatus.DELIVERED);
            return true;
        }
        return false;
    }

    // G06 & W10: Process payment using cash (interfacing with register)
    public boolean processPaymentCash(Payment payment, double tenderedAmount) {
        if (currentUser == null) throw new IllegalStateException("Staff must be logged in");
        return server.getRegister().processCashPayment(payment, tenderedAmount);
    }

    // G06 & W11: Process payment using bankcard (interfacing with register)
    public boolean processPaymentBankcard(Payment payment, String cardNumber) {
        if (currentUser == null) throw new IllegalStateException("Staff must be logged in");
        return server.getRegister().processBankcardPayment(payment, cardNumber);
    }

    // S01 & S02: Supervisor can do chef operations
    public boolean chefAcceptOrderItem(String orderItemId, KitchenDisplay display) {
        checkSupervisorRole();
        return display.acceptOrderItem(orderItemId);
    }

    public boolean chefRejectOrderItem(String orderItemId, int tableId, KitchenDisplay display) {
        checkSupervisorRole();
        return display.rejectOrderItem(orderItemId, tableId);
    }

    public boolean chefMarkItemReady(String orderItemId, int tableId, KitchenDisplay display) {
        checkSupervisorRole();
        return display.markItemReady(orderItemId, tableId);
    }

    // S03: Supervisor can abort/purge a customer's meal from active system with no expectation of payment
    public boolean abortMeal(String orderItemId) {
        checkSupervisorRole();
        return server.purgeMeal(orderItemId);
    }

    // S04: Supervisor can abort/purge a table's account/meals with no expectation of payment
    public boolean abortTableAccount(int tableId, SurfaceComputer surface) {
        checkSupervisorRole();
        surface.setActivated(false);
        return server.purgeTableAccount(tableId);
    }

    // S05: Supervisor can issue a refund for one or more items to a customer
    public boolean issueRefund(Payment payment, List<OrderItem> itemsToRefund) {
        checkSupervisorRole();
        if (!payment.isProcessed()) {
            return false;
        }
        double refundTotal = 0.0;
        for (OrderItem item : itemsToRefund) {
            item.setStatus(OrderItemStatus.REFUNDED);
            refundTotal += item.getPrice();
        }
        return server.getRegister().processRefund(payment, refundTotal);
    }

    private void checkSupervisorRole() {
        if (currentUser == null || currentUser.getRole() != Role.SUPERVISOR) {
            throw new SecurityException("Supervisor role required for this action");
        }
    }
}
