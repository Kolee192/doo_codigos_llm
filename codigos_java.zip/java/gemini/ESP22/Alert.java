import java.time.Instant;

public class Alert {
    private final AlertNotificationType type;
    private final int tableId;
    private final String message;
    private final Instant timestamp;

    public Alert(AlertNotificationType type, int tableId, String message) {
        this.type = type;
        this.tableId = tableId;
        this.message = message;
        this.timestamp = Instant.now();
    }

    public AlertNotificationType getType() {
        return type;
    }

    public int getTableId() {
        return tableId;
    }

    public String getMessage() {
        return message;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "[" + type + " - Table " + tableId + "] " + message;
    }
}
