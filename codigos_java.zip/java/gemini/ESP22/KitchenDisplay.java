public class KitchenDisplay {
    private final RMOSServer server;
    private StaffMember currentUser;

    public KitchenDisplay(RMOSServer server) {
        this.server = server;
    }

    public boolean login(String username, String password) {
        StaffMember staff = server.authenticateStaff(username, password);
        if (staff != null && (staff.getRole() == Role.CHEF || staff.getRole() == Role.SUPERVISOR)) {
            this.currentUser = staff;
            return true;
        }
        return false;
    }

    public void logout() {
        this.currentUser = null;
    }

    public StaffMember getCurrentUser() {
        return currentUser;
    }

    // K01: Chef accepts a customer's order item
    public boolean acceptOrderItem(String orderItemId) {
        if (currentUser == null) throw new IllegalStateException("User not logged in");
        OrderItem item = server.getOrderItem(orderItemId);
        if (item != null && item.getStatus() == OrderItemStatus.ORDERED) {
            item.setStatus(OrderItemStatus.ACCEPTED_BY_KITCHEN);
            return true;
        }
        return false;
    }

    // K02: Chef rejects a customer's order item
    public boolean rejectOrderItem(String orderItemId, int tableId) {
        if (currentUser == null) throw new IllegalStateException("User not logged in");
        OrderItem item = server.getOrderItem(orderItemId);
        if (item != null) {
            item.setStatus(OrderItemStatus.REJECTED_BY_KITCHEN);
            server.notifyAssignedWaiter(tableId,
                    new Alert(AlertNotificationType.ITEM_REJECTED, tableId,
                            "Item rejected by kitchen: " + item.getMenuItem().getName()));
            return true;
        }
        return false;
    }

    // K03: Chef indicates that an order item is ready to be served
    public boolean markItemReady(String orderItemId, int tableId) {
        if (currentUser == null) throw new IllegalStateException("User not logged in");
        OrderItem item = server.getOrderItem(orderItemId);
        if (item != null) {
            item.setStatus(OrderItemStatus.READY_TO_SERVE);
            server.notifyAssignedWaiter(tableId,
                    new Alert(AlertNotificationType.ITEM_READY, tableId,
                            "Item ready to serve: " + item.getMenuItem().getName()));
            return true;
        }
        return false;
    }
}
