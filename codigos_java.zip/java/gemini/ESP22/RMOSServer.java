import java.util.*;

public class RMOSServer {
    private final Map<Integer, TableAccount> activeAccounts;
    private final Map<Integer, TableAccount> allAccounts;
    private final Map<Integer, String> tableAssignedWaiters;
    private final Map<String, AlertListener> waiterListeners;
    private final Map<String, StaffMember> staffMembers;
    private final List<MenuItem> menuCatalog;
    private final Map<String, Order> orders;
    private final Map<String, OrderItem> orderItems;
    private final Map<String, Payment> payments;
    private final Register register;
    private int accountCounter = 1;
    private int orderCounter = 1;
    private int itemCounter = 1;
    private int paymentCounter = 1;

    public RMOSServer(Register register) {
        this.register = register;
        this.activeAccounts = new HashMap<>();
        this.allAccounts = new HashMap<>();
        this.tableAssignedWaiters = new HashMap<>();
        this.waiterListeners = new HashMap<>();
        this.staffMembers = new HashMap<>();
        this.menuCatalog = new ArrayList<>();
        this.orders = new HashMap<>();
        this.orderItems = new HashMap<>();
        this.payments = new HashMap<>();
    }

    public void registerStaff(StaffMember staff) {
        staffMembers.put(staff.getUsername(), staff);
    }

    public StaffMember authenticateStaff(String username, String password) {
        StaffMember staff = staffMembers.get(username);
        if (staff != null && staff.authenticate(password)) {
            return staff;
        }
        return null;
    }

    public void addMenuItem(MenuItem item) {
        menuCatalog.add(item);
    }

    public List<MenuItem> getMenuCatalog() {
        return Collections.unmodifiableList(menuCatalog);
    }

    public Register getRegister() {
        return register;
    }

    public void registerAlertListener(String waiterId, AlertListener listener) {
        waiterListeners.put(waiterId, listener);
    }

    public void unregisterAlertListener(String waiterId) {
        waiterListeners.remove(waiterId);
    }

    public TableAccount openAccount(int tableId, String waiterId) {
        String accId = "ACC-" + (accountCounter++);
        TableAccount account = new TableAccount(accId, tableId);
        activeAccounts.put(tableId, account);
        allAccounts.put(tableId, account);
        tableAssignedWaiters.put(tableId, waiterId);
        return account;
    }

    public TableAccount getActiveAccount(int tableId) {
        return activeAccounts.get(tableId);
    }

    public TableAccount closeAccount(int tableId) {
        TableAccount account = activeAccounts.remove(tableId);
        if (account != null) {
            account.close();
        }
        tableAssignedWaiters.remove(tableId);
        return account;
    }

    public String getAssignedWaiterId(int tableId) {
        return tableAssignedWaiters.get(tableId);
    }

    public OrderItem createOrderItem(MenuItem menuItem, int customerId) {
        String itemId = "ITEM-" + (itemCounter++);
        OrderItem orderItem = new OrderItem(itemId, menuItem, customerId);
        orderItems.put(itemId, orderItem);
        return orderItem;
    }

    public Order createOrder(int tableId) {
        String ordId = "ORD-" + (orderCounter++);
        Order order = new Order(ordId, tableId);
        orders.put(ordId, order);
        return order;
    }

    public Order getOrder(String orderId) {
        return orders.get(orderId);
    }

    public OrderItem getOrderItem(String itemId) {
        return orderItems.get(itemId);
    }

    public void placeOrder(Order order) {
        order.setStatus(OrderStatus.PLACED);
        TableAccount acc = activeAccounts.get(order.tableId());
        if (acc != null) {
            acc.addOrder(order);
        }
        notifyAssignedWaiter(order.tableId(),
                new Alert(AlertNotificationType.ORDER_PLACED, order.tableId(),
                        "New order placed: " + order.getId() + " with " + order.getItems().size() + " items."));
    }

    public void notifyAssignedWaiter(int tableId, Alert alert) {
        String waiterId = tableAssignedWaiters.get(tableId);
        if (waiterId != null) {
            AlertListener listener = waiterListeners.get(waiterId);
            if (listener != null) {
                listener.onAlert(alert);
            }
        }
    }

    public Payment createPayment(PaymentType type, int tableId, Integer customerId) {
        String pid = "PAY-" + (paymentCounter++);
        Payment payment = new Payment(pid, type, tableId, customerId);
        payments.put(pid, payment);
        TableAccount acc = activeAccounts.get(tableId);
        if (acc != null) {
            acc.addPayment(payment);
        }
        return payment;
    }

    public Payment getPayment(String paymentId) {
        return payments.get(paymentId);
    }

    public boolean purgeMeal(String orderItemId) {
        OrderItem item = orderItems.get(orderItemId);
        if (item != null) {
            item.setStatus(OrderItemStatus.PURGED);
            return true;
        }
        return false;
    }

    public boolean purgeTableAccount(int tableId) {
        TableAccount acc = activeAccounts.remove(tableId);
        if (acc != null) {
            acc.purge();
            tableAssignedWaiters.remove(tableId);
            return true;
        }
        return false;
    }
}
