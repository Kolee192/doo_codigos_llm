public enum OrderStatus {
    PENDING,
    PLACED,
    ACCEPTED_BY_WAITER,
    REJECTED_BY_WAITER,
    CANCELLED
}
