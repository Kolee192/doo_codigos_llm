public enum PaymentType {
    CASH,
    BANKCARD
}
