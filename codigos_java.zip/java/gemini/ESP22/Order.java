import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Order {
    private final String id;
    private final int tableId;
    private final List<OrderItem> items;
    private final List<DietaryRequirement> orderRequirements;
    private OrderStatus status;

    public Order(String id, int tableId) {
        this.id = id;
        this.tableId = tableId;
        this.items = new ArrayList<>();
        this.orderRequirements = new ArrayList<>();
        this.status = OrderStatus.PENDING;
    }

    public String getId() {
        return id;
    }

    public int tableId() {
        return tableId;
    }

    public List<OrderItem> getItems() {
        return Collections.unmodifiableList(items);
    }

    public List<DietaryRequirement> getOrderRequirements() {
        return Collections.unmodifiableList(orderRequirements);
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public boolean addItem(OrderItem item) {
        if (status == OrderStatus.PENDING) {
            return items.add(item);
        }
        return false;
    }

    public boolean removeItem(OrderItem item) {
        if (status == OrderStatus.PENDING) {
            return items.remove(item);
        }
        return false;
    }

    public boolean addDietaryRequirement(DietaryRequirement req) {
        if (status == OrderStatus.PENDING) {
            return orderRequirements.add(req);
        }
        return false;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
