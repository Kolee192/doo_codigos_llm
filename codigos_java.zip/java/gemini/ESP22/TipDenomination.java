public enum TipDenomination {
    ONE(1.00),
    TWO(2.00),
    FIVE(5.00),
    TEN(10.00),
    TWENTY(20.00);

    private final double amount;

    TipDenomination(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }
}
