import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TableAccount {
    private final String id;
    private final int tableId;
    private final List<Order> orders;
    private final List<Payment> payments;
    private boolean open;
    private boolean purged;

    public TableAccount(String id, int tableId) {
        this.id = id;
        this.tableId = tableId;
        this.orders = new ArrayList<>();
        this.payments = new ArrayList<>();
        this.open = true;
        this.purged = false;
    }

    public String getId() {
        return id;
    }

    public int getTableId() {
        return tableId;
    }

    public boolean isOpen() {
        return open;
    }

    public void close() {
        this.open = false;
    }

    public boolean isPurged() {
        return purged;
    }

    public void purge() {
        this.purged = true;
        this.open = false;
        for (Order order : orders) {
            for (OrderItem item : order.getItems()) {
                item.setStatus(OrderItemStatus.PURGED);
            }
        }
    }

    public void addOrder(Order order) {
        orders.add(order);
    }

    public List<Order> getOrders() {
        return Collections.unmodifiableList(orders);
    }

    public void addPayment(Payment payment) {
        payments.add(payment);
    }

    public List<Payment> getPayments() {
        return Collections.unmodifiableList(payments);
    }

    public List<OrderItem> getAllMeals() {
        List<OrderItem> all = new ArrayList<>();
        for (Order order : orders) {
            all.addAll(order.getItems());
        }
        return all;
    }
}
