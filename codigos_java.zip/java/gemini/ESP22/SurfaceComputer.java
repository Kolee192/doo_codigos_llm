import java.util.*;

public class SurfaceComputer {
    private final int tableId;
    private final int numberOfSeats;
    private final RMOSServer server;

    private boolean activated;
    private boolean menuEngaged;
    private boolean billModeEngaged;

    private Order pendingOrder;

    private Payment cashPayment;
    private final Map<Integer, Payment> bankcardPayments;

    public SurfaceComputer(int tableId, int numberOfSeats, RMOSServer server) {
        this.tableId = tableId;
        this.numberOfSeats = numberOfSeats;
        this.server = server;
        this.activated = false;
        this.menuEngaged = false;
        this.billModeEngaged = false;
        this.bankcardPayments = new HashMap<>();
    }

    public int getTableId() {
        return tableId;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public boolean isActivated() {
        return activated;
    }

    public void setActivated(boolean activated) {
        this.activated = activated;
        if (!activated) {
            this.menuEngaged = false;
            this.billModeEngaged = false;
            this.pendingOrder = null;
            this.cashPayment = null;
            this.bankcardPayments.clear();
        }
    }

    public boolean isMenuEngaged() {
        return menuEngaged;
    }

    public boolean isBillModeEngaged() {
        return billModeEngaged;
    }

    // C01: Double tap activated surface computer to engage menu
    public boolean doubleTapSurface() {
        if (activated) {
            this.menuEngaged = true;
            return true;
        }
        return false;
    }

    // C02 & C04: Double tap dismiss option; cannot dismiss if non-empty pending order
    public boolean doubleTapDismiss() {
        if (!menuEngaged) {
            return false;
        }
        if (pendingOrder != null && !pendingOrder.isEmpty()) {
            return false; // C04
        }
        this.menuEngaged = false;
        return true;
    }

    // C03: Create an empty pending order through engaged menu
    public Order createPendingOrder() {
        if (!menuEngaged) {
            throw new IllegalStateException("Menu must be engaged to create an order");
        }
        this.pendingOrder = server.createOrder(tableId);
        return this.pendingOrder;
    }

    public Order getPendingOrder() {
        return pendingOrder;
    }

    // C05: Navigate through available items in engaged menu
    public List<MenuItem> getAvailableMenuItems() {
        if (!menuEngaged) {
            throw new IllegalStateException("Menu is not engaged");
        }
        return server.getMenuCatalog();
    }

    // C06: Add item to pending order by dragging item onto order
    public OrderItem dragItemToOrder(MenuItem item, int customerId) {
        if (!menuEngaged || pendingOrder == null) {
            throw new IllegalStateException("Engaged menu and pending order required");
        }
        OrderItem orderItem = server.createOrderItem(item, customerId);
        pendingOrder.addItem(orderItem);
        return orderItem;
    }

    // C07: Remove item from pending order by dragging item off order
    public boolean dragItemOffOrder(OrderItem item) {
        if (!menuEngaged || pendingOrder == null) {
            return false;
        }
        return pendingOrder.removeItem(item);
    }

    // C08: Add special dietary requirement to order by dragging requirement onto order
    public boolean dragDietaryRequirementToOrder(DietaryRequirement req) {
        if (!menuEngaged || pendingOrder == null) {
            return false;
        }
        return pendingOrder.addDietaryRequirement(req);
    }

    // C09: Add wildcard special dietary requirement to order
    public DietaryRequirement addWildcardDietaryRequirement(String customRequirement) {
        if (!menuEngaged || pendingOrder == null) {
            throw new IllegalStateException("Engaged menu and pending order required");
        }
        DietaryRequirement wildcardReq = DietaryRequirement.wildcard(customRequirement);
        pendingOrder.addDietaryRequirement(wildcardReq);
        return wildcardReq;
    }

    // C10: Place order through engaged menu if pending and not empty
    public boolean placeOrder() {
        if (menuEngaged && pendingOrder != null && !pendingOrder.isEmpty() && pendingOrder.getStatus() == OrderStatus.PENDING) {
            server.placeOrder(pendingOrder);
            pendingOrder = null;
            return true;
        }
        return false;
    }

    // C11: Cancel order through engaged menu if pending and not yet placed
    public boolean cancelOrder() {
        if (menuEngaged && pendingOrder != null && pendingOrder.getStatus() == OrderStatus.PENDING) {
            pendingOrder.setStatus(OrderStatus.CANCELLED);
            pendingOrder = null;
            return true;
        }
        return false;
    }

    // C12: Call for waiter assistance through engaged menu
    public void callWaiterAssistance() {
        if (!menuEngaged) {
            throw new IllegalStateException("Menu is not engaged");
        }
        server.notifyAssignedWaiter(tableId,
                new Alert(AlertNotificationType.WAITER_ASSISTANCE, tableId, "Table " + tableId + " requested waiter assistance."));
    }

    // C13: Engage bill mode to finalise payment through engaged menu
    public void engageBillMode() {
        if (!menuEngaged) {
            throw new IllegalStateException("Menu is not engaged");
        }
        this.billModeEngaged = true;
        // C15: Cash payment for the whole table
        this.cashPayment = server.createPayment(PaymentType.CASH, tableId, null);
        // C16: Bankcard payment representation for each customer
        this.bankcardPayments.clear();
        for (int i = 1; i <= numberOfSeats; i++) {
            this.bankcardPayments.put(i, server.createPayment(PaymentType.BANKCARD, tableId, i));
        }
    }

    // C14: Disengage bill mode to cancel the billing process through engaged menu
    public void disengageBillMode() {
        if (!menuEngaged) {
            throw new IllegalStateException("Menu is not engaged");
        }
        this.billModeEngaged = false;
        this.cashPayment = null;
        this.bankcardPayments.clear();
    }

    // C15: Display cash payment representation
    public Payment getCashPaymentRepresentation() {
        if (!billModeEngaged) {
            throw new IllegalStateException("Bill mode is not engaged");
        }
        return cashPayment;
    }

    // C16: Display bankcard payment representation for customer
    public Payment getBankcardPaymentRepresentation(int customerId) {
        if (!billModeEngaged) {
            throw new IllegalStateException("Bill mode is not engaged");
        }
        return bankcardPayments.get(customerId);
    }

    // C17: Display every meal ordered that may be dragged into a payment
    public List<OrderItem> getMealsOrderedForBilling() {
        if (!billModeEngaged) {
            throw new IllegalStateException("Bill mode is not engaged");
        }
        TableAccount acc = server.getActiveAccount(tableId);
        if (acc == null) return Collections.emptyList();
        List<OrderItem> eligible = new ArrayList<>();
        for (OrderItem item : acc.getAllMeals()) {
            if (item.getStatus() == OrderItemStatus.DELIVERED || item.getStatus() == OrderItemStatus.READY_TO_SERVE) {
                eligible.add(item);
            }
        }
        return eligible;
    }

    // C18: Display tip denominations
    public List<TipDenomination> getTipDenominations() {
        if (!billModeEngaged) {
            throw new IllegalStateException("Bill mode is not engaged");
        }
        return Arrays.asList(TipDenomination.values());
    }

    // C19: Drag meal into a bankcard or cash payment
    public boolean dragMealToPayment(OrderItem meal, Payment payment) {
        if (!billModeEngaged || payment == null || meal == null) {
            return false;
        }
        return payment.addMeal(meal);
    }

    // C20: Drag meal out of a bankcard or cash payment
    public boolean dragMealOutOfPayment(OrderItem meal, Payment payment) {
        if (!billModeEngaged || payment == null || meal == null) {
            return false;
        }
        return payment.removeMeal(meal);
    }

    // C21: Drag tip denomination into a bankcard or cash payment
    public boolean dragTipToPayment(TipDenomination tip, Payment payment) {
        if (!billModeEngaged || payment == null || tip == null) {
            return false;
        }
        return payment.addTip(tip.getAmount());
    }

    // C22: Drag tip denomination out of a bankcard or cash payment
    public boolean dragTipOutOfPayment(TipDenomination tip, Payment payment) {
        if (!billModeEngaged || payment == null || tip == null) {
            return false;
        }
        return payment.removeTip(tip.getAmount());
    }
}
