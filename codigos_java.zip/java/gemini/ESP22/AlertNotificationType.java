public enum AlertNotificationType {
    ORDER_PLACED,
    ITEM_REJECTED,
    ITEM_READY,
    WAITER_ASSISTANCE
}
