package dataregistry;

import java.util.ArrayList;
import java.util.List;

public class NotificationService {
    private final List<String> notificationLog = new ArrayList<>();

    public void notifySubscribers(DataPackage dataPackage, String message) {
        for (String email : dataPackage.getSubscribers()) {
            String entry = "[To: " + email + "] Update on " + dataPackage.getName() + ": " + message;
            notificationLog.add(entry);
        }
    }

    public void sendInviteNotification(String email, String publisherName, String invitedBy) {
        notificationLog.add("[To: " + email + "] You have been invited to join publisher '" + publisherName + "' by " + invitedBy);
    }

    public List<String> getNotificationLog() {
        return new ArrayList<>(notificationLog);
    }
}
