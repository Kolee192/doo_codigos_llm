package dataregistry;

import java.time.Instant;
import java.util.*;

public class PublisherOrganization {
    private final String id;
    private final String name;
    private String displayName;
    private String description;
    private final Map<User, Role> members = new HashMap<>();
    private PricingPlan pricingPlan = PricingPlan.FREE;
    private final Instant createdAt;

    public PublisherOrganization(String id, String name, String displayName, String description, User creator) {
        this.id = id;
        this.name = name;
        this.displayName = displayName != null ? displayName : name;
        this.description = description != null ? description : "";
        this.createdAt = Instant.now();
        if (creator != null) {
            members.put(creator, Role.OWNER);
        }
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public PricingPlan getPricingPlan() {
        return pricingPlan;
    }

    public void setPricingPlan(PricingPlan pricingPlan) {
        this.pricingPlan = pricingPlan != null ? pricingPlan : PricingPlan.FREE;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Map<User, Role> getMembers() {
        return Collections.unmodifiableMap(members);
    }

    public void addMember(User user, Role role) {
        members.put(user, role);
    }

    public void removeMember(User user) {
        members.remove(user);
    }

    public void setRole(User user, Role newRole) {
        if (members.containsKey(user)) {
            members.put(user, newRole);
        }
    }

    public boolean isOwner(User user) {
        return members.get(user) == Role.OWNER;
    }

    public boolean hasPublishAccess(User user) {
        Role role = members.get(user);
        return role == Role.OWNER || role == Role.MEMBER;
    }

    @Override
    public String toString() {
        return displayName + " (@" + name + ") - Plan: " + pricingPlan.getName();
    }
}
