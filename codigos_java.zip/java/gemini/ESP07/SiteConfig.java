package dataregistry;

public class SiteConfig {
    private String siteTitle = "DataHub Registry";
    private String adminContact = "admin@datahub.io";
    private boolean allowPublicRegistration = true;
    private int maxGlobalStorageGb = 1000;

    public String getSiteTitle() {
        return siteTitle;
    }

    public void setSiteTitle(String siteTitle) {
        this.siteTitle = siteTitle;
    }

    public String getAdminContact() {
        return adminContact;
    }

    public void setAdminContact(String adminContact) {
        this.adminContact = adminContact;
    }

    public boolean isAllowPublicRegistration() {
        return allowPublicRegistration;
    }

    public void setAllowPublicRegistration(boolean allowPublicRegistration) {
        this.allowPublicRegistration = allowPublicRegistration;
    }

    public int getMaxGlobalStorageGb() {
        return maxGlobalStorageGb;
    }

    public void setMaxGlobalStorageGb(int maxGlobalStorageGb) {
        this.maxGlobalStorageGb = maxGlobalStorageGb;
    }
}
