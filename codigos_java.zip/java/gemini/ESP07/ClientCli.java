package dataregistry;

import java.util.Optional;

public class ClientCli {
    private String configuredRegistryUrl = "https://registry.datahub.io";
    private String userApiKey = "";
    private final RegistryService registryService;
    private final LocalProjectEnvironment localEnv;

    public ClientCli(RegistryService registryService, String projectName) {
        this.registryService = registryService;
        this.localEnv = new LocalProjectEnvironment(projectName);
    }

    public void configure(String registryUrl, String apiKey) {
        this.configuredRegistryUrl = registryUrl;
        this.userApiKey = apiKey;
        System.out.println("[CLI] Client configured: endpoint=" + configuredRegistryUrl + ", key=" + (apiKey.isEmpty() ? "none" : "****"));
    }

    public ValidationResult validate(DataPackageDescriptor descriptor) {
        System.out.println("[CLI] Validating package: " + descriptor.getName());
        return registryService.getValidator().validate(descriptor);
    }

    public void previewViews(DataPackageDescriptor descriptor) {
        System.out.println("[CLI] Previewing views for: " + descriptor.getName());
        if (descriptor.getViews().isEmpty()) {
            System.out.println("  No views declared in datapackage descriptor.");
        } else {
            for (DataPackageView view : descriptor.getViews()) {
                System.out.println("  -> View [" + view.getName() + " | type: " + view.getViewType() + "]");
                System.out.println("     Declaration: " + view.getSpecJson());
            }
        }
    }

    public DataPackage publish(User user, String publisherName, DataPackageDescriptor descriptor, Visibility visibility) {
        System.out.println("[CLI] Running publish command for " + publisherName + "/" + descriptor.getName() + "...");
        return registryService.publishPackage(user, publisherName, descriptor, visibility);
    }

    public void undelete(User user, String publisherName, String packageName) {
        System.out.println("[CLI] Running undelete/restore command for " + publisherName + "/" + packageName);
        registryService.restorePackage(user, publisherName, packageName);
    }

    public SchemaDiff diffVersionsLocally(DataPackageDescriptor v1, DataPackageDescriptor v2) {
        System.out.println("[CLI] Comparing schema diff between v" + v1.getVersion() + " and v" + v2.getVersion());
        Schema s1 = v1.getResources().isEmpty() ? new Schema() : v1.getResources().get(0).getSchema();
        Schema s2 = v2.getResources().isEmpty() ? new Schema() : v2.getResources().get(0).getSchema();
        return s2.compareTo(s1);
    }

    public void installPackageVersionLocally(String publisherName, String packageName, String version, User consumer) {
        DataPackageSnapshot snapshot = registryService.downloadPackage(publisherName, packageName, Optional.of(version), consumer);
        localEnv.installPackageVersion(packageName, snapshot);
        localEnv.pinDependency(packageName, version);
        System.out.println("[CLI] Installed " + packageName + "@" + version + " into local project environment.");
    }

    public LocalProjectEnvironment getLocalEnv() {
        return localEnv;
    }
}
