package dataregistry;

import java.util.Map;

public class DataPackageExporter {

    public String exportToZipArchiveBundle(DataPackageDescriptor descriptor) {
        StringBuilder zipBundle = new StringBuilder();
        zipBundle.append("=== ZIP ARCHIVE BUNDLE: ").append(descriptor.getName()).append(".zip ===\n");
        zipBundle.append("1. /datapackage.json (descriptor: name=").append(descriptor.getName())
                .append(", version=").append(descriptor.getVersion()).append(")\n");

        for (Resource res : descriptor.getResources()) {
            zipBundle.append("2. /data/").append(res.getName()).append(".csv (")
                    .append(res.getDataRows().size()).append(" records, remoteCached=")
                    .append(res.isRemoteCached()).append(")\n");
        }
        zipBundle.append("=== END ARCHIVE ===");
        return zipBundle.toString();
    }

    public String exportToSqliteDdlAndInsert(DataPackageDescriptor descriptor) {
        StringBuilder sql = new StringBuilder();
        sql.append("-- SQLite database export for DataPackage: ").append(descriptor.getName()).append("\n");

        for (Resource res : descriptor.getResources()) {
            String tableName = res.getName().replaceAll("[^a-zA-Z0-9_]", "_");
            sql.append("CREATE TABLE IF NOT EXISTS ").append(tableName).append(" (\n");

            List<Field> fields = res.getSchema().getFields();
            for (int i = 0; i < fields.size(); i++) {
                Field f = fields.get(i);
                String sqlType = switch (f.getType()) {
                    case INTEGER -> "INTEGER";
                    case NUMBER -> "REAL";
                    case BOOLEAN -> "INTEGER";
                    default -> "TEXT";
                };
                sql.append("    ").append(f.getName()).append(" ").append(sqlType);
                if (i < fields.size() - 1) sql.append(",");
                sql.append("\n");
            }
            sql.append(");\n");

            for (Map<String, Object> row : res.getDataRows()) {
                sql.append("INSERT INTO ").append(tableName).append(" VALUES (");
                for (int i = 0; i < fields.size(); i++) {
                    Field f = fields.get(i);
                    Object val = row.get(f.getName());
                    if (val == null) {
                        sql.append("NULL");
                    } else if (val instanceof Number || val instanceof Boolean) {
                        sql.append(val);
                    } else {
                        sql.append("'").append(val.toString().replace("'", "''")).append("'");
                    }
                    if (i < fields.size() - 1) sql.append(", ");
                }
                sql.append(");\n");
            }
        }
        return sql.toString();
    }

    public String generateNodeLibraryCode(String publisherName, String packageName, String version) {
        return """
               // Node.js client dependency snippet
               // package.json:
               // "dependencies": { "@datapackage/%s_%s": "^%s" }
               const { Dataset } = require('data.js');
               async function load() {
                 const dataset = await Dataset.load('https://registry.datahub.io/%s/%s@%s');
                 const table = await dataset.resources[0].read();
                 console.log(table);
               }
               load();
               """.formatted(publisherName, packageName, version, publisherName, packageName, version);
    }

    public String generateRLoaderCode(String publisherName, String packageName, String version) {
        return """
               # R snippet to load DataPackage
               library(datapkg)
               dp <- datapkg::datapackage.read("https://registry.datahub.io/%s/%s@%s")
               data <- datapkg::resource.read(dp, dp$resources[[1]]$name)
               summary(data)
               """.formatted(publisherName, packageName, version);
    }
}
