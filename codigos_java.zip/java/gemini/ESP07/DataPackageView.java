package dataregistry;

public class DataPackageView {
    private final String name;
    private final String viewType; // e.g. "table", "chart", "geo"
    private final String specJson;

    public DataPackageView(String name, String viewType, String specJson) {
        this.name = name;
        this.viewType = viewType;
        this.specJson = specJson;
    }

    public String getName() {
        return name;
    }

    public String getViewType() {
        return viewType;
    }

    public String getSpecJson() {
        return specJson;
    }

    @Override
    public String toString() {
        return "View[" + name + " (" + viewType + "): " + specJson + "]";
    }
}
