package dataregistry;

import java.util.Objects;

public class Field {
    private final String name;
    private final FieldType type;
    private final String description;

    public Field(String name, FieldType type, String description) {
        this.name = Objects.requireNonNull(name, "Field name cannot be null");
        this.type = Objects.requireNonNull(type, "Field type cannot be null");
        this.description = description == null ? "" : description;
    }

    public Field(String name, FieldType type) {
        this(name, type, "");
    }

    public String getName() {
        return name;
    }

    public FieldType getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Field field)) return false;
        return name.equalsIgnoreCase(field.name) && type == field.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name.toLowerCase(), type);
    }

    @Override
    public String toString() {
        return name + " (" + type + ")";
    }
}
