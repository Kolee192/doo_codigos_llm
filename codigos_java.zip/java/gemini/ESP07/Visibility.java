package dataregistry;

public enum Visibility {
    PUBLIC,
    PRIVATE
}
