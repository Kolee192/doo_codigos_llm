package dataregistry;

public class SiteMetrics {
    private final int totalUsers;
    private final int totalOrganizations;
    private final int totalPackages;
    private final int totalDownloads;
    private final long totalApiCalls;

    public SiteMetrics(int totalUsers, int totalOrganizations, int totalPackages, int totalDownloads, long totalApiCalls) {
        this.totalUsers = totalUsers;
        this.totalOrganizations = totalOrganizations;
        this.totalPackages = totalPackages;
        this.totalDownloads = totalDownloads;
        this.totalApiCalls = totalApiCalls;
    }

    public int getTotalUsers() {
        return totalUsers;
    }

    public int getTotalOrganizations() {
        return totalOrganizations;
    }

    public int getTotalPackages() {
        return totalPackages;
    }

    public int getTotalDownloads() {
        return totalDownloads;
    }

    public long getTotalApiCalls() {
        return totalApiCalls;
    }

    @Override
    public String toString() {
        return String.format("Site Metrics -> Users: %d, Orgs: %d, Packages: %d, Total Downloads: %d, API Calls: %d",
                totalUsers, totalOrganizations, totalPackages, totalDownloads, totalApiCalls);
    }
}
