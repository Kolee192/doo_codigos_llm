package dataregistry;

public enum Role {
    ADMIN,
    OWNER,
    MEMBER,
    CONSUMER
}
