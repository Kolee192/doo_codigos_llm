package dataregistry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DataPackageDescriptor {
    private final String name;
    private final String title;
    private final String description;
    private final String version;
    private final List<Resource> resources;
    private final List<DataPackageView> views;

    public DataPackageDescriptor(String name, String title, String description, String version,
                                 List<Resource> resources, List<DataPackageView> views) {
        this.name = name;
        this.title = title;
        this.description = description;
        this.version = version == null ? "1.0.0" : version;
        this.resources = resources != null ? new ArrayList<>(resources) : new ArrayList<>();
        this.views = views != null ? new ArrayList<>(views) : new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getVersion() {
        return version;
    }

    public List<Resource> getResources() {
        return Collections.unmodifiableList(resources);
    }

    public List<DataPackageView> getViews() {
        return Collections.unmodifiableList(views);
    }
}
