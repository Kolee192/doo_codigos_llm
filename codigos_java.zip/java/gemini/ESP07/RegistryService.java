package dataregistry;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

public class RegistryService {
    private final SiteConfig siteConfig = new SiteConfig();
    private final NotificationService notificationService = new NotificationService();
    private final DataPackageValidator validator = new DataPackageValidator();
    private final DataPackageExporter exporter = new DataPackageExporter();

    private final Map<String, User> usersById = new HashMap<>();
    private final Map<String, User> usersByEmail = new HashMap<>();
    private final Map<String, PublisherOrganization> publishersById = new HashMap<>();
    private final Map<String, PublisherOrganization> publishersByName = new HashMap<>();
    private final Map<String, DataPackage> packagesById = new HashMap<>();

    private final AtomicLong apiCallCount = new AtomicLong(0);

    public RegistryService() {
        // Seed default example data package and publisher
        User demoAdmin = new User("usr_admin", "admin", "admin@datahub.io", "Site Admin", AuthProvider.LOCAL);
        registerUser(demoAdmin);

        PublisherOrganization coreOrg = createPublisher("core", "Core Data Examples", "High quality open reference data", demoAdmin);
        coreOrg.setPricingPlan(PricingPlan.ENTERPRISE);

        Schema schema = new Schema(List.of(
                new Field("code", FieldType.STRING, "ISO Country Code"),
                new Field("name", FieldType.STRING, "Country Name"),
                new Field("population", FieldType.INTEGER, "Estimated population")
        ));
        Resource resource = new Resource("countries", "data/countries.csv", schema, List.of(
                Map.of("code", "US", "name", "United States", "population", 331000000),
                Map.of("code", "FR", "name", "France", "population", 67000000),
                Map.of("code", "JP", "name", "Japan", "population", 125000000)
        ), true);

        DataPackageDescriptor exampleDescriptor = new DataPackageDescriptor(
                "country-codes",
                "Standard Country Codes and Names",
                "Comprehensive ISO 3166-1 country codes with population counts",
                "1.0.0",
                List.of(resource),
                List.of(new DataPackageView("table-view", "table", "{\"columns\": [\"code\", \"name\", \"population\"]}"))
        );

        publishPackage(demoAdmin, coreOrg.getName(), exampleDescriptor, Visibility.PUBLIC);
    }

    public SiteConfig getSiteConfig() {
        apiCallCount.incrementAndGet();
        return siteConfig;
    }

    public NotificationService getNotificationService() {
        return notificationService;
    }

    public DataPackageValidator getValidator() {
        return validator;
    }

    public DataPackageExporter getExporter() {
        return exporter;
    }

    public User registerUser(User user) {
        apiCallCount.incrementAndGet();
        usersById.put(user.getId(), user);
        usersByEmail.put(user.getEmail().toLowerCase(), user);
        return user;
    }

    public User signUpViaOAuth(String username, String email, String fullName, AuthProvider provider) {
        apiCallCount.incrementAndGet();
        String id = "usr_" + UUID.randomUUID().toString().substring(0, 8);
        User user = new User(id, username, email, fullName, provider);
        return registerUser(user);
    }

    public Optional<User> getUserById(String id) {
        apiCallCount.incrementAndGet();
        return Optional.ofNullable(usersById.get(id));
    }

    public Optional<User> getUserByEmail(String email) {
        apiCallCount.incrementAndGet();
        return Optional.ofNullable(usersByEmail.get(email.toLowerCase()));
    }

    public PublisherOrganization createPublisher(String name, String displayName, String description, User creator) {
        apiCallCount.incrementAndGet();
        String id = "pub_" + UUID.randomUUID().toString().substring(0, 8);
        PublisherOrganization org = new PublisherOrganization(id, name, displayName, description, creator);
        publishersById.put(id, org);
        publishersByName.put(name.toLowerCase(), org);
        return org;
    }

    public Optional<PublisherOrganization> getPublisherByName(String name) {
        apiCallCount.incrementAndGet();
        return Optional.ofNullable(publishersByName.get(name.toLowerCase()));
    }

    public List<PublisherOrganization> getAllPublishers() {
        apiCallCount.incrementAndGet();
        return new ArrayList<>(publishersByName.values());
    }

    public void inviteMemberToPublisher(User actor, String publisherName, String targetEmail, Role role) {
        apiCallCount.incrementAndGet();
        PublisherOrganization org = publishersByName.get(publisherName.toLowerCase());
        if (org == null) throw new IllegalArgumentException("Publisher not found");
        if (!org.isOwner(actor)) throw new SecurityException("Only owners can invite members");

        Optional<User> existing = getUserByEmail(targetEmail);
        if (existing.isPresent()) {
            org.addMember(existing.get(), role);
        }
        notificationService.sendInviteNotification(targetEmail, org.getDisplayName(), actor.getFullName());
    }

    public void updateMemberRole(User actor, String publisherName, User targetUser, Role newRole) {
        apiCallCount.incrementAndGet();
        PublisherOrganization org = publishersByName.get(publisherName.toLowerCase());
        if (org == null) throw new IllegalArgumentException("Publisher not found");
        if (!org.isOwner(actor)) throw new SecurityException("Only owners can alter roles");
        org.setRole(targetUser, newRole);
    }

    public void removeMember(User actor, String publisherName, User targetUser) {
        apiCallCount.incrementAndGet();
        PublisherOrganization org = publishersByName.get(publisherName.toLowerCase());
        if (org == null) throw new IllegalArgumentException("Publisher not found");
        if (!org.isOwner(actor)) throw new SecurityException("Only owners can remove members");
        org.removeMember(targetUser);
    }

    public void subscribePublisherToPlan(User actor, String publisherName, PricingPlan plan) {
        apiCallCount.incrementAndGet();
        PublisherOrganization org = publishersByName.get(publisherName.toLowerCase());
        if (org == null) throw new IllegalArgumentException("Publisher not found");
        if (!org.isOwner(actor)) throw new SecurityException("Only owners can update billing plans");
        org.setPricingPlan(plan);
    }

    public DataPackage publishPackage(User actor, String publisherName, DataPackageDescriptor descriptor, Visibility visibility) {
        apiCallCount.incrementAndGet();
        PublisherOrganization org = publishersByName.get(publisherName.toLowerCase());
        if (org == null) throw new IllegalArgumentException("Publisher not found: " + publisherName);
        if (!org.hasPublishAccess(actor)) throw new SecurityException("User does not have publishing permissions for " + publisherName);

        // Validation upon publishing
        ValidationResult valResult = validator.validate(descriptor);
        if (!valResult.isValid()) {
            throw new IllegalArgumentException("Package validation failed: " + String.join(", ", valResult.getErrors()));
        }

        // Plan limitation check for private packages
        if (visibility == Visibility.PRIVATE) {
            long existingPrivates = packagesById.values().stream()
                    .filter(p -> p.getPublisherId().equals(org.getId()) && p.getVisibility() == Visibility.PRIVATE && !p.isDeleted())
                    .count();
            if (existingPrivates >= org.getPricingPlan().getMaxPrivatePackages()) {
                throw new IllegalStateException("Pricing plan quota exceeded: cannot create more private packages under " + org.getPricingPlan().getName());
            }
        }

        String packageKey = org.getName() + "/" + descriptor.getName();
        DataPackage existing = packagesById.get(packageKey);
        if (existing == null) {
            DataPackage created = new DataPackage("pkg_" + UUID.randomUUID().toString().substring(0, 8), org.getId(), descriptor, visibility);
            packagesById.put(packageKey, created);
            return created;
        } else {
            existing.updateDescriptor(descriptor, false);
            existing.setVisibility(visibility);
            existing.setPublished(true);
            existing.setDeleted(false);
            notificationService.notifySubscribers(existing, "Package updated to version " + descriptor.getVersion());
            return existing;
        }
    }

    public void tagPackage(User actor, String publisherName, String packageName, String tag, boolean overwrite) {
        apiCallCount.incrementAndGet();
        DataPackage pkg = getPackage(publisherName, packageName)
                .orElseThrow(() -> new IllegalArgumentException("Package not found: " + publisherName + "/" + packageName));

        PublisherOrganization org = publishersById.get(pkg.getPublisherId());
        if (!org.hasPublishAccess(actor)) throw new SecurityException("User cannot tag package");

        pkg.snapshot(tag, overwrite);
    }

    public void unpublishPackage(User actor, String publisherName, String packageName) {
        apiCallCount.incrementAndGet();
        DataPackage pkg = getPackage(publisherName, packageName)
                .orElseThrow(() -> new IllegalArgumentException("Package not found"));
        PublisherOrganization org = publishersById.get(pkg.getPublisherId());
        if (!org.hasPublishAccess(actor)) throw new SecurityException("Unauthorized");
        pkg.setPublished(false);
    }

    public void deletePackage(User actor, String publisherName, String packageName) {
        apiCallCount.incrementAndGet();
        DataPackage pkg = getPackage(publisherName, packageName)
                .orElseThrow(() -> new IllegalArgumentException("Package not found"));
        PublisherOrganization org = publishersById.get(pkg.getPublisherId());
        if (!org.hasPublishAccess(actor)) throw new SecurityException("Unauthorized");
        pkg.setDeleted(true);
    }

    public void restorePackage(User actor, String publisherName, String packageName) {
        apiCallCount.incrementAndGet();
        DataPackage pkg = packagesById.get(publisherName.toLowerCase() + "/" + packageName.toLowerCase());
        if (pkg == null) throw new IllegalArgumentException("Package not found");
        PublisherOrganization org = publishersById.get(pkg.getPublisherId());
        if (!org.hasPublishAccess(actor)) throw new SecurityException("Unauthorized");
        pkg.setDeleted(false);
        pkg.setPublished(true);
    }

    public void permanentlyDeletePackage(User actor, String publisherName, String packageName) {
        apiCallCount.incrementAndGet();
        PublisherOrganization org = publishersByName.get(publisherName.toLowerCase());
        if (org == null || !org.isOwner(actor)) throw new SecurityException("Only owners can permanently delete packages");
        packagesById.remove(publisherName.toLowerCase() + "/" + packageName.toLowerCase());
    }

    public Optional<DataPackage> getPackage(String publisherName, String packageName) {
        apiCallCount.incrementAndGet();
        DataPackage pkg = packagesById.get(publisherName.toLowerCase() + "/" + packageName.toLowerCase());
        if (pkg != null && !pkg.isDeleted()) {
            return Optional.of(pkg);
        }
        return Optional.empty();
    }

    public DataPackageSnapshot downloadPackage(String publisherName, String packageName, Optional<String> versionTag, User consumer) {
        apiCallCount.incrementAndGet();
        DataPackage pkg = getPackage(publisherName, packageName)
                .orElseThrow(() -> new IllegalArgumentException("Package not found or deleted"));

        PublisherOrganization org = publishersById.get(pkg.getPublisherId());
        if (pkg.getVisibility() == Visibility.PRIVATE) {
            if (consumer == null || !org.getMembers().containsKey(consumer)) {
                throw new SecurityException("Private package can only be accessed by publisher members");
            }
        }

        pkg.incrementDownloadCount();

        if (versionTag.isPresent()) {
            return pkg.getSnapshot(versionTag.get())
                    .orElseThrow(() -> new IllegalArgumentException("Version/Tag " + versionTag.get() + " not found"));
        } else {
            return pkg.getSnapshot(pkg.getCurrentDescriptor().getVersion())
                    .orElseGet(() -> new DataPackageSnapshot("latest", pkg.getCurrentDescriptor(), true));
        }
    }

    public List<DataPackage> searchPackages(String query, Optional<String> publisherFilter) {
        apiCallCount.incrementAndGet();
        String q = query.toLowerCase();
        return packagesById.values().stream()
                .filter(p -> !p.isDeleted() && p.isPublished() && p.getVisibility() == Visibility.PUBLIC)
                .filter(p -> publisherFilter.isEmpty() || publishersById.get(p.getPublisherId()).getName().equalsIgnoreCase(publisherFilter.get()))
                .filter(p -> p.getName().toLowerCase().contains(q) ||
                             p.getCurrentDescriptor().getTitle().toLowerCase().contains(q) ||
                             p.getCurrentDescriptor().getDescription().toLowerCase().contains(q))
                .sorted(Comparator.comparingInt(DataPackage::getDownloadCount).reversed())
                .collect(Collectors.toList());
    }

    public List<DataPackage> getExamplePackages() {
        return searchPackages("", Optional.empty());
    }

    public SiteMetrics getMetrics() {
        int totalDownloads = packagesById.values().stream().mapToInt(DataPackage::getDownloadCount).sum();
        return new SiteMetrics(usersById.size(), publishersById.size(), packagesById.size(), totalDownloads, apiCallCount.get());
    }
}
