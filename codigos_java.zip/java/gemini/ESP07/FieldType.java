package dataregistry;

public enum FieldType {
    STRING,
    INTEGER,
    NUMBER,
    BOOLEAN,
    DATE,
    JSON
}
