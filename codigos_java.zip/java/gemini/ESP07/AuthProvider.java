package dataregistry;

public enum AuthProvider {
    LOCAL,
    GITHUB,
    GOOGLE
}
