package dataregistry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class Resource {
    private final String name;
    private final String pathOrUrl;
    private final Schema schema;
    private final List<Map<String, Object>> dataRows;
    private final boolean remoteCached;

    public Resource(String name, String pathOrUrl, Schema schema, List<Map<String, Object>> dataRows, boolean remoteCached) {
        this.name = name;
        this.pathOrUrl = pathOrUrl;
        this.schema = schema != null ? schema : new Schema();
        this.dataRows = dataRows != null ? new ArrayList<>(dataRows) : new ArrayList<>();
        this.remoteCached = remoteCached;
    }

    public Resource(String name, String pathOrUrl, Schema schema, List<Map<String, Object>> dataRows) {
        this(name, pathOrUrl, schema, dataRows, false);
    }

    public String getName() {
        return name;
    }

    public String getPathOrUrl() {
        return pathOrUrl;
    }

    public Schema getSchema() {
        return schema;
    }

    public List<Map<String, Object>> getDataRows() {
        return Collections.unmodifiableList(dataRows);
    }

    public boolean isRemoteCached() {
        return remoteCached;
    }
}
