package dataregistry;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        System.out.println("================================================================");
        System.out.println("      DATA PACKAGE REGISTRY & CLI PLATFORM DEMO");
        System.out.println("================================================================\n");

        RegistryService registry = new RegistryService();

        // 1. Visitor sign-up via OAuth (GitHub / Google) & Onboarding
        System.out.println("--- 1. User Registration & Onboarding Guidance ---");
        User alice = registry.signUpViaOAuth("alice_dev", "alice@cloud.org", "Alice Wonderland", AuthProvider.GITHUB);
        System.out.println("Registered user via OAuth: " + alice);
        System.out.println("Onboarding checklist for new publisher:");
        alice.getOnboardingChecklist().forEach(step -> System.out.println("  " + step));

        User bob = registry.signUpViaOAuth("bob_analyst", "bob@data.org", "Bob Analyst", AuthProvider.GOOGLE);
        System.out.println("Consumer registered: " + bob);

        // 2. Organization, Membership Roles & Pricing Plans
        System.out.println("\n--- 2. Publisher Organizations, Team Roles & Pricing ---");
        PublisherOrganization org = registry.createPublisher("acme-data", "ACME Data Lab", "High frequency environmental metrics", alice);
        System.out.println("Created Publisher: " + org);

        // Owner invites existing user or via email
        registry.inviteMemberToPublisher(alice, "acme-data", "bob@data.org", Role.MEMBER);
        System.out.println("Alice invited Bob to acme-data. Members:");
        org.getMembers().forEach((user, role) -> System.out.println("  - " + user.getFullName() + ": " + role));

        // Owner upgrades pricing plan
        System.out.println("Exploring pricing plans: Free, Pro ($29/mo), Enterprise ($199/mo)");
        registry.subscribePublisherToPlan(alice, "acme-data", PricingPlan.PRO);
        System.out.println("Updated publisher pricing plan: " + org.getPricingPlan());

        // 3. CLI Configuration, Data Package Preparation & Validation
        System.out.println("\n--- 3. Client CLI Configuration & Validation ---");
        ClientCli cli = new ClientCli(registry, "AirQualityResearchProject");
        cli.configure("https://registry.datahub.io", "sec_token_alice_12345");

        Schema weatherSchemaV1 = new Schema(List.of(
                new Field("city", FieldType.STRING),
                new Field("pm25", FieldType.NUMBER, "Fine particulate matter"),
                new Field("recorded_date", FieldType.DATE)
        ));

        Resource weatherResourceV1 = new Resource(
                "air_quality",
                "https://acme-sensors.io/exports/aqi.csv",
                weatherSchemaV1,
                List.of(
                        Map.of("city", "Berlin", "pm25", 14.5, "recorded_date", "2023-10-01"),
                        Map.of("city", "Paris", "pm25", 18.2, "recorded_date", "2023-10-01")
                ),
                true // Remote data cached in registry
        );

        DataPackageView chartView = new DataPackageView(
                "aqi-chart",
                "chart",
                "{\"type\": \"line\", \"spec\": {\"x\": \"city\", \"y\": \"pm25\"}}"
        );

        DataPackageDescriptor v1Descriptor = new DataPackageDescriptor(
                "air-quality",
                "Global Urban Air Quality",
                "Realtime particulate matter indicators by city",
                "1.0.0",
                List.of(weatherResourceV1),
                List.of(chartView)
        );

        // Preview views via CLI
        cli.previewViews(v1Descriptor);

        // Validate package before publishing
        ValidationResult valResult = cli.validate(v1Descriptor);
        System.out.println("Pre-publish validation: " + valResult);

        // 4. Publishing Public & Private Packages
        System.out.println("\n--- 4. Publishing & Version Tagging ---");
        DataPackage publishedPkg = cli.publish(alice, "acme-data", v1Descriptor, Visibility.PUBLIC);
        System.out.println("Successfully published package: " + publishedPkg.getName() + " v" + publishedPkg.getCurrentDescriptor().getVersion());

        // Tag snapshot
        registry.tagPackage(alice, "acme-data", "air-quality", "v1.0.0-gold", false);
        System.out.println("Tagged snapshot: v1.0.0-gold");

        // Attempting to overwrite tag without force flag produces warning/error
        try {
            registry.tagPackage(alice, "acme-data", "air-quality", "v1.0.0-gold", false);
        } catch (IllegalStateException e) {
            System.out.println("Warning caught as expected: " + e.getMessage());
        }
        // Force overwrite
        registry.tagPackage(alice, "acme-data", "air-quality", "v1.0.0-gold", true);
        System.out.println("Successfully re-tagged snapshot with overwrite flag: v1.0.0-gold");

        // 5. Version Update & Schema Comparison
        System.out.println("\n--- 5. Schema Evolution & Version Comparison ---");
        // Bob subscribes to updates
        publishedPkg.addSubscriber(bob.getEmail());

        Schema weatherSchemaV2 = new Schema(List.of(
                new Field("city", FieldType.STRING),
                new Field("pm25", FieldType.NUMBER),
                new Field("recorded_date", FieldType.DATE),
                new Field("pm10", FieldType.NUMBER, "Coarse particulate matter") // Added field
        ));

        Resource weatherResourceV2 = new Resource(
                "air_quality",
                "https://acme-sensors.io/exports/aqi_v2.csv",
                weatherSchemaV2,
                List.of(
                        Map.of("city", "Berlin", "pm25", 14.5, "recorded_date", "2023-10-01", "pm10", 24.0),
                        Map.of("city", "Paris", "pm25", 18.2, "recorded_date", "2023-10-01", "pm10", 30.1)
                ),
                true
        );

        DataPackageDescriptor v2Descriptor = new DataPackageDescriptor(
                "air-quality",
                "Global Urban Air Quality",
                "Updated with PM10 measurement readings",
                "2.0.0",
                List.of(weatherResourceV2),
                List.of(chartView)
        );

        SchemaDiff diff = cli.diffVersionsLocally(v1Descriptor, v2Descriptor);
        System.out.println(diff);

        // Publish update
        cli.publish(alice, "acme-data", v2Descriptor, Visibility.PUBLIC);
        System.out.println("Notification log after v2 release:");
        registry.getNotificationService().getNotificationLog().forEach(n -> System.out.println("  " + n));

        // 6. Search, Discovery & Remote Cache Resilience
        System.out.println("\n--- 6. Search, Discovery & Remote Cache Resilience ---");
        List<DataPackage> searchResults = registry.searchPackages("particulate", Optional.empty());
        System.out.println("Search results for keyword 'particulate': " + searchResults.size() + " package(s) found.");
        for (DataPackage p : searchResults) {
            System.out.println("  - " + p.getName() + " (Age: " + p.getAge().toSeconds() + "s ago, Downloads: " + p.getDownloadCount() + ")");
        }

        // Consumer downloads cached copy even if original server changed
        DataPackageSnapshot downloadedV1 = registry.downloadPackage("acme-data", "air-quality", Optional.of("1.0.0"), bob);
        System.out.println("Bob downloaded specific version 1.0.0 (Remote cached available: " + downloadedV1.isCachedCopyAvailable() + ")");

        // 7. Data Exports: Single Zip Bundle, SQLite Database & Node/R Integration Snippets
        System.out.println("\n--- 7. Download Representations & Developer Integration ---");
        String zipSummary = registry.getExporter().exportToZipArchiveBundle(v2Descriptor);
        System.out.println(zipSummary);

        String sqliteScript = registry.getExporter().exportToSqliteDdlAndInsert(v2Descriptor);
        System.out.println("Generated SQLite Import Script preview:");
        System.out.println(sqliteScript.lines().limit(6).reduce("", (a, b) -> a + "\n" + b));

        System.out.println("R Loader snippet preview:");
        System.out.println(registry.getExporter().generateRLoaderCode("acme-data", "air-quality", "2.0.0"));

        // 8. Multi-version Local Installation & Project Lockfile Pinning
        System.out.println("--- 8. Multi-Version Local Dependency Management ---");
        cli.installPackageVersionLocally("acme-data", "air-quality", "1.0.0", bob);
        cli.installPackageVersionLocally("acme-data", "air-quality", "2.0.0", bob);
        System.out.println("Installed versions locally in project '" + cli.getLocalEnv().getProjectName() + "': "
                + cli.getLocalEnv().listInstalledVersions("air-quality"));
        System.out.println("Pinned dependencies in project lockfile: " + cli.getLocalEnv().getManifestDependencies());

        // 9. Unpublish, Soft Delete, Undelete / Restore & Permanent Deletion
        System.out.println("\n--- 9. Lifecycle: Unpublish, Delete, Restore & Purge ---");
        registry.unpublishPackage(alice, "acme-data", "air-quality");
        System.out.println("Package unpublished. Available in public search? "
                + !registry.searchPackages("air-quality", Optional.empty()).isEmpty());

        registry.deletePackage(alice, "acme-data", "air-quality");
        System.out.println("Package soft deleted. Found in active lookup? "
                + registry.getPackage("acme-data", "air-quality").isPresent());

        // Restore via CLI
        cli.undelete(alice, "acme-data", "air-quality");
        System.out.println("Package undeleted/restored. Found in active lookup? "
                + registry.getPackage("acme-data", "air-quality").isPresent());

        // 10. Platform Administration, Site Configuration & Key Metrics
        System.out.println("\n--- 10. Administration & Platform Activity Metrics ---");
        SiteConfig siteConfig = registry.getSiteConfig();
        siteConfig.setSiteTitle("Open DataHub Enterprise Cloud");
        System.out.println("Updated Site Title: " + registry.getSiteConfig().getSiteTitle());

        SiteMetrics metrics = registry.getMetrics();
        System.out.println(metrics);
        System.out.println("\nDemo completed successfully.");
    }
}
