package dataregistry;

public class PricingPlan {
    public static final PricingPlan FREE = new PricingPlan("Free", 0.0, 1, false, 50);
    public static final PricingPlan PRO = new PricingPlan("Pro", 29.0, 20, true, 5000);
    public static final PricingPlan ENTERPRISE = new PricingPlan("Enterprise", 199.0, 1000, true, 500000);

    private final String name;
    private final double monthlyPriceUsd;
    private final int maxPrivatePackages;
    private final boolean remoteCachingAllowed;
    private final int maxStorageMb;

    public PricingPlan(String name, double monthlyPriceUsd, int maxPrivatePackages, boolean remoteCachingAllowed, int maxStorageMb) {
        this.name = name;
        this.monthlyPriceUsd = monthlyPriceUsd;
        this.maxPrivatePackages = maxPrivatePackages;
        this.remoteCachingAllowed = remoteCachingAllowed;
        this.maxStorageMb = maxStorageMb;
    }

    public String getName() {
        return name;
    }

    public double getMonthlyPriceUsd() {
        return monthlyPriceUsd;
    }

    public int getMaxPrivatePackages() {
        return maxPrivatePackages;
    }

    public boolean isRemoteCachingAllowed() {
        return remoteCachingAllowed;
    }

    public int getMaxStorageMb() {
        return maxStorageMb;
    }

    @Override
    public String toString() {
        return name + " ($" + monthlyPriceUsd + "/mo) [Private packages: " + maxPrivatePackages + ", Storage: " + maxStorageMb + "MB]";
    }
}
