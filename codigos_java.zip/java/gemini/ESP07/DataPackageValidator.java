package dataregistry;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DataPackageValidator {

    public ValidationResult validate(DataPackageDescriptor descriptor) {
        List<String> errors = new ArrayList<>();

        if (descriptor == null) {
            errors.add("Descriptor cannot be null");
            return ValidationResult.failure(errors);
        }

        if (descriptor.getName() == null || descriptor.getName().trim().isEmpty()) {
            errors.add("Package name is required");
        } else if (!descriptor.getName().matches("^[a-z0-9-_]+$")) {
            errors.add("Package name must only contain lowercase alphanumeric, hyphen or underscore characters");
        }

        if (descriptor.getResources() == null || descriptor.getResources().isEmpty()) {
            errors.add("At least one resource must be provided");
        } else {
            for (Resource res : descriptor.getResources()) {
                if (res.getName() == null || res.getName().isBlank()) {
                    errors.add("Resource name cannot be blank");
                }
                if (res.getSchema() == null || res.getSchema().getFields().isEmpty()) {
                    errors.add("Resource " + res.getName() + " must have a defined schema with fields");
                } else {
                    validateResourceData(res, errors);
                }
            }
        }

        return errors.isEmpty() ? ValidationResult.success() : ValidationResult.failure(errors);
    }

    private void validateResourceData(Resource res, List<String> errors) {
        Schema schema = res.getSchema();
        for (int i = 0; i < res.getDataRows().size(); i++) {
            Map<String, Object> row = res.getDataRows().get(i);
            for (Field field : schema.getFields()) {
                Object val = row.get(field.getName());
                if (val != null && !isTypeCompatible(val, field.getType())) {
                    errors.add(String.format("Row %d: value '%s' in field '%s' does not match declared type %s",
                            i + 1, val, field.getName(), field.getType()));
                }
            }
        }
    }

    private boolean isTypeCompatible(Object value, FieldType expectedType) {
        return switch (expectedType) {
            case STRING -> value instanceof String;
            case INTEGER -> value instanceof Integer || value instanceof Long;
            case NUMBER -> value instanceof Number;
            case BOOLEAN -> value instanceof Boolean;
            case DATE -> value instanceof String && ((String) value).matches("^\\d{4}-\\d{2}-\\d{2}$");
            case JSON -> value instanceof String || value instanceof Map || value instanceof List;
        };
    }
}
