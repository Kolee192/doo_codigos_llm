package dataregistry;

import java.util.Collections;
import java.util.List;

public class SchemaDiff {
    private final List<Field> addedFields;
    private final List<Field> removedFields;
    private final List<String> modifiedFields;

    public SchemaDiff(List<Field> addedFields, List<Field> removedFields, List<String> modifiedFields) {
        this.addedFields = Collections.unmodifiableList(addedFields);
        this.removedFields = Collections.unmodifiableList(removedFields);
        this.modifiedFields = Collections.unmodifiableList(modifiedFields);
    }

    public List<Field> getAddedFields() {
        return addedFields;
    }

    public List<Field> getRemovedFields() {
        return removedFields;
    }

    public List<String> getModifiedFields() {
        return modifiedFields;
    }

    public boolean hasChanges() {
        return !addedFields.isEmpty() || !removedFields.isEmpty() || !modifiedFields.isEmpty();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SchemaDiff:\n");
        sb.append("  Added fields: ").append(addedFields).append("\n");
        sb.append("  Removed fields: ").append(removedFields).append("\n");
        sb.append("  Modified fields: ").append(modifiedFields);
        return sb.toString();
    }
}
