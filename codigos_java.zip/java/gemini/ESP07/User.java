package dataregistry;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class User {
    private final String id;
    private final String username;
    private final String email;
    private String fullName;
    private final AuthProvider authProvider;
    private final Instant registeredAt;
    private final List<String> onboardingChecklist;

    public User(String id, String username, String email, String fullName, AuthProvider authProvider) {
        this.id = Objects.requireNonNull(id);
        this.username = Objects.requireNonNull(username);
        this.email = Objects.requireNonNull(email);
        this.fullName = fullName == null ? username : fullName;
        this.authProvider = authProvider != null ? authProvider : AuthProvider.LOCAL;
        this.registeredAt = Instant.now();
        this.onboardingChecklist = new ArrayList<>(List.of(
                "1. Configure CLI client with your API key",
                "2. Create or join a Publisher organization",
                "3. Validate your first dataset locally",
                "4. Run publish command to upload your data package"
        ));
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public AuthProvider getAuthProvider() {
        return authProvider;
    }

    public Instant getRegisteredAt() {
        return registeredAt;
    }

    public List<String> getOnboardingChecklist() {
        return Collections.unmodifiableList(onboardingChecklist);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User user)) return false;
        return id.equals(user.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return username + " (" + email + ", " + authProvider + ")";
    }
}
