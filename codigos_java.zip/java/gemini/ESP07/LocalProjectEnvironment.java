package dataregistry;

import java.util.*;

public class LocalProjectEnvironment {
    private final String projectName;
    private final Map<String, ProjectDependency> manifestDependencies = new LinkedHashMap<>();
    // Local storage of installed packages: packageName -> (version -> DataPackageSnapshot)
    private final Map<String, Map<String, DataPackageSnapshot>> installedPackages = new HashMap<>();

    public LocalProjectEnvironment(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void pinDependency(String packageName, String version) {
        manifestDependencies.put(packageName, new ProjectDependency(packageName, version));
    }

    public Map<String, ProjectDependency> getManifestDependencies() {
        return Collections.unmodifiableMap(manifestDependencies);
    }

    public void installPackageVersion(String packageName, DataPackageSnapshot snapshot) {
        installedPackages
                .computeIfAbsent(packageName, k -> new HashMap<>())
                .put(snapshot.getTagOrVersion(), snapshot);
    }

    public Optional<DataPackageSnapshot> getInstalledVersion(String packageName, String version) {
        Map<String, DataPackageSnapshot> versions = installedPackages.get(packageName);
        if (versions == null) return Optional.empty();
        return Optional.ofNullable(versions.get(version));
    }

    public List<String> listInstalledVersions(String packageName) {
        Map<String, DataPackageSnapshot> versions = installedPackages.get(packageName);
        if (versions == null) return Collections.emptyList();
        return new ArrayList<>(versions.keySet());
    }
}
