package dataregistry;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

public class DataPackage {
    private final String id;
    private final String publisherId;
    private String name;
    private Visibility visibility;
    private boolean published;
    private boolean deleted;
    private int downloadCount;
    private final Instant createdAt;
    private Instant updatedAt;
    private DataPackageDescriptor currentDescriptor;
    private final Map<String, DataPackageSnapshot> snapshots = new LinkedHashMap<>();
    private final Set<String> subscriberEmails = new HashSet<>();

    public DataPackage(String id, String publisherId, DataPackageDescriptor initialDescriptor, Visibility visibility) {
        this.id = id;
        this.publisherId = publisherId;
        this.name = initialDescriptor.getName();
        this.currentDescriptor = initialDescriptor;
        this.visibility = visibility != null ? visibility : Visibility.PUBLIC;
        this.published = true;
        this.deleted = false;
        this.downloadCount = 0;
        this.createdAt = Instant.now();
        this.updatedAt = this.createdAt;
        snapshot(initialDescriptor.getVersion(), false);
    }

    public String getId() {
        return id;
    }

    public String getPublisherId() {
        return publisherId;
    }

    public String getName() {
        return name;
    }

    public Visibility getVisibility() {
        return visibility;
    }

    public void setVisibility(Visibility visibility) {
        this.visibility = visibility;
    }

    public boolean isPublished() {
        return published;
    }

    public void setPublished(boolean published) {
        this.published = published;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public int getDownloadCount() {
        return downloadCount;
    }

    public void incrementDownloadCount() {
        this.downloadCount++;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public Duration getAge() {
        return Duration.between(updatedAt, Instant.now());
    }

    public DataPackageDescriptor getCurrentDescriptor() {
        return currentDescriptor;
    }

    public void updateDescriptor(DataPackageDescriptor newDescriptor, boolean overwriteSnapshot) {
        this.currentDescriptor = newDescriptor;
        this.name = newDescriptor.getName();
        this.updatedAt = Instant.now();
        snapshot(newDescriptor.getVersion(), overwriteSnapshot);
    }

    public void snapshot(String tagOrVersion, boolean overwrite) {
        boolean remoteCaching = currentDescriptor.getResources().stream().anyMatch(Resource::isRemoteCached);
        if (!overwrite && snapshots.containsKey(tagOrVersion)) {
            throw new IllegalStateException("Tag/Version '" + tagOrVersion + "' already exists! Use force/overwrite to replace.");
        }
        snapshots.put(tagOrVersion, new DataPackageSnapshot(tagOrVersion, currentDescriptor, remoteCaching));
    }

    public boolean hasTag(String tag) {
        return snapshots.containsKey(tag);
    }

    public Optional<DataPackageSnapshot> getSnapshot(String tagOrVersion) {
        return Optional.ofNullable(snapshots.get(tagOrVersion));
    }

    public Map<String, DataPackageSnapshot> getAllSnapshots() {
        return Collections.unmodifiableMap(snapshots);
    }

    public void addSubscriber(String email) {
        subscriberEmails.add(email);
    }

    public Set<String> getSubscribers() {
        return Collections.unmodifiableSet(subscriberEmails);
    }
}
