package dataregistry;

public class ProjectDependency {
    private final String packageName;
    private final String pinnedVersion;

    public ProjectDependency(String packageName, String pinnedVersion) {
        this.packageName = packageName;
        this.pinnedVersion = pinnedVersion;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getPinnedVersion() {
        return pinnedVersion;
    }

    @Override
    public String toString() {
        return packageName + "@" + pinnedVersion;
    }
}
