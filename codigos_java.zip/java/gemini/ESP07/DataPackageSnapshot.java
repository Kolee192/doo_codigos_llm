package dataregistry;

import java.time.Instant;

public class DataPackageSnapshot {
    private final String tagOrVersion;
    private final DataPackageDescriptor descriptor;
    private final Instant timestamp;
    private final boolean cachedCopyAvailable;

    public DataPackageSnapshot(String tagOrVersion, DataPackageDescriptor descriptor, boolean cachedCopyAvailable) {
        this.tagOrVersion = tagOrVersion;
        this.descriptor = descriptor;
        this.timestamp = Instant.now();
        this.cachedCopyAvailable = cachedCopyAvailable;
    }

    public String getTagOrVersion() {
        return tagOrVersion;
    }

    public DataPackageDescriptor getDescriptor() {
        return descriptor;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public boolean isCachedCopyAvailable() {
        return cachedCopyAvailable;
    }
}
