package dataregistry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class Schema {
    private final List<Field> fields;

    public Schema(List<Field> fields) {
        this.fields = fields != null ? new ArrayList<>(fields) : new ArrayList<>();
    }

    public Schema() {
        this(new ArrayList<>());
    }

    public List<Field> getFields() {
        return Collections.unmodifiableList(fields);
    }

    public Optional<Field> getField(String name) {
        return fields.stream()
                .filter(f -> f.getName().equalsIgnoreCase(name))
                .findFirst();
    }

    public SchemaDiff compareTo(Schema other) {
        if (other == null) {
            return new SchemaDiff(new ArrayList<>(fields), Collections.emptyList(), Collections.emptyList());
        }

        List<Field> added = new ArrayList<>();
        List<Field> removed = new ArrayList<>();
        List<String> modified = new ArrayList<>();

        for (Field f : fields) {
            Optional<Field> otherField = other.getField(f.getName());
            if (otherField.isEmpty()) {
                added.add(f);
            } else if (otherField.get().getType() != f.getType()) {
                modified.add(f.getName() + " changed type from " + otherField.get().getType() + " to " + f.getType());
            }
        }

        for (Field of : other.getFields()) {
            if (getField(of.getName()).isEmpty()) {
                removed.add(of);
            }
        }

        return new SchemaDiff(added, removed, modified);
    }
}
