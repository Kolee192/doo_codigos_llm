import java.util.UUID;

public class AccessionCsvImporter implements Importer {

    @Override
    public ImportResult parse(String content, String repositoryId) {
        ImportResult result = new ImportResult();
        if (content == null || content.isBlank()) {
            result.addMessage(ImportMessage.Level.ERROR, "Empty CSV content", "Input file contains no content.");
            return result;
        }

        String[] lines = content.split("\\r?\\n");
        if (lines.length <= 1) {
            result.addMessage(ImportMessage.Level.WARNING, "No data rows in CSV", "CSV only contains header or is empty.");
            return result;
        }

        for (int i = 1; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty()) continue;
            String[] tokens = line.split(",", -1);
            if (tokens.length < 3) {
                result.addMessage(ImportMessage.Level.ERROR, "Row " + (i + 1) + " invalid format", "Expected at least accessionNumber, title, accessionDate");
                continue;
            }
            String accNum = tokens[0].trim();
            String title = tokens[1].trim();
            String accDate = tokens[2].trim();
            String extNumber = tokens.length > 3 ? tokens[3].trim() : "1";
            String extType = tokens.length > 4 ? tokens[4].trim() : "linear_feet";

            Accession acc = new Accession("acc_" + UUID.randomUUID(), repositoryId, title, accNum, accDate);
            acc.addDate(new DateSubrecord("accession", "single", accDate, accDate, null));
            acc.addExtent(new ExtentSubrecord("whole", extNumber, extType, null));
            result.addRecord(acc);
            result.addMessage(ImportMessage.Level.INFO, "Imported accession " + accNum, null);
        }
        return result;
    }
}
