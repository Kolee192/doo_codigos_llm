public class ImportMessage {
    public enum Level { INFO, WARNING, ERROR }

    private final Level level;
    private final String message;
    private final String reason;

    public ImportMessage(Level level, String message, String reason) {
        this.level = level;
        this.message = message;
        this.reason = reason;
    }

    public Level getLevel() { return level; }
    public String getMessage() { return message; }
    public String getReason() { return reason; }

    @Override
    public String toString() {
        return "[" + level + "] " + message + (reason != null ? " (Reason: " + reason + ")" : "");
    }
}
