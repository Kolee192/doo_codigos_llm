import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MarcXmlImporter implements Importer {
    private final boolean agentsAndSubjectsOnly;

    public MarcXmlImporter(boolean agentsAndSubjectsOnly) {
        this.agentsAndSubjectsOnly = agentsAndSubjectsOnly;
    }

    @Override
    public ImportResult parse(String content, String repositoryId) {
        ImportResult result = new ImportResult();
        if (content == null || content.isBlank()) {
            result.addMessage(ImportMessage.Level.ERROR, "MARCXML is empty", "Invalid XML content");
            return result;
        }

        Matcher agent100Matcher = Pattern.compile("<datafield[^>]*tag=\"100\"[^>]*>(.*?)</datafield>", Pattern.DOTALL).matcher(content);
        while (agent100Matcher.find()) {
            String fieldContent = agent100Matcher.group(1);
            String name = extractSubfield(fieldContent, "a");
            if (name != null) {
                Agent agent = new Agent("agent_" + UUID.randomUUID(), AgentType.PERSON, name, null, "naf");
                result.addAgent(agent);
                result.addMessage(ImportMessage.Level.INFO, "Imported Agent: " + name, null);
            }
        }

        Matcher subject650Matcher = Pattern.compile("<datafield[^>]*tag=\"650\"[^>]*>(.*?)</datafield>", Pattern.DOTALL).matcher(content);
        while (subject650Matcher.find()) {
            String fieldContent = subject650Matcher.group(1);
            String term = extractSubfield(fieldContent, "a");
            String stdId = extractSubfield(fieldContent, "0");
            if (term != null) {
                Subject subj = new Subject("subj_" + UUID.randomUUID(), repositoryId, term, stdId != null ? stdId : "lcsh/" + term.hashCode(), "lcsh");
                result.addSubject(subj);
                result.addMessage(ImportMessage.Level.INFO, "Imported Subject: " + term, null);
            }
        }

        if (!agentsAndSubjectsOnly) {
            String title = null;
            Matcher title245 = Pattern.compile("<datafield[^>]*tag=\"245\"[^>]*>(.*?)</datafield>", Pattern.DOTALL).matcher(content);
            if (title245.find()) {
                title = extractSubfield(title245.group(1), "a");
            }
            if (title == null) {
                result.addMessage(ImportMessage.Level.ERROR, "Resource title missing in MARCXML 245 field", "Field 245$a not found");
                return result;
            }

            Resource res = new Resource("res_" + UUID.randomUUID(), repositoryId, title, "MARC-" + System.currentTimeMillis(), LevelOfDescription.of("collection"));
            for (Agent a : result.getAgents()) {
                res.linkAgent(a.getId(), AgentRole.CREATOR);
            }
            for (Subject s : result.getSubjects()) {
                res.linkSubject(s.getId());
            }
            result.addRecord(res);
        }

        return result;
    }

    private String extractSubfield(String datafield, String code) {
        Pattern pattern = Pattern.compile("<subfield[^>]*code=\"" + code + "\">(.*?)</subfield>", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(datafield);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }
        return null;
    }
}
