import java.util.ArrayList;
import java.util.List;

public class ImportResult {
    private final List<ArchivalRecord> records = new ArrayList<>();
    private final List<Agent> agents = new ArrayList<>();
    private final List<Subject> subjects = new ArrayList<>();
    private final List<ImportMessage> messages = new ArrayList<>();

    public void addRecord(ArchivalRecord record) { records.add(record); }
    public List<ArchivalRecord> getRecords() { return records; }

    public void addAgent(Agent agent) { agents.add(agent); }
    public List<Agent> getAgents() { return agents; }

    public void addSubject(Subject subject) { subjects.add(subject); }
    public List<Subject> getSubjects() { return subjects; }

    public void addMessage(ImportMessage.Level level, String msg, String reason) {
        messages.add(new ImportMessage(level, msg, reason));
    }

    public List<ImportMessage> getMessages() { return messages; }

    public boolean hasErrors() {
        return messages.stream().anyMatch(m -> m.getLevel() == ImportMessage.Level.ERROR);
    }
}
