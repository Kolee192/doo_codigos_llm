import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EadImporter implements Importer {

    @Override
    public ImportResult parse(String content, String repositoryId) {
        ImportResult result = new ImportResult();
        if (content == null || content.isBlank()) {
            result.addMessage(ImportMessage.Level.ERROR, "EAD import failed", "File is empty or null.");
            return result;
        }

        SourceSystem detectedSource = SourceSystem.ARCHIVES_SPACE_NATIVE;
        if (content.contains("generator=\"Archon\"") || content.contains("<archon:recordid>")) {
            detectedSource = SourceSystem.ARCHON;
        } else if (content.contains("generator=\"Archivists' Toolkit\"") || content.contains("xmlns:at=\"http://archiviststoolkit.org\"")) {
            detectedSource = SourceSystem.ARCHIVISTS_TOOLKIT;
        }

        String title = extractTag(content, "unittitle");
        if (title == null) {
            title = extractTag(content, "titleproper");
        }
        if (title == null) {
            result.addMessage(ImportMessage.Level.ERROR, "Missing title in EAD", "Neither <unittitle> nor <titleproper> could be found.");
            return result;
        }

        String unitid = extractTag(content, "unitid");
        if (unitid == null) {
            unitid = "COLL-" + System.currentTimeMillis();
            result.addMessage(ImportMessage.Level.WARNING, "No <unitid> found", "Generated default identifier: " + unitid);
        }

        String sourceRecordId = extractTag(content, "archon:recordid");
        if (sourceRecordId == null) {
            sourceRecordId = extractTag(content, "at:recordid");
        }
        if (sourceRecordId == null) {
            sourceRecordId = "imported-" + unitid;
        }

        Resource res = new Resource("res_" + UUID.randomUUID(), repositoryId, title, unitid, LevelOfDescription.of("collection"));
        res.setSourceSystem(detectedSource);
        res.setSourceRecordId(sourceRecordId);

        String unitdate = extractTag(content, "unitdate");
        if (unitdate != null) {
            res.addDate(new DateSubrecord("creation", "inclusive", unitdate, null, null));
        }

        String extent = extractTag(content, "extent");
        if (extent != null) {
            res.addExtent(new ExtentSubrecord("whole", extent, "items", null));
        }

        String bioghist = extractTag(content, "bioghist");
        if (bioghist != null) {
            res.addNote(new Note("note_" + UUID.randomUUID(), "bioghist", "Biographical / Historical Note", bioghist));
        }

        Matcher compMatcher = Pattern.compile("<c(?=\\s|>)(.*?)>(.*?)</c>", Pattern.DOTALL).matcher(content);
        int cIndex = 1;
        while (compMatcher.find()) {
            String cAttrs = compMatcher.group(1);
            String cBody = compMatcher.group(2);
            String cTitle = extractTag(cBody, "unittitle");
            String cUnitid = extractTag(cBody, "unitid");
            String cLevel = extractAttribute(cAttrs, "level");
            if (cLevel == null) cLevel = "file";
            if (cTitle == null) cTitle = "Component " + cIndex;

            ResourceComponent rc = new ResourceComponent("rc_" + UUID.randomUUID(), cUnitid != null ? cUnitid : "C-" + cIndex, cTitle, LevelOfDescription.of(cLevel));
            res.addChild(rc);
            cIndex++;
        }

        result.addRecord(res);
        result.addMessage(ImportMessage.Level.INFO, "EAD parsed successfully from " + detectedSource, null);
        return result;
    }

    private String extractTag(String text, String tag) {
        Pattern pattern = Pattern.compile("<" + tag + "[^>]*>(.*?)</" + tag + ">", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }
        return null;
    }

    private String extractAttribute(String attrs, String attrName) {
        Pattern pattern = Pattern.compile(attrName + "=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(attrs);
        if (matcher.find()) {
            return matcher.group(1).trim();
        }
        return null;
    }
}
