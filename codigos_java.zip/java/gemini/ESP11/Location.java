public class Location {
    private String id;
    private String building;
    private String room;
    private String shelf;
    private String barcode;

    public Location(String id, String building, String room, String shelf, String barcode) {
        this.id = id;
        this.building = building;
        this.room = room;
        this.shelf = shelf;
        this.barcode = barcode;
    }

    public String getId() { return id; }
    public String getBuilding() { return building; }
    public String getRoom() { return room; }
    public String getShelf() { return shelf; }
    public String getBarcode() { return barcode; }

    @Override
    public String toString() {
        return building + ", Room " + room + ", Shelf " + shelf;
    }
}
