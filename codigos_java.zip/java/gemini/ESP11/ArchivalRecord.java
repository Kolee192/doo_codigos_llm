import java.util.ArrayList;
import java.util.List;

public abstract class ArchivalRecord {
    private final String id;
    private final String repositoryId;
    private String title;
    private int lockVersion;
    private String sourceRecordId;
    private SourceSystem sourceSystem = SourceSystem.ARCHIVES_SPACE_NATIVE;

    private final List<DateSubrecord> dates = new ArrayList<>();
    private final List<ExtentSubrecord> extents = new ArrayList<>();
    private final List<String> subjectIds = new ArrayList<>();
    private final List<AgentLink> agentLinks = new ArrayList<>();
    private final List<Note> notes = new ArrayList<>();
    private final List<RightsStatement> rightsStatements = new ArrayList<>();
    private CollectionManagement collectionManagement;

    public ArchivalRecord(String id, String repositoryId, String title) {
        this.id = id;
        this.repositoryId = repositoryId;
        this.title = title;
        this.lockVersion = 0;
    }

    public String getId() { return id; }
    public String getRepositoryId() { return repositoryId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public int getLockVersion() { return lockVersion; }
    public void incrementLockVersion() { this.lockVersion++; }
    public void setLockVersion(int lockVersion) { this.lockVersion = lockVersion; }

    public String getSourceRecordId() { return sourceRecordId; }
    public void setSourceRecordId(String sourceRecordId) { this.sourceRecordId = sourceRecordId; }
    public SourceSystem getSourceSystem() { return sourceSystem; }
    public void setSourceSystem(SourceSystem sourceSystem) { this.sourceSystem = sourceSystem; }

    public List<DateSubrecord> getDates() { return dates; }
    public void addDate(DateSubrecord date) { this.dates.add(date); }

    public List<ExtentSubrecord> getExtents() { return extents; }
    public void addExtent(ExtentSubrecord extent) { this.extents.add(extent); }

    public List<String> getSubjectIds() { return subjectIds; }
    public void linkSubject(String subjectId) {
        if (!subjectIds.contains(subjectId)) {
            subjectIds.add(subjectId);
        }
    }

    public List<AgentLink> getAgentLinks() { return agentLinks; }
    public void linkAgent(String agentId, AgentRole role) {
        agentLinks.add(new AgentLink(agentId, role));
    }

    public List<Note> getNotes() { return notes; }
    public void addNote(Note note) { notes.add(note); }

    public List<RightsStatement> getRightsStatements() { return rightsStatements; }
    public void addRightsStatement(RightsStatement stmt) { rightsStatements.add(stmt); }

    public CollectionManagement getCollectionManagement() { return collectionManagement; }
    public void setCollectionManagement(CollectionManagement cm) { this.collectionManagement = cm; }

    public String renderOrderedSections() {
        StringBuilder sb = new StringBuilder();
        sb.append("--- [Dates Section] ---\n");
        for (DateSubrecord d : dates) {
            sb.append("  * ").append(d).append("\n");
        }
        sb.append("--- [Extents Section] ---\n");
        for (ExtentSubrecord e : extents) {
            sb.append("  * ").append(e).append("\n");
        }
        sb.append("--- [Subjects Section] ---\n");
        for (String sId : subjectIds) {
            sb.append("  * Subject ID: ").append(sId).append("\n");
        }
        return sb.toString();
    }
}
