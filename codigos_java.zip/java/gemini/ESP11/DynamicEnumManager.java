import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DynamicEnumManager {
    private final Map<String, List<String>> enumLists = new HashMap<>();

    public DynamicEnumManager() {
        loadDefaultLists();
    }

    public void loadDefaultLists() {
        List<String> levels = new ArrayList<>(List.of(
            "collection", "fonds", "class", "recordgrp", "series", "subseries", "file", "item", "other"
        ));
        enumLists.put("archival_record_level", levels);

        List<String> agentSources = new ArrayList<>(List.of(
            "local", "naf", "lcsh", "viaf", "ulan"
        ));
        enumLists.put("name_source", agentSources);

        List<String> subjectSources = new ArrayList<>(List.of(
            "lcsh", "mesh", "fast", "local", "aat"
        ));
        enumLists.put("subject_source", subjectSources);

        List<String> containerTypes = new ArrayList<>(List.of(
            "box", "folder", "volume", "reel", "carton", "drawer"
        ));
        enumLists.put("container_type", containerTypes);
    }

    public void loadValuesFromStorage(String enumName, List<String> values) {
        enumLists.put(enumName, new ArrayList<>(values));
    }

    public List<String> getValues(String enumName) {
        return enumLists.getOrDefault(enumName, Collections.emptyList());
    }

    public boolean containsValue(String enumName, String value) {
        List<String> list = enumLists.get(enumName);
        return list != null && list.stream().anyMatch(v -> v.equalsIgnoreCase(value));
    }

    public void addValue(String enumName, String value) {
        List<String> list = enumLists.computeIfAbsent(enumName, k -> new ArrayList<>());
        if (!containsValue(enumName, value)) {
            list.add(value);
        }
    }

    public int bulkUpdateValue(String enumName, String oldValue, String newValue) {
        List<String> list = enumLists.get(enumName);
        if (list == null) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).equalsIgnoreCase(oldValue)) {
                list.set(i, newValue);
                count++;
            }
        }
        return count;
    }
}
