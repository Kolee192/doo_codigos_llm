import java.util.ArrayList;
import java.util.List;

public class ResourceComponent {
    private final String id;
    private String componentId; // Component unique identifier (CUID)
    private String title;
    private LevelOfDescription level;
    private int lockVersion = 0;

    private ResourceComponent parent;
    private final List<ResourceComponent> children = new ArrayList<>();
    private final List<DateSubrecord> dates = new ArrayList<>();
    private final List<ExtentSubrecord> extents = new ArrayList<>();
    private final List<String> subjectIds = new ArrayList<>();
    private final List<AgentLink> agentLinks = new ArrayList<>();
    private final List<Instance> instances = new ArrayList<>();
    private final List<Note> notes = new ArrayList<>();

    public ResourceComponent(String id, String componentId, String title, LevelOfDescription level) {
        this.id = id;
        this.componentId = componentId;
        this.title = title;
        this.level = level;
    }

    public String getId() { return id; }
    public String getComponentId() { return componentId; }
    public void setComponentId(String componentId) { this.componentId = componentId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public LevelOfDescription getLevel() { return level; }
    public void setLevel(LevelOfDescription level) { this.level = level; }
    public int getLockVersion() { return lockVersion; }
    public void incrementLockVersion() { this.lockVersion++; }
    public void setLockVersion(int lockVersion) { this.lockVersion = lockVersion; }

    public ResourceComponent getParent() { return parent; }
    public void setParent(ResourceComponent parent) { this.parent = parent; }
    public List<ResourceComponent> getChildren() { return children; }
    public void addChild(ResourceComponent child) {
        child.setParent(this);
        children.add(child);
    }
    public void removeChild(ResourceComponent child) {
        children.remove(child);
        child.setParent(null);
    }

    public List<DateSubrecord> getDates() { return dates; }
    public void addDate(DateSubrecord date) { dates.add(date); }
    public List<ExtentSubrecord> getExtents() { return extents; }
    public void addExtent(ExtentSubrecord extent) { extents.add(extent); }
    public List<String> getSubjectIds() { return subjectIds; }
    public void linkSubject(String subjectId) { subjectIds.add(subjectId); }
    public List<AgentLink> getAgentLinks() { return agentLinks; }
    public void linkAgent(String agentId, AgentRole role) { agentLinks.add(new AgentLink(agentId, role)); }
    public List<Instance> getInstances() { return instances; }
    public void addInstance(Instance instance) { instances.add(instance); }
    public List<Note> getNotes() { return notes; }
    public void addNote(Note note) { notes.add(note); }
}
