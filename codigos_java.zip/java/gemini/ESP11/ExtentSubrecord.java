public class ExtentSubrecord {
    private String portion;
    private String number;
    private String extentType;
    private String containerSummary;

    public ExtentSubrecord(String portion, String number, String extentType, String containerSummary) {
        this.portion = portion;
        this.number = number;
        this.extentType = extentType;
        this.containerSummary = containerSummary;
    }

    public String getPortion() { return portion; }
    public String getNumber() { return number; }
    public String getExtentType() { return extentType; }
    public String getContainerSummary() { return containerSummary; }

    @Override
    public String toString() {
        return number + " " + extentType + (containerSummary != null ? " (" + containerSummary + ")" : "");
    }
}
