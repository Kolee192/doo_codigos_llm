public class Container {
    private String id;
    private String containerType;
    private String indicator;
    private String barcode;
    private Location location;

    public Container(String id, String containerType, String indicator, String barcode) {
        this.id = id;
        this.containerType = containerType;
        this.indicator = indicator;
        this.barcode = barcode;
    }

    public String getId() { return id; }
    public String getContainerType() { return containerType; }
    public String getIndicator() { return indicator; }
    public String getBarcode() { return barcode; }
    public Location getLocation() { return location; }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return containerType + " " + indicator + (location != null ? " [" + location + "]" : "");
    }
}
