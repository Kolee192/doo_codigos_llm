import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class SystemConfiguration {
    private final Properties properties = new Properties();
    private final Map<String, String> helpTopicMappings = new HashMap<>();
    private String helpCenterUrl = "https://help.archivesspace.org";
    private String databasePath = "./demo_db/archivesspace.db";
    private String backupDirectory = "./demo_db_backups";

    public SystemConfiguration() {
        setDefaultHelpMappings();
    }

    private void setDefaultHelpMappings() {
        helpTopicMappings.put("resource", "/help/resources/overview");
        helpTopicMappings.put("accession", "/help/accessions/overview");
        helpTopicMappings.put("digital_object", "/help/digital-objects/overview");
        helpTopicMappings.put("agent", "/help/agents/overview");
        helpTopicMappings.put("subject", "/help/subjects/overview");
    }

    public void loadExternalConfiguration(File configFile) throws IOException {
        if (configFile != null && configFile.exists()) {
            try (FileInputStream fis = new FileInputStream(configFile)) {
                properties.load(fis);
            }
            if (properties.containsKey("help.center.url")) {
                this.helpCenterUrl = properties.getProperty("help.center.url");
            }
            if (properties.containsKey("db.path")) {
                this.databasePath = properties.getProperty("db.path");
            }
            if (properties.containsKey("db.backup.dir")) {
                this.backupDirectory = properties.getProperty("db.backup.dir");
            }
        }
    }

    public void setHelpCenterUrl(String url) {
        this.helpCenterUrl = url;
    }

    public String getHelpCenterUrl() {
        return helpCenterUrl;
    }

    public void setHelpTopicMapping(String topic, String relativePath) {
        helpTopicMappings.put(topic, relativePath);
    }

    public String getHelpUrlForTopic(String topic) {
        String path = helpTopicMappings.getOrDefault(topic, "/help/index");
        return helpCenterUrl.replaceAll("/$", "") + "/" + path.replaceAll("^/", "");
    }

    public void setDatabasePath(String path) {
        this.databasePath = path;
    }

    public String getDatabasePath() {
        return databasePath;
    }

    public void setBackupDirectory(String backupDirectory) {
        this.backupDirectory = backupDirectory;
    }

    public String getBackupDirectory() {
        return backupDirectory;
    }

    public File backupDatabase() throws IOException {
        File dbFile = new File(databasePath);
        File backupDir = new File(backupDirectory);
        if (!backupDir.exists()) {
            backupDir.mkdirs();
        }
        if (!dbFile.exists()) {
            if (dbFile.getParentFile() != null) {
                dbFile.getParentFile().mkdirs();
            }
            dbFile.createNewFile();
        }
        File backupTarget = new File(backupDir, "db_backup_" + System.currentTimeMillis() + ".bak");
        Files.copy(dbFile.toPath(), backupTarget.toPath(), StandardCopyOption.REPLACE_EXISTING);
        return backupTarget;
    }
}
