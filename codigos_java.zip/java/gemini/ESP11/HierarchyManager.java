import java.util.List;

public class HierarchyManager {

    public static boolean moveUp(List<ResourceComponent> siblings, ResourceComponent target) {
        int index = siblings.indexOf(target);
        if (index > 0) {
            siblings.remove(index);
            siblings.add(index - 1, target);
            return true;
        }
        return false;
    }

    public static boolean moveDown(List<ResourceComponent> siblings, ResourceComponent target) {
        int index = siblings.indexOf(target);
        if (index >= 0 && index < siblings.size() - 1) {
            siblings.remove(index);
            siblings.add(index + 1, target);
            return true;
        }
        return false;
    }

    public static boolean reparent(ResourceComponent target, ResourceComponent newParent, List<ResourceComponent> currentSiblings) {
        if (target == null || target == newParent) {
            return false;
        }
        currentSiblings.remove(target);
        if (newParent != null) {
            newParent.addChild(target);
        }
        return true;
    }

    public static boolean dragAndDrop(List<ResourceComponent> currentSiblings, ResourceComponent item, List<ResourceComponent> targetList, int targetIndex) {
        if (item == null || targetList == null) {
            return false;
        }
        currentSiblings.remove(item);
        if (targetIndex < 0) {
            targetList.add(0, item);
        } else if (targetIndex >= targetList.size()) {
            targetList.add(item);
        } else {
            targetList.add(targetIndex, item);
        }
        return true;
    }

    public static boolean moveDigitalObjectUp(List<DigitalObject> siblings, DigitalObject target) {
        int index = siblings.indexOf(target);
        if (index > 0) {
            siblings.remove(index);
            siblings.add(index - 1, target);
            return true;
        }
        return false;
    }

    public static boolean moveDigitalObjectDown(List<DigitalObject> siblings, DigitalObject target) {
        int index = siblings.indexOf(target);
        if (index >= 0 && index < siblings.size() - 1) {
            siblings.remove(index);
            siblings.add(index + 1, target);
            return true;
        }
        return false;
    }
}
