import java.io.File;
import java.io.IOException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("Archives Management System Demo");
        System.out.println("==================================================");

        // 1. LDAP and Local Authentication & User Management
        LdapDirectory ldap = new LdapDirectory();
        ldap.registerLdapUser("ldap_archivist", "ldap_secret");

        AuthService authService = new AuthService(ldap);
        User adminUser = new User("admin", "admin123", "System Administrator", "admin@aspace.edu", true);
        authService.createUser(null, adminUser);

        User entryUser = new User("entry_clerk", "clerk123", "Basic Entry Clerk", "clerk@aspace.edu", false);
        authService.createUser(adminUser, entryUser);

        // Admin resets a user's password
        authService.resetPassword(adminUser, "entry_clerk", "new_clerk_pass_456");
        System.out.println("Password reset successful for entry_clerk: " +
            authService.authenticateLocal("entry_clerk", "new_clerk_pass_456").isPresent());

        // LDAP Authentication
        var ldapUserOpt = authService.authenticateLdap("ldap_archivist", "ldap_secret");
        System.out.println("LDAP Login successful: " + ldapUserOpt.isPresent());

        // 2. Configuration & External Help Center
        SystemConfiguration config = new SystemConfiguration();
        config.setHelpCenterUrl("https://help.archivescenter.org");
        config.setHelpTopicMapping("resource_component", "/help/resources/components");
        System.out.println("Help link for resource_component: " + config.getHelpUrlForTopic("resource_component"));

        try {
            File backup = config.backupDatabase();
            System.out.println("Demo database backed up successfully to: " + backup.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Database backup failed: " + e.getMessage());
        }

        // 3. Dynamic Enums and Controlled Vocabularies
        DynamicEnumManager enumManager = new DynamicEnumManager();
        enumManager.addValue("archival_record_level", "sub-subseries");
        System.out.println("Updated levels: " + enumManager.getValues("archival_record_level"));
        int updated = enumManager.bulkUpdateValue("name_source", "naf", "loc_naf");
        System.out.println("Bulk updated 'naf' to 'loc_naf': " + updated + " replacement(s)");

        // 4. Repositories and Role Assignments
        Repository repo = new Repository("repo_101", "SPEC-COLL", "Special Collections & Archives");
        repo.setAdditionalProperty("buildingHours", "9am - 5pm M-F");
        repo.setAdditionalProperty("curatorContact", "archives@university.edu");

        RepositoryService repoService = new RepositoryService();
        repoService.createRepository(adminUser, repo);

        // Assign Repository Manager and Advanced Data Entry roles
        User repoManager = new User("mgr_sarah", "mgr123", "Sarah Manager", "sarah@aspace.edu", false);
        authService.createUser(adminUser, repoManager);
        adminUser.assignRole(repo.getId(), Role.REPOSITORY_MANAGER);
        repoManager.assignRole(repo.getId(), Role.REPOSITORY_MANAGER);
        entryUser.assignRole(repo.getId(), Role.ADVANCED_DATA_ENTRY);

        // 5. Container & Location Information
        Location shelfLoc = new Location("loc_1", "Main Library", "Vault 3", "Shelf B4", "BC-99001");
        repoService.saveLocation(shelfLoc);

        Container box1 = new Container("box_1", "box", "1", "BARCODE-001");
        box1.setLocation(shelfLoc);
        repoService.saveContainer(box1);

        // 6. Agents and Subjects with Standard Identifiers
        Subject subject = new Subject("subj_1", repo.getId(), "Civil Rights Movements", "sh85026371", "lcsh");
        repoService.saveSubject(subject);

        Agent agentCreator = new Agent("agent_1", AgentType.PERSON, "King", "Martin Luther, Jr.", "loc_naf");
        agentCreator.addNote(new Note("n_ag_1", "general", "Biographical Note", "American minister and activist."));
        repoService.saveAgent(agentCreator);

        // 7. Resource with Finding Aid, Dates, Extents, Instances, Notes, and Collection Management
        Resource resource = new Resource("res_1", repo.getId(), "Dr. Martin Luther King Jr. Papers", "MLK-001", LevelOfDescription.of("collection"));
        resource.setSourceSystem(SourceSystem.ARCHIVISTS_TOOLKIT);
        resource.setSourceRecordId("AT_REC_8849");

        // Display dates and extents before subjects
        resource.addDate(new DateSubrecord("inclusive", "inclusive", "1955-1968", "1955", "1968"));
        resource.addExtent(new ExtentSubrecord("whole", "25.5", "linear_feet", "20 record cartons"));
        resource.linkSubject(subject.getId());
        resource.linkAgent(agentCreator.getId(), AgentRole.CREATOR);

        FindingAidData fa = resource.getFindingAidData();
        fa.setFindingAidTitle("Inventory of the Dr. Martin Luther King Jr. Papers");
        fa.setFindingAidAuthor("Processed by Special Collections Staff");
        fa.setFindingAidDate("2024");
        fa.setFindingAidLanguage("eng");
        fa.setAdministrativeSummary("Acquired directly from donor estate.");

        resource.setCollectionManagement(new CollectionManagement("completed", 120.0, "Arranged alphabetically and chronologically", "S. Archivist"));
        resource.addRightsStatement(new RightsStatement("right_1", "copyright", "active", "US", "Fair use with attribution"));
        resource.addInstance(Instance.forContainer("inst_1", InstanceType.MIXED_MATERIALS, box1));

        // Add Resource Components with Unique Identifiers
        ResourceComponent series1 = new ResourceComponent("rc_1", "SER-01", "Series 1: Correspondence", LevelOfDescription.of("series"));
        ResourceComponent file1 = new ResourceComponent("rc_2", "FILE-0101", "File 1: 1956 Letters", LevelOfDescription.of("file"));
        series1.addChild(file1);
        resource.addChild(series1);

        ResourceComponent series2 = new ResourceComponent("rc_3", "SER-02", "Series 2: Speeches and Sermons", LevelOfDescription.of("series"));
        resource.addChild(series2);

        repoService.saveResource(adminUser, resource, 0);

        // 8. Keyboard / Drag-and-Drop Hierarchy Rearrangement
        System.out.println("\nRearranging hierarchy (moving Series 2 up)...");
        HierarchyManager.moveUp(resource.getChildren(), series2);
        System.out.println("First series is now: " + resource.getChildren().get(0).getTitle());

        // 9. Finding Aid View
        System.out.println("\n" + resource.viewFindingAid());

        // 10. Concurrency / Optimistic Locking Verification
        System.out.println("Testing Optimistic Locking...");
        try {
            // Attempting to save with outdated lockVersion 0 when record is at lockVersion 1
            repoService.saveResource(adminUser, resource, 0);
        } catch (ConcurrencyException ex) {
            System.out.println("Caught expected ConcurrencyException: " + ex.getMessage());
        }

        // 11. Importers: CSV, EAD (Archon / AT), MARCXML, EAC-CPF with error handling
        System.out.println("\n--- Testing Importers & Diagnostics ---");

        // CSV Accession Importer
        String csvData = "accessionNumber,title,accessionDate,extentNumber,extentType\n" +
                         "ACC-2024-001,Community Theater Records,2024-02-15,3,linear_feet\n" +
                         "ACC-2024-002,Local Historical Photographs,2024-03-01,1,box\n";
        AccessionCsvImporter csvImporter = new AccessionCsvImporter();
        ImportResult csvResult = csvImporter.parse(csvData, repo.getId());
        for (ArchivalRecord rec : csvResult.getRecords()) {
            repoService.saveAccession(repoManager, (Accession) rec, 0);
        }
        System.out.println("CSV imported records: " + csvResult.getRecords().size());

        // EAD with error demo
        EadImporter eadImporter = new EadImporter();
        ImportResult invalidEad = eadImporter.parse("<ead><eadheader></eadheader></ead>", repo.getId());
        for (ImportMessage msg : invalidEad.getMessages()) {
            System.out.println("Diagnostic Error Reported: " + msg);
        }

        // Valid Archon EAD import
        String archonEad = """
            <ead generator="Archon">
              <eadheader>
                <eadid>ARCHON-COL-10</eadid>
              </eadheader>
              <archdesc level="collection">
                <did>
                  <unittitle>Archon Migrated Historical Collection</unittitle>
                  <unitid>ARC-10</unitid>
                  <archon:recordid>ARCHON_REC_772</archon:recordid>
                  <unitdate>1910-1945</unitdate>
                  <extent>10 linear feet</extent>
                </did>
                <dsc>
                  <c level="series">
                    <did>
                      <unittitle>Migrated Series 1</unittitle>
                      <unitid>SER-01</unitid>
                    </did>
                  </c>
                </dsc>
              </archdesc>
            </ead>
            """;
        ImportResult validEadResult = eadImporter.parse(archonEad, repo.getId());
        Resource importedRes = (Resource) validEadResult.getRecords().get(0);
        System.out.println("Imported Resource: " + importedRes.getTitle() + ", Source: " + importedRes.getSourceSystem() + ", SourceID: " + importedRes.getSourceRecordId());

        // MARCXML Import (Agents & Subjects only)
        String marcXml = """
            <record>
              <datafield tag="100" ind1="1" ind2=" ">
                <subfield code="a">Parks, Rosa</subfield>
              </datafield>
              <datafield tag="650" ind1=" " ind2="0">
                <subfield code="a">Bus boycotts</subfield>
                <subfield code="0">sh85018245</subfield>
              </datafield>
            </record>
            """;
        MarcXmlImporter marcImporter = new MarcXmlImporter(true);
        ImportResult marcResult = marcImporter.parse(marcXml, repo.getId());
        System.out.println("MARCXML Imported Agents count: " + marcResult.getAgents().size());
        System.out.println("MARCXML Imported Subjects count: " + marcResult.getSubjects().size());

        // 12. Exporters: EAD & EAC-CPF
        System.out.println("\n--- Testing Exporters ---");
        EadExporter eadExporter = new EadExporter();
        String eadXmlOutput = eadExporter.export(resource);
        System.out.println("Exported EAD preview (first 250 chars):\n" + eadXmlOutput.substring(0, Math.min(250, eadXmlOutput.length())) + "...\n");

        EacCpfExporter eacExporter = new EacCpfExporter();
        String eacXmlOutput = eacExporter.export(agentCreator);
        System.out.println("Exported EAC-CPF preview (first 250 chars):\n" + eacXmlOutput.substring(0, Math.min(250, eacXmlOutput.length())) + "...\n");

        // 13. Digital Objects & Repository Search
        DigitalObject dobj = new DigitalObject("dobj_1", repo.getId(), "Dr. MLK Audio Interview 1965", "DO-001", "https://digital.aspace.edu/record/001");
        repoService.saveDigitalObject(adminUser, dobj, 0);

        Event ingestEvent = new Event("ev_1", repo.getId(), "ingestion", "Success");
        ingestEvent.linkRecord(dobj.getId());
        ingestEvent.linkAgent(agentCreator.getId());
        repoService.saveEvent(ingestEvent);

        System.out.println("--- Search Repository for 'King' ---");
        List<ArchivalRecord> searchResults = repoService.search(adminUser, repo.getId(), "King");
        for (ArchivalRecord r : searchResults) {
            System.out.println("Found [" + r.getClass().getSimpleName() + "]: " + r.getTitle());
        }

        System.out.println("\nDemo completed successfully.");
    }
}
