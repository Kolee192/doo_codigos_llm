import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EacCpfImporter implements Importer {

    @Override
    public ImportResult parse(String content, String repositoryId) {
        ImportResult result = new ImportResult();
        if (content == null || content.isBlank()) {
            result.addMessage(ImportMessage.Level.ERROR, "EAC-CPF empty", "No content");
            return result;
        }

        AgentType agentType = AgentType.PERSON;
        if (content.contains("<entityType>corporateBody</entityType>")) {
            agentType = AgentType.CORPORATE_ENTITY;
        } else if (content.contains("<entityType>family</entityType>")) {
            agentType = AgentType.FAMILY;
        }

        String primaryName = null;
        Pattern nameEntry = Pattern.compile("<nameEntry[^>]*>(.*?)</nameEntry>", Pattern.DOTALL);
        Matcher m = nameEntry.matcher(content);
        if (m.find()) {
            String entry = m.group(1);
            Pattern part = Pattern.compile("<part>(.*?)</part>");
            Matcher pm = part.matcher(entry);
            if (pm.find()) {
                primaryName = pm.group(1).trim();
            }
        }

        if (primaryName == null) {
            result.addMessage(ImportMessage.Level.ERROR, "Missing <part> in <nameEntry>", "Cannot extract agent name from EAC-CPF");
            return result;
        }

        Agent agent = new Agent("agent_" + UUID.randomUUID(), agentType, primaryName, null, "viaf");
        result.addAgent(agent);
        result.addMessage(ImportMessage.Level.INFO, "Imported EAC-CPF Agent: " + primaryName, null);
        return result;
    }
}
