import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class AuthService {
    private final Map<String, User> userStore = new HashMap<>();
    private final LdapDirectory ldapDirectory;

    public AuthService(LdapDirectory ldapDirectory) {
        this.ldapDirectory = ldapDirectory;
    }

    public void createUser(User actor, User newUser) {
        if (actor != null && !actor.isSystemAdmin()) {
            throw new SecurityException("Only System Administrators can create users.");
        }
        userStore.put(newUser.getUsername(), newUser);
    }

    public Optional<User> authenticateLocal(String username, String password) {
        User user = userStore.get(username);
        if (user != null && user.verifyPassword(password)) {
            return Optional.of(user);
        }
        return Optional.empty();
    }

    public Optional<User> authenticateLdap(String username, String password) {
        if (ldapDirectory != null && ldapDirectory.authenticate(username, password)) {
            User user = userStore.get(username);
            if (user != null) {
                return Optional.of(user);
            }
            User syncedUser = new User(username, password, username, username + "@ldap.org", false);
            userStore.put(username, syncedUser);
            return Optional.of(syncedUser);
        }
        return Optional.empty();
    }

    public void resetPassword(User actor, String targetUsername, String newPassword) {
        if (!actor.isSystemAdmin()) {
            throw new SecurityException("Only System Administrators can reset passwords.");
        }
        User target = userStore.get(targetUsername);
        if (target == null) {
            throw new IllegalArgumentException("User not found: " + targetUsername);
        }
        target.setPassword(newPassword);
    }

    public Optional<User> findByUsername(String username) {
        return Optional.ofNullable(userStore.get(username));
    }
}
