public class Accession extends ArchivalRecord {
    private String accessionNumber;
    private String accessionDate;
    private String contentDescription;

    public Accession(String id, String repositoryId, String title, String accessionNumber, String accessionDate) {
        super(id, repositoryId, title);
        this.accessionNumber = accessionNumber;
        this.accessionDate = accessionDate;
    }

    public String getAccessionNumber() { return accessionNumber; }
    public void setAccessionNumber(String accessionNumber) { this.accessionNumber = accessionNumber; }
    public String getAccessionDate() { return accessionDate; }
    public void setAccessionDate(String accessionDate) { this.accessionDate = accessionDate; }
    public String getContentDescription() { return contentDescription; }
    public void setContentDescription(String contentDescription) { this.contentDescription = contentDescription; }
}
