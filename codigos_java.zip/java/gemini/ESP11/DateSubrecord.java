public class DateSubrecord {
    private String label;
    private String dateType;
    private String expression;
    private String beginDate;
    private String endDate;

    public DateSubrecord(String label, String dateType, String expression, String beginDate, String endDate) {
        this.label = label;
        this.dateType = dateType;
        this.expression = expression;
        this.beginDate = beginDate;
        this.endDate = endDate;
    }

    public String getLabel() { return label; }
    public String getDateType() { return dateType; }
    public String getExpression() { return expression; }
    public String getBeginDate() { return beginDate; }
    public String getEndDate() { return endDate; }

    @Override
    public String toString() {
        return expression != null && !expression.isBlank() ? expression : beginDate + " - " + endDate;
    }
}
