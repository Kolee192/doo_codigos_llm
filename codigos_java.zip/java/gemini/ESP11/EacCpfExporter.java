public class EacCpfExporter {

    public String export(Agent agent) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<eac-cpf xmlns=\"urn:isbn:1-931666-33-4\">\n");
        sb.append("  <control>\n");
        sb.append("    <recordId>").append(agent.getId()).append("</recordId>\n");
        sb.append("  </control>\n");
        sb.append("  <cpfDescription>\n");
        sb.append("    <identity>\n");
        String typeTag = switch (agent.getAgentType()) {
            case PERSON -> "person";
            case CORPORATE_ENTITY -> "corporateBody";
            case FAMILY -> "family";
        };
        sb.append("      <entityType>").append(typeTag).append("</entityType>\n");
        for (NameForm nf : agent.getNameForms()) {
            sb.append("      <nameEntry>\n");
            sb.append("        <part>").append(nf.getFullDisplay()).append("</part>\n");
            if (nf.getSource() != null) {
                sb.append("        <authorizedForm>").append(nf.getSource()).append("</authorizedForm>\n");
            }
            sb.append("      </nameEntry>\n");
        }
        sb.append("    </identity>\n");
        sb.append("  </cpfDescription>\n");
        sb.append("</eac-cpf>\n");
        return sb.toString();
    }
}
