public class CollectionManagement {
    private String processingStatus;
    private double processingHoursTotal;
    private String processingPlan;
    private String processors;

    public CollectionManagement(String processingStatus, double processingHoursTotal, String processingPlan, String processors) {
        this.processingStatus = processingStatus;
        this.processingHoursTotal = processingHoursTotal;
        this.processingPlan = processingPlan;
        this.processors = processors;
    }

    public String getProcessingStatus() { return processingStatus; }
    public void setProcessingStatus(String processingStatus) { this.processingStatus = processingStatus; }
    public double getProcessingHoursTotal() { return processingHoursTotal; }
    public void setProcessingHoursTotal(double processingHoursTotal) { this.processingHoursTotal = processingHoursTotal; }
    public String getProcessingPlan() { return processingPlan; }
    public void setProcessingPlan(String processingPlan) { this.processingPlan = processingPlan; }
    public String getProcessors() { return processors; }
    public void setProcessors(String processors) { this.processors = processors; }
}
