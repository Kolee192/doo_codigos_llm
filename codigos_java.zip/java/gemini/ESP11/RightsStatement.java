public class RightsStatement {
    private String id;
    private String rightsType;
    private String status;
    private String jurisdiction;
    private String notes;

    public RightsStatement(String id, String rightsType, String status, String jurisdiction, String notes) {
        this.id = id;
        this.rightsType = rightsType;
        this.status = status;
        this.jurisdiction = jurisdiction;
        this.notes = notes;
    }

    public String getId() { return id; }
    public String getRightsType() { return rightsType; }
    public String getStatus() { return status; }
    public String getJurisdiction() { return jurisdiction; }
    public String getNotes() { return notes; }

    public void setStatus(String status) { this.status = status; }
    public void setNotes(String notes) { this.notes = notes; }
}
