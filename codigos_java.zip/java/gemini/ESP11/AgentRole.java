public enum AgentRole {
    CREATOR,
    SOURCE,
    SUBJECT
}
