import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Event {
    private final String id;
    private final String repositoryId;
    private String eventType;
    private Date timestamp;
    private String outcome;
    private final List<String> linkedRecordIds = new ArrayList<>();
    private final List<String> linkedAgentIds = new ArrayList<>();

    public Event(String id, String repositoryId, String eventType, String outcome) {
        this.id = id;
        this.repositoryId = repositoryId;
        this.eventType = eventType;
        this.outcome = outcome;
        this.timestamp = new Date();
    }

    public String getId() { return id; }
    public String getRepositoryId() { return repositoryId; }
    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }
    public Date getTimestamp() { return timestamp; }
    public String getOutcome() { return outcome; }
    public void setOutcome(String outcome) { this.outcome = outcome; }
    public List<String> getLinkedRecordIds() { return linkedRecordIds; }
    public void linkRecord(String recordId) { linkedRecordIds.add(recordId); }
    public List<String> getLinkedAgentIds() { return linkedAgentIds; }
    public void linkAgent(String agentId) { linkedAgentIds.add(agentId); }
}
