public class NameForm {
    private String primaryName;
    private String restOfName;
    private String source;

    public NameForm(String primaryName, String restOfName, String source) {
        this.primaryName = primaryName;
        this.restOfName = restOfName;
        this.source = source;
    }

    public String getPrimaryName() { return primaryName; }
    public void setPrimaryName(String primaryName) { this.primaryName = primaryName; }
    public String getRestOfName() { return restOfName; }
    public void setRestOfName(String restOfName) { this.restOfName = restOfName; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public String getFullDisplay() {
        if (restOfName != null && !restOfName.isBlank()) {
            return primaryName + ", " + restOfName;
        }
        return primaryName;
    }
}
