import java.util.ArrayList;
import java.util.List;

public class Agent {
    private final String id;
    private AgentType agentType;
    private final List<NameForm> nameForms = new ArrayList<>();
    private final List<Note> notes = new ArrayList<>();

    public Agent(String id, AgentType agentType, String primaryName, String restOfName, String source) {
        this.id = id;
        this.agentType = agentType;
        this.nameForms.add(new NameForm(primaryName, restOfName, source));
    }

    public String getId() { return id; }
    public AgentType getAgentType() { return agentType; }
    public void setAgentType(AgentType agentType) { this.agentType = agentType; }
    public List<NameForm> getNameForms() { return nameForms; }
    public void addNameForm(NameForm nameForm) { nameForms.add(nameForm); }
    public List<Note> getNotes() { return notes; }
    public void addNote(Note note) { notes.add(note); }

    public NameForm getPrimaryNameForm() {
        return nameForms.isEmpty() ? null : nameForms.get(0);
    }
}
