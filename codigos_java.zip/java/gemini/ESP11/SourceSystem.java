public enum SourceSystem {
    ARCHON,
    ARCHIVISTS_TOOLKIT,
    ARCHIVES_SPACE_NATIVE,
    CUSTOM
}
