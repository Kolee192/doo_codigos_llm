public class Instance {
    private String id;
    private InstanceType instanceType;
    private Container container;
    private String digitalObjectId;

    public Instance(String id, InstanceType instanceType, Container container, String digitalObjectId) {
        this.id = id;
        this.instanceType = instanceType;
        this.container = container;
        this.digitalObjectId = digitalObjectId;
    }

    public static Instance forContainer(String id, InstanceType type, Container container) {
        return new Instance(id, type, container, null);
    }

    public static Instance forDigitalObject(String id, String digitalObjectId) {
        return new Instance(id, InstanceType.DIGITAL_OBJECT, null, digitalObjectId);
    }

    public String getId() { return id; }
    public InstanceType getInstanceType() { return instanceType; }
    public Container getContainer() { return container; }
    public void setContainer(Container container) { this.container = container; }
    public String getDigitalObjectId() { return digitalObjectId; }
}
