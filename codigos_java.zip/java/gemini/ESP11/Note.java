public class Note {
    private String id;
    private String type;
    private String label;
    private String content;

    public Note(String id, String type, String label, String content) {
        this.id = id;
        this.type = type;
        this.label = label;
        this.content = content;
    }

    public String getId() { return id; }
    public String getType() { return type; }
    public String getLabel() { return label; }
    public String getContent() { return content; }

    public void setLabel(String label) { this.label = label; }
    public void setContent(String content) { this.content = content; }
}
