public class FindingAidData {
    private String findingAidTitle;
    private String findingAidSubtitle;
    private String findingAidAuthor;
    private String findingAidDate;
    private String findingAidLanguage;
    private String findingAidStatus;
    private String administrativeSummary;

    public FindingAidData() {}

    public String getFindingAidTitle() { return findingAidTitle; }
    public void setFindingAidTitle(String findingAidTitle) { this.findingAidTitle = findingAidTitle; }
    public String getFindingAidSubtitle() { return findingAidSubtitle; }
    public void setFindingAidSubtitle(String findingAidSubtitle) { this.findingAidSubtitle = findingAidSubtitle; }
    public String getFindingAidAuthor() { return findingAidAuthor; }
    public void setFindingAidAuthor(String findingAidAuthor) { this.findingAidAuthor = findingAidAuthor; }
    public String getFindingAidDate() { return findingAidDate; }
    public void setFindingAidDate(String findingAidDate) { this.findingAidDate = findingAidDate; }
    public String getFindingAidLanguage() { return findingAidLanguage; }
    public void setFindingAidLanguage(String findingAidLanguage) { this.findingAidLanguage = findingAidLanguage; }
    public String getFindingAidStatus() { return findingAidStatus; }
    public void setFindingAidStatus(String findingAidStatus) { this.findingAidStatus = findingAidStatus; }
    public String getAdministrativeSummary() { return administrativeSummary; }
    public void setAdministrativeSummary(String administrativeSummary) { this.administrativeSummary = administrativeSummary; }
}
