import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class RepositoryService {
    private final Map<String, Repository> repositories = new HashMap<>();
    private final Map<String, Resource> resources = new HashMap<>();
    private final Map<String, Accession> accessions = new HashMap<>();
    private final Map<String, DigitalObject> digitalObjects = new HashMap<>();
    private final Map<String, Subject> subjects = new HashMap<>();
    private final Map<String, Agent> agents = new HashMap<>();
    private final Map<String, Event> events = new HashMap<>();
    private final Map<String, Location> locations = new HashMap<>();
    private final Map<String, Container> containers = new HashMap<>();

    public void createRepository(User user, Repository repo) {
        if (!user.isSystemAdmin()) {
            throw new SecurityException("Only System Administrators can create repositories.");
        }
        repositories.put(repo.getId(), repo);
    }

    public Optional<Repository> getRepository(String repoId) {
        return Optional.ofNullable(repositories.get(repoId));
    }

    public void saveResource(User user, Resource resource, int expectedLockVersion) {
        checkPermission(user, resource.getRepositoryId(), Permission.CREATE_ADVANCED_RECORD, Permission.EDIT_RECORD);
        Resource existing = resources.get(resource.getId());
        if (existing != null) {
            if (existing.getLockVersion() != expectedLockVersion) {
                throw new ConcurrencyException("Record has been modified by another user. Current version: "
                    + existing.getLockVersion() + ", your version: " + expectedLockVersion);
            }
            resource.setLockVersion(expectedLockVersion + 1);
        } else {
            resource.setLockVersion(0);
        }
        resources.put(resource.getId(), resource);
    }

    public void deleteResource(User user, String resourceId) {
        Resource res = resources.get(resourceId);
        if (res != null) {
            checkPermission(user, res.getRepositoryId(), Permission.DELETE_RECORD);
            resources.remove(resourceId);
        }
    }

    public Optional<Resource> getResource(User user, String resourceId) {
        Resource res = resources.get(resourceId);
        if (res != null) {
            checkPermission(user, res.getRepositoryId(), Permission.VIEW_RECORD);
            return Optional.of(res);
        }
        return Optional.empty();
    }

    public void saveAccession(User user, Accession accession, int expectedLockVersion) {
        checkPermission(user, accession.getRepositoryId(), Permission.CREATE_BASIC_RECORD, Permission.EDIT_RECORD);
        Accession existing = accessions.get(accession.getId());
        if (existing != null) {
            if (existing.getLockVersion() != expectedLockVersion) {
                throw new ConcurrencyException("Accession modified by another user. Conflict detected.");
            }
            accession.setLockVersion(expectedLockVersion + 1);
        } else {
            accession.setLockVersion(0);
        }
        accessions.put(accession.getId(), accession);
    }

    public Optional<Accession> getAccession(User user, String accessionId) {
        Accession acc = accessions.get(accessionId);
        if (acc != null) {
            checkPermission(user, acc.getRepositoryId(), Permission.VIEW_RECORD);
            return Optional.of(acc);
        }
        return Optional.empty();
    }

    public void saveDigitalObject(User user, DigitalObject dobj, int expectedLockVersion) {
        checkPermission(user, dobj.getRepositoryId(), Permission.CREATE_BASIC_RECORD, Permission.EDIT_RECORD);
        DigitalObject existing = digitalObjects.get(dobj.getId());
        if (existing != null && existing.getLockVersion() != expectedLockVersion) {
            throw new ConcurrencyException("Digital object modified concurrently.");
        }
        dobj.setLockVersion(expectedLockVersion + 1);
        digitalObjects.put(dobj.getId(), dobj);
    }

    public Optional<DigitalObject> getDigitalObject(User user, String id) {
        DigitalObject dobj = digitalObjects.get(id);
        if (dobj != null) {
            checkPermission(user, dobj.getRepositoryId(), Permission.VIEW_RECORD);
            return Optional.of(dobj);
        }
        return Optional.empty();
    }

    public void saveSubject(Subject subject) {
        subjects.put(subject.getId(), subject);
    }

    public Optional<Subject> getSubject(String id) {
        return Optional.ofNullable(subjects.get(id));
    }

    public void saveAgent(Agent agent) {
        agents.put(agent.getId(), agent);
    }

    public Optional<Agent> getAgent(String id) {
        return Optional.ofNullable(agents.get(id));
    }

    public void saveEvent(Event event) {
        events.put(event.getId(), event);
    }

    public Optional<Event> getEvent(String id) {
        return Optional.ofNullable(events.get(id));
    }

    public void saveLocation(Location loc) {
        locations.put(loc.getId(), loc);
    }

    public Optional<Location> getLocation(String id) {
        return Optional.ofNullable(locations.get(id));
    }

    public void saveContainer(Container container) {
        containers.put(container.getId(), container);
    }

    public Optional<Container> getContainer(String id) {
        return Optional.ofNullable(containers.get(id));
    }

    public List<ArchivalRecord> search(User user, String repoId, String query) {
        checkPermission(user, repoId, Permission.VIEW_RECORD);
        String q = query.toLowerCase();
        List<ArchivalRecord> results = new ArrayList<>();

        for (Resource res : resources.values()) {
            if (res.getRepositoryId().equals(repoId)) {
                if (res.getTitle().toLowerCase().contains(q) || res.getResourceIdentifier().toLowerCase().contains(q)) {
                    results.add(res);
                }
            }
        }
        for (Accession acc : accessions.values()) {
            if (acc.getRepositoryId().equals(repoId)) {
                if (acc.getTitle().toLowerCase().contains(q) || acc.getAccessionNumber().toLowerCase().contains(q)) {
                    results.add(acc);
                }
            }
        }
        for (DigitalObject dobj : digitalObjects.values()) {
            if (dobj.getRepositoryId().equals(repoId)) {
                if (dobj.getTitle().toLowerCase().contains(q) || dobj.getDigitalObjectId().toLowerCase().contains(q)) {
                    results.add(dobj);
                }
            }
        }
        return results;
    }

    private void checkPermission(User user, String repoId, Permission... permissions) {
        if (user.isSystemAdmin()) {
            return;
        }
        var userPerms = user.getPermissions(repoId);
        for (Permission p : permissions) {
            if (userPerms.contains(p)) {
                return;
            }
        }
        throw new SecurityException("User " + user.getUsername() + " does not have required permissions in repository " + repoId);
    }
}
