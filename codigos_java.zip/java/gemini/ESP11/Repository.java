import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Repository {
    private final String id;
    private String repoCode;
    private String name;
    private final Map<String, String> additionalProperties = new HashMap<>();

    public Repository(String id, String repoCode, String name) {
        this.id = id;
        this.repoCode = repoCode;
        this.name = name;
    }

    public String getId() { return id; }
    public String getRepoCode() { return repoCode; }
    public void setRepoCode(String repoCode) { this.repoCode = repoCode; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public void setAdditionalProperty(String key, String value) {
        additionalProperties.put(key, value);
    }

    public String getAdditionalProperty(String key) {
        return additionalProperties.get(key);
    }

    public Map<String, String> getAdditionalProperties() {
        return Collections.unmodifiableMap(additionalProperties);
    }
}
