public enum AgentType {
    PERSON,
    CORPORATE_ENTITY,
    FAMILY
}
