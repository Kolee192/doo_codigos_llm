import java.util.ArrayList;
import java.util.List;

public class DigitalObject extends ArchivalRecord {
    private String digitalObjectId;
    private String uri;
    private final List<DigitalObject> children = new ArrayList<>();

    public DigitalObject(String id, String repositoryId, String title, String digitalObjectId, String uri) {
        super(id, repositoryId, title);
        this.digitalObjectId = digitalObjectId;
        this.uri = uri;
    }

    public String getDigitalObjectId() { return digitalObjectId; }
    public void setDigitalObjectId(String digitalObjectId) { this.digitalObjectId = digitalObjectId; }
    public String getUri() { return uri; }
    public void setUri(String uri) { this.uri = uri; }
    public List<DigitalObject> getChildren() { return children; }
    public void addChild(DigitalObject child) { children.add(child); }
}
