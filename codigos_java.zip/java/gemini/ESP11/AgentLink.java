public class AgentLink {
    private final String agentId;
    private final AgentRole role;

    public AgentLink(String agentId, AgentRole role) {
        this.agentId = agentId;
        this.role = role;
    }

    public String getAgentId() { return agentId; }
    public AgentRole getRole() { return role; }
}
