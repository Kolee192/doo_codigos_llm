public class Subject {
    private final String id;
    private final String repositoryId;
    private String heading;
    private String standardIdentifier;
    private String source;

    public Subject(String id, String repositoryId, String heading, String standardIdentifier, String source) {
        this.id = id;
        this.repositoryId = repositoryId;
        this.heading = heading;
        this.standardIdentifier = standardIdentifier;
        this.source = source;
    }

    public String getId() { return id; }
    public String getRepositoryId() { return repositoryId; }
    public String getHeading() { return heading; }
    public void setHeading(String heading) { this.heading = heading; }
    public String getStandardIdentifier() { return standardIdentifier; }
    public void setStandardIdentifier(String standardIdentifier) { this.standardIdentifier = standardIdentifier; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
}
