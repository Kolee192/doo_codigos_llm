import java.util.HashMap;
import java.util.Map;

public class LdapDirectory {
    private final Map<String, String> ldapCredentials = new HashMap<>();

    public void registerLdapUser(String username, String password) {
        ldapCredentials.put(username, password);
    }

    public boolean authenticate(String username, String password) {
        return password != null && password.equals(ldapCredentials.get(username));
    }
}
