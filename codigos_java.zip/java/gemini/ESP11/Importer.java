public interface Importer {
    ImportResult parse(String content, String repositoryId);
}
