public class LevelOfDescription {
    private final String level;
    private final String otherLevel;

    public LevelOfDescription(String level, String otherLevel) {
        this.level = level;
        this.otherLevel = otherLevel;
    }

    public static LevelOfDescription of(String level) {
        return new LevelOfDescription(level, null);
    }

    public static LevelOfDescription ofOther(String otherLevel) {
        return new LevelOfDescription("other", otherLevel);
    }

    public String getLevel() {
        return level;
    }

    public String getOtherLevel() {
        return otherLevel;
    }

    public String getDisplayLevel() {
        if ("other".equalsIgnoreCase(level) && otherLevel != null && !otherLevel.isBlank()) {
            return "Other: " + otherLevel;
        }
        return level;
    }

    @Override
    public String toString() {
        return getDisplayLevel();
    }
}
