import java.util.List;

public class EadExporter {

    public String export(Resource resource) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        sb.append("<ead>\n");
        sb.append("  <eadheader>\n");
        sb.append("    <eadid>").append(resource.getResourceIdentifier()).append("</eadid>\n");
        sb.append("    <filedesc>\n");
        sb.append("      <titlestmt>\n");
        sb.append("        <titleproper>").append(resource.getTitle()).append("</titleproper>\n");
        if (resource.getFindingAidData().getFindingAidAuthor() != null) {
            sb.append("        <author>").append(resource.getFindingAidData().getFindingAidAuthor()).append("</author>\n");
        }
        sb.append("      </titlestmt>\n");
        sb.append("    </filedesc>\n");
        sb.append("  </eadheader>\n");
        sb.append("  <archdesc level=\"").append(resource.getLevel().getLevel()).append("\">\n");
        sb.append("    <did>\n");
        sb.append("      <unittitle>").append(resource.getTitle()).append("</unittitle>\n");
        sb.append("      <unitid>").append(resource.getResourceIdentifier()).append("</unitid>\n");
        for (DateSubrecord d : resource.getDates()) {
            sb.append("      <unitdate>").append(d.getExpression()).append("</unitdate>\n");
        }
        for (ExtentSubrecord e : resource.getExtents()) {
            sb.append("      <extent>").append(e.getNumber()).append(" ").append(e.getExtentType()).append("</extent>\n");
        }
        sb.append("    </did>\n");

        for (Note note : resource.getNotes()) {
            sb.append("    <note type=\"").append(note.getType()).append("\">\n");
            sb.append("      <p>").append(note.getContent()).append("</p>\n");
            sb.append("    </note>\n");
        }

        if (!resource.getChildren().isEmpty()) {
            sb.append("    <dsc>\n");
            for (ResourceComponent rc : resource.getChildren()) {
                exportComponent(rc, sb, 6);
            }
            sb.append("    </dsc>\n");
        }

        sb.append("  </archdesc>\n");
        sb.append("</ead>\n");
        return sb.toString();
    }

    private void exportComponent(ResourceComponent comp, StringBuilder sb, int indentSpaces) {
        String indent = " ".repeat(indentSpaces);
        sb.append(indent).append("<c level=\"").append(comp.getLevel().getLevel()).append("\">\n");
        sb.append(indent).append("  <did>\n");
        sb.append(indent).append("    <unittitle>").append(comp.getTitle()).append("</unittitle>\n");
        if (comp.getComponentId() != null) {
            sb.append(indent).append("    <unitid>").append(comp.getComponentId()).append("</unitid>\n");
        }
        sb.append(indent).append("  </did>\n");
        for (ResourceComponent child : comp.getChildren()) {
            exportComponent(child, sb, indentSpaces + 2);
        }
        sb.append(indent).append("</c>\n");
    }
}
