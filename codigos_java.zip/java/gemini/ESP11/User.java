import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class User {
    private final String username;
    private String passwordHash;
    private String fullName;
    private String email;
    private boolean isSystemAdmin;
    private final Map<String, Role> repositoryRoles = new HashMap<>();

    public User(String username, String password, String fullName, String email, boolean isSystemAdmin) {
        this.username = username;
        this.passwordHash = hashPassword(password);
        this.fullName = fullName;
        this.email = email;
        this.isSystemAdmin = isSystemAdmin;
    }

    public static String hashPassword(String password) {
        return Integer.toHexString(password.hashCode());
    }

    public boolean verifyPassword(String password) {
        return passwordHash.equals(hashPassword(password));
    }

    public void setPassword(String newPassword) {
        this.passwordHash = hashPassword(newPassword);
    }

    public String getUsername() {
        return username;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isSystemAdmin() {
        return isSystemAdmin;
    }

    public void setSystemAdmin(boolean systemAdmin) {
        isSystemAdmin = systemAdmin;
    }

    public void assignRole(String repositoryId, Role role) {
        repositoryRoles.put(repositoryId, role);
    }

    public void removeRole(String repositoryId) {
        repositoryRoles.remove(repositoryId);
    }

    public Role getRoleForRepository(String repositoryId) {
        if (isSystemAdmin) {
            return Role.SYSTEM_ADMIN;
        }
        return repositoryRoles.get(repositoryId);
    }

    public Map<String, Role> getRepositoryRoles() {
        return Collections.unmodifiableMap(repositoryRoles);
    }

    public Set<Permission> getPermissions(String repositoryId) {
        Set<Permission> permissions = new HashSet<>();
        if (isSystemAdmin) {
            Collections.addAll(permissions, Permission.values());
            return permissions;
        }

        Role role = repositoryRoles.get(repositoryId);
        if (role == null) {
            return permissions;
        }

        switch (role) {
            case REPOSITORY_MANAGER -> {
                permissions.add(Permission.VIEW_RECORD);
                permissions.add(Permission.CREATE_BASIC_RECORD);
                permissions.add(Permission.CREATE_ADVANCED_RECORD);
                permissions.add(Permission.EDIT_RECORD);
                permissions.add(Permission.DELETE_RECORD);
                permissions.add(Permission.MANAGE_REPOSITORY);
            }
            case ADVANCED_DATA_ENTRY -> {
                permissions.add(Permission.VIEW_RECORD);
                permissions.add(Permission.CREATE_BASIC_RECORD);
                permissions.add(Permission.CREATE_ADVANCED_RECORD);
                permissions.add(Permission.EDIT_RECORD);
            }
            case BASIC_DATA_ENTRY -> {
                permissions.add(Permission.VIEW_RECORD);
                permissions.add(Permission.CREATE_BASIC_RECORD);
                permissions.add(Permission.EDIT_RECORD);
            }
            case READ_ONLY -> {
                permissions.add(Permission.VIEW_RECORD);
            }
            default -> {}
        }
        return permissions;
    }
}
