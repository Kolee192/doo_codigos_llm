import java.util.ArrayList;
import java.util.List;

public class Resource extends ArchivalRecord {
    private String resourceIdentifier;
    private LevelOfDescription level;
    private FindingAidData findingAidData = new FindingAidData();
    private final List<ResourceComponent> children = new ArrayList<>();
    private final List<Instance> instances = new ArrayList<>();

    public Resource(String id, String repositoryId, String title, String resourceIdentifier, LevelOfDescription level) {
        super(id, repositoryId, title);
        this.resourceIdentifier = resourceIdentifier;
        this.level = level;
    }

    public String getResourceIdentifier() { return resourceIdentifier; }
    public void setResourceIdentifier(String resourceIdentifier) { this.resourceIdentifier = resourceIdentifier; }
    public LevelOfDescription getLevel() { return level; }
    public void setLevel(LevelOfDescription level) { this.level = level; }
    public FindingAidData getFindingAidData() { return findingAidData; }
    public void setFindingAidData(FindingAidData findingAidData) { this.findingAidData = findingAidData; }

    public List<ResourceComponent> getChildren() { return children; }
    public void addChild(ResourceComponent child) {
        children.add(child);
        child.setParent(null);
    }

    public List<Instance> getInstances() { return instances; }
    public void addInstance(Instance instance) { instances.add(instance); }

    public String viewFindingAid() {
        StringBuilder sb = new StringBuilder();
        sb.append("====================================================\n");
        sb.append("FINDING AID: ").append(findingAidData.getFindingAidTitle() != null ? findingAidData.getFindingAidTitle() : getTitle()).append("\n");
        sb.append("Identifier: ").append(resourceIdentifier).append("\n");
        sb.append("Author: ").append(findingAidData.getFindingAidAuthor()).append("\n");
        sb.append("Date: ").append(findingAidData.getFindingAidDate()).append("\n");
        sb.append("Language: ").append(findingAidData.getFindingAidLanguage()).append("\n");
        sb.append("Level: ").append(level).append("\n");
        sb.append("Administrative Summary: ").append(findingAidData.getAdministrativeSummary()).append("\n");
        sb.append("----------------------------------------------------\n");
        sb.append(renderOrderedSections());
        sb.append("----------------------------------------------------\n");
        sb.append("COLLECTION STRUCTURE:\n");
        renderHierarchy(children, sb, 1);
        sb.append("====================================================\n");
        return sb.toString();
    }

    private void renderHierarchy(List<ResourceComponent> components, StringBuilder sb, int depth) {
        String indent = "  ".repeat(depth);
        for (ResourceComponent rc : components) {
            sb.append(indent)
              .append("- [").append(rc.getComponentId() != null ? rc.getComponentId() : "no-id")
              .append("] ")
              .append(rc.getTitle())
              .append(" (").append(rc.getLevel()).append(")\n");
            renderHierarchy(rc.getChildren(), sb, depth + 1);
        }
    }
}
