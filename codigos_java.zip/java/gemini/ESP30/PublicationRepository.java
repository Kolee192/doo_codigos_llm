import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class PublicationRepository {
    private final Map<String, Publication> publications = new ConcurrentHashMap<>();

    public void save(Publication publication) {
        if (publication != null && publication.getId() != null) {
            publications.put(publication.getId(), publication);
        }
    }

    public Optional<Publication> findById(String id) {
        if (id == null) return Optional.empty();
        return Optional.ofNullable(publications.get(id));
    }

    public List<Publication> findAll() {
        return new ArrayList<>(publications.values());
    }

    public boolean delete(String id) {
        if (id == null) return false;
        return publications.remove(id) != null;
    }
}
