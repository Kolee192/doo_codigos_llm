public enum DocumentFormat {
    PDF,
    PS,
    ODT;

    public static DocumentFormat fromFileName(String filename) {
        if (filename == null || !filename.contains(".")) {
            throw new IllegalArgumentException("Invalid file name: " + filename);
        }
        String ext = filename.substring(filename.lastIndexOf('.') + 1).toUpperCase();
        try {
            return DocumentFormat.valueOf(ext);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Unsupported document format: " + ext + ". Supported formats: PDF, PS, ODT");
        }
    }
}
