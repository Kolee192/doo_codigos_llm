public enum UserRole {
    MEMBER,
    PUBLISHER,
    MODERATOR,
    ADMINISTRATOR
}
