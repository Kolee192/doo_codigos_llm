import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class GroupRepository {
    private final Map<String, Group> groups = new ConcurrentHashMap<>();

    public boolean exists(String groupName) {
        return groupName != null && groups.containsKey(groupName.toLowerCase());
    }

    public void save(Group group) {
        if (group != null && group.getName() != null) {
            groups.put(group.getName().toLowerCase(), group);
        }
    }

    public Optional<Group> findByName(String groupName) {
        if (groupName == null) return Optional.empty();
        return Optional.ofNullable(groups.get(groupName.toLowerCase()));
    }

    public boolean delete(String groupName) {
        if (groupName == null) return false;
        return groups.remove(groupName.toLowerCase()) != null;
    }

    public List<Group> findAll() {
        return new ArrayList<>(groups.values());
    }
}
