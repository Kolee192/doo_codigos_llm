import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

public class PublicationService {
    private final PublicationRepository publicationRepository;
    private final DocumentParser documentParser;

    public PublicationService(PublicationRepository publicationRepository, DocumentParser documentParser) {
        this.publicationRepository = publicationRepository;
        this.documentParser = documentParser;
    }

    public PagedResult<Publication> search(UserSession session, PublicationSearchCriteria criteria, int pageSize) {
        ensureCanAccessPublications(session);
        List<Publication> filtered = publicationRepository.findAll().stream()
                .filter(p -> criteria.getKeyword() == null ||
                        p.getTitle().toLowerCase().contains(criteria.getKeyword().toLowerCase()) ||
                        p.getAbstractText().toLowerCase().contains(criteria.getKeyword().toLowerCase()))
                .filter(p -> criteria.getAuthorName() == null ||
                        p.getAuthors().stream().anyMatch(a -> a.getName().toLowerCase().contains(criteria.getAuthorName().toLowerCase())))
                .filter(p -> criteria.getStartYear() == null || p.getPublicationYear() >= criteria.getStartYear())
                .filter(p -> criteria.getEndYear() == null || p.getPublicationYear() <= criteria.getEndYear())
                .filter(p -> criteria.getReferenceKeyword() == null ||
                        p.getReferences().stream().anyMatch(r -> r.getTitle().toLowerCase().contains(criteria.getReferenceKeyword().toLowerCase())))
                .collect(Collectors.toList());

        return new PagedResult<>(filtered, pageSize);
    }

    public Publication viewDetails(UserSession session, String publicationId) {
        ensureCanAccessPublications(session);
        return publicationRepository.findById(publicationId)
                .orElseThrow(() -> new IllegalArgumentException("Publication not found: " + publicationId));
    }

    public List<Publication> viewMultipleDetails(UserSession session, List<String> publicationIds) {
        ensureCanAccessPublications(session);
        List<Publication> result = new ArrayList<>();
        for (String id : publicationIds) {
            publicationRepository.findById(id).ifPresent(result::add);
        }
        return result;
    }

    public byte[] downloadPublication(UserSession session, String publicationId) {
        ensureCanAccessPublications(session);
        Publication p = viewDetails(session, publicationId);
        return p.getDocumentData();
    }

    public List<byte[]> downloadMultiplePublications(UserSession session, List<String> publicationIds) {
        ensureCanAccessPublications(session);
        List<byte[]> files = new ArrayList<>();
        for (String id : publicationIds) {
            files.add(downloadPublication(session, id));
        }
        return files;
    }

    public List<Reference> consultReferences(UserSession session, String publicationId) {
        ensureCanAccessPublications(session);
        Publication p = viewDetails(session, publicationId);
        return p.getReferences();
    }

    public List<Reference> consultReferencesForMultiple(UserSession session, List<String> publicationIds) {
        ensureCanAccessPublications(session);
        Set<Reference> references = new LinkedHashSet<>();
        for (String id : publicationIds) {
            references.addAll(consultReferences(session, id));
        }
        return new ArrayList<>(references);
    }

    public String displayFullText(UserSession session, String publicationId) {
        ensureCanAccessPublications(session);
        Publication p = viewDetails(session, publicationId);
        if (p.getFullText() == null || p.getFullText().isBlank()) {
            throw new IllegalStateException("Full text is not available in the system for this publication.");
        }
        return p.getFullText();
    }

    public Publication viewReferenceDetails(UserSession session, String publicationId, String referenceId) {
        ensureCanAccessPublications(session);
        Publication parent = viewDetails(session, publicationId);
        Reference reference = parent.getReferences().stream()
                .filter(r -> r.getId().equals(referenceId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Reference not found in publication: " + referenceId));

        if (reference.getTargetPublicationId() == null) {
            throw new IllegalArgumentException("Reference is not registered as a publication in the system.");
        }

        return publicationRepository.findById(reference.getTargetPublicationId())
                .orElseThrow(() -> new IllegalArgumentException("Referenced publication does not exist in the system."));
    }

    public String exportReferencesBib(UserSession session, String publicationId) {
        List<Reference> references = consultReferences(session, publicationId);
        return ReferenceExporter.exportToBib(references);
    }

    public String exportReferencesRis(UserSession session, String publicationId) {
        List<Reference> references = consultReferences(session, publicationId);
        return ReferenceExporter.exportToRis(references);
    }

    public Author viewAuthor(UserSession session, String publicationId, String authorName) {
        ensureCanAccessPublications(session);
        Publication p = viewDetails(session, publicationId);
        return p.getAuthors().stream()
                .filter(a -> a.getName().equalsIgnoreCase(authorName))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Author not found on publication: " + authorName));
    }

    public List<Publication> getMyPublications(UserSession session) {
        ensurePublisherOrAbove(session);
        String username = session.getCurrentUser().getUsername();
        return publicationRepository.findAll().stream()
                .filter(p -> p.getOwnerUsername() != null && p.getOwnerUsername().equalsIgnoreCase(username))
                .collect(Collectors.toList());
    }

    public void editOwnPublication(UserSession session, String publicationId, String newTitle, String newAbstract, int newYear) {
        ensurePublisherOrAbove(session);
        Publication publication = publicationRepository.findById(publicationId)
                .orElseThrow(() -> new IllegalArgumentException("Publication not found: " + publicationId));

        boolean isOwner = session.getCurrentUser().getUsername().equalsIgnoreCase(publication.getOwnerUsername());
        boolean isAdminOrMod = session.getCurrentUser().getRole() == UserRole.ADMINISTRATOR ||
                              session.getCurrentUser().getRole() == UserRole.MODERATOR;

        if (!isOwner && !isAdminOrMod) {
            throw new SecurityException("Only owner or Moderator/Admin can edit this publication.");
        }

        if (newTitle != null) publication.setTitle(newTitle);
        if (newAbstract != null) publication.setAbstractText(newAbstract);
        if (newYear > 0) publication.setPublicationYear(newYear);

        publicationRepository.save(publication);
    }

    public DocumentParser.ParsedDocument inspectDocumentForUpload(UserSession session, String filename, byte[] documentData) {
        ensurePublisherOrAbove(session);
        return documentParser.parse(filename, documentData, session.getCurrentUser().getUsername());
    }

    public Publication confirmUploadPublication(UserSession session, String filename, byte[] documentData,
                                                String title, String abstractText, int publicationYear) {
        ensurePublisherOrAbove(session);
        DocumentFormat format = DocumentFormat.fromFileName(filename);
        DocumentParser.ParsedDocument parsed = documentParser.parse(filename, documentData, session.getCurrentUser().getUsername());

        String pubId = "PUB-" + UUID.randomUUID().toString().substring(0, 8);
        String finalTitle = (title != null && !title.isBlank()) ? title : parsed.getTitle();
        String finalAbstract = (abstractText != null && !abstractText.isBlank()) ? abstractText : parsed.getAbstractText();
        int finalYear = (publicationYear > 0) ? publicationYear : parsed.getPublicationYear();

        Publication publication = new Publication(
                pubId,
                finalTitle,
                parsed.getAuthors(),
                finalYear,
                finalAbstract,
                parsed.getFullText(),
                format,
                documentData,
                parsed.getReferences(),
                session.getCurrentUser().getUsername()
        );

        publicationRepository.save(publication);
        return publication;
    }

    private void ensureCanAccessPublications(UserSession session) {
        if (!session.isLoggedIn() && !session.canSearchWithoutLogin()) {
            throw new SecurityException("Access denied: Please login from the internet or connect via VUB-network.");
        }
    }

    private void ensurePublisherOrAbove(UserSession session) {
        if (!session.isLoggedIn() ||
                (session.getCurrentUser().getRole() != UserRole.PUBLISHER &&
                 session.getCurrentUser().getRole() != UserRole.MODERATOR &&
                 session.getCurrentUser().getRole() != UserRole.ADMINISTRATOR)) {
            throw new SecurityException("Access denied: Publisher, Moderator or Administrator role required.");
        }
    }
}
