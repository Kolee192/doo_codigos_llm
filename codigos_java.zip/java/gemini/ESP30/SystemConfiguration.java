import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class SystemConfiguration {
    private final Map<String, String> settings = new HashMap<>();

    public SystemConfiguration() {
        settings.put("site.name", "VUB Academic Publication Portal");
        settings.put("admin.email", "admin@vub.be");
        settings.put("max.upload.size.mb", "50");
        settings.put("pagination.default.size", "5");
        settings.put("maintenance.mode", "false");
    }

    public String get(String key) {
        return settings.get(key);
    }

    public void set(String key, String value) {
        settings.put(key, value);
    }

    public Map<String, String> getAllSettings() {
        return Collections.unmodifiableMap(settings);
    }
}
