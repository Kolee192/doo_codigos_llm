public class User {
    private String username;
    private String password;
    private String name;
    private String email;
    private String university;
    private String department;
    private UserRole role;
    private String groupName;

    public User(String username, String password, String name, String email,
                String university, String department, UserRole role, String groupName) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.university = university;
        this.department = department;
        this.role = role;
        this.groupName = groupName;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", role=" + role +
                ", group='" + groupName + '\'' +
                '}';
    }
}
