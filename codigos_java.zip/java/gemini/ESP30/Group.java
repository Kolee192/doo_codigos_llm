import java.util.HashSet;
import java.util.Set;

public class Group {
    private String name;
    private String description;
    private Set<String> memberUsernames;

    public Group(String name, String description) {
        this.name = name;
        this.description = description;
        this.memberUsernames = new HashSet<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<String> getMemberUsernames() {
        return memberUsernames;
    }

    public void addMember(String username) {
        this.memberUsernames.add(username);
    }

    public void removeMember(String username) {
        this.memberUsernames.remove(username);
    }

    public boolean isEmpty() {
        return memberUsernames.isEmpty();
    }

    @Override
    public String toString() {
        return "Group{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", membersCount=" + memberUsernames.size() +
                '}';
    }
}
