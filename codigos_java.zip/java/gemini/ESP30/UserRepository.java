import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class UserRepository {
    private final Map<String, User> users = new ConcurrentHashMap<>();

    public boolean exists(String username) {
        return username != null && users.containsKey(username.toLowerCase());
    }

    public void save(User user) {
        if (user != null && user.getUsername() != null) {
            users.put(user.getUsername().toLowerCase(), user);
        }
    }

    public Optional<User> findByUsername(String username) {
        if (username == null) return Optional.empty();
        return Optional.ofNullable(users.get(username.toLowerCase()));
    }

    public boolean delete(String username) {
        if (username == null) return false;
        return users.remove(username.toLowerCase()) != null;
    }

    public List<User> findAll() {
        return new ArrayList<>(users.values());
    }
}
