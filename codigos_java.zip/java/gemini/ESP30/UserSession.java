public class UserSession {
    private final NetworkType networkType;
    private User currentUser;

    public UserSession(NetworkType networkType) {
        this.networkType = networkType;
        this.currentUser = null;
    }

    public NetworkType getNetworkType() {
        return networkType;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public boolean isVubNetwork() {
        return networkType == NetworkType.VUB_NETWORK;
    }

    public boolean canSearchWithoutLogin() {
        return isVubNetwork();
    }

    public void logout() {
        this.currentUser = null;
    }
}
