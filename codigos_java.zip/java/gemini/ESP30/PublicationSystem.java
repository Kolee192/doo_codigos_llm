public class PublicationSystem {
    private final UserRepository userRepository;
    private final GroupRepository groupRepository;
    private final PublicationRepository publicationRepository;
    private final EmailService emailService;
    private final SystemConfiguration configuration;
    private final DocumentParser documentParser;

    private final UserService userService;
    private final GroupService groupService;
    private final ConfigurationService configurationService;
    private final PublicationService publicationService;

    public PublicationSystem() {
        this.userRepository = new UserRepository();
        this.groupRepository = new GroupRepository();
        this.publicationRepository = new PublicationRepository();
        this.emailService = new EmailService();
        this.configuration = new SystemConfiguration();
        this.documentParser = new DocumentParser();

        this.userService = new UserService(userRepository, emailService, configuration);
        this.groupService = new GroupService(groupRepository);
        this.configurationService = new ConfigurationService(configuration);
        this.publicationService = new PublicationService(publicationRepository, documentParser);

        seedInitialData();
    }

    private void seedInitialData() {
        User admin = new User("admin", "admin123", "System Administrator", "admin@vub.be", "VUB", "IT", UserRole.ADMINISTRATOR, "Administrators");
        User mod = new User("moderator", "mod123", "System Moderator", "mod@vub.be", "VUB", "CS", UserRole.MODERATOR, "Moderators");
        User pub = new User("publisher1", "pub123", "Dr. Jane Doe", "jdoe@vub.be", "VUB", "Software Languages Lab", UserRole.PUBLISHER, "Researchers");
        User member = new User("member1", "mem123", "John Student", "jstudent@vub.be", "VUB", "Computer Science", UserRole.MEMBER, "Students");

        userRepository.save(admin);
        userRepository.save(mod);
        userRepository.save(pub);
        userRepository.save(member);

        Group adminGroup = new Group("Administrators", "System administrators group");
        adminGroup.addMember("admin");
        Group modGroup = new Group("Moderators", "Moderation staff");
        modGroup.addMember("moderator");
        Group researchGroup = new Group("Researchers", "Publishing researchers");
        researchGroup.addMember("publisher1");
        Group emptyGroup = new Group("ArchivedGroup", "An empty group for testing deletion");

        groupRepository.save(adminGroup);
        groupRepository.save(modGroup);
        groupRepository.save(researchGroup);
        groupRepository.save(emptyGroup);
    }

    public UserSession createSession(NetworkType networkType) {
        return new UserSession(networkType);
    }

    public UserService getUserService() {
        return userService;
    }

    public GroupService getGroupService() {
        return groupService;
    }

    public ConfigurationService getConfigurationService() {
        return configurationService;
    }

    public PublicationService getPublicationService() {
        return publicationService;
    }

    public PublicationRepository getPublicationRepository() {
        return publicationRepository;
    }

    public EmailService getEmailService() {
        return emailService;
    }
}
