public class PublicationSearchCriteria {
    private String keyword;
    private String authorName;
    private Integer startYear;
    private Integer endYear;
    private String referenceKeyword;

    public PublicationSearchCriteria() {}

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public Integer getStartYear() {
        return startYear;
    }

    public void setStartYear(Integer startYear) {
        this.startYear = startYear;
    }

    public Integer getEndYear() {
        return endYear;
    }

    public void setEndYear(Integer endYear) {
        this.endYear = endYear;
    }

    public String getReferenceKeyword() {
        return referenceKeyword;
    }

    public void setReferenceKeyword(String referenceKeyword) {
        this.referenceKeyword = referenceKeyword;
    }
}
