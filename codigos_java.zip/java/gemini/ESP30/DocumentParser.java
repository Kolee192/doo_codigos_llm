import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class DocumentParser {

    public static class ParsedDocument {
        private String title;
        private List<Author> authors;
        private int publicationYear;
        private String abstractText;
        private String fullText;
        private List<Reference> references;

        public ParsedDocument(String title, List<Author> authors, int publicationYear,
                              String abstractText, String fullText, List<Reference> references) {
            this.title = title;
            this.authors = authors;
            this.publicationYear = publicationYear;
            this.abstractText = abstractText;
            this.fullText = fullText;
            this.references = references;
        }

        public String getTitle() { return title; }
        public List<Author> getAuthors() { return authors; }
        public int getPublicationYear() { return publicationYear; }
        public String getAbstractText() { return abstractText; }
        public String getFullText() { return fullText; }
        public List<Reference> getReferences() { return references; }
    }

    public ParsedDocument parse(String filename, byte[] documentData, String defaultAuthor) {
        DocumentFormat format = DocumentFormat.fromFileName(filename);
        String rawContent = new String(documentData, StandardCharsets.UTF_8);

        String title = filename.substring(0, filename.lastIndexOf('.')).replace("_", " ");
        String abstractText = "Abstract extracted from " + format + " file.";
        String fullText = rawContent;
        int year = 2023;

        // Try to parse structured content if available
        for (String line : rawContent.split("\n")) {
            String trimmed = line.trim();
            if (trimmed.startsWith("Title:")) {
                title = trimmed.substring("Title:".length()).trim();
            } else if (trimmed.startsWith("Abstract:")) {
                abstractText = trimmed.substring("Abstract:".length()).trim();
            } else if (trimmed.startsWith("Year:")) {
                try {
                    year = Integer.parseInt(trimmed.substring("Year:".length()).trim());
                } catch (NumberFormatException ignored) {}
            }
        }

        List<Author> authors = new ArrayList<>();
        authors.add(new Author("auth-" + defaultAuthor, defaultAuthor, "VUB Department of Computer Science", defaultAuthor + "@vub.be"));

        List<Reference> references = new ArrayList<>();
        return new ParsedDocument(title, authors, year, abstractText, fullText, references);
    }
}
