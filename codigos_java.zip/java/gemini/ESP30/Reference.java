import java.util.ArrayList;
import java.util.List;

public class Reference {
    private String id;
    private String title;
    private List<Author> authors;
    private int publicationYear;
    private String abstractText;
    private List<String> citedReferences;
    private String targetPublicationId; // null if not linked to publication in system

    public Reference(String id, String title, List<Author> authors, int publicationYear,
                     String abstractText, List<String> citedReferences, String targetPublicationId) {
        this.id = id;
        this.title = title;
        this.authors = authors != null ? new ArrayList<>(authors) : new ArrayList<>();
        this.publicationYear = publicationYear;
        this.abstractText = abstractText;
        this.citedReferences = citedReferences != null ? new ArrayList<>(citedReferences) : new ArrayList<>();
        this.targetPublicationId = targetPublicationId;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public List<Author> getAuthors() {
        return authors;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public String getAbstractText() {
        return abstractText;
    }

    public List<String> getCitedReferences() {
        return citedReferences;
    }

    public String getTargetPublicationId() {
        return targetPublicationId;
    }

    public void setTargetPublicationId(String targetPublicationId) {
        this.targetPublicationId = targetPublicationId;
    }

    @Override
    public String toString() {
        String mainAuthor = authors.isEmpty() ? "Unknown" : authors.get(0).getName();
        return "[" + id + "] " + title + " (" + publicationYear + ") by " + mainAuthor;
    }
}
