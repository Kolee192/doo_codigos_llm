import java.util.List;
import java.util.stream.Collectors;

public class GroupService {
    private final GroupRepository groupRepository;

    public GroupService(GroupRepository groupRepository) {
        this.groupRepository = groupRepository;
    }

    public Group createGroup(UserSession session, String groupName, String description, List<String> initialUsers) {
        ensureAdmin(session);
        if (groupRepository.exists(groupName)) {
            throw new IllegalArgumentException("Group name already exists: " + groupName);
        }
        Group group = new Group(groupName, description);
        if (initialUsers != null) {
            initialUsers.forEach(group::addMember);
        }
        groupRepository.save(group);
        return group;
    }

    public List<Group> searchGroups(UserSession session, String nameFilter) {
        ensureAdmin(session);
        return groupRepository.findAll().stream()
                .filter(g -> nameFilter == null || g.getName().toLowerCase().contains(nameFilter.toLowerCase()))
                .collect(Collectors.toList());
    }

    public void deleteGroup(UserSession session, String groupName) {
        ensureAdmin(session);
        Group group = groupRepository.findByName(groupName)
                .orElseThrow(() -> new IllegalArgumentException("Group does not exist: " + groupName));
        if (!group.isEmpty()) {
            throw new IllegalStateException("Group is not empty: cannot delete group with existing members.");
        }
        groupRepository.delete(groupName);
    }

    public void editGroupSettings(UserSession session, String groupName, String newDescription) {
        ensureAdmin(session);
        Group group = groupRepository.findByName(groupName)
                .orElseThrow(() -> new IllegalArgumentException("Group does not exist: " + groupName));
        if (newDescription != null) {
            group.setDescription(newDescription);
        }
        groupRepository.save(group);
    }

    private void ensureAdmin(UserSession session) {
        if (!session.isLoggedIn() || session.getCurrentUser().getRole() != UserRole.ADMINISTRATOR) {
            throw new SecurityException("Access denied: Administrator privileges required.");
        }
    }
}
