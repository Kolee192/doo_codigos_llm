public enum NetworkType {
    INTERNET,
    VUB_NETWORK
}
