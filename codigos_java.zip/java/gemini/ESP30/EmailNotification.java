import java.time.LocalDateTime;

public class EmailNotification {
    private String recipient;
    private String subject;
    private String message;
    private LocalDateTime timestamp;

    public EmailNotification(String recipient, String subject, String message) {
        this.recipient = recipient;
        this.subject = subject;
        this.message = message;
        this.timestamp = LocalDateTime.now();
    }

    public String getRecipient() {
        return recipient;
    }

    public String getSubject() {
        return subject;
    }

    public String getMessage() {
        return message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "[Email to: " + recipient + " | Subject: " + subject + "] " + message;
    }
}
