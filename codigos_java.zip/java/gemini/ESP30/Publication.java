import java.util.ArrayList;
import java.util.List;

public class Publication {
    private String id;
    private String title;
    private List<Author> authors;
    private int publicationYear;
    private String abstractText;
    private String fullText;
    private DocumentFormat format;
    private byte[] documentData;
    private List<Reference> references;
    private String ownerUsername;

    public Publication(String id, String title, List<Author> authors, int publicationYear,
                       String abstractText, String fullText, DocumentFormat format,
                       byte[] documentData, List<Reference> references, String ownerUsername) {
        this.id = id;
        this.title = title;
        this.authors = authors != null ? new ArrayList<>(authors) : new ArrayList<>();
        this.publicationYear = publicationYear;
        this.abstractText = abstractText;
        this.fullText = fullText;
        this.format = format;
        this.documentData = documentData != null ? documentData.clone() : new byte[0];
        this.references = references != null ? new ArrayList<>(references) : new ArrayList<>();
        this.ownerUsername = ownerUsername;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<Author> getAuthors() {
        return authors;
    }

    public void setAuthors(List<Author> authors) {
        this.authors = authors != null ? new ArrayList<>(authors) : new ArrayList<>();
    }

    public Author getMainAuthor() {
        return authors.isEmpty() ? null : authors.get(0);
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public String getAbstractText() {
        return abstractText;
    }

    public void setAbstractText(String abstractText) {
        this.abstractText = abstractText;
    }

    public String getFullText() {
        return fullText;
    }

    public void setFullText(String fullText) {
        this.fullText = fullText;
    }

    public DocumentFormat getFormat() {
        return format;
    }

    public void setFormat(DocumentFormat format) {
        this.format = format;
    }

    public byte[] getDocumentData() {
        return documentData != null ? documentData.clone() : new byte[0];
    }

    public void setDocumentData(byte[] documentData) {
        this.documentData = documentData != null ? documentData.clone() : new byte[0];
    }

    public List<Reference> getReferences() {
        return references;
    }

    public void setReferences(List<Reference> references) {
        this.references = references != null ? new ArrayList<>(references) : new ArrayList<>();
    }

    public String getOwnerUsername() {
        return ownerUsername;
    }

    public void setOwnerUsername(String ownerUsername) {
        this.ownerUsername = ownerUsername;
    }

    @Override
    public String toString() {
        String authorName = getMainAuthor() != null ? getMainAuthor().getName() : "Unknown";
        return "[" + id + "] \"" + title + "\" by " + authorName + " (" + publicationYear + ")";
    }
}
