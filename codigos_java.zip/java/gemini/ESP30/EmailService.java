import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmailService {
    private final List<EmailNotification> sentEmails = new ArrayList<>();

    public void sendEmail(String recipient, String subject, String body) {
        EmailNotification notification = new EmailNotification(recipient, subject, body);
        sentEmails.add(notification);
    }

    public List<EmailNotification> getSentEmails() {
        return Collections.unmodifiableList(sentEmails);
    }

    public EmailNotification getLastSentEmail() {
        if (sentEmails.isEmpty()) {
            return null;
        }
        return sentEmails.get(sentEmails.size() - 1);
    }
}
