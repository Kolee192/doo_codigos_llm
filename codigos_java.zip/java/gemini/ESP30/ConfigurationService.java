import java.util.Map;

public class ConfigurationService {
    private final SystemConfiguration configuration;

    public ConfigurationService(SystemConfiguration configuration) {
        this.configuration = configuration;
    }

    public Map<String, String> getConfiguration(UserSession session) {
        ensureAdmin(session);
        return configuration.getAllSettings();
    }

    public void updateConfiguration(UserSession session, String key, String value) {
        ensureAdmin(session);
        configuration.set(key, value);
    }

    private void ensureAdmin(UserSession session) {
        if (!session.isLoggedIn() || session.getCurrentUser().getRole() != UserRole.ADMINISTRATOR) {
            throw new SecurityException("Access denied: Administrator privileges required.");
        }
    }
}
