import java.util.Collections;
import java.util.List;

public class PagedResult<T> {
    private final List<T> allItems;
    private final int pageSize;
    private int currentPage;

    public PagedResult(List<T> allItems, int pageSize) {
        this.allItems = allItems != null ? allItems : Collections.emptyList();
        this.pageSize = Math.max(pageSize, 1);
        this.currentPage = 0;
    }

    public int getTotalPages() {
        if (allItems.isEmpty()) {
            return 1;
        }
        return (int) Math.ceil((double) allItems.size() / pageSize);
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public boolean hasNextPage() {
        return currentPage < getTotalPages() - 1;
    }

    public boolean hasPreviousPage() {
        return currentPage > 0;
    }

    public void nextPage() {
        if (hasNextPage()) {
            currentPage++;
        }
    }

    public void previousPage() {
        if (hasPreviousPage()) {
            currentPage--;
        }
    }

    public List<T> getCurrentPageItems() {
        if (allItems.isEmpty()) {
            return Collections.emptyList();
        }
        int fromIndex = currentPage * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, allItems.size());
        if (fromIndex >= allItems.size()) {
            return Collections.emptyList();
        }
        return allItems.subList(fromIndex, toIndex);
    }

    public List<T> getAllItems() {
        return Collections.unmodifiableList(allItems);
    }

    public int getTotalResults() {
        return allItems.size();
    }
}
