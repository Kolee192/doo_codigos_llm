import java.util.List;

public class ReferenceExporter {

    public static String exportToBib(List<Reference> references) {
        StringBuilder sb = new StringBuilder();
        for (Reference ref : references) {
            String authorStr = ref.getAuthors().isEmpty() ? "Unknown" : ref.getAuthors().get(0).getName();
            String citeKey = (authorStr.replaceAll("\\s+", "") + ref.getPublicationYear()).toLowerCase();
            sb.append("@article{").append(citeKey).append(",\n")
              .append("  title = {").append(ref.getTitle()).append("},\n")
              .append("  author = {").append(authorStr).append("},\n")
              .append("  year = {").append(ref.getPublicationYear()).append("},\n")
              .append("  abstract = {").append(ref.getAbstractText()).append("}\n")
              .append("}\n\n");
        }
        return sb.toString();
    }

    public static String exportToRis(List<Reference> references) {
        StringBuilder sb = new StringBuilder();
        for (Reference ref : references) {
            sb.append("TY  - JOUR\n");
            sb.append("TI  - ").append(ref.getTitle()).append("\n");
            for (Author a : ref.getAuthors()) {
                sb.append("AU  - ").append(a.getName()).append("\n");
            }
            sb.append("PY  - ").append(ref.getPublicationYear()).append("\n");
            sb.append("AB  - ").append(ref.getAbstractText()).append("\n");
            sb.append("ER  - \n\n");
        }
        return sb.toString();
    }
}
