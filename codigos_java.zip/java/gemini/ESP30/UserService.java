import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class UserService {
    private final UserRepository userRepository;
    private final EmailService emailService;
    private final SystemConfiguration systemConfiguration;

    public UserService(UserRepository userRepository, EmailService emailService, SystemConfiguration systemConfiguration) {
        this.userRepository = userRepository;
        this.emailService = emailService;
        this.systemConfiguration = systemConfiguration;
    }

    public User login(String username, String password, UserSession session) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Invalid username or password."));
        if (!user.getPassword().equals(password)) {
            throw new IllegalArgumentException("Invalid username or password.");
        }
        session.setCurrentUser(user);
        return user;
    }

    public void register(String username, String password, String name, String email,
                         String university, String department) {
        if (userRepository.exists(username)) {
            throw new IllegalArgumentException("Username already exists in the system: " + username);
        }
        User newUser = new User(username, password, name, email, university, department, UserRole.MEMBER, "Default");
        userRepository.save(newUser);

        String adminEmail = systemConfiguration.get("admin.email");
        emailService.sendEmail(
                adminEmail,
                "New User Registration Request",
                "New user registered: " + username + " (" + name + ", " + email + ", " + university + ", " + department + ")"
        );
    }

    public void requestPasswordChange(String username, String newPassword) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("No valid username found on the system: " + username));
        user.setPassword(newPassword);
        userRepository.save(user);

        String adminEmail = systemConfiguration.get("admin.email");
        emailService.sendEmail(
                adminEmail,
                "Password Change Notification",
                "User " + username + " has requested and updated their password."
        );
    }

    public void editPersonalData(UserSession session, String newPassword, String university, String department, String name) {
        if (!session.isLoggedIn()) {
            throw new IllegalStateException("Must be logged in to edit personal data.");
        }
        User current = session.getCurrentUser();
        if (newPassword != null && !newPassword.isBlank()) {
            current.setPassword(newPassword);
        }
        if (university != null && !university.isBlank()) {
            current.setUniversity(university);
        }
        if (department != null && !department.isBlank()) {
            current.setDepartment(department);
        }
        if (name != null && !name.isBlank()) {
            current.setName(name);
        }
        userRepository.save(current);
    }

    public List<User> searchUsers(UserSession session, UserSearchCriteria criteria) {
        ensureModeratorOrAdmin(session);
        return userRepository.findAll().stream()
                .filter(u -> criteria.getUsername() == null || u.getUsername().toLowerCase().contains(criteria.getUsername().toLowerCase()))
                .filter(u -> criteria.getName() == null || u.getName().toLowerCase().contains(criteria.getName().toLowerCase()))
                .filter(u -> criteria.getEmail() == null || u.getEmail().toLowerCase().contains(criteria.getEmail().toLowerCase()))
                .filter(u -> criteria.getRole() == null || u.getRole() == criteria.getRole())
                .collect(Collectors.toList());
    }

    public void editUserSettings(UserSession session, String username, UserRole newRole, String newGroupName, String newEmail) {
        ensureModeratorOrAdmin(session);
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + username));
        if (newRole != null) {
            user.setRole(newRole);
        }
        if (newGroupName != null) {
            user.setGroupName(newGroupName);
        }
        if (newEmail != null) {
            user.setEmail(newEmail);
        }
        userRepository.save(user);
    }

    public User createUser(UserSession session, String username, String password, String email, String groupName, UserRole role) {
        ensureAdmin(session);
        if (userRepository.exists(username)) {
            throw new IllegalArgumentException("Username already exists: " + username);
        }
        User newUser = new User(username, password, username, email, "VUB", "Computer Science", role, groupName);
        userRepository.save(newUser);
        return newUser;
    }

    public void deleteUser(UserSession session, String username) {
        ensureAdmin(session);
        if (!userRepository.exists(username)) {
            throw new IllegalArgumentException("Username does not exist: " + username);
        }
        userRepository.delete(username);
    }

    private void ensureModeratorOrAdmin(UserSession session) {
        if (!session.isLoggedIn() ||
                (session.getCurrentUser().getRole() != UserRole.MODERATOR &&
                 session.getCurrentUser().getRole() != UserRole.ADMINISTRATOR)) {
            throw new SecurityException("Access denied: Moderator or Administrator privileges required.");
        }
    }

    private void ensureAdmin(UserSession session) {
        if (!session.isLoggedIn() || session.getCurrentUser().getRole() != UserRole.ADMINISTRATOR) {
            throw new SecurityException("Access denied: Administrator privileges required.");
        }
    }
}
