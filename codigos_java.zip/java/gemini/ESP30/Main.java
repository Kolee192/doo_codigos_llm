import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Starting VUB Academic Publication Portal Demo ===\n");
        PublicationSystem system = new PublicationSystem();

        // 3.2.1 Log in from Internet
        System.out.println("-- 3.2.1 & 3.2.4: Internet access and login/logout --");
        UserSession internetSession = system.createSession(NetworkType.INTERNET);
        try {
            // Cannot search before login from Internet
            system.getPublicationService().search(internetSession, new PublicationSearchCriteria(), 5);
        } catch (SecurityException e) {
            System.out.println("Expected rejection: " + e.getMessage());
        }
        User publisherUser = system.getUserService().login("publisher1", "pub123", internetSession);
        System.out.println("Logged in user: " + publisherUser.getName() + " [Role: " + publisherUser.getRole() + "]");
        internetSession.logout();
        System.out.println("Logged off successfully. Logged in: " + internetSession.isLoggedIn());

        // 3.2.2 Log in via VUB-Network (can search immediately without logging in)
        System.out.println("\n-- 3.2.2: Access via VUB-network --");
        UserSession vubSession = system.createSession(NetworkType.VUB_NETWORK);
        PagedResult<Publication> preSearch = system.getPublicationService().search(vubSession, new PublicationSearchCriteria(), 5);
        System.out.println("Can search immediately without login on VUB-network. Initial publications count: " + preSearch.getTotalResults());

        // 3.2.3 Register for an account
        System.out.println("\n-- 3.2.3: Register new user --");
        system.getUserService().register("alice_smith", "pass123", "Alice Smith", "alice@vub.be", "VUB", "Engineering");
        System.out.println("Admin notified email count: " + system.getEmailService().getSentEmails().size());
        System.out.println("Last email: " + system.getEmailService().getLastSentEmail());

        // 3.2.5 Change password
        System.out.println("\n-- 3.2.5: Change forgotten password --");
        system.getUserService().requestPasswordChange("alice_smith", "newpass456");
        System.out.println("Password change request email: " + system.getEmailService().getLastSentEmail());

        // Login as publisher to upload publications (3.2.22)
        vubSession.setCurrentUser(publisherUser);
        System.out.println("\n-- 3.2.22: Upload publication (PDF/PS/ODT) --");
        String sampleDocument = "Title: Actor Systems in Distributed Computing\n" +
                               "Abstract: A comprehensive study on actor paradigms.\n" +
                               "Year: 2022\n" +
                               "Body: Actors provide an elegant foundation for concurrent systems.";
        byte[] docBytes = sampleDocument.getBytes(StandardCharsets.UTF_8);

        // Preview / inspection step
        DocumentParser.ParsedDocument preview = system.getPublicationService().inspectDocumentForUpload(vubSession, "actor_systems.pdf", docBytes);
        System.out.println("Document inspected. Retrieved title: " + preview.getTitle() + ", Year: " + preview.getPublicationYear());

        // Confirm publication upload
        Publication pub1 = system.getPublicationService().confirmUploadPublication(
                vubSession,
                "actor_systems.pdf",
                docBytes,
                preview.getTitle(),
                preview.getAbstractText(),
                preview.getPublicationYear()
        );
        System.out.println("Uploaded publication: " + pub1);

        // Upload a second publication that references the first one
        String doc2Content = "Title: Microservice Orchestration\n" +
                             "Abstract: Patterns for resilient microservices.\n" +
                             "Year: 2023\n" +
                             "Body: Full text content of microservice orchestration analysis.";
        Publication pub2 = system.getPublicationService().confirmUploadPublication(
                vubSession,
                "microservices.odt",
                doc2Content.getBytes(StandardCharsets.UTF_8),
                "Microservice Orchestration",
                "Patterns for resilient microservices.",
                2023
        );

        // Add a cited reference to pub2 that targets pub1
        Reference refToPub1 = new Reference(
                "REF-001",
                pub1.getTitle(),
                pub1.getAuthors(),
                pub1.getPublicationYear(),
                pub1.getAbstractText(),
                List.of(),
                pub1.getId()
        );
        pub2.getReferences().add(refToPub1);
        system.getPublicationRepository().save(pub2);

        // 3.2.6 & 3.2.7 Search and Paginated Results
        System.out.println("\n-- 3.2.6 & 3.2.7: Search publications & view results pagination --");
        PublicationSearchCriteria criteria = new PublicationSearchCriteria();
        criteria.setKeyword("Systems");
        PagedResult<Publication> searchResults = system.getPublicationService().search(vubSession, criteria, 1);
        System.out.println("Search found: " + searchResults.getTotalResults() + " results, total pages: " + searchResults.getTotalPages());
        System.out.println("Page 0 items:");
        searchResults.getCurrentPageItems().forEach(p -> System.out.println(" - " + p.getTitle() + " by " + p.getMainAuthor().getName()));

        // 3.2.8 View publication details
        System.out.println("\n-- 3.2.8: View publication details --");
        Publication details = system.getPublicationService().viewDetails(vubSession, pub2.getId());
        System.out.println("Title: " + details.getTitle());
        System.out.println("Main Author: " + details.getMainAuthor());
        System.out.println("Abstract: " + details.getAbstractText());
        System.out.println("References count: " + details.getReferences().size());

        // 3.2.9 View detailed info for multiple publications
        System.out.println("\n-- 3.2.9: View multiple publication details --");
        List<Publication> multipleDetails = system.getPublicationService().viewMultipleDetails(vubSession, List.of(pub1.getId(), pub2.getId()));
        System.out.println("Retrieved details for: " + multipleDetails.size() + " publications.");

        // 3.2.10 & 3.2.11 Download single and multiple publications
        System.out.println("\n-- 3.2.10 & 3.2.11: Download single & multiple publications --");
        byte[] fileData = system.getPublicationService().downloadPublication(vubSession, pub1.getId());
        System.out.println("Downloaded " + pub1.getTitle() + ", bytes: " + fileData.length);
        List<byte[]> multipleFiles = system.getPublicationService().downloadMultiplePublications(vubSession, List.of(pub1.getId(), pub2.getId()));
        System.out.println("Downloaded " + multipleFiles.size() + " files successfully.");

        // 3.2.12 & 3.2.13 Consult references
        System.out.println("\n-- 3.2.12 & 3.2.13: Consult references single & multiple --");
        List<Reference> singleRefs = system.getPublicationService().consultReferences(vubSession, pub2.getId());
        System.out.println("References for pub2: " + singleRefs);
        List<Reference> allRefs = system.getPublicationService().consultReferencesForMultiple(vubSession, List.of(pub1.getId(), pub2.getId()));
        System.out.println("Total combined references: " + allRefs.size());

        // 3.2.14 Display full text
        System.out.println("\n-- 3.2.14: Display full text of publication --");
        String fullText = system.getPublicationService().displayFullText(vubSession, pub1.getId());
        System.out.println("Full text excerpt:\n" + fullText);

        // 3.2.15 View details of a cited reference
        System.out.println("\n-- 3.2.15: View details of a cited reference --");
        Publication targetPub = system.getPublicationService().viewReferenceDetails(vubSession, pub2.getId(), "REF-001");
        System.out.println("Referenced publication resolved: " + targetPub.getTitle() + " (" + targetPub.getPublicationYear() + ")");

        // 3.2.16 & 3.2.17 Export references in BIB and RIS format
        System.out.println("\n-- 3.2.16 & 3.2.17: Export references (BibTeX and RIS) --");
        String bibExport = system.getPublicationService().exportReferencesBib(vubSession, pub2.getId());
        System.out.println("BibTeX Export:\n" + bibExport);
        String risExport = system.getPublicationService().exportReferencesRis(vubSession, pub2.getId());
        System.out.println("RIS Export:\n" + risExport);

        // 3.2.18 View Author
        System.out.println("-- 3.2.18: View Author information --");
        Author author = system.getPublicationService().viewAuthor(vubSession, pub1.getId(), "publisher1");
        System.out.println("Author details: " + author);

        // 3.2.19 Editing personal data
        System.out.println("\n-- 3.2.19: Editing personal data --");
        system.getUserService().editPersonalData(vubSession, "newPubPassword", "VUB - Vrije Universiteit Brussel", "DINF", "Dr. Jane Doe Updated");
        System.out.println("Updated user name: " + vubSession.getCurrentUser().getName() + ", Department: " + vubSession.getCurrentUser().getDepartment());

        // 3.2.20 & 3.2.21 Access and Edit own publications
        System.out.println("\n-- 3.2.20 & 3.2.21: Access and edit own publications --");
        List<Publication> myPubs = system.getPublicationService().getMyPublications(vubSession);
        System.out.println("My publications count: " + myPubs.size());
        system.getPublicationService().editOwnPublication(vubSession, pub1.getId(), "Actor Systems in Distributed Computing (2nd Edition)", null, 2024);
        Publication updatedPub = system.getPublicationService().viewDetails(vubSession, pub1.getId());
        System.out.println("Updated publication title: " + updatedPub.getTitle() + " (" + updatedPub.getPublicationYear() + ")");

        // Switch to Admin Session for Administration requirements (3.2.23 - 3.2.31)
        UserSession adminSession = system.createSession(NetworkType.VUB_NETWORK);
        system.getUserService().login("admin", "admin123", adminSession);

        // 3.2.23 & 3.2.24 Search users and edit user settings
        System.out.println("\n-- 3.2.23 & 3.2.24: Search users and edit user settings --");
        UserSearchCriteria uCriteria = new UserSearchCriteria();
        uCriteria.setRole(UserRole.MEMBER);
        List<User> members = system.getUserService().searchUsers(adminSession, uCriteria);
        System.out.println("Found " + members.size() + " member users.");
        system.getUserService().editUserSettings(adminSession, "alice_smith", UserRole.PUBLISHER, "Researchers", "alice.smith@vub.be");
        System.out.println("Promoted alice_smith to PUBLISHER.");

        // 3.2.25 & 3.2.26 Create and Delete user
        System.out.println("\n-- 3.2.25 & 3.2.26: Create User & Delete User --");
        User createdUser = system.getUserService().createUser(adminSession, "temp_user", "temp123", "temp@vub.be", "Default", UserRole.MEMBER);
        System.out.println("Created temporary user: " + createdUser.getUsername());
        system.getUserService().deleteUser(adminSession, "temp_user");
        System.out.println("Deleted temporary user successfully.");

        // 3.2.27, 3.2.28, 3.2.29, 3.2.30 Group Management
        System.out.println("\n-- 3.2.27 - 3.2.30: Group management (Create, Search, Edit, Delete) --");
        Group createdGroup = system.getGroupService().createGroup(adminSession, "SpecialInterestGroup", "Temporary interest group", List.of());
        System.out.println("Created group: " + createdGroup.getName());
        List<Group> foundGroups = system.getGroupService().searchGroups(adminSession, "SpecialInterest");
        System.out.println("Search groups found: " + foundGroups.size() + " group(s).");
        system.getGroupService().editGroupSettings(adminSession, "SpecialInterestGroup", "Updated group description.");
        system.getGroupService().deleteGroup(adminSession, "SpecialInterestGroup");
        System.out.println("Deleted empty group successfully.");

        // 3.2.31 Edit system configuration settings
        System.out.println("\n-- 3.2.31: Edit system configuration settings --");
        System.out.println("Initial configuration: " + system.getConfigurationService().getConfiguration(adminSession));
        system.getConfigurationService().updateConfiguration(adminSession, "max.upload.size.mb", "100");
        system.getConfigurationService().updateConfiguration(adminSession, "pagination.default.size", "10");
        System.out.println("Updated max upload size: " + system.getConfigurationService().getConfiguration(adminSession).get("max.upload.size.mb") + " MB");

        System.out.println("\n=== Demo completed successfully. All requirements verified. ===");
    }
}
